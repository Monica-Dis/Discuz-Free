<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_diy/init.php';
if($_G['uid']){
    $loginurl =  $_G['siteurl'].'home.php?mod=space&uid='.$_G['uid'].'&do=profile&mycenter=1&mobile=2';
}else{
    if($_G['cache']['plugin']['xigua_login']){
        $loginurl = $_G['siteurl'].'member.php?mod=logging&action=login&mobile=2';
    }else{
        $loginurl = $_G['siteurl'].'member.php?mod=logging&action=login&mobile=2';
    }
}
define('FORUM_UCENTER', $loginurl);
define('THREAD_POSTURL',  $_G['siteurl'].'forum.php?mod=post&action=newthread&fid='.$_GET['fid'].'&mobile=2');

if($_GET['redirect']){
    dheader('Location:'.FORUM_UCENTER);
}
if($_GET['newthread']){
    dheader('Location:'.THREAD_POSTURL);
}

$diy_config = xigua_diyc::config(TRUE);

$pid = intval($_GET['pid']);
$pageinfo = C::t('#xigua_diy#xigua_diy_page')->fetch($pid);

if(empty($pageinfo)){
    if (!headers_sent()) {
        header('HTTP/1.1 404 Not Found');
        header('Status: 404 Not Found');
    }
    exit;
}
$title       = $pageinfo['title'] ? $pageinfo['title'] : $wechat['wsq_sitename'];
$keywords    = $pageinfo['keywords'];
$description = $pageinfo['description'];
$code        = html_entity_decode($pageinfo['code']);
$style       = xigua_diyc::get_style($pageinfo['style']);

$actionurl = $_G['siteurl'] . 'plugin.php?id=xigua_diy:index&diy=yes&pid=' . $pid;
$actionsaveurl = $_G['siteurl'] . 'plugin.php?id=xigua_diy:index&diy=yes&ac=save&pid=' . $pid;

$diy = FALSE;
$isdiyer = $_G['uid'] && in_array($_G['uid'], array_filter(explode(',', $pageinfo['adminuid'])));
if (($_G['adminid']> 0 || $isdiyer) && $_GET['diy'] == 'yes') {  //in diy
    $ac = $_GET['ac'];
    xigua_diyc::clearfromcache($pid);
    switch ($ac) {
        case 'new':
            if (submitcheck('type') && in_array($_GET['type'], array_keys($diy_config))) {
                $type = daddslashes($_GET['type']);
                $ret = C::t('#xigua_diy#xigua_diy_setting')->insert(array(
                    'pid'          => $pid,
                    'type'         => $type,
                    'modulename'   => $diy_config[ $type ]['modulename'],
                    'displayorder' => 999,
                    'upts'         => $_G['timestamp'],
                    'value'        => 'a:0:{}'
                ));
                if ($ret) {
                    xigua_diyc::l('add_success');
                } else {
                    xigua_diyc::l('add_failed');
                }
            }
            exit;
            break;
        case 'del':
            if (submitcheck('cid')) {
                $ret = C::t('#xigua_diy#xigua_diy_setting')->delete(intval($_GET['cid']));
                if ($ret) {
                    xigua_diyc::l('del_success');
                } else {
                    xigua_diyc::l('del_failed');
                }
            }
            exit;
            break;
        case 'order':
            if (submitcheck('cid')) {

                $ids = dintval(explode('_', trim($_GET['cid'])), TRUE);
                $idx = dintval(explode('_', trim($_GET['idx'])), TRUE);

                if (count($ids) != count($idx)) {
                    exit('0');
                }
                foreach ($ids as $k => $id) {
                    $ret = C::t('#xigua_diy#xigua_diy_setting')->update($id, array(
                        'displayorder' => $idx[ $k ]
                    ));
                }
                exit('1');
            }
            exit;
            break;
        case 'card':
            $cid = intval($_GET['cid']);
            $profile = C::t('#xigua_diy#xigua_diy_setting')->fetch($cid);
            if (empty($profile)) {
                exit('Access Denied!');
            }

            $p = xigua_diyc::run($profile);
            include xp_display('cards/' . $p['type'] . '/tpl');
            exit;
            break;
        case 'upload':
            if (submitcheck('formhash')) {
                $ret = xigua_diyc::upload($_FILES['xiguafile']);
                $ret['error'] = iconv(CHARSET, 'utf-8', $ret['error']);
                echo json_encode($ret);
            }
            exit;
            break;
        case 'save':
            if (submitcheck('row')) {
                $cid = intval($_GET['cid']);
                $row = dhtmlspecialchars($_GET['row']);

                $profile = C::t('#xigua_diy#xigua_diy_setting')->fetch($cid);
                if (empty($profile) || empty($row)) {
                    xigua_diyc::l('add_failed');
                    exit;
                }

                $ret = C::t('#xigua_diy#xigua_diy_setting')->update($cid, array(
                    'upts'  => $_G['timestamp'],
                    'value' => serialize($row)
                ), TRUE);

                if ($ret) {
                    xigua_diyc::l('save_success');
                } else {
                    xigua_diyc::l('save_failed');
                }
            }
            exit;
            break;
        default:
            $ac && exit('Access Denied!');
            break;
    }
    $module = '';
    foreach ($diy_config as $k => $v) {
        $module .= "<li><a href='javascript:;' data-type='$k' title='$v[introduce]'><img src='$v[icon]'>$v[modulename]</a></li>";
    }

    $diy = TRUE;
    define('IN_DIY', $diy);
    $title = 'DIY - ' . $title;
}else if($_GET['preview']!='previews'){
    if(!checkmobile()){
        dheader('Location:'.$_G['siteurl']);
        exit;
    }
}

$cards = array();
//$cards = xigua_diyc::readfromcache($pid);
if(!$cards){
    $cards = C::t('#xigua_diy#xigua_diy_setting')->list_all($pid);
    foreach ($cards as $id => $card) {
        $cards[ $id ] = xigua_diyc::run($card, TRUE);
    }
    xigua_diyc::writetocache($cards, $pid);
}

$link = $src = $css = $js = '';
foreach ($diy_config as $v) {
    $js  .= (strpos($js,  $v['js'])  === false) ? $v['js']  : '';
    $css .= (strpos($css, $v['css']) === false) ? $v['css'] : '';
    $src .= (strpos($src, $v['src']) === false) ? $v['src'] : '';
    $link .= (strpos($link, $v['link']) === false) ? $v['link'] : '';
}
$ispcma = !dstrpos(strtolower($_SERVER['HTTP_USER_AGENT']), array('iphone', 'android', 'phone', 'mobile', 'wap', 'netfront', 'java', 'opera mobi', 'opera mini','ucweb', 'windows ce', 'symbian', 'series', 'webos', 'sony', 'blackberry', 'dopod', 'nokia', 'samsung','palmsource', 'xda', 'pieplus', 'meizu', 'midp', 'cldc', 'motorola', 'foma', 'docomo', 'up.browser','up.link', 'blazer', 'helio', 'hosin', 'huawei', 'novarra', 'coolpad', 'webos', 'techfaith', 'palmsource','alcatel', 'amoi', 'ktouch', 'nexian', 'ericsson', 'philips', 'sagem', 'wellcom', 'bunjalloo', 'maui', 'smartphone','iemobile', 'spice', 'bird', 'zte-', 'longcos', 'pantech', 'gionee', 'portalmmm', 'jig browser', 'hiptop','benq', 'haier', '^lct', '320x320', '240x320', '176x220', 'windows phone', 'ipad'), true);
define('DIY_INWECHAT', stripos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')   !== false);

include template('xigua_diy:touch/index');