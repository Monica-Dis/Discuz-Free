<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$pluginid = 'xigua_diy';

$query = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_diy_page` (
 `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `style` varchar(20) NOT NULL,
 `title` varchar(500) NOT NULL,
 `keywords` varchar(2000) NOT NULL,
 `description` varchar(2000) NOT NULL,
 `code` varchar(5000) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 PRIMARY KEY (`pid`),
 KEY `crts` (`crts`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_diy_setting` (
 `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `type` varchar(50) NOT NULL,
 `modulename` varchar(80) NOT NULL,
 `displayorder` smallint(5) NOT NULL DEFAULT '0',
 `upts` int(10) unsigned NOT NULL,
 `value` text NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`),
 KEY `pid` (`pid`)
) ENGINE=InnoDB;
SQL;
runquery($query);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_diy/discuz_plugin_xigua_diy.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_diy/discuz_plugin_xigua_diy_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_diy/discuz_plugin_xigua_diy_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_diy/discuz_plugin_xigua_diy_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_diy/discuz_plugin_xigua_diy_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . 'source/plugin/xigua_diy/install.php');

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'adminuid\'', array('xigua_diy_page'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_diy_page` ADD `adminuid` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'icon\'', array('xigua_diy_page'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_diy_page` ADD `icon` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}