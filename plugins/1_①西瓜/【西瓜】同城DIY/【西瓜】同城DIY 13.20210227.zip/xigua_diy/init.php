<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include DISCUZ_ROOT . 'source/plugin/xigua_diy/core/cards.class.php';
include DISCUZ_ROOT . 'source/plugin/xigua_diy/core/parser.class.php';
require_once libfile('function/cache');

if(!$_G['cache']['plugin']){
    loadcache('plugin');
}

define('XG_PORTAL_PATH', dirname(__FILE__) . DIRECTORY_SEPARATOR);
define('XG_PORTAL_TPL_PATH', XG_PORTAL_PATH . 'template' . DIRECTORY_SEPARATOR);

function xp_display($template_name){
    return XG_PORTAL_TPL_PATH.$template_name.'.php';
}
function lang_diy($lang, $echo = 1)
{
    if ($echo) {
        echo lang('plugin/xigua_diy', $lang);
    } else {
        return lang('plugin/xigua_diy', $lang);
    }
}
if($_GET['ac']=='upload'){

}else{
if(!function_exists('lang_hb')){
    function lang_hb($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_hb', $lang);
        }else{
            return lang('plugin/xigua_hb', $lang);
        }
    }
}

if(!function_exists('lang_hs')) {
    function lang_hs($lang, $echo = 1){
        if ($echo) {
            echo lang('plugin/xigua_hs', $lang);
        } else {
            return lang('plugin/xigua_hs', $lang);
        }
    }
}

if(!function_exists('lang_hm')) {
    function lang_hm($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_hm', $lang);
        }else{
            return lang('plugin/xigua_hm', $lang);
        }
    }
}

if(!function_exists('hb_trans')){
    function hb_trans($count, $power = 4, $fixed = 1) {
        $count = intval($count);
        if ($count < 10000 || !$power || $power <= 0) {
            return $count;
        } else if ($power < 1) {
            $power = 1;
        } else if ($power > 5) {
            $power = 4;
        }
        $unit = array('', '', '', 'K', lang('plugin/xigua_hb', 'wan'));
        $v = $count / pow(10, $power);
        return round($v, $fixed) . $unit[$power];
    }
}
}

$hb_config = $_G['cache']['plugin']['xigua_hb'];
$SCRITPTNAME = $hb_config['scriptname'] ? $hb_config['scriptname'] : 'plugin.php';
$form_charset = $_G['cache']['plugin']['xigua_diy']['charset']=='default' ? CHARSET :$_G['cache']['plugin']['xigua_diy']['charset'];