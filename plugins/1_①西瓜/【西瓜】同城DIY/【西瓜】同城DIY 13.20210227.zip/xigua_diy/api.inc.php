<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include DISCUZ_ROOT.'source/plugin/xigua_diy/init.php';

if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}

if(!$_GET['api'] || !preg_match('/^[\w]+$/', $_GET['api'])){
    exit('missing api');
}
if(!defined('IS_ADMINID')){
    define('IS_ADMINID', 0);
}
define('HB_NOTIFY_URL', $_G['siteurl'].'source/plugin/xigua_hb/lib/notify_wx.php');
define('HB_INWECHAT', stripos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')   !== false);
define('IN_APPBYME',  strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false);
define('IN_QIANFAN',  strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false);
define('IN_MAGAPP',   strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'magapp')  !== false);
define('IN_MOCUZ', strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'mocuzapp') !== false);
define('IN_IOS', stripos($_SERVER['HTTP_USER_AGENT'], 'iPhone')!==false||stripos($_SERVER['HTTP_USER_AGENT'], 'iPad')!==false);
define('IN_PROG',stripos($_SERVER['HTTP_USER_AGENT'], 'miniProgram')!==false);

$apifile = DISCUZ_ROOT.'source/plugin/xigua_diy/template/cards/'.$_GET['api'].'/api.php';
if(is_file($apifile)){
    include $apifile;
}