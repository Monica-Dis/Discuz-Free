<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Date: 2015/6/16
 * Time: 11:42
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_x_log` (
 `log_id` int(11) NOT NULL AUTO_INCREMENT,
 `code` varchar(20) NOT NULL,
 `errmsg` varchar(500) NOT NULL,
 `content` varchar(8000) NOT NULL,
 `crts` int(11) NOT NULL,
 `openid` varchar(32) NOT NULL,
 `uid` int(11) NOT NULL,
 `template_id` varchar(80) NOT NULL,
 PRIMARY KEY (`log_id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_x` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `template_id` varchar(80) NOT NULL,
 `type` int(1) NOT NULL,
 `title` varchar(200) NOT NULL,
 `primary_industry` varchar(200) NOT NULL,
 `deputy_industry` varchar(200) NOT NULL,
 `content` varchar(2000) NOT NULL,
 `example` varchar(2000) NOT NULL,
 `split` varchar(5000) NOT NULL,
 `lastsend` int(11) unsigned NOT NULL,
 `sendtimes` int(11) unsigned NOT NULL,
 `succeedtimes` int(11) unsigned NOT NULL,
 PRIMARY KEY (`id`),
 KEY `template_id` (`template_id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_x_user` (
 `uid` int(11) NOT NULL,
 `opentype` varchar(2000) NOT NULL,
 PRIMARY KEY (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_x_fans` (
 `openid` varchar(32) NOT NULL,
 `last_send` datetime NOT NULL,
 `wechat_info` text NOT NULL,
 `subscribe_ts` int(11) NOT NULL DEFAULT '0',
 `total_times` int(11) NOT NULL,
 PRIMARY KEY (`openid`),
 KEY `subscribe_ts` (`subscribe_ts`),
 KEY `last_send` (`last_send`)
) ENGINE=InnoDB;

SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_x/discuz_plugin_xigua_x.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_x/discuz_plugin_xigua_x_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_x/discuz_plugin_xigua_x_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_x/discuz_plugin_xigua_x_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_x/discuz_plugin_xigua_x_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_x/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_x/upgrade.php');
$finish = TRUE;


