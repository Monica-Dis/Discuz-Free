<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$pluginid = 'xigua_integralmall';

$Hooks = array(
    'forumdisplay_topBar',
    'viewthread_variables',
    'profile_variables',
    'profile_authorInfo'
);

$data = array();
foreach($Hooks as $Hook) {
    $data[] = array(
        $Hook => array(
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid,
            'method' => $Hook,
            'order'  => 0,
        )
    );
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_intmall` (
 `tid` int(10) unsigned NOT NULL,
 `uid` int(10) unsigned NOT NULL,
 `aid` varchar(2000) NOT NULL,
 `author` varchar(20) NOT NULL,
 `goodkind` varchar(80) NOT NULL DEFAULT '',
 `goodname` varchar(80) NOT NULL DEFAULT '',
 `marketprice` varchar(80) NOT NULL DEFAULT '',
 `goodnum` varchar(80) NOT NULL DEFAULT '',
 `mallstart` varchar(80) NOT NULL DEFAULT '',
 `mallend` varchar(80) NOT NULL DEFAULT '',
 `malltype` varchar(80) NOT NULL DEFAULT '',
 `sellprice` varchar(80) NOT NULL DEFAULT '',
 `baseprice` varchar(80) NOT NULL DEFAULT '',
 `rangeprice` varchar(80) NOT NULL DEFAULT '',
 `rangemaxprice` varchar(80) NOT NULL DEFAULT '',
 `lastpost` varchar(20) NOT NULL DEFAULT '',
 `hot` int(11) NOT NULL DEFAULT '0',
 `give` int(11) NOT NULL DEFAULT '0',
 `lognum` int(10) unsigned NOT NULL,
 `status` tinyint(1) NOT NULL DEFAULT '0',
 `ccd` varchar(10) NOT NULL DEFAULT '0',
 `zuobi` varchar(2000) NOT NULL DEFAULT '',
 PRIMARY KEY (`tid`),
 KEY `mallend` (`mallend`),
 KEY `uid` (`uid`),
 KEY `malltype` (`malltype`),
 KEY `status` (`status`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_intmall_code` (
 `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `tid` int(10) unsigned NOT NULL,
 `code` text,
 `uid` int(8) unsigned NOT NULL,
 `hassend` tinyint(1) unsigned NOT NULL DEFAULT '0',
 `sendinfo` varchar(2000) NOT NULL,
 PRIMARY KEY (`vid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_intmall_log` (
 `lid` int(10) NOT NULL AUTO_INCREMENT,
 `tid` int(10) unsigned NOT NULL,
 `uid` int(10) NOT NULL DEFAULT '0',
 `username` varchar(20) NOT NULL,
 `dateline` int(10) NOT NULL,
 `currentprice` mediumint(8) NOT NULL,
 `status` tinyint(1) NOT NULL DEFAULT '0',
 `extra` int(10) NOT NULL DEFAULT '0',
 PRIMARY KEY (`lid`),
 KEY `tid_3` (`tid`,`uid`),
 KEY `uid` (`uid`),
 KEY `tid` (`tid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_intmall_receiver` (
 `uid` int(10) unsigned NOT NULL,
 `fields` text NOT NULL,
 PRIMARY KEY (`uid`)
) ENGINE=InnoDB;

ALTER TABLE `pre_xigua_intmall` ADD `shuxing` VARCHAR(2000) NOT NULL AFTER `zuobi`;
ALTER TABLE `pre_xigua_intmall` CHANGE `zuobi` `zuobi` VARCHAR(2000) NOT NULL DEFAULT '';
SQL;

$ar = array(
    'discuz_plugin_xigua_integralmall.xml',
    'discuz_plugin_xigua_integralmall_SC_GBK.xml',
    'discuz_plugin_xigua_integralmall_SC_UTF8.xml',
    'discuz_plugin_xigua_integralmall_TC_BIG5.xml',
    'discuz_plugin_xigua_integralmall_TC_UTF8.xml',
    'install.php',
);
foreach ($ar as $v) {
    $path = DISCUZ_ROOT . './source/plugin/xigua_integralmall/'.$v;
    @file_put_contents($path, '');
    @unlink($path);
}

runquery_silent($sql);
$finish = TRUE;


function runquery_silent($sql) {
    global $_G;
    $tablepre = $_G['config']['db'][1]['tablepre'];
    $dbcharset = $_G['config']['db'][1]['dbcharset'];

    $sql = str_replace(array(' cdb_', ' `cdb_', ' pre_', ' `pre_'), array(' {tablepre}', ' `{tablepre}', ' {tablepre}', ' `{tablepre}'), $sql);
    $sql = str_replace("\r", "\n", str_replace(array(' {tablepre}', ' `{tablepre}'), array(' '.$tablepre, ' `'.$tablepre), $sql));

    $ret = array();
    $num = 0;
    foreach(explode(";\n", trim($sql)) as $query) {
        $queries = explode("\n", trim($query));
        foreach($queries as $query) {
            $ret[$num] .= $query[0] == '#' || $query[0].$query[1] == '--' ? '' : $query;
        }
        $num++;
    }
    unset($sql);

    foreach($ret as $query) {
        $query = trim($query);
        if($query) {

            if(substr($query, 0, 12) == 'CREATE TABLE') {
                $name = preg_replace("/CREATE TABLE ([a-z0-9_]+) .*/is", "\\1", $query);
                DB::query(createtable($query, $dbcharset));

            } else {
                DB::query($query, array(), true);
            }

        }
    }
}

if(is_file(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::updateAPIHook($data);
}