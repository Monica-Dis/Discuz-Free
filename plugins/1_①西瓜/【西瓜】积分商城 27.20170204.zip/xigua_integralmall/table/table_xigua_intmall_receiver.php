<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 15/7/23
 * Time: 23:22
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class table_xigua_intmall_receiver extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_intmall_receiver';
        $this->_pk = 'uid';

        parent::__construct();
    }
}