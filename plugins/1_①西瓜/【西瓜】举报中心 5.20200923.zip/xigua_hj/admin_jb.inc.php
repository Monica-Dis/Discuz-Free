<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';

$page = max(1, intval(getgpc('page')));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;

$sta = array(
    0 => lang('plugin/xigua_hj', 'status0'),
    1 => lang('plugin/xigua_hj', 'status1'),
    2 => lang('plugin/xigua_hj', 'status2'),
);

if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hj#xigua_hj_report')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            if(isset($item['status'])){
                $old = C::t('#xigua_hj#xigua_hj_report')->fetch($index);
                if($old['status']!=$item['status']){
                    $item['upts'] = TIMESTAMP;
                    $item['douid'] = $_G['uid'];
                }
            }
            C::t('#xigua_hj#xigua_hj_report')->update($index, $item);
        }
    }

    cpmsg(lang_hb('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hj&pmod=admin_jb&page=$page", 'succeed');
}

$wherearr = array();
$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword)){
    $wherearr[] = "uid='$keyword' OR mobile='$keyword'";
}
if(isset($_GET['status'])){
    $wherearr[] = "status='".intval($_GET['status'])."'";
}

$ob = 'id DESC';

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hj&pmod=admin_jb&page=1");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="" value="'.$_GET['keyword'].'" class="txt" /> ';
foreach ($sta as $index => $item) {
    $chk = isset($_GET['status']) && $_GET['status']==$index ? 'checked':'';
    echo " <label><input type=\"radio\" name=\"status\" value=\"$index\" $chk>$item</label>";
}
echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';

showtableheader(lang('plugin/xigua_hj', 'jbgl'));
showtablerow('class="header"', array(), array(
    lang_hb('del', 0),
    lang_hb('user', 0),
    lang('plugin/xigua_hj', 'name'),
    lang_hb('mobile', 0),
    lang('plugin/xigua_hj', 'reson'),
    lang('plugin/xigua_hj', 'desc'),
    lang('plugin/xigua_hj', 'referer'),
    lang('plugin/xigua_hj', 'crts'),
    lang('plugin/xigua_hj', 'status'),
    lang('plugin/xigua_hj', 'status_u'),
));

$res = C::t('#xigua_hj#xigua_hj_report')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
$icount = C::t('#xigua_hj#xigua_hj_report')->fetch_count_by_page($wherearr);

$secids = $shids = array();
foreach ($res as $v) {
    if ($v['uid']) {
        $uids[$v['uid']] = $v['uid'];
        $uids[$v['douid']] = $v['douid'];
    }
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}

foreach ($res as $v) {
    $id = $v['id'];
    $sel = '';
    foreach ($sta as $index => $item) {
        if($v['status'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
        "[UID: {$v['uid']}]". $users[$v['uid']]['username'],
        $v['name'],
        $v['mobile'],
        $v['reson'],
        $v['description'],
        "<a target='_blank' href='{$v['referer']}'>{$v['referer']}</a>",
        $v['crts_u'],
        "<select name='r[$id][status]' >$sel</select>",
        $v['douid'] ? "[UID: {$v['douid']}]". $users[$v['douid']]['username'] : '-',
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hj&pmod=admin_jb&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', 'del', "", $multipage);
showtablefooter();
showformfooter();/*Dism_taobao-com*/
