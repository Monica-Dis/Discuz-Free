<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/common.php')){
    echo lang('plugin/xigua_hj', 'bcj');
    exit;
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
$hj_config = $_G['cache']['plugin']['xigua_hj'];

$aclist = array('index', 'report');
$aclist_login = array();

$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist)) {
    $_GET['ac'] = 'index';
}
$isself = in_array($ac, $aclist_login) || (strpos($ac, 'my')!==false && !$_G['uid']);
if ($isself && !$_G['uid']) {
    hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$navtitle = $hj_config['jbtitle'];
$desc = $hj_config['jbdesc'];
$link = $_GET['referer'] ?$_GET['referer'] : $_SERVER['HTTP_REFERER'];
$page = max(1, intval(getgpc('page')));
$lpp   = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;


function hj_post_x($url, $note, $uids = array()){
    global $_G;
    $config = $_G['cache']['plugin']['xigua_hb'];
    if(is_file(DISCUZ_ROOT.'source/plugin/xigua_x/xWechat.lib.class.php')){
        $xconfig = $_G['cache']['plugin']['xigua_x'];
        include_once DISCUZ_ROOT. './source/plugin/xigua_x/xWechat.lib.class.php';
        $client = new xWeChat($xconfig['appid'], $xconfig['appsecret']);
        $template_sys = C::t('#xigua_x#xigua_x')->get_by_type(2);  //system template

        $data_sys = unserialize($template_sys['split']);
        if($uids){
            $xconfig = $_G['cache']['plugin']['xigua_x'];
            $wechat_table = $xconfig['wechattable'];
            $openids = DB::fetch_all("SELECT openid,uid FROM %t WHERE uid IN (%n) AND openid<>''", array($wechat_table, $uids), 'uid');
            if(!$openids){
                return true;
            }
        }else{
            $openids = DB::fetch_all('SELECT * FROM ' . DB::table('xigua_x_fans') . " WHERE 1 ORDER BY rand() LIMIT 0, {$config['kuosan']} ", array(), 'openid');
            if(!$openids){
                return true;
            }
            return true;
        }

        $template_id = $template_sys['template_id'];
        foreach ($data_sys as $index => $item) {
            $item['value'] = str_replace(array(
                '{note}',
                '{time}',
                '{type}',
                '{username}',
                '{author}',
            ), array(
                $note,
                dgmdate(TIMESTAMP, 'Y-m-d H:i:s'),
                lang('plugin/xigua_x', 'system'),
                '',
                ''
            ), $item['value']);
            $data_sys[$index]['value'] = diconv($item['value'], CHARSET, 'UTF-8');
        }

        foreach ($openids as $uid => $openidinfo) {
            $openid = (is_array($openidinfo)&&$openidinfo['openid']) ? $openidinfo['openid'] : $openidinfo;

            //send
            $param = array(
                'touser'      => $openid,
                'template_id' => $template_id,
                'url'         => $url,
                'topcolor'    => '#ff0000',
                'data'        => $data_sys,
            );

            $data_sys['url'] = array('value' => $url,  );
            $insertdata = array(
                'uid'         => 0,
                'openid'      => $openid,
                'template_id' => $template_id,
                'crts'        => TIMESTAMP,
                'content'     => json_encode($data_sys),
            );
            if($result = $client->dosendTemplate($param)){
                $insertdata['code'] = 0;
                $insertdata['errmsg'] = lang('plugin/xigua_x', 'sendsuccess');
                C::t('#xigua_x#xigua_x')->incr_by_tplid($template_id, 1);
            }else{
                $error = diconv($client->error(), 'UTF-8');
                $insertdata['code'] = $client->ERROR_NO;
                $insertdata['errmsg'] = $error;
                C::t('#xigua_x#xigua_x')->incr_by_tplid($template_id, 0);
            }
            C::t('#xigua_x#xigua_x_log')->insert($insertdata);
        }
        return true;
    }
    return false;
}

switch ($ac){
    case 'index':
        $ac = 'hj_index';
        break;
    case 'report':
        if(submitcheck('form')){
            $form = $_GET['form'];
            $jbyy = array_filter(explode("\n", trim($hj_config['jbyy'])));
            $form['reson'] = $jbyy[$form['tagid']-1];

            if($form['mobile']){
                if(!preg_match($isMob, $form['mobile']) && !preg_match($isTel, $form['mobile'])){
                    hb_message(lang_hb('dianhua2',0), 'error');
                }
            }
            foreach (unserialize($hj_config['require_field']) as $index => $item) {
                if($item!='0'){
                    if(!$form[$item]){
                        hb_message(lang('plugin/xigua_hj', 'qtx').lang('plugin/xigua_hj', $item), 'error');
                    }
                }
            }
            C::t('#xigua_hj#xigua_hj_report')->insert(array(
                'reson' => $form['reson'],
                'name' => $form['name'],
                'mobile' => $form['mobile'],
                'description' => $form['desc'],
                'referer' => $form['referer'],
                'crts' => TIMESTAMP,
                'status' => 0,
                'uid' => $_G['uid'],
            ));
            $user = getuserbyuid($_G['uid']);
            global $adminids, $SCRITPTNAME, $_G;
            if($adminids){
                if(!$form['referer']){
                    $form['referer'] = $_G['siteurl'].$SCRITPTNAME.'?id=xigua_hb';
                }
                $form['referer'] = str_replace('&amp;', '&',$form['referer']);
                $font = $form['name']. lang('plugin/xigua_hj', 'ggjbl') . lang('plugin/xigua_hj', 'yy').'' .$form['desc'].$form['reson'];
//                hj_post_x($form['referer'], $font, $adminids);
                notification_add($adminids[0],'system', "<a href='{url}'>".$font."</a>", array('url' => $form['referer']),1);
            }
            hb_message(lang('plugin/xigua_hj', 'jbcg'), 'success', "javascript:window.history.go(-1);");
        }
        break;
}
if(!checkmobile()){
    include template('xigua_hb:index');
    exit;
}
if (is_file(DISCUZ_ROOT . "source/plugin/xigua_hj/template/touch/{$_GET['ac']}.php")) {
    include template('xigua_hj:' . $_GET['ac']);
}