<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="infoblock">
    <!--{if $left_img}-->
    <a href="{eval echo $left_link ? $left_link : hb_pc_rewriteoutput('hangye_page', $v['hangye_id1'])}"  target="_blank"  class="recently-browse zp-daoliu-bg c-blocka"><img src="$left_img" class="block" style="width:100%" /></a>
    <!--{elseif $hs_setting[catmiddle]}-->
    <a href="$hs_setting[catmiddle_link]"  target="_blank"  class="recently-browse zp-daoliu-bg c-blocka"><img src="$hs_setting[catmiddle]" class="block" style="width:100%" /></a>
    <!--{/if}-->
    <!--{if $hb_setting[appqrcode]}-->
    <div class="infowraper clearfix">
        <img class="qrcode erwei z" src="{$hb_setting[appqrcode]}" alt="">
        <div class="inlineblock tips1 z">
            <p>{$hb_setting[appname]}</p>
            <p>{$hb_setting[apptext]}</p>
        </div>
    </div>
    <!--{/if}-->
    <div class="sidebar-filter safe-tip">
        <div class="title"><i class="iconfont icon-jubao2 color-red2"></i> {lang xigua_hb:aqxts}</div>
        <p class="sidebar-filter-block">
            $hb_setting[aqxts]
        </p></div>
    <!--{if $_GET['ac']=='hangye' && $likeslist}-->
    <div class="sidebar-filter safe-tip">
        <div class="title">{lang xigua_hs:hot}{lang xigua_hb:shj}
            <a href="{echo hb_pc_rewriteoutput('hangye_page', $hyid, 'orderby=hot')}" class="y txt txt-link-more" style="display: inline-block;padding-right: 8px;margin: 0;background-position:right 8px">{lang xigua_hb:more}</a>
        </div>
        <div>
            <!--{loop $likeslist $_k $_v}-->
            <a class="recentitem" href="{echo hb_pc_rewriteoutput('shop_page', $_v[shid])}" target="_blank">
                <img style="border-radius:100%" src="{$_v[logo]}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" alt="">
                <div class="jobher ">
                    <span class="timu inlineblock" style="width:100%">{$_v[name]}</span>
                </div>
                <div class="gongsi">{$_v[hangye]}</div>
            </a>
            <!--{/loop}-->
        </div>
    </div>
    <!--{/if}-->
    <!--{if $_GET['ac']=='view' && $qrcodeurl1}-->
    <div class="infowraper clearfix">
        <img class="qrcode erwei z" src="{$qrcodeurl1}" alt="">
        <div class="inlineblock tips1 z">
            <p>{$v[name]}</p>
            <p>{lang xigua_hs:gengduodongtai}</p>
        </div>
    </div>
    <!--{/if}-->
</div>