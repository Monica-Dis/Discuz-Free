<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="company-desc-box inner home-inner clearfix">
    <div class="company-desc right-box" style="overflow:inherit">
        <div>
            <div class="intro-box basic-box">
                <div  class="intro-desc-item basic-desc-item clearfix">
                    <div  class="title-box clearfix"><p  class="title">{lang xigua_hb:sjxx}</p>
                        <!--<p class="more"> <a href="javascript:void(0)" class="link-more"></a></p>--></div>
                    <div  class="intro-content clearfix">
                        <p  class="inline-p-ele">
                            <a target="_blank" href="javascript:;" id="v_openLocation" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[name]" data-addr="$v[addr]">{lang xigua_hb:dz}{lang xigua_hb:m}{$v[city]}$v[addr]</a>
                        </p>
                        <!--{eval
                    if($_G['cache']['plugin']['xigua_hr']):
                    $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris_bysh(array($v['shid']));
                    $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($v[uid]));
                    endif;
                    }-->
                        <!--{if $veris2[$v[shid]] || $bao[$v[uid]]}-->
                        <p class="inline-p-ele">{echo lang('home/template', 'memcp_verify')}{lang xigua_hb:m}<!--{if $veris2[$v[shid]]}--><span><i class="iconfont icon-duigou2 f12 main_color"></i> {lang xigua_hr:qy}</span><!--{/if}-->
                        <!--{if $bao[$v[uid]]}--><span><i class="iconfont icon-duigou2 f12 main_color"></i> <!--{if $_G[cache][plugin][xigua_hr][bzjed]}--><span class=" main_color">{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</span><!--{else}-->{lang xigua_hr:yjbzj}<!--{/if}--></span><!--{/if}--></p>
                        <!--{/if}-->
                        <!--{if 1 || $shtel=="tel:".$v[tel]}-->
                        <p  class="inline-p-ele">{lang xigua_hb:tel}{lang xigua_hb:m}<b>{echo substr_replace($v['tel'], '********',3, 11);}</b></p>
                        <!--{else}-->
                        <div  class="inline-p-ele">{lang xigua_hb:tel}{lang xigua_hb:m}
                            <a href="javascript:;" class="view_click" style="display: none;color:#0d47a1">{lang xigua_hb:ckdh}</a>
                            <div class="share-panel3" style="display: none;">
                                <div class="share-layer share-layer-comp" style="top:-30px;left:15px;">
                                    <div class="popover">
                                        <i class="popover-tag popover-bottom-triangle"></i>
                                    </div>
                                    <div>
                                        <img src="{$qrcodeurl1}">
                                        <p style="text-align: center;margin-bottom:10px;">{lang xigua_hb:saoma}{lang xigua_hb:cklxfs}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--{/if}-->
                        <!--{if $shdata[qr]}-->
                        <div  class="inline-p-ele">{lang xigua_hb:weixin}{lang xigua_hb:m}<a href="javascript:;" class="view_click" style="color:#0d47a1">{lang xigua_hb:ck}{lang xigua_hb:wx}</a>
                            <div class="share-panel3" style="display: none;">
                                <div class="share-layer share-layer-comp" style="top:-30px;left:15px;">
                                    <div class="popover">
                                        <i class="popover-tag popover-bottom-triangle"></i>
                                    </div>
                                    <div>
                                        <img src="{$shdata[qr]}">
                                        <p style="text-align: center;margin-bottom:10px;">{lang xigua_hb:saoma}{lang xigua_hs:guanzhu_sj}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--{/if}-->
                    </div>

                    <div class="mobile-layer clearfix">
                        <div class="apply-btn apply-btn2" data-mobile="" >{lang xigua_hb:smddh}</div>
                        <div class="share-panel2">
                            <div class="share-layer share-layer-comp">
                                <div class="popover">
                                    <i class="popover-tag popover-bottom-triangle"></i>
                                </div>
                                <div>
                                    <img src="$qrcodeurl1" />
                                    <p style="text-align: center;margin-bottom: 10px;">{lang xigua_hb:wx}{lang xigua_hb:smddh}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--{if $v[tags] && in_array('tag', $vipinfo['access'])}-->
                    <div style="margin-top:30px">
                        <!--{loop $v[tags] $tg}-->
                        <a href='{echo hb_pc_rewriteoutput("hangye_page", 0, "tag=$tg");}' class="view_sh_tag">$tg</a>
                        <!--{/if}-->
                    </div>
                    <!--{/if}-->
                </div>
                <div class="intro-desc-item basic-desc-item clearfix">
                    <div class="title-box clearfix">
                        <p class="title">{lang xigua_hb:shj}{lang xigua_hs:jianjie}</p></div>
                    <div class="intro-content" style="padding-top:4px;">
                        <!--{if $v['jieshao']}-->
                        <p>{echo hs_nl2br($v['jieshao']);}</p>
                        <!--{else}-->
                        <p>{lang xigua_hb:nojieshao}</p>
                        <!--{/if}-->
                        <!--{loop $v[append_img] $__k $__v}-->
                        <p><img class="intro-img" src="{$__v}" /></p>
                        <p>{echo hs_nl2br($v[append_text][$__k]);}</p>
                        <!--{/loop}-->
                        <!--{loop $v[album] $__k $__v}-->
                        <p><img class="intro-img" src="{$__v}" /></p>
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="left-box">
        <!--{template xigua_hs:left_box}-->
    </div>
</div>