<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<style>.swiper-container{width:100%;height:300px;margin-left:auto;margin-right:auto}
.swiper-slide{background-size:cover;background-position:center}
.gallery-top{height:80%;width:100%}
.gallery-thumbs{height:20%;box-sizing:border-box;padding:10px 0}
.gallery-thumbs .swiper-slide{width:25%;height:100%;opacity:.4}
.gallery-thumbs .swiper-slide-thumb-active{opacity:1}
.intro-content{padding-top:4px;background:#000;height:600px}
</style>
<div class="company-desc-box inner home-inner clearfix">
    <div class="company-desc right-box">
        <div>
            <div class="intro-box basic-box">
                <div class="intro-desc-item basic-desc-item clearfix" style="border:0">
                    <div class="title-box clearfix"><p class="title">{lang xigua_hs:album}</p>
                        <p class="more"> <a href="javascript:void(0)" class="link-more">{lang xigua_hb:gong} <em class="main_color">{echo count($shdata[album]);}</em> {lang xigua_hb:zhang}</a></p>
                    </div>
                    <div class="intro-content">
                        <div class="swiper-container gallery-top">
                            <div class="swiper-wrapper">
                                <!--{loop $shdata[album] $___v}-->
                                <div class="swiper-slide" style="background-image:url({$___v})"></div>
                                <!--{/loop}-->
                            </div>
                            <div class="swiper-button-next swiper-button-white"></div>
                            <div class="swiper-button-prev swiper-button-white"></div>
                        </div>
                        <div class="swiper-container gallery-thumbs">
                            <div class="swiper-wrapper">
                                <!--{loop $shdata[album] $___v}-->
                                <div class="swiper-slide" style="background-image:url({$___v})"></div>
                                <!--{/loop}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="left-box">
        <!--{template xigua_hs:left_box}-->
    </div>
</div>
<script>
var galleryThumbs = new Swiper('.gallery-thumbs', {
    spaceBetween: 10,
    slidesPerView: 4,
    freeMode: true,
    watchSlidesVisibility: true,
    watchSlidesProgress: true,
    autoplay: {
        delay: 5000,
        disableOnInteraction: true,
    },
});
var galleryTop = new Swiper('.gallery-top', {
    autoplay: {
        delay: 5000,
        disableOnInteraction: true,
    },
    spaceBetween: 10,
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    thumbs: {
        swiper: galleryThumbs
    }
});
</script>