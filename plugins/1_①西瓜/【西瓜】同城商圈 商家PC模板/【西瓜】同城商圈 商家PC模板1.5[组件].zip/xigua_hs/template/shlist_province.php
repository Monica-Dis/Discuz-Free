<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $pros = array('������', '�Ϻ���', '����ʡ',);}-->
<!--{loop $pros $kk $vv}-->
<!--{eval
$_id = DB::result_first("select id from ".DB::table('xigua_hb_district')." where name LIKE '$vv%' AND level=1");
$subaddr = DB::fetch_all("select * from ".DB::table('xigua_hb_district')." where upid=$_id order by id asc");
$new_subaddrs = array_chunk(array_slice($subaddr, 0, 8), 2);
$wherenew = array();
$wherenew[] = "province like '%$vv%' and display=1 AND endts>=" . TIMESTAMP;
$shlist3 = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($wherenew, 0, 10, 'dig_endts DESC, views DESC', 'shid,name,logo');
}-->
<div class="quanzhi inner home-inner shixi" >
    <div class="left">
        <div class="quanzhi-title">
            <div class="ele-pointer">{$vv}</div>
        </div>
        <div class="quanzhi-logo ele-pointer quanzhi-logo-shixi"></div>
        <div class="quanzhi-logo-txt ele-pointer">{lang xigua_hb:sj}</div>
        <div  class="quanzhi-recomand">
            <!--{loop $new_subaddrs $_k $_v}-->
            <p>
                <a target="_blank" href="{echo hb_pc_rewriteoutput('hangye_page', $_v[0][id], 'hyid=0&province='.$vv.'&city='.$_v[0][name])}" class="first ellipsis">$_v[0][name]</a>
                <em class="vline v-line-spc"></em>
                <a target="_blank" href="{echo hb_pc_rewriteoutput('hangye_page', $_v[1][id], 'hyid=0&province='.$vv.'&city='.$_v[1][name])}" class="second ellipsis">$_v[1][name]</a>
            </p>
            <!--{/loop}-->
        </div>
        <a target="_blank" href="{echo hb_pc_rewriteoutput('hangye_page', 0)}"  class="quanzhi-more">{lang xigua_hb:ck}{lang xigua_hb:more}</a>
    </div>
    <div class="right recomand-content clearfix">
        <div>
            <!--{loop $shlist3 $_k $_v}-->
            <a target="_blank" href="{echo hb_pc_rewriteoutput('shop_page', $_v[shid])}" class="shixi-item"><img src="$_v[logo]" class="img" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" style="border-radius:0" alt="">
                <div class="job-compnay ellipsis">{$_v[name]}</div>
            </a>
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{/loop}-->