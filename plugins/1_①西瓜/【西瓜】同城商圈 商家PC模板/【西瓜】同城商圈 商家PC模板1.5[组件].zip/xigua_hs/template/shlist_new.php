<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $new_hangyes2 || $shlist2}-->
<div class="quanzhi inner home-inner shixi" >
    <div class="left">
        <div class="quanzhi-title">
            <div class="ele-pointer">{lang xigua_hb:zx}{lang xigua_hb:shj}</div>
        </div>
        <div class="quanzhi-logo ele-pointer quanzhi-logo-shixi"></div>
        <div class="quanzhi-logo-txt ele-pointer">{lang xigua_hb:sj}</div>
        <div  class="quanzhi-recomand">
            <!--{loop $new_hangyes2 $_k $_v}-->
            <p>
                <a target="_blank" href="{echo hb_pc_rewriteoutput('hangye_page', $_v[0][id])}" class="first">$_v[0][name]</a>
                <em class="vline v-line-spc"></em>
                <a target="_blank" href="{echo hb_pc_rewriteoutput('hangye_page', $_v[1][id])}" class="second">$_v[1][name]</a>
            </p>
            <!--{/loop}-->
        </div>
        <a target="_blank" href="{echo hb_pc_rewriteoutput('hangye_page', 0)}"  class="quanzhi-more">{lang xigua_hb:ck}{lang xigua_hb:more}</a>
    </div>
    <div class="right recomand-content clearfix">
        <div>
            <!--{loop $shlist2 $_k $_v}-->
            <a target="_blank" href="{echo hb_pc_rewriteoutput('shop_page', $_v[shid])}" class="shixi-item"><img src="$_v[logo]" class="img" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" style="border-radius:0" alt="">
                <div class="job-compnay ellipsis">{$_v[name]}</div>
            </a>
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{/if}-->