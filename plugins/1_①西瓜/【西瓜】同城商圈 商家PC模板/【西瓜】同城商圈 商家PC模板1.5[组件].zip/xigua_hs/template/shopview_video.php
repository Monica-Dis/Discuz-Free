<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="company-desc-box inner home-inner clearfix">
    <div class="company-desc right-box">
        <div>
            <!--{if $v[video]}-->
            <div class="bgf"><video poster="{$v['video_cover']}" <!--{if $hs_config[autoplay]}-->autoplay muted<!--{/if}--> style="background:#000;width:100%;max-height:{echo $hs_config[vrheight]*2}px;height:{echo $hs_config[vrheight]*2}px" src="{$v['video']}" controls="controls" x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"></video></div>
            <!--{elseif $v[shipin]}-->
            $v['shipin']
            <!--{/if}-->
        </div>
    </div>
    <div class="left-box">
        <!--{template xigua_hs:left_box}-->
    </div>
</div>