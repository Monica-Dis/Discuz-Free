<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template xigua_hb:common_header}-->
<div class="inner home-inner">
    <div class="search-box ">
        <div class="search-form clearfix ">
            <div  class="clearfix">
                <div class="search-form-con">
                    <div class="position-sel search-form-ele" style="width:0;background:transparent;padding-left:12px"></div>
                    <form  action="$SCRITPTNAME" method="get" id="searchForm">
                        <input type="hidden" name="id" value="xigua_hs">
                        <input type="hidden" name="ac" value="hangye">
                        <input type="hidden" name="st" value="$_GET[st]">
                        <input type="hidden" name="idu" value="$_GET[idu]">
                        <div class="ipt-wrap">
                            <input type="text" name="keyword" autocomplete="off" maxlength="50" placeholder="$hs_config[defaultstxt]" class="ipt-search search-form-ele"  <!--{if $keyword}-->value="$keyword"<!--{/if}-->>
                        </div>
                    </form>
                    <div class="search-btn">
                        <i class="icon search-icon"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="inner home-content">
    <div class="filterwraper">
        <div class="filterarea">
            <div class="area clearfix"><span class="areatitle">{lang xigua_hb:plugins_edit_vars_type_area}{lang xigua_hb:m}</span>
                <div class="arearight inlineblock">
                    <a class="first_check areaitem<!--{if !$_GET[province]}-->active<!--{/if}-->" href='{eval echo hb_pc_rewriteoutput("hangye_page", $hyid, "province=&city=&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}'  >{lang xigua_hb:quanbu}</a>
                    <!--{loop $dist0 $v}-->
                    <a class="first_check areaitem<!--{if $_GET[province]==$v[name]}-->active<!--{eval $city_id=$v['id'];}--><!--{/if}-->" href='{eval echo hb_pc_rewriteoutput("hangye_page", $hyid, "province=".urlencode($v[name])."&city=&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}'>$v[name]</a>
                    <!--{/loop}-->
                    <!--{loop $dist0 $k $v}-->
                    <!--{if $_GET[province]!=$v['name']}--><!--{eval continue;}--><!--{/if}-->
                    <div class="subcat_text sub_cheker" id="sub_cheker_$v[id]">
                        <a href='{eval echo hb_pc_rewriteoutput("hangye_page", $hyid, "province=".urlencode($v[name])."&city=&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}' class="fareitem fareitem<!--{if !$_GET[city]}-->active<!--{/if}-->">{lang xigua_hb:quan}{$v[name]}</a>
                        <!--{loop $v[child] $vv}-->
                        <a href='{eval echo hb_pc_rewriteoutput("hangye_page", $hyid, "province=".urlencode($v[name])."&city=".urlencode($vv[name])."&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}' id="sub_check{$vv[id]}" class="fareitem fareitem<!--{if $city==$vv[name]&&$_GET[city]}-->active<!--{/if}-->">$vv[name]</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
            </div>
            <div class="fare clearfix"><span class="faretitle">{lang xigua_hs:cat}{lang xigua_hb:m}</span>
                <div class="arearight inlineblock">
                    <a class="first_cat_check fareitem<!--{if !$hyid}-->active<!--{/if}-->" href='{eval echo hb_pc_rewriteoutput("hangye_page", 0, "province=".urlencode($_GET[province])."&city=".urlencode($city)."&dist=".urlencode($dist)."&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}'>{lang xigua_hb:buxian}</a>
                    <!--{loop $cat_tree $k $v}-->
                    <!--{if !$v[cat_link]}-->
                    <a class="first_cat_check fareitem<!--{if $hyid==$v[id]||$pid==$v[id]}-->active<!--{/if}-->" href='{eval echo hb_pc_rewriteoutput("hangye_page", $v[id], "province=".urlencode($_GET[province])."&city=".urlencode($city)."&dist=".urlencode($dist)."&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}'>$v[name]</a>
                    <!--{else}-->
                    <a class="first_cat_check fareitem<!--{if $hyid==$v[id]||$pid==$v[id]}-->active<!--{/if}-->" href="$v[cat_link]">$v[name]</a>
                    <!--{/if}-->
                    <!--{/loop}-->
                    <!--{loop $cat_tree $k $v}-->
                    <!--{if !($hyid==$v[id]||$pid==$v[id]) || !$v[sub]}--><!--{eval continue;}--><!--{/if}-->
                    <div class="subcat_text" id="sub_cat_cheker_$v[id]">
                        <a class="sub_cat_check fareitem<!--{if $hyid==$v[id]}-->active<!--{/if}-->" href='{eval echo hb_pc_rewriteoutput("hangye_page", $v[id], "province=".urlencode($_GET[province])."&city=".urlencode($city)."&dist=".urlencode($dist)."&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}'>{lang xigua_hb:quanbu}</a>
                        <!--{loop $v[sub] $vv}-->
                        <a class="sub_cat_check fareitem<!--{if $hyid==$vv[id]}-->active<!--{/if}-->"  href='<!--{if $vv[cat_link]}-->$vv[cat_link]<!--{else}-->{eval echo hb_pc_rewriteoutput("hangye_page", $vv[id], "province=".urlencode($_GET[province])."&city=".urlencode($city)."&dist=".urlencode($dist)."&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}<!--{/if}-->'>$vv[name]</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
    </div>
    <div class="bigblock clearfix">
        <div class="listblock">
            <div id="recentblock" class="filterwraper">
                <div class="listfilter clearfix">
                    <div class="leftzone  z">
                        <span  style="display:inline-block;">
<!--{loop $orderby_list $_ok $_ol}-->
<!--{if $_ok=='near'}-->
<!--{eval continue;}-->
<!--{/if}-->
<a class="sort <!--{if $orderby==$_ok}-->active<!--{/if}-->" href='{eval echo hb_pc_rewriteoutput("hangye_page", $hyid, "province=".urlencode($_GET[province])."&city=".urlencode($city)."&dist=".urlencode($dist)."&orderby=$_ok&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}'>$_ol</a>
<!--{/loop}-->
                        </span>
                    </div>
                    <!--<div class="rightzone y">
                        <span class="guaree">{lang xigua_hb:zk}</span>
                    </div>-->
                </div>
            </div>
            <div class="listwraper">
                <div id="list" class="listitems mod-post x-postlist pt0 bgf"></div>
                <div href="javascript:;" class="load-more"> {lang xigua_hb:ck}{lang xigua_hb:more} <i class="iconfont icon-jinrujiantou f14"></i></div>
                <div class="weui-loadmore weui-loadmore_line">
                    <div class="hs_empty"><i class="icon iconfont icon-zanwuwenda"></i><p>{lang xigua_hb:zanwugengduo}</p></div>
                </div>
            </div>
        </div>
        <!--{template xigua_hs:left_box}-->
    </div>
</div>
<script>
var loadingurl = _APPNAME+'?id=xigua_hs&hyid=$hyid&province={echo urlencode($_GET[province])}&city={echo urlencode($city)}&dist={echo urlencode($dist)}&orderby=$orderby&keyword={echo urlencode($keyword)}&lat=$lat&lng=$lng&filter={echo urlencode($filter)}&ac=myshop_li&inajax=1&page=';
</script>
<!--{template xigua_hb:common_footer}-->