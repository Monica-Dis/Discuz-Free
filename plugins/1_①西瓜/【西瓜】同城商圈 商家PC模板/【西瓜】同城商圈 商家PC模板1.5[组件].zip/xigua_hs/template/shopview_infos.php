<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="company-desc-box inner home-inner clearfix">
    <div class="company-desc right-box">
        <div class="intro-box basic-box"><div  class="intro-desc-item basic-desc-item clearfix" style="border:0;padding-bottom:0"><div  class="title-box clearfix" style="margin-bottom:0"><p  class="title">{lang xigua_hs:sjdt}</p></div></div></div>
        <div class="listwraper">
            <div id="list" class="listitems mod-post x-postlist pt0"></div>
            <div href="javascript:;" class="load-more"> {lang xigua_hb:ck}{lang xigua_hb:more} <i class="iconfont icon-jinrujiantou f14"></i></div>
            <div class="weui-loadmore weui-loadmore_line">
                <div class="hs_empty"><i class="icon iconfont icon-zanwuwenda"></i><p>{lang xigua_hb:zanwugengduo}</p></div>
            </div>
        </div>
    </div>
    <div class="left-box">
        <!--{template xigua_hs:left_box}-->
    </div>
</div>
<script> var loadingurl = '$SCRITPTNAME?id=xigua_hb&newdt={$v[shid]}&ac=list_item&inajax=1&page='; </script>