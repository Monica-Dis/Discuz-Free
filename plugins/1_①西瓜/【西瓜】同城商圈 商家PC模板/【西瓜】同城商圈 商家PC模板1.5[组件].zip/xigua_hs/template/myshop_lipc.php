<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval include_once DISCUZ_ROOT.'source/plugin/xigua_hs/include/c_shtel.php';}-->
<!--{loop $list $v}-->
<div class="shlst clearfix" >
    <a class="inlineblock percent80 clearfix" href="{echo hb_pc_rewriteoutput('shop_page', $v[shid])}" target="_blank" >
        <img src="{$v['logo']}" onerror="this.error=null;this.src='{$hs_config[dftshlogo]}'"  class="shlogo" style="border-radius:0" >
        <div class="z shlst_subtit" >
            <div class="shtitle" >
                <!--{if $v[dig]}--><em class="is-star dig_tag">{lang xigua_hs:dig}</em> <!--{/if}-->{$v['name']} <!--{if $v[shipin]||$v[video]}--> <em class="color-red hs_tag"><i class="iconfont icon-shipin"></i></em><!--{/if}--><!--{if $v[quanjing]}--> <em class="color-red hs_tag"><i class="iconfont icon-icon-test"></i></em><!--{/if}--><!--{if $v[end]}--> <em class="hs_tag"><i class="iconfont icon-jubao c9 f12"> {lang xigua_hs:guoqi}</i></em><!--{/if}--><!--{if !($_G[cache][plugin][xigua_hr][qytb]||$_G[cache][plugin][xigua_hr][bzjtb]) && ($veris2[$v[shid]] || $bao[$v[uid]])}-->
                <!--{if $veris2[$v[shid]]}--><!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-dropbox vm"></i><!--{/if}--><!--{/if}-->
                <!--{if $bao[$v[uid]]}--><!--{if !$bao[$v[uid]][icon]}--><!--{eval $bao[$v[uid]][icon] = $_G[cache][plugin][xigua_hr][bzjtb];}--><!--{/if}--><!--{if $bao[$v[uid]][icon]}--><img class="rzimg vm" src="$bao[$v[uid]][icon]" /> <!--{else}--><i class="iconfont icon-baozhengjinmoshi color-good vm pr_1" style="font-size:19px;position:relative;top:2px"></i><!--{/if}--><!--{if $_G[cache][plugin][xigua_hr][bzjed]}--><span class="f13 main_color">{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</span><!--{/if}--><!--{/if}-->
                <!--{/if}-->
            </div>
            <div class="brief top20 clearfix" >
                <p class="ellipsis"><!--{if $v[xuanchuan]}--><i class="f14 vm pr-1 iconfont icon-praise_fill color-red2"></i> {$v[xuanchuan]}<!--{else}-->
                    <!--{if $hs_config[showopentime]}-->
                    <i class="f13 vm pr-1 iconfont icon-shijian"></i> {$v[opentime]}
                    <!--{else}-->{echo strip_tags($v['jieshao'])}<!--{/if}-->
                    <!--{/if}--></p>
                <p class="ellipsis"><i class="iconfont icon-mudedi vm f15 pr-1"></i> {$v[city]}{$v['addr']}</p>
            </div>
            <!--{if $v[tags]}-->
            <div class="top20  " style="margin-bottom:5px">
                <!--{loop $v[tags] $tag}-->
                <span class="mod-feed-tag" >$tag</span>
                <!--{/loop}-->
            </div>
            <!--{else}-->
            <div class="top20  " style="margin-bottom:5px">
                <!--{loop $v[hangyes] $hy}-->
                <span class="mod-feed-tag">$hy</span>
                <!--{/loop}-->
            </div>
            <!--{/if}-->
        </div>
    </a>
    <div class="inlineblock percent19">
        <a class="votebtn inlineblock"  href="{echo hb_pc_rewriteoutput('shop_page', $v[shid])}" target="_blank">{lang xigua_hb:ck}</a>
        <div class="top20">
            <!--{if $viewtype =='new'}-->
            <span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]" ><!--{eval $v[crts_u]=str_replace('&nbsp;', '', $v[crts_u])}-->{echo strpos($v[crts_u], '-')!==false ? date('m-d', strtotime($v[crts_u])) : $v[crts_u]}{lang xigua_hs:ruzhu}</span>
            <!--{elseif $viewtype =='near'}-->
            <span class="li_location tag-gray" data-lat="$v[lat]" data-lng="$v[lng]" >{$v[distance]}</span>
            <!--{elseif $viewtype =='guanzhu'}-->
            <span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]" >{echo hb_trans($v[follow])}{lang xigua_hs:guanzhu}</span>
            <!--{elseif $viewtype =='fenxiang'}-->
            <span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]" >{echo hb_trans($v[shares])}{lang xigua_hs:fenxiang}</span>
            <!--{else}-->
            <!--{if !$_GET[is_my]}--><span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]" >{echo hb_trans($v[views])}{lang xigua_hs:view}</span><!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/loop}-->