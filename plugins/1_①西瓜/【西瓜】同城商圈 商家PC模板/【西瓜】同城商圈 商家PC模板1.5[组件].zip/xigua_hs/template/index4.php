<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template xigua_hb:common_header}-->
<div class="main home-content" <!--{if $hs_setting[shindex_toppic]}-->style="background-image:url($hs_setting[shindex_toppic])"<!--{/if}-->>
<div class="inner home-inner">
    <div class="search-box ">
        <div class="search-form clearfix ">
            <div  class="clearfix">
                <div class="search-form-con">
                    <div class="position-sel search-form-ele">
                        <i class="line"></i><span class="label-text search-form-ele"><em class="search-form-ele" id="searchv">{lang xigua_hb:shj}</em><i class="icon more-down-icon"></i></span>
                        <div class="industry-box">
                            <ul>
                                <li><a href="javascript:;" data-id="xigua_hb" data-ac="cat" data-txt="{lang xigua_hb:xinxi}">{lang xigua_hb:xinxi}</a></li>
                                <li><a href="javascript:;" data-id="xigua_hs" data-ac="hangye" data-txt="{lang xigua_hb:shj}">{lang xigua_hb:shj}</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="ipt-wrap">
                    <form class="z x_form" id="searchForm" method="get" action="$SCRITPTNAME">
                        <input type="hidden" name="id" value="xigua_hs">
                        <input type="hidden" name="ac" value="hangye">
                        <input type="hidden" name="st" value="$_GET[st]">
                        <input type="hidden" name="idu" value="$_GET[idu]">
                        <input type="text" name="keyword" autocomplete="off" maxlength="50" placeholder="$hs_config[defaultstxt]" value="" class="ipt-search search-form-ele">
                    </form>
                    </div>
                    <div class="search-btn">
                        <i class="icon search-icon"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="inner home-inner page-core clearfix" >
    <div class="left job-classify" <!--{if $hb_setting[leftcolor]}-->style="background:{echo $hb_setting[leftcolor]=='#000000'? $config[maincolor] : $hb_setting[leftcolor]}"<!--{/if}-->>
    <!--{loop $cat_tree_all $_k $_v}--><!--{eval
$ii++;
$ij = 0;
if($ii>10):
    break;
endif;
}-->
    <div class="box">
        <div class="first-item">
            <a target="_blank" href="{echo $_v[cat_link] ? $_v[cat_link] : hb_pc_rewriteoutput('hangye_page', $_v[id], $cityauto)}" class="query-item">$_v[name]</a>
            <!--{if !$hb_setting[hidecat]}-->
            <!--{loop $_v[sub] $__k $__v}-->
            <a target="_blank" href="{echo $__v[cat_link] ? $__v[cat_link] : hb_pc_rewriteoutput('hangye_page', $__v[id], $cityauto)}" class="query-item">$__v[name]</a>
            <!--{/loop}-->
            <!--{/if}-->
        </div>
        <div class="job-menu-sub" style="top:{echo $i*40;}px;height:auto">
            <div class="popover">
                <i class="popover-left-triangle" style="top:5px;left:-35px;"></i>
                <!--{eval $i++;}-->
            </div>
            <ul>
                <li class="clearfix">
                    <div class="head-txt">$_v[name]</div>
                    <div class="text">
                        <!--{if !$_v[sub]}-->
                        <a target="_blank" href="{echo $_v[cat_link] ? $_v[cat_link] :  hb_pc_rewriteoutput('hangye_page', $_v[id], $cityauto)}" class="job-classify-btn">$_v[name]</a>
                        <!--{else}-->
                        <!--{loop $_v[sub] $__k $__v}-->
                        <a target="_blank" href="{echo $__v[cat_link] ? $__v[cat_link] :  hb_pc_rewriteoutput('hangye_page', $__v[id], $cityauto)}" class="job-classify-btn">$__v[name]</a>
                        <!--{/loop}-->
                        <!--{/if}-->
                    </div>
                </li>
                <!--{loop $cat_tree_all $tmp_k $tmp_v}-->
                <!--{if $tmp_k==$_v[id]}-->
                <!--{eval continue;}-->
                <!--{/if}--><!--{eval
$ij++;
if($ij>0):
    break;
endif;
}-->
                <li class="clearfix">
                    <div class="head-txt">$tmp_v[name]</div>
                    <div class="text">
                        <!--{if !$tmp_v[sub]}-->
                        <a target="_blank" href="{echo $tmp_v[cat_link] ? $tmp_v[cat_link] :  hb_pc_rewriteoutput('hangye_page', $tmp_v[id], $cityauto)}" class="job-classify-btn">$tmp_v[name]</a>
                        <!--{else}-->
                        <!--{loop $tmp_v[sub] $__k $__v}-->
                        <a target="_blank" href="{echo $__v[cat_link] ? $__v[cat_link] :  hb_pc_rewriteoutput('hangye_page', $__v[id], $cityauto)}" class="job-classify-btn">$__v[name]</a>
                        <!--{/loop}-->
                        <!--{/if}-->
                    </div>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <!--{/loop}-->
</div>
<div class="middle banner">
    <div class="ivu-carousel"  style="width:690px">
        <!--{if $hs_setting[pcslider1]}-->
        <div class="swiper-container pc_swiper">
            <div class="swiper-wrapper">
                <!--{eval for($i=1; $i<=4; $i++):
                $key1 = 'pcslider'.$i;
                $key2 = 'pcslider_link'.$i;
                }-->
                <!--{if $hs_setting[$key1]}-->
                <div class="swiper-slide">
                    <a target="_blank" href="{$hs_setting[$key2]}"><img src="{$hs_setting[$key1]}"></a>
                </div>
                <!--{/if}-->
                <!--{eval endfor;}-->
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <!--{elseif $topnavslider}-->
        <div class="swiper-container pc_swiper">
            <div class="swiper-wrapper">
                <!--{loop $topnavslider $slider}-->
                <div class="swiper-slide">$slider</div>
                <!--{/loop}-->
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <!--{/if}-->
    </div>
</div>
<div class="right job-video">
    <div class="nav clearfix">
        <ul class="jav_right">
            <li class="cur"><a class="title">{lang xigua_hb:zx}{lang xigua_hs:ruzhu}</a></li>
            <!--{if $toutiaoitems}-->
            <li><a class="title">$hs_config[toutitle]</a></li>
            <!--{/if}-->
        </ul>
    </div>
    <div class="content jav_right_bottom">
        <!--{loop $newest $_k $_v}-->
        <!--{eval $_k=$_k+1;}-->
        <a target="_blank" href="{echo hb_pc_rewriteoutput('shop_page', $_v[shid])}" class="paihang-item source">
            <div class="paihang-item-rank">$_k</div>
            <div class="paihang-item-left ellipsis" style="max-width:135px"><img class="hs_indexlogo" src="{$_v[logo]}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'"> {$_v[name]}{lang xigua_hs:cgrz}</div>
            <div class="paihang-item-right">{$_v[crts_u]}</div>
        </a>
        <!--{/loop}-->
        <a target="_blank" href="{echo hb_pc_rewriteoutput('hangye_page', 0)}" class="txt txt-link-more">{lang xigua_hb:ck}{lang xigua_hb:more}</a>
    </div>
    <!--{if $toutiaoitems}-->
    <div class="content jav_right_bottom" style="display:none">
        <!--{loop $toutiaoitems $_k $toutiaoitem}-->
        <!--{eval list($font, $link)= explode(",", trim($toutiaoitem)); }-->
        <!--{eval $_k=$_k+1;}-->
        <a target="_blank" href="$link" class="paihang-item source">
            <div class="paihang-item-rank">$_k</div>
            <div class="paihang-item-left ellipsis" style="max-width:175px">$font</div>
        </a>
        <!--{/loop}-->
    </div>
    <!--{/if}-->
</div>
</div>
<!--{template xigua_hs:shlist}-->
<!--{template xigua_hs:shlist_new}-->
<div class="brand-box" >
    <div class="inner home-inner brand-box-content clearfix">
        <p class="brand-box-title">{$config[tname]}</p>
        <div class="brand-box-container">
            <dl style="width: 33%;padding-left: 0;text-align: center;margin-right: 0;">
                <dt>$totalviews<em>+</em></dt>
                <dd>{lang xigua_hb:shj}{lang xigua_hb:views}</dd>
            </dl>
            <!--{if $totalpub}-->
            <dl style="width: 33%;padding-left: 0;text-align: center;margin-right: 0;">
                <dt>$totalpub<em>+</em></dt>
                <dd>{lang xigua_hb:yiruzhu}{lang xigua_hb:shj}</dd>
            </dl>
            <!--{/if}-->
            <dl style="width: 33%;padding-left: 0;text-align: center;margin-right: 0;">
                <dt>$totalshares<em>+</em></dt>
                <dd>{lang xigua_hb:shj}{lang xigua_hb:views2}</dd>
            </dl>
        </div>
    </div>
</div>
</div>
<!--{template xigua_hb:common_footer}-->