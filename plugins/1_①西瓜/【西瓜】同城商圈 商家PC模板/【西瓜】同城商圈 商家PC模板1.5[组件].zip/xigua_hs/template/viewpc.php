<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template xigua_hb:common_header}-->
<style>.apply-btn{border-radius:6px}.view_sh_tag{padding:7px 12px}.mobile-layer{float:none;margin-bottom:10px}.intro-box .intro-desc-item .inline-p-ele{margin-bottom:20px}</style>
<div class="company-detail home-body">
    <div class="main home-content">
        <div class="head-banner main_bg" <!--{if $hs_setting[shview_toppic]}-->style="background-image:url($hs_setting[shview_toppic])"<!--{/if}-->>
            <div class="head-banner-box inner home-inner clearfix" >
                <div>
                    <img src="$v[logo]" onerror="this.error=null;this.src='{$hs_config[dftshlogo]}'" class="company-img" >
                    <!--{if $vipinfo[icon]}--><div class="crown" style="background-image:url({$vipinfo[icon]})"></div><!--{/if}-->
                </div>
                <div class="item-content" >
                    <div class="title" ><span class="mr15">{$v[name]}</span> <span class="f14">{$vipinfo['name']}</span>
                        <!--{if $v[end]}--> <em class="hs_tag"><i class="iconfont icon-jubao c9 f12"> {lang xigua_hs:guoqi}</i></em><!--{else}-->
                        <span class="f14">{lang xigua_hs:qian}{$v['rank']}{lang xigua_hs:ming}</span>
                        <!--{/if}-->
                    </div>
                    <div class="hb-equal-line clearfix" >
                        <div class="line-equal-item" style="padding-left:0;" >
                            <label class="select-label" >{lang xigua_hs:suoshuhangye}</label><span class="select-content ellipsis" >
<!--{loop $v[hangyes] $hy}-->$hy <!--{/loop}--></span>
                        </div>
                        <!--{if $v[opentime]}-->
                        <div class="line-equal-item border-left" >
                            <label class="select-label" >{lang xigua_hs:opentime}</label><span class="select-content">{$v[opentime]}</span>
                        </div>
                        <!--{/if}-->
                        <div class="line-equal-item border-left" >
                            <label class="select-label" >{lang xigua_hs:fenxiang}</label><span class="select-content f20" >{$v[shares]}</span>
                        </div>
                        <div class="line-equal-item border-left" >
                            <label class="select-label" > {lang xigua_hs:view}</label><span class="select-content f20" >{$v[views]}</span>
                        </div>
                    </div>
                </div>
                <div class="item-right" >
                    <div class="item_right_share">
                        <p class="apply-btn link-share">{lang xigua_hb:shares}</p>
                        <div class="share-panel" style="display: none;">
                            <div class="share-layer share-layer-comp" style="top: 44px;left: 53px;">
                                <div class="popover">
                                    <i class="popover-tag popover-bottom-triangle"></i>
                                </div>
                                <div>
                                    <img src="{$qrcodeurl1}">
                                    <p style="text-align: center;margin-bottom: 10px;">{lang xigua_hb:wxsysfx}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="head-tab not-fixed-head-tab">
            <ul class="inner home-inner clearfix">
                <li class="ht-tab-item <!--{if !$_GET['vtype']}-->active<!--{/if}-->"><a href="{echo hb_pc_rewriteoutput('shop_page', $v[shid]);}">{lang xigua_hb:shj}{lang xigua_hs:jianjie}</a></li>
                <li class="ht-tab-item <!--{if $_GET['vtype']=='infos'}-->active<!--{/if}-->"><a href="{echo hb_pc_rewriteoutput('shop_page', $v[shid], 'vtype=infos');}">{lang xigua_hs:sjdt}</a></li>
                <!--{if $gonggao && $gonggao[0][content] && in_array('gonggao', $vipinfo['access'])}-->
                <li class="ht-tab-item <!--{if $_GET['vtype']=='announce'}-->active<!--{/if}-->"><a href="{echo hb_pc_rewriteoutput('shop_page', $v[shid], 'vtype=announce');}">{lang xigua_hs:dianpugonggao}</a></li>
                <!--{/if}-->
                <!--{if $v[video]||$v[shipin]}-->
                <li class="ht-tab-item <!--{if $_GET['vtype']=='video'}-->active<!--{/if}-->"><a href="{echo hb_pc_rewriteoutput('shop_page', $v[shid], 'vtype=video');}">{lang xigua_hs:sjsp}</a></li>
                <!--{/if}-->
                <!--{if $v['quanjing']}-->
                <li class="ht-tab-item <!--{if $_GET['vtype']=='overall'}-->active<!--{/if}-->"><a href="{echo hb_pc_rewriteoutput('shop_page', $v[shid], 'vtype=overall');}">{lang xigua_hs:sjqj}</a></li>
                <!--{/if}-->
                <!--{if $shdata[album]}-->
                <li class="ht-tab-item <!--{if $_GET['vtype']=='album'}-->active<!--{/if}-->"><a href="{echo hb_pc_rewriteoutput('shop_page', $v[shid], 'vtype=album');}">{lang xigua_hs:album}</a></li>
                <!--{/if}-->
                <li class="ht-tab-item <!--{if $_GET['vtype']=='fans'}-->active<!--{/if}-->"><a href="{echo hb_pc_rewriteoutput('shop_page', $v[shid], 'vtype=fans');}">{lang xigua_hb:shj}{lang xigua_hs:fans}</a></li>
                <!--{if $v[links] && in_array('link', $vipinfo['access'])}-->
                    <!--{loop $v[links][font] $_i $_f}-->
<!--{if $_f}--><li class="ht-tab-item"><a href="{$v[links][link][$_i]}" target="_blank">{$_f}</a></li><!--{/if}-->
                    <!--{/loop}-->
                <!--{/if}-->
            </ul>
        </div>
        <!--{if !$_GET['vtype']}-->
        <!--{template xigua_hs:shopview_jianjie}-->
        <!--{elseif $_GET['vtype']=='announce'}-->
        <!--{template xigua_hs:shopview_announce}-->
        <!--{elseif $_GET['vtype']=='infos'}-->
        <!--{template xigua_hs:shopview_infos}-->
        <!--{elseif $_GET['vtype']=='video'}-->
        <!--{template xigua_hs:shopview_video}-->
        <!--{elseif $_GET['vtype']=='overall'}-->
        <!--{template xigua_hs:shopview_overall}-->
        <!--{elseif $_GET['vtype']=='album'}-->
        <!--{template xigua_hs:shopview_album}-->
        <!--{elseif $_GET['vtype']=='fans'}-->
        <!--{template xigua_hs:shopview_fans}-->
        <!--{/if}-->
    </div>
</div>
<script>
var GOOGLE = '{$hs_config[google]}';
$(document).on('click', '#v_openLocation', function () {
    var that = $(this), windowhref = '';
    if (GOOGLE) {
        windowhref = _APPNAME + '?id=xigua_hs&ac=googleMap&lat=' + that.data('lat') + "&lng=" + that.data('lng');
    } else if (typeof BAIDUSDK != 'undefined') {
        windowhref = '//api.map.baidu.com/marker?location=' + that.data('lat') + "," + that.data('lng') + '&coord_type=gcj02&zoom=10&title=' + that.data('name') + '&output=html&src=webapp.baidu.openAPIdemo&content=' + that.data('addr');
    } else {
        windowhref = "//apis.map.qq.com/uri/v1/marker?marker=coord:" + that.data('lat') + "," + that.data('lng') + ";title:" + that.data('name') + ";addr:" + that.data('addr');
    }
    that.attr('href', windowhref);
    that.trigger('click');
    return false;
});
$('.view_click').hover(function () {
    $(this).parent().find('.share-panel3').show();
}, function () {
    $(this).parent().find('.share-panel3').hide();
});
</script>
<!--{template xigua_hb:common_footer}-->