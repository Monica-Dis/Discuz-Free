<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<style>
.connections-box .qiye-connections{float:left;width:411px;background:#fff}
.connections-box .qiye-connections:last-child,.connections-box .qiye-connections:nth-last-child(2){margin-bottom:0}
.connections-box .qiye-connections:nth-child(2n){padding-left:6px}
.business-media-box{position:relative;box-sizing:border-box;padding:30px 24px 30px 100px;width:100%;background:#fcfcfc;margin-bottom:6px}
.business-media-box .bd-img{width:60px;height:60px;position:absolute;top:24px;left:24px;border-radius:50%;box-sizing:border-box}
.business-media-box .item-content .title{font-size:18px;line-height:18px;margin-bottom:16px;font-weight:500}
.business-media-box .item-content .btxt{color:#666;line-height:14px;margin-top:16px}
</style>
<div class="company-desc-box inner home-inner clearfix">
    <div class="company-desc right-box clearfix">
        <div class="intro-box basic-box">
            <div class="intro-desc-item basic-desc-item clearfix" style="border:0">
                <div class="title-box clearfix"><p class="title">{lang xigua_hb:shj}{lang xigua_hs:fans}</p>
                    <p class="more"> <a href="javascript:void(0)" ><!--class="link-more"-->{lang xigua_hb:gong} <em class="main_color">{$v[follow]}</em> {lang xigua_hb:ren}</a></p>
                </div>
                <div class="intro-content">
                    <div id="list" class="connections-box clearfix"></div>
                    <div href="javascript:;" class="load-more"> {lang xigua_hb:ck}{lang xigua_hb:more} <i class="iconfont icon-jinrujiantou f14"></i></div>
                    <div class="weui-loadmore weui-loadmore_line">
                        <div class="hs_empty"><i class="icon iconfont icon-zanwuwenda"></i><p>{lang xigua_hb:zanwugengduo}</p></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="left-box">
        <!--{template xigua_hs:left_box}-->
    </div>
</div>
<script>
    var loadingurl = _APPNAME+'?id=xigua_hs&ac=follow&do=fans&shid={$shid}&inajax=1&page=';
</script>