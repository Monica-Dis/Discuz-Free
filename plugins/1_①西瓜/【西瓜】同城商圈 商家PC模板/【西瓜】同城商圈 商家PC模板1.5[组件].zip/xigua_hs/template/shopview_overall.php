<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="company-desc-box inner home-inner clearfix">
    <div class="company-desc right-box">
        <div>
            <iframe src="{$v['quanjing']}" style="display:block;background:#000;width:100%;border:0;height:{echo $hs_config[vrheight]*3}px" frameborder="0" class="view_iframe"></iframe>
        </div>
    </div>
    <div class="left-box">
        <!--{template xigua_hs:left_box}-->
    </div>
</div>