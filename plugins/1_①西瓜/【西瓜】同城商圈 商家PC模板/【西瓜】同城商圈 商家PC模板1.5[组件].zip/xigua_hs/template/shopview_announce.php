<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="company-desc-box inner home-inner clearfix">
    <div class="company-desc right-box">
        <div>
            <div class="intro-box basic-box">
                <!--{if $gonggao && $gonggao[0][content] && in_array('gonggao', $vipinfo['access'])}-->
                <div class="intro-desc-item basic-desc-item clearfix">
                    <div class="title-box clearfix">
                        <p class="title">{lang xigua_hs:dianpugonggao}</p>
                        <!--{if 0}--><p class="more"><a href="javascript:;" data-id="$shid" id="history_gonggao" class="link-more">{lang xigua_hs:lishigonggao}</a></p><!--{/if}-->
                    </div>
                    <div class="intro-content clearfix">
                        <p>{echo hs_nl2br(strip_tags($gonggao[0][content]));}</p>
                    </div>
                </div>
                <!--{/if}-->
            </div>
        </div>
    </div>
    <div class="left-box">
        <!--{template xigua_hs:left_box}-->
    </div>
</div>