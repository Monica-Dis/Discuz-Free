<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{loop $list $v}-->
<!--{if !$users[$v[uid]][username]}-->
<!--{eval continue;}-->
<!--{/if}-->
<div  class="qiye-connections">
    <div  class="business-media-box">
        <img src="{avatar($v[uid], 'big', true)}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" class="bd-img">
        <div class="item-content">
            <div class="title">$users[$v[uid]][username]</div>
            <p class="btxt ellipsis">$v[crts_u]{lang xigua_hs:guanzhu}</p>
        </div>
    </div>
</div>
<!--{/loop}-->
