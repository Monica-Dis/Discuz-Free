<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_common.php';
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!$hb_setting):
    $cache_key = 'hb_ext_setting';
    loadcache($cache_key);
    $hb_setting = $_G['cache'][$cache_key];
endif;
if (!$hs_setting):
    $cache_key = 'hs_ext_setting';
    loadcache($cache_key);
    $hs_setting = $_G['cache'][$cache_key];
endif;
/*if($hs_setting['logo']){
    $hb_setting['logo'] = $hs_setting['logo'];
}*/
//$indexhome = hb_pc_rewriteoutput('hsindex_page');
if ($hs_setting['open']) {
    if (!checkmobile()) {
        switch ($ac) {
            case 'index':
                $hangyes = C::t('#xigua_hs#xigua_hs_hangye')->list_by_pid(0, TRUE);
                $new_hangyes = array_chunk(array_slice($hangyes, 0, 8), 2);
                $new_hangyes2 = array_chunk(array_slice(array_reverse($hangyes), 0, 8), 2);
                $wherenew = array();
                $wherenew[] = 'display=1 AND endts>=' . TIMESTAMP;
                $shlist = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($wherenew, 0, 10, 'dig_endts DESC, views DESC', 'shid,name,logo');
                $shlist2 = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($wherenew, 0, 10, 'shid DESC', 'shid,name,logo');
                if(!$cat_tree){
                    $list_all = C::t('#xigua_hs#xigua_hs_hangye')->list_all();
                    C::t('#xigua_hs#xigua_hs_hangye')->init($list_all);
                    $cat_tree_init = $cat_tree = C::t('#xigua_hs#xigua_hs_hangye')->get_tree_array(0);
                    $cat_tree_all = $cat_tree = array_values($cat_tree);
                }else{
                    $cat_tree_all = $cat_tree = array_values($cat_tree);
                }
                $toutiaoitems = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_hb']['toutext'])));
                $totalshares  = C::t('#xigua_hs#xigua_hs_shanghu')->total_shares();
                include template('xigua_hs:index4');
                exit;
                break;
            case 'hangye':
                $city = $_GET['city'];
                $province = $_GET['province'];
                $dist = $_GET['dist'];
                $where  = array(
                    'display=1 AND endts>='.TIMESTAMP,
//                    'dig_endts>'.TIMESTAMP
                );
                $likeslist = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where, 0, 6, '(dig_endts-dig_startts) DESC, views DESC', 'name,logo,shid,uid,hangye_id1,hangye_id2,crts,upts,hangye');
//                dmp($likeslist);
                include template('xigua_hs:hangyepc');
                exit;
                break;
            case 'view':
                $left_img = '';
                foreach (array_reverse($hangye) as $index => $item) {
                    if($item['adimage']){
                        $left_img = $item['adimage'];
                        $left_link = $item['adlink'];
                    }
                }
                if ($config['qraut']) {
                    $qrcodeurl1 = "$SCRITPTNAME?id=xigua_hb:qrauto&ode=sh_{$v['shid']}{$urlext}";
                } else {
                    $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hs&ac=view&shid={$v['shid']}{$urlext}";
                    $ewm = md5('hs_'.$v['shid'].$_G['cookie']['URLEXT']);
                    $repath = './source/plugin/xigua_hb/tmp/';
                    $qrfile = $repath . $ewm . '.png';
                    $abs_qrfile = DISCUZ_ROOT . $qrfile;
                    if (!is_file($abs_qrfile)) {
                        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                        if(class_exists('QRcode')){
                            QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5, 1);
                        }
                    }
                    $qrcodeurl1 = $qrfile;
                }
                include DISCUZ_ROOT.'source/plugin/xigua_hs/include/c_view.php';
                include template('xigua_hs:viewpc');
                exit;
                break;
        }
    }
}
