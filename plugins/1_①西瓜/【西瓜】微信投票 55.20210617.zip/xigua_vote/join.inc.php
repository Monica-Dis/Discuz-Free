<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/11/2
 * Time: 22:35
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$_GET = dhtmlspecialchars($_GET);
if($jid = intval($_GET['jid'])){
    $joininfo = C::t('#xigua_vote#xigua_join')->fetch_by_jid($jid);
    if(!$joininfo){
        $jid = 0;
    }
}

if(submitcheck('formhash') && !$jid){
    $append = $_GET['append'];

    $pic_data = array();
    $pic = run_upload_multi($_FILES['pic']);
    foreach ($pic as $item) {
        if($item['error'] == 0){
            $pic_data[] = $item['url'];
        }
    }
    $append['pic'] = serialize($pic_data);
    $append['crts'] = $_G['timestamp'];
    $append['vid'] = $vid;
    $append['status'] = JOIN_YISHENHE;
    $append['openid'] = uniqid(TIMESTAMP);

    $jid = C::t('#xigua_vote#xigua_join')->insert($append, true, true);
    if($jid){
        C::t('#xigua_vote#xigua_vote')->update_joins_by_vid($vid, 1);
        C::t('#xigua_vote#xigua_vote')->update_totalvotes($vid);

        cpmsg(sl('add_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=join&vid=$vid&jid=$jid", 'succeed');
    }else{
        cpmsg(sl('add_error'),   "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=join&vid=$vid", 'error');
    }
}else if(submitcheck('formhash') && $jid){
    $append = $_GET['append'];

    $cover_data = (array)$append['oldpic'];
    $cover = run_upload_multi($_FILES['pic']);
    foreach ($cover as $item) {
        if($item['error'] == 0){
            $cover_data[] = $item['url'];
        }
    }
    unset($append['oldpic']);

    $append['pic'] = serialize($cover_data);
    $append['crts'] = $_G['timestamp'];

    $ret = C::t('#xigua_vote#xigua_join')->update($append, array('jid' => $jid));
    if($ret){
        C::t('#xigua_vote#xigua_vote')->update_totalvotes($vid);
        cpmsg(sl('update_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=join&vid=$vid&jid=$jid", 'succeed');
    }else{
        cpmsg(sl('update_error'),   "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=join&vid=$vid", 'error');
    }
}
$backurl = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=joinlist&vid=$vid&backpage=$_GET[backpage]&page=$_GET[page]&status=".JOIN_YISHENHE;

$formheader = "plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=join&vid=$vid&jid=$jid";
echo showformheader($formheader, 'enctype');
?>
<link rel="stylesheet" href="./source/plugin/xigua_vote/static/kindeditor/themes/default/default.css" />
<table class="tb tb2 fixpadding">
    <tbody>
    <tr>
        <th colspan="15" class="partition">
            <?php echo $data['title'].'(ID:'.$data['vid'].') - '.($joininfo ? sl('n4') : sl('m21')).("<a class='fr' href=\"$backurl\">".sl('back').sl('manage_joinlist')."</a>");?>
        </th>
    </tr>

    <?php if($joinfield['name']['require']): ?>
    <tr>
        <td colspan="2" class="td27"><?php echo $joinfield['name']['etc']?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <input name="append[name]" value="<?php echo $joininfo['name'] ?>" type="text" class="txt">
        </td>
        <td class="vtop tips2"><?php echo sl('n5') ?><?php echo $joinfield['name']['etc'] ?></td>
    </tr>
    <?php endif; ?>

    <?php if($joinfield['mobile']['require']): ?>
    <tr>
        <td colspan="2" class="td27"><?php echo $joinfield['mobile']['etc']?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <input name="append[mobile]" value="<?php echo $joininfo['mobile'] ?>" type="text" class="txt">
        </td>
        <td class="vtop tips2"><?php echo sl('n5') ?><?php echo $joinfield['mobile']['etc'] ?></td>
    </tr>
    <?php endif; ?>

    <?php if($joinfield['sex']['require']): ?>
    <tr>
        <td colspan="2" class="td27"><?php echo $joinfield['sex']['etc']?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <ul onmouseover="altStyle(this);">
                <li><input class="radio" type="radio" name="append[sex]" value="1" <?php echo $joininfo['sex']==1?'checked':''; ?>><?php echo sl('man') ?></li>
                <li><input class="radio" type="radio" name="append[sex]" value="0" <?php echo intval($joininfo['sex'])==0?'checked':''; ?>><?php echo sl('woman') ?></li>
            </ul>
        </td>
        <td class="vtop tips2"><?php echo sl('n5') ?><?php echo $joinfield['sex']['etc'] ?></td>
    </tr>
    <?php endif; ?>


    <?php for($i=1; $i<=20;$i++){ $fi = 'ext'.$i;?>
    <?php if($joinfield[$fi]['require']): ?>
        <tr>
            <td colspan="2" class="td27"><?php echo $joinfield[$fi]['etc']?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform" >
                <input name="append[<?php echo $fi?>]" value="<?php echo $joininfo[$fi] ?>" type="text" class="txt c12">
            </td>
            <td class="vtop tips2">&nbsp;</td>
        </tr>
    <?php endif; ?>
    <?php }?>





    <?php if($joinfield['profile']['require']): ?>
    <tr>
        <td colspan="2" class="td27"><?php echo $joinfield['profile']['etc']?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <textarea id="c11" style="width:100%;height:300px;visibility:hidden;" name="append[profile]" type="text" class="txt c12"><?php echo $joininfo['profile']?></textarea>
        </td>
        <td class="vtop tips2"><?php echo sl('n5') ?><?php echo $joinfield['profile']['etc'] ?></td>
    </tr>
    <?php endif; ?>

    <?php if($joinfield['pic']['require']): ?>
    <tr>
        <td colspan="2" class="td27"><?php echo $joinfield['pic']['etc']?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <div style="margin-bottom:5px">
                <?php foreach ((array)$joininfo['pic'] as $k => $item) {
                    if(!$item){continue;}
                    echo "<span id='w1$k'><a href='$item' target='_blank'><img class=\"imgi\" src=\"$item\" onmouseover=\"$('p1$k').style.display='block'\" onmouseout=\"$('p1$k').style.display='none'\" /></a><img class='imgprevew' src=\"$item\" id='p1$k' /> <input name='append[oldpic][]' readonly value='$item' type='hidden'><a onclick='$(\"w1$k\").parentNode.removeChild($(\"w1$k\"))' class='closeX'>X&nbsp;&nbsp;</a></span>";
                }?>
            </div>

            <div id="coverdiv">
                <input name='pic[]' type='file' class='txt uploadbtn marginbot'>
                <a class="block" style="cursor:pointer" onclick="add_cover(this);return false;"><?php echo sl('m9') ?></a>
            </div>

        </td>
        <td class="vtop tips2"><?php echo sl('n6') ?><?php echo $joinfield['pic']['etc'] ?></td>
    </tr>
    <?php endif; ?>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('n7')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <input name="append[totalvotes]" type="number" class="txt" value="<?php echo $joininfo['totalvotes']?>">
        </td>
        <td class="vtop tips2"><?php echo sl('n8') ?></td>
    </tr>

    <?php

    $datav = C::t('#xigua_vote#xigua_vote')->fetch_by_vid($_GET['vid']);

    $groupconfig = array();
    if(trim($data['groupconfig'])) :
        foreach (explode("\n", trim($datav['groupconfig'])) as $index => $item) :
            list($tmp_key, $tmp_val) = explode('=', trim($item));
            $groupconfig[trim($tmp_key)] = trim($tmp_val);
        endforeach;
        $GLOBALS['cgroup'] = $cgroup = $groupconfig;
        if ($groupconfig) :
            $cgroupselect = '<select name="append[cgroup]"><option value="">--</option>';
            foreach ($cgroup as $index => $item) :
                $selected = $joininfo['cgroup']==$index ? 'selected="selected"': '';
                $cgroupselect .= "<option $selected value=\"$index\">$item</option>";
            endforeach;
            $cgroupselect .= "</select>";
        endif;
    endif;

    ?>
    <tr>
        <td colspan="2" class="td27"><?php echo sl('upconf')?></td>
    </tr>
    <tr>
        <td colspan="2" class="td27">
            <?php echo $cgroupselect?>
        </td>
    </tr>
    <tr>
        <td colspan="2" class="td27">
            <input name="dosubmit" value="<?php echo sl('m30') ?>" type="submit" class="btn" />
        </td>
    </tr>
    </tbody>
</table>
<script>
    function add_cover(obj){
        var i = document.createElement('input');
        i.name = 'pic[]';
        i.type = 'file';
        i.className = 'txt uploadbtn marginbot';
        $('coverdiv').insertBefore(i, obj);
        return false;
    }
</script>
<script charset="utf-8" src="./source/plugin/xigua_vote/static/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="./source/plugin/xigua_vote/static/kindeditor/lang/zh_CN.js"></script>
<script>
var uploadurl = '<?php echo $_G['site_url']?>source/plugin/xigua_vote/lib/UPLOAD.php';
var ritems = [
    'source', '|', 'undo', 'redo', '|', 'preview', 'template', 'cut', 'copy', 'paste',
    'plainpaste', 'wordpaste', '|', 'justifyleft', 'justifycenter', 'justifyright',
    'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
    'superscript', 'clearhtml', 'quickformat', 'selectall', '|', 'fullscreen', '/',
    'formatblock', 'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold',
    'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'image', 'multiimage', 'table', 'hr', 'emoticons', 'baidumap', 'pagebreak',
    'anchor', 'link', 'unlink'
];
var config = {
    uploadJson : uploadurl,
    allowFileManager: false,
    items : ritems
};
KindEditor.ready(function(K) {
    editor1 = K.create('.c12', config);
});
</script>
<?php
showformfooter(); /*dis'.'m.tao'.'bao.com*/
