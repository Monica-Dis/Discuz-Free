<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/9/3
 * Time: 17:31
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/admincp/menu.php';
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/common.php';

$page = max(1, intval(getgpc('page')));
$lpp   = 30;
$start_limit = ($page - 1) * $lpp;

$url = "plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=user&page=$page";

if(submitcheck('permsubmit')){

    global $_G;
    include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
    include_once libfile('function/cache');
    $wechat_client = new WeChatClient($_G['wechat']['setting']['wechat_appId'], $_G['wechat']['setting']['wechat_appsecret']);

    foreach ($_GET['openid'] as $openid) {
        if(is_numeric($openid)){
            $member = getuserbyuid($openid);

            $userinfo = array(
                'openid'     => $openid,
                'nickname'   => $member['username'],
                'headimgurl' => avatar($openid, 'middle', true),
                'subscribe'  => 1
            );

        }else{
            $userinfo = $wechat_client->getUserInfoById($openid);
            if(!$userinfo || $userinfo['errcode']){

                $appid = $_G['wechat']['setting']['wechat_appId'];
                $appsecret = $_G['wechat']['setting']['wechat_appsecret'];

                $url1 = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";
                $json = dfsockopen($url1);
                if(!$json){
                    $json = file_get_contents($url1);
                }
                $access_data = json_decode($json, true);
                $access_token = $access_data['access_token'];

                if($access_token){
                    savecache( 'wechatat_' . $appid, array(
                        'token' => $access_token,
                        'expiration' => time() + 6200,
                    ));
                }

                $url1 = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=$access_token&openid=$openid&lang=en";
                $json = dfsockopen($url1);
                if(!$json){
                    $json = file_get_contents($url1);
                }
                $userinfo = json_decode($json, true);
            }
            unset($userinfo['unionid']);
            foreach ($userinfo as $index => $item) {
                $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
            }
        }
        if($userinfo['nickname']){
            C::t('#xigua_vote#xigua_user')->insert($userinfo);
            C::t('#xigua_vote#xigua_user')->subscribe($openid);
        }
    }
    cpmsg(sl('update_succeed'), "action=$url", 'succeed');
}

$list  = C::t('#xigua_vote#xigua_user')->fetch_by_page($start_limit, $lpp);
$count = C::t('#xigua_vote#xigua_user')->fetch_count();

$multipage = multi($count, $lpp, $page, ADMINSCRIPT."?action=$url");
lang('admincp');
$lang = & $_G['lang']['admincp'];
showformheader($url,'','vlist');

showtableheader(sl('manage_user'));

$rowhead = array(
    'openid',
    sl('n15'),
    sl('o18'),
    sl('o19'),
    sl('sex'),
    sl('o20'),
    sl('o6'),
);
function get_sex1($sexno){
    $sex = array(
        '' => '-',
        0=> sl('woman'),
        1=> sl('man'),
    );
    return $sex[$sexno];
}
showtablerow('class="header"', array(), $rowhead);


foreach ($list as $row) {
    $rowbody = array(
        $row['openid']."<input type=\"hidden\" name=\"openid[]\" value=\"{$row['openid']}\" />",
        ($row['headimgurl'] ? ('<img class="headimgurl" src="'.$row['headimgurl'].'" />'.$row['nickname']) : $row['openid']),
        $row['subscribe'] ? sl('yes'):sl('no'),
        ($row['subscribe_time'] ? date('Y-m-d H:i:s', $row['subscribe_time']) : '-'),
        get_sex1($row['sex']),
        $row['lastvote'] ? date('Y-m-d H:i:s', $row['lastvote']) : '-',
        $row['hasvotes'],
    );
    showtablerow('', array(), $rowbody);
}

showsubmit('permsubmit', $lang['plugins_config_upgrade'], '', $multipage);
showtablefooter(); /*Dism_taobao-com*/
showformfooter(); /*dis'.'m.tao'.'bao.com*/
?>
<script>
    function submitit(){
        if(confirm('<?php sl('confirm_deluser', 1)?>')){
            $('vlist').submit();
        }
        return false;
    }
</script>