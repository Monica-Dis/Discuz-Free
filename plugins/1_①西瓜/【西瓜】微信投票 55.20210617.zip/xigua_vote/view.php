<?php exit('Access Denied!');?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <meta name="keywords" content="$navdesc">
    <meta name="description" content="$navdesc">
    <link href="source/plugin/xigua_vote/static/{$stylecss}.css?t={$pluginversion}" rel="stylesheet"/>
    <link href="source/plugin/xigua_vote/static/icomoon/style.css?t={$pluginversion}" rel="stylesheet"/>
    <style>*{font-size:14px}</style>
</head>
<body>

<!--{if !MAGAPP}-->
<!--{eval $baominglink = "javascript:$('#tip14').css('display','-webkit-box');";}-->
<!--{/if}-->

<div class="container_map_ami container_map">
    <!--{if $config[viewlunbo]}-->
    <section id="header" class="header">
        <span class="rules" data-cate="0"></span>
        <a href="#cont1" class="rules_text">{echo sl('a6')}</a>
        <div class="swipe cl">
            <div class="swipe-wrap">
                <!--{loop $data['cover'] $item}-->
                <div><a><img src="{$item}"/></a></div>
                <!--{/loop}-->
            </div>
            <nav class="bullets">
                <ul class="position"><!--{loop $data['cover'] $index $item}--><li {if $index==0}class="current"{/if}></li><!--{/loop}--></ul>
            </nav>
        </div>
        <img id="swipload" style="display:block" src="{$data[cover][0]}">
    </section>
    <!--{/if}-->

    <section class="content1">
        <a class="close closev" href="plugin.php?id=xigua_vote:index&vid={$vid}&rand=1"></a>
        <h2 class="title">{$data[joinfield][name][etc]}{echo sl('a7')}</h2>
        <p class="info">{$jid}{echo sl('n3')} $jdata[name]  <!--{if $jdata[status]==JOIN_WEISHENHE}-->{echo sl('a8')}<!--{/if}-->
        <span class="totalvote">{$jdata[totalvotes]} {$config[touunit]}</span>
        </p>


        <!--{if $data[joinfield][sex][require]&& !$data[joinfield][sex][show]}-->
        <p class="profile">
            <b>{$data[joinfield][sex][etc]}:</b>
            <!--{if $jdata[sex] == 1}-->{echo sl('nan')}<!--{else}-->{echo sl('nv')}<!--{/if}-->
        </p>
        <!--{/if}-->

        <!--{if $data[joinfield][profile][require]&& !$data[joinfield][profile][show]}-->
        <p class="profile">
            <b>{$data[joinfield][profile][etc]}:</b>
            {$jdata[profile]}
        </p>
        <!--{/if}-->

        <!--{if $data[joinfield][ext2][require]&& !$data[joinfield][ext2][show]}-->
        <p class="profile">
            <b>{$data[joinfield][ext2][etc]}:</b>
            {$jdata[ext2]}
        </p>
        <!--{/if}-->
        <!--{if $data[joinfield][ext3][require]&& !$data[joinfield][ext3][show]}-->
        <p class="profile">
            <b>{$data[joinfield][ext3][etc]}:</b>
            {$jdata[ext3]}
        </p>
        <!--{/if}-->
        <!--{if $data[joinfield][ext4][require]&& !$data[joinfield][ext4][show]}-->
        <p class="profile">
            <b>{$data[joinfield][ext4][etc]}:</b>
            {$jdata[ext4]}
        </p>
        <!--{/if}-->
        <!--{if $data[joinfield][ext5][require]&& !$data[joinfield][ext5][show]}-->
        <p class="profile">
            <b>{$data[joinfield][ext5][etc]}:</b>
            {$jdata[ext5]}
        </p>
        <!--{/if}-->
        <!--{if $data[joinfield][ext6][require]&& !$data[joinfield][ext6][show]}-->
        <p class="profile">
            <b>{$data[joinfield][ext6][etc]}:</b>
            {$jdata[ext6]}
        </p>
        <!--{/if}-->
        <!--{if $data[joinfield][ext7][require]&& !$data[joinfield][ext7][show]}-->
        <p class="profile">
            <b>{$data[joinfield][ext7][etc]}:</b>
            {$jdata[ext7]}
        </p>
        <!--{/if}-->

        <!--{if !$data[joinfield][pic][show]}-->
        <!--{loop $jdata[pic] $item}-->
        <img src="{$item}" />
        <!--{/loop}-->
        <!--{/if}-->


        <!--{if $data[joinfield][ext1][require]&& !$data[joinfield][ext1][show]}-->
        <p class="profile">
            <b>{$data[joinfield][ext1][etc]}:</b>
            {$jdata[ext1]}
        </p>
        <!--{/if}-->
        <div class="content1_bottom">
            <a class="btn btn2 votenow" data-jid="{$jid}" data-vid="{$vid}">{$config[xtou]}<!--{if $config[zbeishu] && APPBYME}--> X {$config[zbeishu]}<!--{/if}--></a>
            <!--{if $showshare}--><a class="btn btn3 vote_share" href="javascript:void(0);">{$config[xla]}</a><!--{/if}-->
            <!--{if $config[allowbaoming]}--><a class="btn btn3" href="$baominglink">{echo sl('a4')}</a><!--{/if}-->
            <a class="btn btn3" href="plugin.php?id=xigua_vote:index&vid={$vid}&rand=1">{echo sl('a9')}</a>
        </div>

    </section>

    <!--{if $config[viewshuoming]}-->
    <article class="cont1">
        <!--{if $data[content]}-->
        <a name="cont1" id="cont1" class="cont_title">{echo sl('m23')}</a>
        <div class="cont_content cl">{$data[content]}</div>
        <!--{/if}-->
        <!--{if $data[prizecontent]}-->
        <h2 class="cont_title">{echo sl('m24')}</h2>
        <div class="cont_content cl">{$data[prizecontent]}</div>
        <!--{/if}-->
        <!--{if $data[statement]}-->
        <h2 class="cont_title">{echo sl('m25')}</h2>
        <div class="cont_content cl">{$data[statement]}</div>
        <!--{/if}-->
        <!--{if $data[zanzhu]}-->
        <h2 class="cont_title">{echo sl('zanzhu')}</h2>
        <div class="cont_content cl">{$data[zanzhu]}</div>
        <!--{/if}-->
    </article>
    <!--{/if}-->

    <!--{if $config[comment]}-->{$config[comment]}<!--{/if}-->
</div>

<section id="tip14" class="mask"<!--{if 0}--> style="display:-webkit-box"<!--{/if}-->>
<div class="modal"><span class="close" onclick="closex('tip14')"></span>
    <h2>{echo sl('o29')}</h2>
    <!--{if $config[onlyam]}-->
    <p>{$config[guideapp]}</p>
    <!--{if $config[gongzhongcode]}--><img src="{$config[gongzhongcode]}" onerror="this.error=null;this.src='{$config[gongzhongcode]}'" style="display: block;width:157px;height:157px;margin: 0 auto -10px;"><!--{/if}-->
    <a href="{$config[guideapplink]}" class="btns">{$config[guideappbtn]}</a>
    <!--{else}-->
    <p>{echo sprintf(sl('o31'),$config[gongzhonghao], $config[gongzhong])}</p>
    <!--{if $config[gongzhongcode]}--><img src="{$config[gongzhongcode]}" onerror="this.error=null;this.src='{$config[gongzhongcode]}'" style="display: block;width:157px;height:157px;margin: 0 auto -10px;"><!--{/if}-->
    <a href="plugin.php?id=xigua_vote:index&ac=guide&vid={$vid}" class="btns">{echo sl('o28')}</a>
    <!--{/if}-->
</div>
</section>

<section class="mask" id="endtip" <!--{if $voteend}--> style="display:-webkit-box"<!--{/if}-->>
<section class="alltip">
    <span class="close" onclick="closex('endtip')"></span>
    <h2>{$config[endtip]}</h2>
    <a href="plugin.php?id=xigua_vote:index&ac=guide&vid={$vid}" class="btns">{echo sl('o28')}</a>
</section>
</section>

<section class="mask  animated-fast" id="alltip">
    <section class="alltip">
        <span class="close" onclick="closex('alltip')"></span>
        <h2></h2>
        <!--{if $showshare}--><a href="javascript:;" class="btns vote_share">{echo sl('o27')}</a><!--{/if}-->
    </section>
</section>
<div id="wechat-mask"><div id="wechat-guider"></div></div>
<div id="backtotop" class="backtotop"><span class="icon-chevron-up"></span></div>
<script src="source/plugin/xigua_vote/static/jquery.min.js?t={$pluginversion}"></script>
<script src="source/plugin/xigua_vote/static/custom.js?t={$pluginversion}"></script>
<script>
var voteerr=[
    '{echo sl("votefail")}',
    '{echo sl("votefail")}',
    '{echo sl("voteend")}',
    '{echo sl("voteperday")}',
    '{echo sl("maxinjoin")}',
    '{echo sl("iplimit")}',
    '{echo sl("weishenhe")}',
    '{echo sl("notexists")}',
    '{echo sl("mustinwechat")}',
    '{echo sl("maxprejoinday")}',
    '{echo sl("maxatvote")}',
    '{echo sprintf(sl("notintime"), $config[xiantime])}',
    '{echo sl("jiangetaiduan")}',
    '{echo sl("ipadressnotallow")}',
    '{echo sprintf(sl("xianguanzhu"), $config[gongzhonghao])}',
    '{echo sl("notexists_huifu")}'

];
$('.votenow').on('click',function(){
    var vid = $(this).attr('data-vid');
    var jid = $(this).attr('data-jid');
    var url = 'plugin.php?id=xigua_vote:index&ac=votenow&jid='+jid+'&vid='+vid;
    $.ajax({
        type: 'POST',
        dataType: 'json',
        url: url,
        data: {formhash:'{FORMHASH}'},
        success: function (data) {
            var addd = 1;
            <!--{if stripos($_SERVER['HTTP_USER_AGENT'], 'magapp') !== false}-->
            addd = parseInt('{$config['zbeishu']}');
            <!--{/if}-->
            if(data.error==0){
                alert_pop('{echo sl("votesucceed")}');
                var totalvote = $('span.totalvote');
                totalvote.html((parseInt(totalvote.html())+addd)+' {$config[touunit]}');
            }else if(data.error){
                if(data.msg=='notstart'){
                    alert_pop('{echo sl("notstart")}');
                    return;
                }
                if(data.error == 14){
                    <!--{if APPBYME}-->
                    alert('{lang login}');
                    window.location.href = window.location.href+'&relo=1';
                    <!--{else}-->
                    $('#tip14').css('display','-webkit-box');
                    <!--{/if}-->
                }else if(data.error == 13){
                    alert_pop(data.msg);
                }else if(data.error<16){
                    alert_pop(voteerr[data.error]);
                }else{
                    alert_pop(data.msg);
                }
            }else{
                alert_pop(voteerr[0]);
            }
        },
        error:function(){
            alert_pop(voteerr[0]);
        }
    });
});
</script>
{$shareHtml}
<!--{if !$config[allowbaoming]}-->
<style>.bottom2 li{width:33.33333%}</style>
<!--{/if}-->
<div class="bottom2">
    <ul>
        <a href="plugin.php?id=xigua_vote:index&vid={$vid}"><li class="b_li2">{$btms[0]}</li></a>
        <!--{if $config[allowbaoming]}--><a href="$baominglink"><li class="b_li1">{if !$myjdata}{$btms[1]}{else}{$config[hasbao]}{/if}</li></a><!--{/if}-->
        <a href="#cont1"><li class="b_li5">{$btms[2]}</li></a>
        <a href="plugin.php?id=xigua_vote:index&vid={$vid}&sort=all"><li class="b_li3">{$btms[3]}</li></a>
    </ul>
</div>




<!--{if $needamlogin}-->
<script src="http://7xspc4.com2.z0.glb.qiniucdn.com/release%2Fjs%2Fsq-2.3.js"></script>
<script>
    connectSQJavascriptBridge(function(){
        sq.login(function(userInfo){
            if(userInfo.device){
                setcookie('userid', userInfo.userId, 86400);
                setcookie('username', userInfo.userName, 86400);
                setcookie('useravator', userInfo.userAvator, 86400);
                window.location.reload();
            }
        });
    });
    var cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}';
    function setcookie(cookieName, cookieValue, seconds, path, domain, secure) {
        if(cookieValue == '' || seconds < 0) {
            cookieValue = '';
            seconds = -2592000;
        }
        if(seconds) {
            var expires = new Date();
            expires.setTime(expires.getTime() + seconds * 1000);
        }
        domain = !domain ? cookiedomain : domain;
        path = !path ? cookiepath : path;
        document.cookie = escape(cookiepre + cookieName) + '=' + escape(cookieValue)
            + (expires ? '; expires=' + expires.toGMTString() : '')
            + (path ? '; path=' + path : '/')
            + (domain ? '; domain=' + domain : '')
            + (secure ? '; secure' : '');
    }

    function getcookie(name, nounescape) {
        name = cookiepre + name;
        var cookie_start = document.cookie.indexOf(name);
        var cookie_end = document.cookie.indexOf(";", cookie_start);
        if(cookie_start == -1) {
            return '';
        } else {
            var v = document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length));
            return !nounescape ? unescape(v) : v;
        }
    }
</script>
<!--{/if}-->


<script>
    !function(){function n(n){if(!window.MagAndroidClient){if(window.WebViewJavascriptBridge)return n(WebViewJavascriptBridge);if(document.addEventListener("WebViewJavascriptBridgeReady",function(i){n(WebViewJavascriptBridge)},!1),window.WVJBCallbacks)return window.WVJBCallbacks.push(n);window.WVJBCallbacks=[n];var i=document.createElement("iframe");i.style.display="none",i.src="wvjbscheme://__BRIDGE_LOADED__",document.documentElement.appendChild(i),setTimeout(function(){document.documentElement.removeChild(i)},0)}}n(function(n){n.init&&"function"==typeof n.init&&n.init(function(n,i){}),n.registerHandler("jsCallBack",function(n,i){var o=JSON.parse(n),a=o.id,c=o.val,e=mag.callbacks[a];e&&(e.type&&"json"==e.type&&c&&(c=JSON.parse(c)),e.success(c))})}),mag={VERSION:"1.0",ready:function(i){n(function(){i()}),window.MagAndroidClient&&i()},callbacks:{},iosConnect:n,jsCallBack:function(n,i){var o=mag.callbacks[n];o&&(o.type&&"json"==o.type&&i&&(i=JSON.parse(i)),o.success(i))},getLocation:function(i){i&&(mag.callbacks.getLocation={type:"json",success:i},window.MagAndroidClient&&window.MagAndroidClient.getLocation(),n(function(n){n.callHandler("getLocation","",function(n){})}))},mapPick:function(i){i&&(mag.callbacks.mapPick={type:"json",success:i},window.MagAndroidClient&&window.MagAndroidClient.mapPick(),n(function(n){n.callHandler("mapPick","",function(){})}))},closeWin:function(){window.MagAndroidClient&&window.MagAndroidClient.closeWin(),n(function(n){n.callHandler("closeWin","",function(n){})})},previewImage:function(i){var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.previewImage(o),n(function(n){n.callHandler("previewImage",o,function(n){})})},picPick:function(i){mag.callbacks.picPickPreview={type:"json",success:i.preview},mag.callbacks.picPickSuccess={type:"json",success:i.success},mag.callbacks.picPickFail={type:"json",success:i.fail};var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.picPick(o),n(function(n){n.callHandler("picPick",o,function(n){})})},camera:function(i){mag.callbacks.cameraPreview={type:"json",success:i.preview},mag.callbacks.cameraSuccess={type:"json",success:i.success},mag.callbacks.cameraFail={type:"json",success:i.fail};var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.camera(o),n(function(n){n.callHandler("camera",o,function(n){})})},setData:function(i){var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.setData(o),n(function(n){n.callHandler("setData",o,function(n){})})},share:function(i,o){mag.callbacks.shareSuccess={type:"",success:o},window.MagAndroidClient&&window.MagAndroidClient.share(i),n(function(n){n.callHandler("share",i,function(n){})})},socialBind:function(i,o,a){mag.callbacks.bindOnSuccess={type:"json",success:o},mag.callbacks.bindOnFail={type:"json",success:a},window.MagAndroidClient&&window.MagAndroidClient.socialBind(i),n(function(n){n.callHandler("socialBind",i,function(n){})})},report:function(i){var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.report(o),n(function(n){n.callHandler("report",o,function(n){})})},scanQR:function(i){i&&(mag.callbacks.scanQR={type:"",success:i},window.MagAndroidClient&&window.MagAndroidClient.scanQR(),n(function(n){n.callHandler("scanQR","",function(n){})}))},actionSheet:function(i,o){if(o){var a=JSON.stringify(i);mag.callbacks.actionSheet={type:"json",success:o},window.MagAndroidClient&&window.MagAndroidClient.actionSheet(a),n(function(n){n.callHandler("actionSheet",a,function(n){})})}},toast:function(i){window.MagAndroidClient&&window.MagAndroidClient.toast(i),n(function(n){n.callHandler("toast",i,function(n){})})},dialog:function(i){var o=JSON.stringify(i);mag.callbacks.dialogSuccess={type:"json",success:i.success},mag.callbacks.dialogCancel={type:"json",success:i.cancel},window.MagAndroidClient&&window.MagAndroidClient.dialog(o),n(function(n){n.callHandler("dialog",o,function(n){})})},progress:function(){window.MagAndroidClient&&window.MagAndroidClient.progress(),n(function(n){n.callHandler("progress","",function(n){})})},hideProgress:function(){window.MagAndroidClient&&window.MagAndroidClient.hideProgress(),n(function(n){n.callHandler("hideProgress","",function(n){})})},setTitle:function(i){window.MagAndroidClient&&window.MagAndroidClient.setTitle(i),n(function(n){n.callHandler("setTitle",i,function(n){})})},showNavigation:function(){window.MagAndroidClient&&window.MagAndroidClient.showNavigation(),n(function(n){n.callHandler("showNavigation","",function(n){})})},hideNavigation:function(){window.MagAndroidClient&&window.MagAndroidClient.hideNavigation(),n(function(n){n.callHandler("hideNavigation","",function(n){})})},setNavigationColor:function(i){window.MagAndroidClient&&window.MagAndroidClient.setNavigationColor(i),n(function(n){n.callHandler("setNavigationColor",i,function(n){})})},hideMore:function(){window.MagAndroidClient&&window.MagAndroidClient.hideMore(),n(function(n){n.callHandler("hideMore","",function(n){})})},showMore:function(){window.MagAndroidClient&&window.MagAndroidClient.showMore(),n(function(n){n.callHandler("showMore","",function(n){})})},tel:function(i){window.MagAndroidClient&&window.MagAndroidClient.tel(i),n(function(n){n.callHandler("tel",i,function(n){})})},sms:function(i,o){var a=JSON.stringify({phone:i,content:o});window.MagAndroidClient&&window.MagAndroidClient.sms(a),n(function(n){n.callHandler("sms",a,function(n){})})},toLogin:function(i){mag.callbacks.loginSuccess={type:"json",success:i},window.MagAndroidClient&&window.MagAndroidClient.toLogin(),n(function(n){n.callHandler("toLogin","",function(n){})})},toUserHome:function(i){window.MagAndroidClient&&window.MagAndroidClient.toUserHome(i),n(function(n){n.callHandler("toUserHome",i,function(n){})})},commentBar:function(i){var o=JSON.stringify(i);i.onComment&&(mag.callbacks.commentBar={type:"json",success:i.onComment}),i.onPageSelect&&(mag.callbacks.pageSelect={type:"json",success:i.onPageSelect}),i.onApplaud&&(mag.callbacks.applaud={type:"json",success:i.onApplaud}),window.MagAndroidClient&&window.MagAndroidClient.commentBar(o),n(function(n){n.callHandler("commentBar",o,function(n){})})},toComment:function(i){var o=JSON.stringify(i);i.success&&(mag.callbacks.comment={type:"json",success:i.success}),window.MagAndroidClient&&window.MagAndroidClient.toComment(o),n(function(n){n.callHandler("toComment",o,function(n){})})},newWin:function(i,o){i.indexOf("?")<0&&(i+="?");for(var a in o)i+="&"+a+"="+o[a];window.MagAndroidClient&&window.MagAndroidClient.newWin(i),n(function(n){n.callHandler("newWin",i,function(n){})})},setPageLife:function(n){mag.callbacks.pageAppear={type:"",success:n.pageAppear},mag.callbacks.pageDisappear={type:"",success:n.pageDisappear}},pay:function(i,o,a){mag.callbacks.payOnSuccess={type:"",success:o},mag.callbacks.payOnFail={type:"",success:a};var c=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.pay(c),n(function(n){n.callHandler("pay",c,function(n){})})},alipay:function(i,o,a){if(!i)return!1;mag.callbacks.alipayOnSuccess={type:"",success:o},mag.callbacks.alipayOnFail={type:"",success:a},window.MagAndroidClient&&window.MagAndroidClient.alipay(i),n(function(n){n.callHandler("alipay",i,function(n){})})},phoneBind:function(i){mag.callbacks.phoneBindSuccess={type:"string",success:i},window.MagAndroidClient&&window.MagAndroidClient.phoneBind(),n(function(n){n.callHandler("phoneBind","",function(n){})})},qqConnectLogin:function(i){window.MagAndroidClient&&window.MagAndroidClient.qqConnectLogin(i),n(function(n){n.callHandler("qqConnectLogin",i,function(n){})})},bounceEnable:function(i){n(function(n){n.callHandler("bounceEnable",i,function(n){})})}},window.mag=mag,mag.VERSION="1.0"}();

    mag.setData({
        shareData: {
            title: '$navtitle',
            des: '$navdesc',
            picurl: '$img',
            linkurl: '$cururl'
        }
    });
    mag.bounceEnable('false');
</script>
</body>
</html>