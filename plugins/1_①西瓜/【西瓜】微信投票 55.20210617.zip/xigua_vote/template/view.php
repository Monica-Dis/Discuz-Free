<?php exit('Access Denied!');?>
<!doctype html>
<html>
<head>
    <meta charset="{CHARSET}">
    <title>{$navtitle}</title>
</head>
<body>
<img src="$qrurl"/>
</body>
</html>
