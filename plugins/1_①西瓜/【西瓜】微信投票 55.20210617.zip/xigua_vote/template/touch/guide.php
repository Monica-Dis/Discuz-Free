<?php exit('Access Denied!')?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link href="source/plugin/xigua_vote/static/{$stylecss}.css?t={$pluginversion}" rel="stylesheet"/>
    <link href="source/plugin/xigua_vote/static/icomoon/style.css?t={$pluginversion}" rel="stylesheet"/>
    <style>*{font-size:14px}</style>
</head>
<body class="guanzhubody">
<section class="guanzhu">
    <h2>{echo sl('c1');}</h2>
    <img src="{$config[gongzhongcode]}" width="157" height="157">
    <h3>{echo sl('c3')}</h3>
    <p>{echo sl('c4')}</p>
    <span class="btnm">{$config[gongzhonghao]}</span>
    <p>{echo sl('c5')}</p>
    <h2>{echo sl('c2');}</h2>
    <h3>{echo sprintf(sl('c6'), {$config[gongzhong]});}</h3>
    <p>{echo sl('c7');}</p>
</section>
</body>
</html>