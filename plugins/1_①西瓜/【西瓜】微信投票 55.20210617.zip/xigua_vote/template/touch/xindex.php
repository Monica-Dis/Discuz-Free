<?php exit('Access Denied!');?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="{CHARSET}">
  <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
  <meta name="apple-mobile-web-app-capable" content="yes"/>
  <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
  <meta content="telephone=no" name="format-detection"/>
  <title>{$navtitle}</title>
  <meta name="keywords" content="">
  <meta name="description" content="$navdesc">
  <link href="source/plugin/xigua_vote/static/{$stylecss}.css?t={$pluginversion}" rel="stylesheet"/>
  <link href="source/plugin/xigua_vote/static/icomoon/style.css?t={$pluginversion}" rel="stylesheet"/>
  <!--{if $config['wh']}--><style>.star-ul .star-face span{margin-top:$config['wh']}</style><!--{/if}-->
</head>
<body>
<!--{if $config['onlyallowamjoin']}-->
<!--{if APPBYME}-->
    <!--{eval $baominglink = "plugin.php?id=xigua_vote:index&vid=$vid&ac=signup";}-->
<!--{else}-->
    <!--{eval $baominglink = "javascript:$('#tip14').css('display','-webkit-box');";}-->
<!--{/if}-->
<!--{/if}-->

<div class="container_map_ami container_map">
  <section id="header" class="header">
    <span class="rules" data-cate="0"></span>
    <a href="#cont1" class="rules_text">{echo sl('a6')}</a>
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $data['cover'] $item}-->
            <div><a><img src="{$item}"/></a></div>
            <!--{/loop}-->
        </div>
      <nav class="bullets">
        <ul class="position"><!--{loop $data['cover'] $index $item}--><li {if $index==0}class="current"{/if}></li><!--{/loop}--></ul>
      </nav>
    </div>
    <img id="swipload" style="display:block" src="{$data[cover][0]}">
  </section>

  <section class="index-wrap">
<!--{if $config[allowbaoming]}-->
    <div class="baomingbtn">
      <a class="btn btn2" href="{if !$joinend}$baominglink{else}javascript:alert_pop('{echo sl('a5')}');{/if}">
        {if !$jdata}{echo sl('a4')}{else}{$config[hasbao]}{/if}</a>
    </div>
<!--{/if}-->
      <!--{if $config[daojistart]}-->
      <style>
          .timectrl .timer{display:inline}
          .timectrl .timer strong{font-size:16px;margin-left:5px;}
          .timectrl .timer strong:first-child{margin-left:0;}
          .timectrl{margin-top:20px;text-align:center}
      </style>
      <div class="timectrl">
          <strong>{$config['zendtimetip']}</strong>
          <div class="timer" id="timer"></div>
      </div>
      <!--{/if}-->
    <div class="topna cl">
      <ul class="cl">
        <li><p>{echo sl('a1')}</p><span>{$data[joins]}</span></li>
        <li><p>{echo sl('a2')}</p><span class="totalvote">{$data[votes]}</span></li>
        <li><p>{echo sl('a3')}</p><span>{$data[views]}</span></li>
      </ul>
    </div>
  </section>

  <ul class="menu-tab cl">
    <li>
      <a href="plugin.php?id=xigua_vote:index&vid=$vid"><div <!--{if !$_GET[sort]}-->class="tab-cur"<!--{/if}-->>{$config[newest]}</div></a>
    </li>
    <li>
      <a href="plugin.php?id=xigua_vote:index&vid=$vid&sort=hot"><div <!--{if $_GET[sort]=='hot'}-->class="tab-cur"<!--{/if}-->>{$config[hotest]}</div></a>
    </li>
    <li id="more-list">
      <a href="plugin.php?id=xigua_vote:index&vid=$vid&sort=all"><div <!--{if $_GET[sort]=='all'}-->class="tab-cur"<!--{/if}-->><p class="tab-more-p">{$config[paihang]}<span class="icon-chart-bar"></span></p></div></a>
    </li>
  </ul>

  <article class="main-cont">

      <!--{if $GLOBALS['cgroup']}-->
      <ul class="topic-menu cl">
          <li class="<!--{if !$_GET[cgr]}-->btn3<!--{else}-->btn1<!--{/if}-->">
              <a href="plugin.php?id=xigua_vote:index&vid=$vid&sort=$_GET[sort]">{echo lang('core', 'title_share_all')}</a>
          </li>
          <!--{loop $GLOBALS['cgroup'] $cgroup_key $cgroup_item}-->
          <li class="<!--{if $_GET[cgr]==$cgroup_key}-->btn3<!--{else}-->btn1<!--{/if}-->">
              <a href="plugin.php?id=xigua_vote:index&vid=$vid&sort=$_GET[sort]&cgr=$cgroup_key">$cgroup_item</a>
          </li>
          <!--{/loop}-->
      </ul>
      <!--{/if}-->

    <section id="search" class="search">
      <div class="search-div">
        <form id="search-form" action="" method="post" accept-charset="utf-8">
          <input type="hidden" name="formhash" value="{FORMHASH}">
        <input id="search-input" name="keyword" class="search-input" autocomplete="off" type="text" placeholder="{$config[searchtxt]}">
        <span id="search-btn" class="search-btn">{echo sl('o33')}</span>
        </form>
      </div>
    </section>

    <section class="advance">
      <span class="icon-sound sound"></span>
      <p style="display:block">{echo sprintf(sl('o32'), $config[lapiao], $config[lapiao])}</p>
    </section>

    <!--{if $_GET[sort]=='all'}-->
    <ul class="vote_index cl">
      <!--{loop $list $key $item}-->
      <li {if $item[rank]<=3}class="inrank"{/if}>
        <p class="p{$item[rank]}">{$item[rank]}</p>
        <p class="vote_face"><a class="cl" href="plugin.php?id=xigua_vote:index&ac=view&vid={$vid}&jid={$item[jid]}"><img src="{$item[pic][0]}" onerror="this.error=null;this.src='source/plugin/xigua_vote/static/no1.png'"></a></p>
        <p class="vote_name"><a class="cl" href="plugin.php?id=xigua_vote:index&ac=view&vid={$vid}&jid={$item[jid]}">{$item[name]}</a></p>
        <p class="vote_num">{$item[totalvotes]} {$config[touunit]}</p>
        <p class="vote_vote votenow" data-jid="{$item[jid]}" data-vid="{$vid}">{$config[tougai]}</p>
        <!--{if $showshare}--><p class="vote_share" data-jid="{$item[jid]}" data-scr="{$item[pic][0]}" data-navtitle="{$item[navtitle]}" data-navdesc="{$item[navdesc]}">{$config[lapiao]}</p>
        <!--{else}-->
        <style>.vote_index li p.vote_vote{border-right:0}</style>
        <!--{/if}-->
        </li>
      <!--{/loop}-->
    </ul>
    <!--{else}-->
    <ul class="cl star-ul">
      <!--{loop $list $key $item}-->
      <li class="item {if $item[rank]<=3 && $_GET[sort]=='hot'}inrank{/if}">
        <a class="cl" href="plugin.php?id=xigua_vote:index&ac=view&vid={$vid}&jid={$item[jid]}">
          <p class="star-ranking">{echo $item[bsid] ? $item[bsid] : $item[jid]}{echo sl('n3')}</p>
          <p class="star-face"><span></span>
<!--<img src="{$item[pic][0]}" onerror="this.error=null;this.src='source/plugin/xigua_vote/static/no1.png'">-->
            <em style="background:url({$item[pic][0]}) no-repeat center;background-size:cover;"></em>
          </p>
        </a>
        <div class="cl starp">
          <p class="star-name fl">{$item[name]}</p>
          <p class="star-num fr">{$item[totalvotes]} {$config[touunit]}</p>
        </div>
        <div class="cl">
        <!--{if $showshare}-->
            <a class="btn fl btn3 vote_share" data-jid="{$item[jid]}" data-scr="{$item[pic][0]}" data-navtitle="{$item[navtitle]}" data-navdesc="{$item[navdesc]}">{$config[lapiao]}</a>
            <a class="btn fr btn2 votenow" data-jid="{$item[jid]}" data-vid="{$vid}">{$config[tougai]}</a>
        <!--{else}-->
            <a class="btn btn2 votenow" data-jid="{$item[jid]}" data-vid="{$vid}">{$config[tougai]}</a>
        <!--{/if}-->
        </div>
      </li>
      <!--{/loop}-->
    </ul>
    <!--{/if}-->

    <!--{if $multi}--><div class="multi">$multi</div><!--{else}--><!--{/if}-->
  </article>

  <article class="cont1">
    <!--{if $data[content]}-->
    <a name="cont1" id="cont1" class="cont_title">{echo sl('m23')}</a>
    <div class="cont_content cl">{$data[content]}</div>
    <!--{/if}-->
    <!--{if $data[prizecontent]}-->
    <h2 class="cont_title">{echo sl('m24')}</h2>
    <div class="cont_content cl">{$data[prizecontent]}</div>
    <!--{/if}-->
    <!--{if $data[statement]}-->
    <h2 class="cont_title">{echo sl('m25')}</h2>
    <div class="cont_content cl">{$data[statement]}</div>
    <!--{/if}-->
    <!--{if $data[zanzhu]}-->
    <h2 class="cont_title">{echo sl('zanzhu')}</h2>
    <div class="cont_content cl">{$data[zanzhu]}</div>
    <!--{/if}-->
  </article>
</div>

<!--{if $data[music]}-->
<div id="audio_btn" class="video_exist play_yinfu" style="display: block;">
  <div id="yinfu" class="rotate"></div>
  <audio loop="loop" id="media" autoplay="autoplay" preload="preload">
    <source src="{$data[music]}" type="audio/mpeg" />
  </audio>
</div>
<!--{/if}-->

<section id="tip14" class="mask"<!--{if (!IN_WECHAT && !$voteend) || $mustsubscribe}--> style="display:-webkit-box"<!--{/if}-->>
  <div class="modal"><span class="close" onclick="closex('tip14')"></span>
    <h2>{echo sl('o29')}</h2>
    <!--{if $config[onlyam]}-->
    <p>{$config[guideapp]}</p>
      <!--{if $config[gongzhongcode]}--><img src="{$config[gongzhongcode]}" style="display: block;width:157px;height:157px;margin: 0 auto -10px;"><!--{/if}-->
    <a href="{$config[guideapplink]}" class="btns">{$config[guideappbtn]}</a>
    <!--{else}-->
    <p>{echo sprintf(sl('o31'),$config[gongzhonghao], $config[gongzhong])}</p>
    <!--{if $config[gongzhongcode]}--><img src="{$config[gongzhongcode]}" style="display: block;width:157px;height:157px;margin: 0 auto -10px;"><!--{/if}-->
    <a href="plugin.php?id=xigua_vote:index&ac=guide&vid={$vid}" class="btns">{echo sl('o28')}</a>
    <!--{/if}-->
  </div>
</section>

<section class="mask" id="endtip" <!--{if $voteend}--> style="display:-webkit-box"<!--{/if}-->>
  <section class="alltip">
    <span class="close" onclick="closex('endtip')"></span>
    <h2>{$config[endtip]}</h2>
    <a href="plugin.php?id=xigua_vote:index&ac=guide&vid={$vid}" class="btns">{echo sl('o28')}</a>
  </section>
</section>

<section class="mask animated-fast" id="alltip">
  <section class="alltip">
    <span class="close" onclick="closex('alltip')"></span>
    <h2></h2>
      <!--{if $showshare}--><a href="javascript:;" class="btns vote_share">{echo sl('o27')}</a><!--{/if}-->
  </section>
</section>

<div id="wechat-mask"><div id="wechat-guider"></div></div>
<div id="backtotop" class="backtotop"><span class="icon-chevron-up"></span></div>
<script src="source/plugin/xigua_vote/static/jquery.min.js?t={$pluginversion}"></script>
<script src="source/plugin/xigua_vote/static/custom.js?t={$pluginversion}"></script>
<script>
  var voteerr=[
    '{echo sl("votefail")}',
    '{echo sl("votefail")}',
    '{echo sl("voteend")}',
    '{echo sl("voteperday")}',
    '{echo sl("maxinjoin")}',
    '{echo sl("iplimit")}',
    '{echo sl("weishenhe")}',
    '{echo sl("notexists")}',
    '{echo sl("mustinwechat")}',
    '{echo sl("maxprejoinday")}',
    '{echo sl("maxatvote")}',
    '{echo sprintf(sl("notintime"), $config[xiantime])}',
    '{echo sl("jiangetaiduan")}',
    '{echo sl("ipadressnotallow")}',
    '{echo sprintf(sl("xianguanzhu"), $config[gongzhonghao])}',
    '{echo sl("notexists_huifu")}'

  ];
  $('.votenow').on('click',function(){
    var thi = $(this);
    var vid = thi.attr('data-vid');
    var jid = thi.attr('data-jid');
    var url = 'plugin.php?id=xigua_vote:index&ac=votenow&jid='+jid+'&vid='+vid;
    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: url,
      data: {formhash:'{FORMHASH}'},
      success: function (data) {
        if(data.error==0){
          alert_pop('{echo sl("votesucceed")}');
          var starnum = thi.parent().parent().find('.star-num');
          var votenum = thi.parent().find('.vote_num');
          var totalvote = $('span.totalvote');
          starnum.html((parseInt(starnum.html())+1)+' {$config[touunit]}');
          votenum.html((parseInt(votenum.html())+1)+' {$config[touunit]}');
          totalvote.html((parseInt(totalvote.html())+1));
        }else if(data.error){
            if(data.msg=='notstart'){
                alert_pop('{echo sl("notstart")}');
                return;
            }
          if(data.error == 14){
            <!--{if APPBYME}-->
            window.location.href = window.location.href+'&relo=1';
            <!--{else}-->
            $('#tip14').css('display','-webkit-box');
            <!--{/if}-->
          }else if(data.error == 13){
            alert_pop(data.msg);
          }else if(data.error<16){
            alert_pop(voteerr[data.error]);
          }else{
            alert_pop(data.msg);
          }
        }else{
          alert_pop(voteerr[0]);
        }
      },
      error:function(){
        alert_pop(voteerr[0]);
      }
    });
  });
</script>
{$shareHtml}
<!--{if !$config[allowbaoming]}-->
<style>.bottom2 li{width:33.33333%}</style>
<!--{/if}-->
<div class="bottom2">
  <ul>
    <a href="plugin.php?id=xigua_vote:index&vid={$vid}"><li class="b_li2">{$btms[0]}</li></a>
      <!--{if $config[allowbaoming]}--><a href="$baominglink"><li class="b_li1">
        {if !$jdata}{$btms[1]}{else}{$config[hasbao]}{/if}</li></a><!--{/if}-->
    <a href="#cont1"><li class="b_li5">{$btms[2]}</li></a>
    <a href="plugin.php?id=xigua_vote:index&vid={$vid}&sort=all"><li class="b_li3">{$btms[3]}</li></a>
  </ul>
</div>

<!--{if $needamlogin}-->
<script src="http://7xspc4.com2.z0.glb.qiniucdn.com/release%2Fjs%2Fsq-2.3.js"></script>
<script>
  connectSQJavascriptBridge(function(){
    sq.login(function(userInfo){
      if(userInfo.device){
        setcookie('userid', userInfo.userId, 86400);
        setcookie('username', userInfo.userName, 86400);
        setcookie('useravator', userInfo.userAvator, 86400);
        window.location.reload();
      }
    });
  });
  var cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}';
  function setcookie(cookieName, cookieValue, seconds, path, domain, secure) {
    if(cookieValue == '' || seconds < 0) {
      cookieValue = '';
      seconds = -2592000;
    }
    if(seconds) {
      var expires = new Date();
      expires.setTime(expires.getTime() + seconds * 1000);
    }
    domain = !domain ? cookiedomain : domain;
    path = !path ? cookiepath : path;
    document.cookie = escape(cookiepre + cookieName) + '=' + escape(cookieValue)
        + (expires ? '; expires=' + expires.toGMTString() : '')
        + (path ? '; path=' + path : '/')
        + (domain ? '; domain=' + domain : '')
        + (secure ? '; secure' : '');
  }

  function getcookie(name, nounescape) {
    name = cookiepre + name;
    var cookie_start = document.cookie.indexOf(name);
    var cookie_end = document.cookie.indexOf(";", cookie_start);
    if(cookie_start == -1) {
      return '';
    } else {
      var v = document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length));
      return !nounescape ? unescape(v) : v;
    }
  }
</script>
<!--{/if}-->
<!--{eval $tlang = lang('core', 'date');}-->
<script>
    var endtime= new Date('{$voteend_string}');
    var starttime= new Date('{$crts_string}');
    var keeptime = endtime - starttime;
    var itimer = document.getElementById("timer");
    var handler = '';
    function GetRTime(){
        var nowtime = new Date();
        var t = endtime.getTime() - nowtime.getTime();
        if(t<0){
            clearInterval(handler);
            itimer.innerHTML = '{$voteend_string}';
            return;
        }
        var dd = t/1000;

        var d=Math.floor(dd/3600/24);
        var h=Math.floor(dd/3600%24);
        var m=Math.floor(dd/60%60);
        var s=Math.floor(dd%60);
//        var o=Math.floor(t/10%10);

        var ddis = '', hdis = '', mdis = '', sdis = '';
        if(h<10){h = '0'+h;}
        if(m<10){m = '0'+m;}
        if(s<10){s = '0'+s;}
//        if(o<10){o = '0'+o;}
        if(d){
            ddis = '<strong>'+d+'</strong>' + "{$tlang[day]}";
        }
        hdis = '<strong>'+h+'</strong>' + "{$tlang[hour]}";
        mdis = '<strong>'+m+'</strong>' + "{$tlang[min]}";
        sdis = '<strong>'+s+'</strong>' + "{$tlang[sec]}";
        itimer.innerHTML = ddis + hdis + mdis + sdis /*+ ('<strong>'+o+'</strong>')*/;
    }
    <!--{if $config[daojistart]}-->
    handler = setInterval(GetRTime, 1000);
    <!--{/if}-->
</script>
</body>
</html>