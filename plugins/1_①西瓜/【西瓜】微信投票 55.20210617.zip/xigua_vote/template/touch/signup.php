<?php exit('Access Denied!');?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}{$config[baomingtitle]}</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link href="source/plugin/xigua_vote/static/{$stylecss}.css?t={$pluginversion}" rel="stylesheet"/>
    <link href="source/plugin/xigua_vote/static/icomoon/style.css?t={$pluginversion}" rel="stylesheet"/>
    <style>*{font-size:14px}

        .signupform li span{
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;}
    </style>
</head>
<body>
<!--{eval $joinfield = $data[joinfield]}-->
<div class="container_map_ami container_map">

    <h2 class="signtitle">{$config[baomingtitle]}</h2>
    <form id="signupform" action="plugin.php?id=xigua_vote:index&vid={$vid}&ac=signup&jid={$jdata[jid]}" {$formfix}>
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <ul class="signupform cl">
        <!--{if $joinfield[name][require]}-->
        <li>
            <span>{$joinfield[name][etc]}</span>
            <span><input type="text" name="append[name]" value="{$jdata[name]}" placeholder="{$joinfield[name][etc]}" ></span>
        </li>
        <!--{/if}-->
        <!--{if $joinfield[mobile][require]}-->
        <li>
            <span>{$joinfield[mobile][etc]}</span>
            <span><input type="text" name="append[mobile]" value="{$jdata[mobile]}" placeholder="{$joinfield[mobile][etc]}" ></span>
        </li>
        <!--{/if}-->
        <!--{if $joinfield[sex][require]}-->
        <li>
            <span>{$joinfield[sex][etc]}</span>
            <span>
                <input type="hidden" name="append[sex]" value="{if $jdata}$jdata[sex]{else}1{/if}">
                <a class="gender {if $jdata}{if $jdata[sex]==1}checked{/if}{else}checked{/if}" data-value="1">{echo sl('nan')}
                    {if $jdata}{if $jdata[sex]==1}<i class="icon-checkmark"></i>{/if}{else}<i class="icon-checkmark"></i>{/if}
                </a>
                <a class="gender {if $jdata}{if $jdata[sex]==0}checked{/if}{else}{/if}" data-value="0">{echo sl('nv')}
                    {if $jdata}{if $jdata[sex]==0}<i class="icon-checkmark"></i>{/if}{else}{/if}
                </a>
            </span>
        </li>
        <!--{/if}-->


        <!--{eval
        for($i=1;$i<=20;$i++) :
            $fd = 'ext'.$i;
            if($joinfield[$fd]['require']):
                echo '<li><span>'.$joinfield[$fd]['etc'].'</span>            <span><input placeholder="'.$joinfield[$fd]['etc'].'" type="text" name="append['.$fd.']" value="'.$jdata[$fd].'" ></span>        </li>';
            endif;
        endfor;
        }-->





        <!--{if $joinfield[profile][require]}-->
        <li>
            <span style="line-height:70px">{$joinfield[profile][etc]}</span>
            <span>
                <textarea name="append[profile]" placeholder="{$joinfield[profile][etc]}">{$jdata[profile]}</textarea>
            </span>
        </li>
        <!--{/if}-->
        <!--{if $joinfield[pic][require]}-->
        <li>
            <span>{$joinfield[pic][etc]}</span>
            <span class="cl photolist">
                <!--{if $jdata}-->
                <!--{loop $jdata[pic] $pic}-->
                <div><b style="background:url($pic);"></b><em class="close" onclick="return clex(this);"></em><input type="hidden" name="pic[]" value="$pic" /></div>
                <!--{/loop}-->
                <!--{/if}-->
                <div id="photo">
                    <em class="photo icon-plus2"></em>
                    <input type="file" id="filedata" >
                </div>
            </span>
        </li>
        <!--{/if}-->

        <!--{eval

            $groupconfig = array();
            if(trim($data['groupconfig'])) :
                foreach (explode("\n", trim($data['groupconfig'])) as $index => $item) :
                    list($tmp_key, $tmp_val) = explode('=', trim($item));
                    $groupconfig[trim($tmp_key)] = trim($tmp_val);
                endforeach;
                $GLOBALS['cgroup'] = $cgroup = $groupconfig;
                if ($groupconfig) :
                    $cgroupselect = '<select name="append[cgroup]"><option value="">--</option>';
                    foreach ($cgroup as $index => $item) :
                        $selected = $jdata['cgroup']==$index ? 'selected="selected"': '';
                        $cgroupselect .= "<option $selected value=\"$index\">$item</option>";
                    endforeach;
                    $cgroupselect .= "</select>";
                endif;
            endif;
        }-->
        <!--{if $cgroupselect}-->
        <li>
            <span>{echo sl('upconf')}</span>
            <span>$cgroupselect</span>
        </li>
        <!--{/if}-->

        <li class="submitbtnli">
            <p><a class="btn btn2" id="submit">
                    <!--{if $jdata}-->
                    {echo sl('b1');}
                    <!--{else}-->
                    {echo sl('b2');}
                    <!--{/if}-->
                </a></p>
        </li>
        <li>
            <p>{eval
                $baohelpdis = str_replace('<br/><br/>','<br/>', preg_replace('/\s+/', '',nl2br($config['baohelp'])));
                $baohelpjs =  preg_replace('/\s+/', ' ', $config['baohelp']);
                echo $baohelpdis;
                }</p>
        </li>
    </ul>
    </form>
</div>

<section class="mask animated-fast" id="alltip">
    <section class="alltip">
        <span class="close" onclick="closex('alltip')"></span>
        <h2></h2>
        <!--{if $showshare}--><a href="javascript:;" class="btns vote_share">{echo sl('o27');}</a><!--{/if}-->
    </section>
</section>
<div id="backtotop" class="backtotop"><span class="icon-chevron-up"></span></div>
<script src="source/plugin/xigua_vote/static/jquery.min.js?t={$pluginversion}"></script>
<script src="source/plugin/xigua_vote/static/custom.js?t={$pluginversion}"></script>
<script src="source/plugin/xigua_vote/static/lib/mobileFix.mini.js?t={$pluginversion}"></script>
<script src="source/plugin/xigua_vote/static/lib/exif.js?t={$pluginversion}"></script>
<script src="source/plugin/xigua_vote/static/lrz.js?t={$pluginversion}"></script>
<script>
{if !$joinend}
$('#submit').on('click', function(){
    var form = $('#signupform');
    var name    = $.trim($('input[name="append[name]"]').val());
    var mobile  = $.trim($('input[name="append[mobile]"]').val());
    var sex     = $.trim($('input[name="append[sex]"]').val());
    var pic     = $.trim($('input[name="pic[]"]').val());
    var profile = $.trim($('textarea[name="append[profile]"]').val());

    <!--{if $joinfield[name][require]}-->
    if(name==''){
        alert('{echo sl("n5")}{$joinfield[name][etc]}');
        return false;
    }
    <!--{/if}-->
    <!--{if $joinfield[mobile][require]}-->
    if(mobile==''){
        alert('{echo sl("n5")}{$joinfield[mobile][etc]}');
        return false;
    }else if((mobile.length == 11 && /^(1\d{10})$/.test(mobile))==false){
        alert('{echo sl("n5")}{echo sl("b3")}{$joinfield[mobile][etc]}');
        return false;
    }
    <!--{/if}-->
    <!--{if $joinfield[pic][require]}-->
    if(pic==''){
        alert('{echo sl("b4")}{$joinfield[pic][etc]}');
        return false;
    }
    <!--{/if}-->
    <!--{if $joinfield[profile][require]}-->
    if(profile==''){
        alert('{echo sl("n5")}{$joinfield[profile][etc]}');
        return false;
    }
    <!--{/if}-->

    <!--{if $joinfield[ext1][must]}-->if($.trim($('input[name="append[ext1]"]').val())==''){alert('{echo sl("n5")}{$joinfield[ext1][etc]}');return false;}<!--{/if}-->
    <!--{if $joinfield[ext2][must]}-->if($.trim($('input[name="append[ext2]"]').val())==''){alert('{echo sl("n5")}{$joinfield[ext2][etc]}');return false;}<!--{/if}-->
    <!--{if $joinfield[ext3][must]}-->if($.trim($('input[name="append[ext3]"]').val())==''){alert('{echo sl("n5")}{$joinfield[ext3][etc]}');return false;}<!--{/if}-->
    <!--{if $joinfield[ext4][must]}-->if($.trim($('input[name="append[ext4]"]').val())==''){alert('{echo sl("n5")}{$joinfield[ext4][etc]}');return false;}<!--{/if}-->
    <!--{if $joinfield[ext5][must]}-->if($.trim($('input[name="append[ext5]"]').val())==''){alert('{echo sl("n5")}{$joinfield[ext5][etc]}');return false;}<!--{/if}-->
    <!--{if $joinfield[ext6][must]}-->if($.trim($('input[name="append[ext6]"]').val())==''){alert('{echo sl("n5")}{$joinfield[ext6][etc]}');return false;}<!--{/if}-->
    <!--{if $joinfield[ext7][must]}-->if($.trim($('input[name="append[ext7]"]').val())==''){alert('{echo sl("n5")}{$joinfield[ext7][etc]}');return false;}<!--{/if}-->
    $.ajax({
        type:'POST',
        dataType:'json',
        url:form.attr('action'),
        data: form.serialize(),
        success:function(data){
            if(data.error==0){
                alert_pop('<!--{if $jdata}-->{echo sl("b5")}<!--{else}-->{echo sl("b6")}<!--{/if}-->');
                setTimeout(function(){
                    window.location.href ='plugin.php?id=xigua_vote:index&ac=view&vid={$vid}&jid='+data.jid;
                },1000);
            }else{
                alert_pop('{$baohelpjs}');
            }
        },
        error:function(){
            alert_pop('{$baohelpjs}');
        }
    });
    return false;
});
function uploadavatar (obj) {
    /*var file = obj.files[0];
    if (!/image\/\w+/.test(file.type)) {
        alert("ֻ��ѡ��ͼƬ");
        return false;
    }
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function (e) {
        console.log(this.result);
        var results = this.result;
        var clearBase64 =  results.substr(results.indexOf(',') + 1);
        $('<div class="ajaxwaitid"></div>').insertBefore('#photo');
        $.ajax({
            type:'POST',
            dataType:'json',
            url :'plugin.php?id=xigua_vote:index&vid={$vid}&ac=signup&upload=1' ,
            data: {formhash:'{FORMHASH}',img:clearBase64},
            success:function(data){
                $('.ajaxwaitid').remove();
                if(data.error==0){
                    $('<div><b style="background:url('+results+')"></b><em class="close" onclick="return clex(this);"></em><input type="hidden" name="pic[]" value="'+data.url+'" /></div>').insertBefore('#photo');
                }else{
                    alert_pop('{$baohelpjs}');
                }
            },
            error:function(){
                $('.ajaxwaitid').remove();
                alert_pop('{$baohelpjs}');
            }
        });
    }
    return false;*/
    lrz(obj.files[0], {width:1080, quality:10}, function (results) {
        var clearBase64 =  results.base64.substr(results.base64.indexOf(',') + 1);
        $('<div class="ajaxwaitid"></div>').insertBefore('#photo');
        $.ajax({
            type:'POST',
            dataType:'json',
            url :'plugin.php?id=xigua_vote:index&vid={$vid}&ac=signup&upload=1' ,
            data: {formhash:'{FORMHASH}',img:clearBase64},
            success:function(data){
                $('.ajaxwaitid').remove();
                if(data.error==0){
                    $('<div><b style="background:url('+results.base64+')"></b><em class="close" onclick="return clex(this);"></em><input type="hidden" name="pic[]" value="'+data.url+'" /></div>').insertBefore('#photo');
                }else{
                    alert_pop('{$baohelpjs}');
                }
            },
            error:function(){
                $('.ajaxwaitid').remove();
                alert_pop('{$baohelpjs}');
            }
        });
    });
    obj.value = '';
    return false;
}
{else}
alert_pop('{echo sl("a5")}');
{/if}
function clex(obj){
    $(obj).parent().remove();
    return false;
}
</script>

<!--{if $needamlogin}-->
<script src="http://7xspc4.com2.z0.glb.qiniucdn.com/release%2Fjs%2Fsq-2.3.js"></script>
<script>
    connectSQJavascriptBridge(function(){
        sq.login(function(userInfo){
            if(userInfo.userId){
                setcookie('userid', userInfo.userId, 86400);
                setcookie('username', userInfo.userName, 86400);
                setcookie('useravator', userInfo.userAvator, 86400);
                window.location.reload();
            }
        });
    });
    var cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}';
    function setcookie(cookieName, cookieValue, seconds, path, domain, secure) {
        if(cookieValue == '' || seconds < 0) {
            cookieValue = '';
            seconds = -2592000;
        }
        if(seconds) {
            var expires = new Date();
            expires.setTime(expires.getTime() + seconds * 1000);
        }
        domain = !domain ? cookiedomain : domain;
        path = !path ? cookiepath : path;
        document.cookie = escape(cookiepre + cookieName) + '=' + escape(cookieValue)
            + (expires ? '; expires=' + expires.toGMTString() : '')
            + (path ? '; path=' + path : '/')
            + (domain ? '; domain=' + domain : '')
            + (secure ? '; secure' : '');
    }

    function getcookie(name, nounescape) {
        name = cookiepre + name;
        var cookie_start = document.cookie.indexOf(name);
        var cookie_end = document.cookie.indexOf(";", cookie_start);
        if(cookie_start == -1) {
            return '';
        } else {
            var v = document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length));
            return !nounescape ? unescape(v) : v;
        }
    }
</script>
<!--{/if}-->
</body>
</html>