<?php exit('Access Denied!');?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <meta name="keywords" content="">
    <meta name="description" content="$navdesc">
    <link href="source/plugin/xigua_vote/static/{$stylecss}.css?t={$pluginversion}" rel="stylesheet"/>
    <link href="source/plugin/xigua_vote/static/icomoon/style.css?t={$pluginversion}" rel="stylesheet"/>
    <style>*{font-size:14px}</style>
</head>
<body>

<!--{if $config['onlyallowamjoin']}-->
<!--{if APPBYME}-->
<!--{eval $baominglink = "plugin.php?id=xigua_vote:index&vid=$vid&ac=signup";}-->
<!--{else}-->
<!--{eval $baominglink = "javascript:$('#tip14').css('display','-webkit-box');";}-->
<!--{/if}-->
<!--{/if}-->

<div class="container_map_ami container_map">
    <!--{if $config[viewlunbo]}-->
    <section id="header" class="header">
        <span class="rules" data-cate="0"></span>
        <a href="#cont1" class="rules_text">{echo sl('a6')}</a>
        <div class="swipe cl">
            <div class="swipe-wrap">
                <!--{loop $data['cover'] $item}-->
                <div><a><img src="{$item}"/></a></div>
                <!--{/loop}-->
            </div>
            <nav class="bullets">
                <ul class="position"><!--{loop $data['cover'] $index $item}--><li {if $index==0}class="current"{/if}></li><!--{/loop}--></ul>
            </nav>
        </div>
        <img id="swipload" style="display:block" src="{$data[cover][0]}">
    </section>
    <!--{/if}-->

    <section class="content1">
        <a class="close closev" href="plugin.php?id=xigua_vote:index&vid={$vid}&rand=1"></a>
        <h2 class="title">{$data[joinfield][name][etc]}{echo sl('a7')}</h2>
        <p class="info">{echo $jdata[bsid] ? $jdata[bsid] : $jdata[jid]}{echo sl('n3')} $jdata[name]  <!--{if $jdata[status]==JOIN_WEISHENHE}-->{echo sl('a8')}<!--{/if}-->
        <span class="totalvote">{$jdata[totalvotes]} {$config[touunit]}</span>
        </p>


        <!--{if $data[joinfield][sex][require]&& !$data[joinfield][sex][show]}-->
        <p class="profile">
            <b>{$data[joinfield][sex][etc]}:</b>
            <!--{if $jdata[sex] == 1}-->{echo sl('nan')}<!--{else}-->{echo sl('nv')}<!--{/if}-->
        </p>
        <!--{/if}-->

        <!--{if $data[joinfield][profile][require]&& !$data[joinfield][profile][show]}-->
        <p class="profile">
            <b>{$data[joinfield][profile][etc]}:</b>
            {$jdata[profile]}
        </p>
        <!--{/if}-->


        <!--{eval
        for($i=1;$i<=20;$i++) :
            $fd = 'ext'.$i;
            if($data['joinfield'][$fd]['require']&& !$data['joinfield'][$fd]['show']):
                echo '<p class="profile"><b>'.$data['joinfield'][$fd]['etc'].':</b>'.$jdata[$fd].'</p>';
            endif;
        endfor;
        }-->

        <!--{if !$data[joinfield][pic][show]}-->
        <!--{loop $jdata[pic] $item}-->
        <img src="{$item}" />
        <!--{/loop}-->
        <!--{/if}-->

        <div class="content1_bottom">
            <a class="btn btn2 votenow" data-jid="{$jid}" data-vid="{$vid}">{$config[xtou]}<!--{if $config[zbeishu] && APPBYME}--> X {$config[zbeishu]}<!--{/if}--></a>
            <!--{if $showshare}--><a class="btn btn3 vote_share" href="javascript:void(0);">{$config[xla]}</a><!--{/if}-->
            <!--{if $config[allowbaoming]}--><a class="btn btn3" href="$baominglink">{echo sl('a4')}</a><!--{/if}-->
            <a class="btn btn3" href="plugin.php?id=xigua_vote:index&vid={$vid}&rand=1">{echo sl('a9')}</a>
        </div>

    </section>

    <!--{if $config[viewshuoming]}-->
    <article class="cont1">
        <!--{if $data[content]}-->
        <a name="cont1" id="cont1" class="cont_title">{echo sl('m23')}</a>
        <div class="cont_content cl">{$data[content]}</div>
        <!--{/if}-->
        <!--{if $data[prizecontent]}-->
        <h2 class="cont_title">{echo sl('m24')}</h2>
        <div class="cont_content cl">{$data[prizecontent]}</div>
        <!--{/if}-->
        <!--{if $data[statement]}-->
        <h2 class="cont_title">{echo sl('m25')}</h2>
        <div class="cont_content cl">{$data[statement]}</div>
        <!--{/if}-->
        <!--{if $data[zanzhu]}-->
        <h2 class="cont_title">{echo sl('zanzhu')}</h2>
        <div class="cont_content cl">{$data[zanzhu]}</div>
        <!--{/if}-->
    </article>
    <!--{/if}-->

    <!--{if $config[comment]}-->{$config[comment]}<!--{/if}-->
</div>

<section id="tip14" class="mask"<!--{if (!IN_WECHAT && !$voteend) || $mustsubscribe}--> style="display:-webkit-box"<!--{/if}-->>
<div class="modal"><span class="close" onclick="closex('tip14')"></span>
    <h2>{echo sl('o29')}</h2>
    <!--{if $config[onlyam]}-->
    <p>{$config[guideapp]}</p>
    <!--{if $config[gongzhongcode]}--><img src="plugin.php?id=xigua_vote:qrcode&jid={$jid}" onerror="this.error=null;this.src='{$config[gongzhongcode]}'" style="display: block;width:157px;height:157px;margin: 0 auto -10px;"><!--{/if}-->
    <a href="{$config[guideapplink]}" class="btns">{$config[guideappbtn]}</a>
    <!--{else}-->
    <p>{echo sprintf(sl('o31'),$config[gongzhonghao], $config[gongzhong])}</p>
    <!--{if $config[gongzhongcode]}--><img src="plugin.php?id=xigua_vote:qrcode&jid={$jid}" onerror="this.error=null;this.src='{$config[gongzhongcode]}'" style="display: block;width:157px;height:157px;margin: 0 auto -10px;"><!--{/if}-->
    <a href="plugin.php?id=xigua_vote:index&ac=guide&vid={$vid}" class="btns">{echo sl('o28')}</a>
    <!--{/if}-->
</div>
</section>

<section class="mask" id="endtip" <!--{if $voteend}--> style="display:-webkit-box"<!--{/if}-->>
<section class="alltip">
    <span class="close" onclick="closex('endtip')"></span>
    <h2>{$config[endtip]}</h2>
    <a href="plugin.php?id=xigua_vote:index&ac=guide&vid={$vid}" class="btns">{echo sl('o28')}</a>
</section>
</section>

<section class="mask  animated-fast" id="alltip">
    <section class="alltip">
        <span class="close" onclick="closex('alltip')"></span>
        <h2></h2>
        <!--{if $showshare}--><a href="javascript:;" class="btns vote_share">{echo sl('o27')}</a><!--{/if}-->
    </section>
</section>
<div id="wechat-mask"><div id="wechat-guider"></div></div>
<div id="backtotop" class="backtotop"><span class="icon-chevron-up"></span></div>
<script src="source/plugin/xigua_vote/static/jquery.min.js?t={$pluginversion}"></script>
<script src="source/plugin/xigua_vote/static/custom.js?t={$pluginversion}"></script>
<script>
var voteerr=[
    '{echo sl("votefail")}',
    '{echo sl("votefail")}',
    '{echo sl("voteend")}',
    '{echo sl("voteperday")}',
    '{echo sl("maxinjoin")}',
    '{echo sl("iplimit")}',
    '{echo sl("weishenhe")}',
    '{echo sl("notexists")}',
    '{echo sl("mustinwechat")}',
    '{echo sl("maxprejoinday")}',
    '{echo sl("maxatvote")}',
    '{echo sprintf(sl("notintime"), $config[xiantime])}',
    '{echo sl("jiangetaiduan")}',
    '{echo sl("ipadressnotallow")}',
    '{echo sprintf(sl("xianguanzhu"), $config[gongzhonghao])}',
    '{echo sl("notexists_huifu")}'

];
$('.votenow').on('click',function(){
    var vid = $(this).attr('data-vid');
    var jid = $(this).attr('data-jid');
    var url = 'plugin.php?id=xigua_vote:index&ac=votenow&jid='+jid+'&vid='+vid;
    $.ajax({
        type: 'POST',
        dataType: 'json',
        url: url,
        data: {formhash:'{FORMHASH}'},
        success: function (data) {
            if(data.error==0){
                alert_pop('{echo sl("votesucceed")}');
                var totalvote = $('span.totalvote');
                totalvote.html((parseInt(totalvote.html())+1)+' {$config[touunit]}');
            }else if(data.error){
                if(data.msg=='notstart'){
                    alert_pop('{echo sl("notstart")}');
                    return;
                }
                if(data.error == 14){
                    <!--{if APPBYME}-->
                    window.location.href = window.location.href+'&relo=1';
                    <!--{else}-->
                    $('#tip14').css('display','-webkit-box');
                    <!--{/if}-->
                }else if(data.error == 13){
                    alert_pop(data.msg);
                }else if(data.error<16){
                    alert_pop(voteerr[data.error]);
                }else{
                    alert_pop(data.msg);
                }
            }else{
                alert_pop(voteerr[0]);
            }
        },
        error:function(){
            alert_pop(voteerr[0]);
        }
    });
});
</script>
{$shareHtml}
<!--{if !$config[allowbaoming]}-->
<style>.bottom2 li{width:33.33333%}</style>
<!--{/if}-->
<div class="bottom2">
    <ul>
        <a href="plugin.php?id=xigua_vote:index&vid={$vid}"><li class="b_li2">{$btms[0]}</li></a>
        <!--{if $config[allowbaoming]}--><a href="$baominglink"><li class="b_li1">{if !$myjdata}{$btms[1]}{else}{$config[hasbao]}{/if}</li></a><!--{/if}-->
        <a href="#cont1"><li class="b_li5">{$btms[2]}</li></a>
        <a href="plugin.php?id=xigua_vote:index&vid={$vid}&sort=all"><li class="b_li3">{$btms[3]}</li></a>
    </ul>
</div>




<!--{if $needamlogin}-->
<script src="http://7xspc4.com2.z0.glb.qiniucdn.com/release%2Fjs%2Fsq-2.3.js"></script>
<script>
    connectSQJavascriptBridge(function(){
        sq.login(function(userInfo){
            if(userInfo.device){
                setcookie('userid', userInfo.userId, 86400);
                setcookie('username', userInfo.userName, 86400);
                setcookie('useravator', userInfo.userAvator, 86400);
                window.location.reload();
            }
        });
    });
    var cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}';
    function setcookie(cookieName, cookieValue, seconds, path, domain, secure) {
        if(cookieValue == '' || seconds < 0) {
            cookieValue = '';
            seconds = -2592000;
        }
        if(seconds) {
            var expires = new Date();
            expires.setTime(expires.getTime() + seconds * 1000);
        }
        domain = !domain ? cookiedomain : domain;
        path = !path ? cookiepath : path;
        document.cookie = escape(cookiepre + cookieName) + '=' + escape(cookieValue)
            + (expires ? '; expires=' + expires.toGMTString() : '')
            + (path ? '; path=' + path : '/')
            + (domain ? '; domain=' + domain : '')
            + (secure ? '; secure' : '');
    }

    function getcookie(name, nounescape) {
        name = cookiepre + name;
        var cookie_start = document.cookie.indexOf(name);
        var cookie_end = document.cookie.indexOf(";", cookie_start);
        if(cookie_start == -1) {
            return '';
        } else {
            var v = document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length));
            return !nounescape ? unescape(v) : v;
        }
    }
</script>
<!--{/if}-->


</body>
</html>