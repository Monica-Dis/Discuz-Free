<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/11/13
 * Time: 23:49
 */
if(!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
include_once libfile('function/cache');

$cookie = substr(md5('wechatxiguavote'.$_G['siteurl'].$_G['wechat']['setting']['wechat_appId']), 0, 8);
$openid = !empty($_G['cookie'][$cookie]) ? authcode($_G['cookie'][$cookie], 'DECODE', $_G['config']['security']['authkey']) : '';

define('APPBYME', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
if(APPBYME){
    define('IN_WECHAT', 1);
    $mustsubscribe = 0;

    $openid   = getcookie('userid');
    $nickname = getcookie('username');
    $nickname = iconv("UCS-2",CHARSET, pack('H*', str_replace('%u', '', $nickname)));
    $headimgurl = getcookie('useravator');

    if(($_GET['ac'] == 'signup' && !$openid) || $_GET['relo']) {
        $needamlogin = 1;
    }

    if($openid){
        $needamlogin = 0;
    }

    if($openid){
        if(!$userinfo = C::t('#xigua_vote#xigua_user')->fetch($openid)){
            $userinfo = array(
                'openid'     => $openid,
                'nickname'   => $nickname,
                'headimgurl' => $headimgurl,
                'subscribe'  => 1
            );
            C::t('#xigua_vote#xigua_user')->insert($userinfo);
        }
    }

}else if( !$showshare    || ($config['isdingyuehao']&& (!$config['guanzhusignup'] && !$config['xianguanzhu']))){
    define('IN_WECHAT', 1);
    $mustsubscribe = 0;

    $openid = $_G['uid'];
    $nickname = $_G['username'];
    $headimgurl =  avatar($openid, 'middle', true);

    if(($_GET['ac'] == 'signup'|| $_GET['relo']) && !$openid) {
        dheader('location: member.php?mod=logging&action=login&referer='.rawurlencode(xg_currenturl()));
        dheader('location: '."plugin.php?id=xigua_login:login&backreferer=".rawurlencode($_G['siteurl']."plugin.php?id=xigua_hb&".http_build_query($_GET)));
    }
    if($openid){
        if(!$userinfo = C::t('#xigua_vote#xigua_user')->fetch($openid)){
            $userinfo = array(
                'openid'     => $openid,
                'nickname'   => $nickname,
                'headimgurl' => $headimgurl,
                'subscribe'  => 1
            );
            C::t('#xigua_vote#xigua_user')->insert($userinfo);
        }
    }
}else{
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);

    if((IN_WECHAT || $_GET['ac'] == 'signup') && !$config['isdingyuehao'] ) {
        $wechat_client = new WeChatClient($_G['wechat']['setting']['wechat_appId'], $_G['wechat']['setting']['wechat_appsecret']);

        if(!$openid) {
            if(empty($_GET['oauth'])) {
                $redirect_uri = $wechat_client->getOAuthConnectUri($_G['siteurl'].'plugin.php?id=xigua_vote:index&ac='.$_GET['ac'].'&vid='.$vid.'&jid='.$_GET['jid'].'&oauth=yes', '', 'snsapi_userinfo');

                $config = $_G['cache']['plugin']['xigua_login'];
                if($config['rhref'] = trim($config['rhref'])) {
                    $jieurl = $config['rhref'];
                    if (strpos($jieurl, 'r.html') === false) {
                        $jieurl = rtrim($jieurl, '/') . '/source/plugin/xigua_login/r.html';
                    }
                    $baseUrl = urlencode($_G['siteurl'].'plugin.php?id=xigua_vote:index&oauth=yes&ac='.$_GET['ac'].'&vid='.$vid.'&jid='.$_GET['jid'].'');
                    $redirect_uri = "$jieurl?appid=".$_G['wechat']['setting']['wechat_appId']."&redirect_uri={$baseUrl}&response_type=code&scope=snsapi_base&state=#wechat_redirect";
                }

                dheader('location: '.$redirect_uri);
            } else {
                $tockeninfo = $wechat_client->getAccessTokenByCode($_GET['code']);
                $openid = $tockeninfo['openid'];
                $access_token = $tockeninfo['access_token'];
                dsetcookie($cookie, authcode($openid, 'ENCODE', $_G['config']['security']['authkey']), 7000);
                dsetcookie('voteaccesstoken', authcode($access_token, 'ENCODE', $_G['config']['security']['authkey']), 7100);
            }
        }

        if(!$userinfo = C::t('#xigua_vote#xigua_user')->fetch($openid)){
//        $userinfo = $wechat_client->getUserInfoById($openid);
            $userinfo = $wechat_client->getUserInfoByAuth(authcode($_G['cookie']['voteaccesstoken'], 'DECODE', $_G['config']['security']['authkey']), $openid);
            unset($userinfo['unionid']);
            unset($userinfo['privilege']);
            foreach ($userinfo as $index => $item) {
                $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
            }
            if(!$userinfo || $userinfo['errcode']){
//            echo "����Ա���ô�������ϵ����Ա��";
//            print_r($userinfo);
//            exit;
                if(empty($_GET['oauth'])) {
                    $redirect_uri = $wechat_client->getOAuthConnectUri($_G['siteurl'].'plugin.php?id=xigua_vote:index&ac='.$_GET['ac'].'&vid='.$vid.'&jid='.$_GET['jid'].'&oauth=yes', '', 'snsapi_userinfo');

                    $config = $_G['cache']['plugin']['xigua_login'];
                    if($config['rhref'] = trim($config['rhref'])) {
                        $jieurl = $config['rhref'];
                        if (strpos($jieurl, 'r.html') === false) {
                            $jieurl = rtrim($jieurl, '/') . '/source/plugin/xigua_login/r.html';
                        }
                        $baseUrl = urlencode($redirect_uri);
                        $redirect_uri = "$jieurl?appid=".$_G['wechat']['setting']['wechat_appId']."&redirect_uri={$baseUrl}&response_type=code&scope=snsapi_base&state=#wechat_redirect";
                    }


                    dheader('location: '.$redirect_uri);
                } else {
                    $tockeninfo = $wechat_client->getAccessTokenByCode($_GET['code']);
                    $openid = $tockeninfo['openid'];
                    $access_token = $tockeninfo['access_token'];
                    dsetcookie($cookie, authcode($openid, 'ENCODE', $_G['config']['security']['authkey']), 7000);
                    dsetcookie('voteaccesstoken', authcode($access_token, 'ENCODE', $_G['config']['security']['authkey']), 7100);
                }
            }else{
                if($userinfo){
                    C::t('#xigua_vote#xigua_user')->insert($userinfo);
                }
            }
        }


        /*hook start*/
        //ǿ�Ƹ����û���Ϣ
        if(
            ($config['guanzhusignup']&&$_GET['ac'] == 'signup') || $config['xianguanzhu']
        ){
            $userinfo = $wechat_client->getUserInfoById($openid);

            if(!$userinfo || $userinfo['errcode']){

                $appid = $_G['wechat']['setting']['wechat_appId'];
                $appsecret = $_G['wechat']['setting']['wechat_appsecret'];

                $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";
                $json = dfsockopen($url);
                if(!$json){
                    $json = file_get_contents($url);
                }
                $access_data = json_decode($json, true);
                $access_token = $access_data['access_token'];

                if($access_token){
                    savecache( 'wechatat_' . $appid, array(
                        'token' => $access_token,
                        'expiration' => time() + 6200,
                    ));
                }

                $url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=$access_token&openid=$openid&lang=en";
                $json = dfsockopen($url);
                if(!$json){
                    $json = file_get_contents($url);
                }
                $userinfo = json_decode($json, true);
            }

            if($userinfo && !$userinfo['errcode']){
                unset($userinfo['unionid']);
                unset($userinfo['privilege']);
                foreach ($userinfo as $index => $item) {
                    $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
                }
                C::t('#xigua_vote#xigua_user')->insert($userinfo);
            }
        }

        /*hook end*/



        if($config['guanzhusignup']){
            if(!$userinfo['subscribe']){
                $mustsubscribe = 1;
            }
        }
    }

    if($config['isdingyuehao']){
        if($_GET['openid']){
            $openid = trim($_GET['openid']);
            dsetcookie($cookie, authcode($openid, 'ENCODE', $_G['config']['security']['authkey']), 86400000);
        }

        $mustsubscribe = 0;
        if($_GET['ac'] == 'signup' && !$openid){
            $mustsubscribe = 1;
        }
    }
    if($_GET['openid'] || $_GET['code'] || $_GET['oauth']){
        dheader('Location: '.str_replace(array('openid=', 'code=', 'oauth='), '_=', xg_currenturl()));
    }
}