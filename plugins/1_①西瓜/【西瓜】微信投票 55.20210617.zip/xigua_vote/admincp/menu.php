<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//dis'.'m.tao'.'bao.com
?>
<link href="source/plugin/xigua_vote/static/admincp.css?002" rel="stylesheet" />
<script src="static/js/calendar.js"></script>
