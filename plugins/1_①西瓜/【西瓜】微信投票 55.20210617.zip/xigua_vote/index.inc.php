<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/8/18
 * Time: 15:29
 */

if(!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/common.php';
$pluginversion = '20170419';
if($_GET['sort']){
    $_GET['sort'] = in_array($_GET['sort'], array('hot', 'all')) ? $_GET['sort'] : '';
}
if($_GET['ac']){
    $_GET['ac'] = in_array($_GET['ac'], array('signup', 'view', 'votenow','guide')) ? $_GET['ac'] : 'xindex';
}else{
    $_GET['ac'] = 'xindex';
}


$vid = intval($_GET['vid']);
if(!$data = C::t('#xigua_vote#xigua_vote')->fetch_by_vid($vid)){
    if($data = C::t('#xigua_vote#xigua_vote')->fetch_default_vid()) {
        $vid = $_GET['vid'] = $data['vid'];
    }else{
        exit(sl('n1'));
    }
}
$stylecss = 'base_'.$data['tpl'];


if($_GET['ac'] == 'guide')
{
    include template('xigua_vote:'.$_GET['ac']);
    exit;
}

include_once DISCUZ_ROOT . 'source/plugin/xigua_vote/wechat.php';
$needreplace = array(
    '{title}',
    '{name}',
    '{jid}',
    '{totalvotes}',
);

$navtitle = $data['title'];
$now = $_G['timestamp'];
$joinend = ($now> $data['joinend_ts']);
$voteend = ($now> $data['voteend_ts']);

$voteend_string = dgmdate($data['voteend_ts'], 'Y/m/d H:i:s');
$joinend_string = dgmdate($data['joinend_ts'], 'Y/m/d H:i:s');
$crts_string = dgmdate($data['crts'], 'Y/m/d H:i:s');


$data['votes'] = $data['votes']+$data['vvotes'];
$data['views'] = $data['views']+$data['vviews'];

$btms = array_values(array_filter(explode("\n", trim($config['btm']))));


switch($_GET['ac'])
{
    case 'votenow':
        $response = array('error' => 1, 'msg' => 'unknown');
        if(submitcheck('formhash')){
            $jid = intval($_GET['jid']);
            $response = C::t('#xigua_vote#xigua_join')->votenow($openid, $vid, $jid, $voteend, $joinend, $config, $data);
        }
        if($response['error']==14){
            if(!APPBYME && ($config['isdingyuehao']&& (!$config['guanzhusignup'] || !$config['xianguanzhu']))){
                $response['error']= 13;
                $response['msg'] = diconv(sl('loading'), CHARSET, 'UTF-8')."<script>window.location.href='member.php?mod=logging&action=login&referer=".urlencode(dreferer())."';</script>";
            }
        }
        exit(json_encode($response));
        break;
    case 'view':
        $jid = intval($_GET['jid']);
        $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_jid($jid);
        if($openid && $vid){
            $myjdata = C::t('#xigua_vote#xigua_join')->fetch_by_openid($openid, $vid);
        }
        $baominglink = "plugin.php?id=xigua_vote:index&vid=$vid&ac=signup";

        $jdata['ext1'] = parse_vote_media($jdata['ext1']);
        $jdata['ext2'] = parse_vote_media($jdata['ext2']);
        $jdata['ext3'] = parse_vote_media($jdata['ext3']);
        $jdata['ext4'] = parse_vote_media($jdata['ext4']);
        $jdata['ext5'] = parse_vote_media($jdata['ext5']);
        $jdata['ext6'] = parse_vote_media($jdata['ext6']);
        $jdata['ext7'] = parse_vote_media($jdata['ext7']);

        $replaced = array(
            $data['title'],
            $jdata['name'],
            $jid,
            $jdata['totalvotes'],
        );
        $navtitle = str_replace($needreplace, $replaced, $config['lapt']);
        $navdesc = str_replace($needreplace, $replaced, $config['lapd']);

//        $navtitle .= ($jdata['bsid']?$jdata['bsid']:$jid).sl('n3').$jdata['name'];
        $img = $jdata['pic'][0] ?$jdata['pic'][0] : $data['cover'][0];

        if(!checkmobile()){
            include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            $preview = $_G['siteurl'] .'plugin.php?id=xigua_vote:index&ac=view&jid='.$jid.'&vid='.$vid;
            $qrelative = 'source/plugin/xigua_vote/cache/qrcode_'.$vid.'_'.$jid.'.png';
            $qrfile = DISCUZ_ROOT . $qrelative;
            if(!file_exists($qrfile)) {
                QRcode::png($preview, $qrfile, QR_ECLEVEL_L, 5);
            }
            $qrurl = $_G['siteurl'] . $qrelative;
        }

        break;
    case 'signup':
        if($mustsubscribe){
            if($config['onlyam'] && !APPBYME){
                dheader("Location: $config[guideapplink]");
            }else{
                dheader("Location: plugin.php?id=xigua_vote:index&ac=guide&vid=$vid");
            }
        }
        $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_openid($openid, $vid);

        if($_GET['upload'] && submitcheck('formhash')){
            $filena = uniqid(time()).'.jpg';
            $file_attach = $outputfile = 'source/plugin/xigua_vote/cache/'.$filena;
            $base64 = base64_decode($_GET['img']);

            if($base64){
                $ifp = fopen( DISCUZ_ROOT.$outputfile, "wb" );
                fwrite( $ifp, $base64 );
                fclose( $ifp );
            }

            if(is_file(DISCUZ_ROOT.$outputfile)){
                $imgurl = $_G['site_url'].$outputfile;
                $saved_file = DISCUZ_ROOT.$file_attach;
                if($config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET']){
                    include_once DISCUZ_ROOT.'source/plugin/xigua_vote/lib/OSS/Common.php';
                    if ($surl = vote_sso_upload($filena, $saved_file)) {
                        $imgurl = $surl;
                        @unlink($saved_file);
                    }
                }
                $ret1 = array(
                    'error' => 0,
                    'url' => $imgurl
                );
            }else{
                $ret1 = array(
                    'error' => 9,
                    'url' => '',
                );
            }
            echo json_encode($ret1);
            exit;
        }else if(!$_GET['upload'] && submitcheck('formhash')){
            if($joinend){
                $ret = array('jid' => 0, 'error' => 1);
                echo json_encode($ret);
                exit;
            }
            $_GET = dhtmlspecialchars($_GET);
            $append = $_GET['append'];
            $pic    = $_GET['pic'];
            if(!checkmobile()){
                foreach ($append as $ky => $item) {
                    $append[$ky] = diconv($item, 'utf-8', CHARSET, true);
                }
            }

            $append['openid'] = $openid;
            $append['pic'] = serialize($pic);
            $append['crts'] = $_G['timestamp'];
            $append['vid'] = $vid;
            $append['status'] = $data['checksignup'] ? JOIN_WEISHENHE : JOIN_YISHENHE;
            $append['totalvotes'] = 0;
            $append['totalviews'] = 0;

            if($jid = intval($_GET['jid'])){
                $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_openid($openid, $vid);
                if($jdata['status']==JOIN_YIPINGBI){
                    unset($append['status']);
                }
                unset($append['openid'], $append['totalvotes'], $append['totalviews']);
                $affetced = C::t('#xigua_vote#xigua_join')->update($append, array('openid' => $openid, 'jid' => $jid));
                $ret = array('jid' => $jid, 'error' => 0);

            }else{

                $jid = C::t('#xigua_vote#xigua_join')->insert($append, true);
                if($jid){
                    C::t('#xigua_vote#xigua_vote')->update_joins_by_vid($vid, 1);
                    $ret = array('jid' => $jid, 'error' => 0);
                }else{
                    $ret = array('jid' => 0, 'error' => 1);
                }
            }
            echo json_encode($ret);
            exit;
        }
        break;
    default:
        $baominglink = "plugin.php?id=xigua_vote:index&vid=$vid&ac=signup";
        if($config['pubu']){
            list($wi, $hei) = explode(':', trim($config['pubu']));
            $config['wh'] = (($hei/$wi)*100) .'%';
        }
        if(!checkmobile()){
            include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            $preview = $_G['siteurl'] .'plugin.php?id=xigua_vote:index&vid='.$vid;
            $qrelative = 'source/plugin/xigua_vote/cache/qrcode_'.$vid.'.png';
            $qrfile = DISCUZ_ROOT . $qrelative;
            if(!file_exists($qrfile)) {
                QRcode::png($preview, $qrfile, QR_ECLEVEL_L, 5);
            }
            $qrurl = $_G['siteurl'] . $qrelative;
        }else{


            if($openid && $vid){
                $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_openid($openid, $vid);
            }

            $groupconfig = array();
            if(trim($data['groupconfig'])) {
                foreach (explode("\n", trim($data['groupconfig'])) as $index => $item) {
                    list($tmp_key, $tmp_val) = explode('=', trim($item));
                    $groupconfig[trim($tmp_key)] = trim($tmp_val);
                }
                $GLOBALS['cgroup'] = $cgroup = $groupconfig;
                if ($groupconfig) {
                    $cgroupselect = '<select name="cgroup"><option value="">--</option>';
                    foreach ($cgroup as $index => $item) {
                        $cgroupselect .= "<option value=\"$index\">$item</option>";
                    }
                    $cgroupselect .= "</select>";
                }
            }

            $img = $data['cover'][0];
            $navdesc = $data['shareinfo'];

            $icount = $data['joins'];

            if(submitcheck('formhash') && $_GET['keyword'] = dhtmlspecialchars($_GET['keyword'])){
                $list = C::t('#xigua_vote#xigua_join')->fetch_by_search($vid, $_GET['keyword']);
            }else{
                if($GLOBALS['cgroup']){
                    $icount = C::t('#xigua_vote#xigua_join')->fetch_count($vid);
                }

                $page = max(1, intval(getgpc('page')));
                $lpp   = 12;
                $start_limit = ($page - 1) * $lpp;
                $_G['gp_ajaxtarget'] = '';
                $multi = multi($icount, $lpp, $page, "plugin.php?id=xigua_vote:index&vid=$vid&sort=$_GET[sort]&cgr=$_GET[cgr]", 0, 6, 0, 1);
                $multi = str_replace('\"', '"', $multi);
                $list = C::t('#xigua_vote#xigua_join')->fetch_joinlist_by_page($vid, $start_limit, $lpp, (!$_GET['sort'] ? 'time' : 'vote'));
            }
            foreach ($list as $k => $v) {

                $replaced = array(
                    $data['title'],
                    $v['name'],
                    $v['jid'],
                    $v['totalvotes'],
                );
                $list[$k]['navdesc'] = str_replace($needreplace, $replaced, $config['lapt']);
                $list[$k]['navtitle'] = str_replace($needreplace, $replaced, $config['lapd']);

                foreach ($list[$k]['pic'] as $kk => $vv) {
                    if(strpos($vv, 'http://')===false && strpos($vv, 'https://')===false){
                        $list[$k]['pic'][$kk] = $_G['siteurl'] .$vv;
                    }
                }
            }

        }
        break;
}

if(checkmobile()){
if(is_file(DISCUZ_ROOT.'source/plugin/xigua_f/m.class.php')){
    include_once DISCUZ_ROOT.'source/plugin/xigua_f/m.class.php';
    $shareHtml =  mobileplugin_xigua_f::global_footer_mobile();
}else{
    if(strpos($img, 'http://')===false && strpos($img, 'https://')===false){
        $img = $_G['siteurl'] .$img;
    }
    $noncestr = uniqid('wx');
    $cururl = xg_currenturl();

    $shareHtml = "<script>var title = '$title';var desc = '$navdesc';var link = '$cururl';var imgUrl = '$img';function readywx(){}</script>";

    if(IN_WECHAT){
        $signature = vote_signature($noncestr, $cururl, $now);
        $shareHtml = $signature ? <<<HTML
<script src="//res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script>
var title = '$title';
var desc = '$navdesc';
var link = '$cururl';
var imgUrl = '$img';
wx.config({
  debug:false,
  appId: '{$_G[wechat][setting][wechat_appId]}',
  timestamp: '$now',
  nonceStr: '$noncestr',
  signature: '$signature',
  jsApiList: ['onMenuShareTimeline','onMenuShareAppMessage','onMenuShareQQ','onMenuShareWeibo']
});
readywx();
function readywx(){
wx.ready(function () {
    wx.onMenuShareAppMessage({ title: title, desc: desc,link: link,imgUrl: imgUrl});
    wx.onMenuShareTimeline({title: title,link: link,imgUrl: imgUrl});
    wx.onMenuShareQQ({title: title,desc: desc,link: link,imgUrl: imgUrl});
    wx.onMenuShareWeibo({title: title,desc: desc,link: link,imgUrl: imgUrl});
    document.getElementById('media').play();
});
}
</script>
HTML
            : '';
    }else if(APPBYME){
        $shareHtml = <<<HTML
<script src="https://market-cdn.app.xiaoyun.com/release/sq-2.3.js"></script>
<script type="text/javascript">
var TOPBAR_MORE_SHARE = 'share';
function share(){
    AppbymeJavascriptBridge.share("$title", "$navdesc", "$cururl", function(data){
        alert(data.errInfo);
    });
}
</script>
HTML;

    }
}
}

include template('xigua_vote:'.$_GET['ac']);
