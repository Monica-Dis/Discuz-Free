<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/11/3
 * Time: 21:56
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

$url = "plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=joinlist&vid=$vid&lpp=$lpp&page=$page&backpage=$_GET[backpage]&status=$_GET[status]";
$joinurl = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=join&vid=$vid&backpage=$_GET[backpage]";
$backurl = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&page=".$_GET['backpage'];
$exporturl = ADMINSCRIPT."?action=$url&export=1";

if(submitcheck('export', 1)){

    $detail = '';
    $exlist = C::t('#xigua_vote#xigua_join')->fetch_joinlist_by_page($vid, 0, 9999999, 'vote', 1);

    foreach ($exlist as $index => $item) {
//        unset($item['pic']);
        unset($item['totalviews']);
        foreach ($item as $idx => $vtm) {
            if($idx=='pic'){
                $vtm = implode(',', $vtm);
            }
            $item[$idx] = str_replace(array("\n",','), '', $vtm);
        }
        if($index==0){
            $detail.= implode(',', array_keys($item))."\n";
        }
        $detail.= implode(',', $item)."\n";
    }

    $filename = date('YmdHis', TIMESTAMP).'.csv';

    ob_end_clean();
    header('Content-Encoding: none');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.$filename);
    header('Pragma: no-cache');
    header('Expires: 0');
    if($_G['charset'] != 'gbk') {
        $detail = diconv($detail, $_G['charset'], 'GBK');
    }
    echo $detail;
    exit;
}

if(submitcheck('srch') && $_GET['searchtxt']){
    $txt = stripsearchkey($_GET['searchtxt']);

    $list = C::t('#xigua_vote#xigua_join')->fetch_by_search($vid, $txt);
    $count = count($list);
    $multipage = multi($count, $count, $page, ADMINSCRIPT."?action=$url");
    $_GET['formhash'] = '';
}else{
    $list = C::t('#xigua_vote#xigua_join')->fetch_joinlist_by_page($vid, $start_limit, $lpp, 'time', 1);
    $count = C::t('#xigua_vote#xigua_join')->fetch_count($vid, 1);
    $multipage = multi($count, $lpp, $page, ADMINSCRIPT."?action=$url");
}
if(submitcheck('formhash')){
    $jids = array_values(array_filter($_GET['jids']));
    if($_GET['operation1'] == 1){
        if(C::t('#xigua_vote#xigua_join')->update_status($jids)) {
            cpmsg(sl('update_succeed'), "action=".str_replace("&page=$page","&page=".($page-1), $url), 'succeed');
        }
    }else if($_GET['operation1'] == 2){
        foreach ($jids as $jid) {
            if(C::t('#xigua_vote#xigua_join')->delete($jid)) {
                C::t('#xigua_vote#xigua_vote')->update_totalvotes($vid);
                C::t('#xigua_vote#xigua_vote')->update_joins_by_vid($vid, -1);
            }
        }
        cpmsg(sl('del_succeed'), "action=".str_replace("&page=$page","&page=".($page-1), $url), 'succeed');
    }else if($_GET['operation1'] == 3){
        if($jids){
            if(C::t('#xigua_vote#xigua_join')->update_status($jids, JOIN_YIPINGBI)) {
                cpmsg(sl('update_succeed'), "action=".str_replace("&page=$page","&page=".($page-1), $url), 'succeed');
            }
        }
    }else if($_GET['operation1'] == 4){

        if(C::t('#xigua_vote#xigua_join')->update_status($jids, JOIN_YISHENHE)) {
            cpmsg(sl('update_succeed'), "action=".str_replace("&page=$page","&page=".($page-1), $url), 'succeed');
        }
    }
    else if($_GET['operation1'] == 5){

        $newjids = (array_filter($_GET['newjids']));
        if($newjids){
            foreach ($newjids as $index => $newjid) {
                if($index!=$newjid){
                    @DB::query("UPDATE %t set jid=%d where jid=%d", array('xigua_join', $newjid, $index), 0);
                }
            }
        }
        if(C::t('#xigua_vote#xigua_join')->multi_update_cgroup($_GET['cgroup'])) {
            cpmsg(sl('update_succeed'), "action=".str_replace("&page=$page","&page=".($page-1), $url), 'succeed');
        }
    }
}


if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_vote'];
showformheader($url,'','vform');
echo '<div><input type="text" id="searchtxt" name="searchtxt" value="'.$txt.'" class="txt" placeholder="'.$config['searchtxt'].'" /> <input name="srch" value="1" type="hidden" /> <input type="submit" class="btn" value="'.cplang('search').'" /></div>';
showformfooter(); /*dis'.'m.tao'.'bao.com*/

showformheader($url,'','vlist');

$baominglink = ADMINSCRIPT ."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=joinlist&vid=$vid&page=$page&status=";

if($data['checksignup']){
    $shen = "&nbsp;&nbsp;
<a href=\"$baominglink".JOIN_YISHENHE."\" class=\"nava ".($_GET['status']==JOIN_YISHENHE?'navc':'')."\">".sl('n9')."</a>
<a href=\"$baominglink".JOIN_WEISHENHE."\" class=\"nava ".($_GET['status']==JOIN_WEISHENHE?'navc':'')."\">".sl('n10')."</a>
<a href=\"$baominglink".JOIN_YIPINGBI."\" class=\"nava ".($_GET['status']==JOIN_YIPINGBI?'navc':'')."\">".sl('n11')."</a>";
}else{
    $shen = "&nbsp;&nbsp;
<a href=\"$baominglink".JOIN_YISHENHE."\" class=\"nava ".($_GET['status']==JOIN_YISHENHE?'navc':'')."\">".sl('n12')."</a>
<a href=\"$baominglink".JOIN_YIPINGBI."\" class=\"nava ".($_GET['status']==JOIN_YIPINGBI?'navc':'')."\">".sl('n11')."</a>";
}

showtableheader(
    $data['title'] . sl('manage_joinlist') .
    $shen.
    "<a class='fr' href=\"$exporturl\">&nbsp;&nbsp;".cplang('export')."&nbsp;&nbsp;</a>".
    "<a class='fr' href=\"$backurl\">".sl('back').sl('list')."</a>".
    "<a class='fr mr20' href=\"$joinurl\">".sl('n13')."</a>"
);

/*start~~~~~~~~~~~~~~~~~~~~~~~*/
$groupconfig = array();
if(trim($data['groupconfig'])) {
    foreach (explode("\n", trim($data['groupconfig'])) as $index => $item) {
        list($tmp_key, $tmp_val) = explode('=', trim($item));
        $groupconfig[trim($tmp_key)] = trim($tmp_val);
    }
    $GLOBALS['cgroup'] = $cgroup = $groupconfig;
    if ($groupconfig) {
        $cgroupselect = '<select name="cgroup"><option value="">--</option>';
        foreach ($cgroup as $index => $item) {
            $cgroupselect .= "<option value=\"$index\">$item</option>";
        }
        $cgroupselect .= "</select>";
    }
}
/*end~~~~~~~~~~~~~~~~~~~~~~~~~*/

$rowhead = array();
$rowhead[] = sl('n14');
$rowhead[] = sl('fenl');
$rowhead[] = sl('n15');
foreach (array('name', 'mobile', 'sex', 'profile', 'pic') as $item) {
    if($joinfield[$item]['require']){
        $rowhead[] =  $joinfield[$item]['etc'];
    }
}
$rowhead[] = sl('n16');
$rowhead[] = sl('n7');
$rowhead[] = sl('n17');

showtablerow('class="header"', array(), $rowhead);

foreach ($list as $row) {
    if($row['openid']){
        $openids[] = $row['openid'];
    }
}
$users = C::t('#xigua_vote#xigua_user')->fetch_by_openids($openids);
foreach ($list as $row) {

    $pic = '';
    foreach ((array)$row['pic'] as $k => $item) {
        $k = $k.$row['jid'];
        if(!$item){
            continue;
        }
        $pic .= "<span id='w1$k'><a href='$item' target='_blank'><img class=\"imgi\" src=\"$item\" onmouseover=\"$('p1$k').style.display='block'\" onmouseout=\"$('p1$k').style.display='none'\" /></a><img class='imgprevew' src=\"$item\" id='p1$k' /></span>";
    }

    $rowbody = array();
    $rowbody[] = '<input type="checkbox" class="checkbox" name="jids[]" value="'.$row['jid'].'"  />'.
        "<input name=\"newjids[{$row['jid']}]\" value=\"{$row['jid']}\" style='width:30px' />";

    $rowbody[] = $cgroupselect ? str_replace(array(
        'name="cgroup"',
        '<option value="' . $row['cgroup'] . '">'
    ), array(
        'name="cgroup[' . $row['jid'] . ']"',
        '<option value="' . $row['cgroup'] . '" selected>'
    ), $cgroupselect) : '--';

    $rowbody[] = ($users[$row['openid']]['headimgurl'] ? '<img class="headimgurl" src="'.$users[$row['openid']]['headimgurl'].'" />' : '').
        ($users[$row['openid']]['nickname'] ? ' <span class="nickspan">'.$users[$row['openid']]['nickname'].'</span>'.($row['openid']) : $row['openid']);

    if($joinfield['name']['require']){
        $rowbody[] = $row['name'];
    }
    if($joinfield['mobile']['require']){
        $rowbody[] = $row['mobile'];
    }
    if($joinfield['sex']['require']){
        $rowbody[] = $row['sex']==1 ? sl('man') : sl('woman');
    }
    if($joinfield['profile']['require']){
        $rowbody[] = "<div class=\"divprofile\">$row[profile]</div>";
    }
    if($joinfield['pic']['require']){
        $rowbody[] = $pic;
    }

    $voteloglink = ADMINSCRIPT ."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=votelog&vid=$vid&jid=$row[jid]&backpage=$page";

    $rowbody[] = $row['crts'];
    $rowbody[] = $row['totalvotes'];
    $rowbody[] =
        "<a href='$voteloglink'>".sl('n18')."</a>&nbsp;&nbsp;".
        '<a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=join&vid=".$row['vid'].'&jid='.$row['jid'].'&backpage='.$_GET['backpage'].'&page='.$page.'">'.sl('n19').'</a>';
    ;

    showtablerow('', array(), $rowbody);
}
showtablerow('', 'colspan="99"', '
<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'jids\')"><label for="chkall">'.sl('n20').'</label>&nbsp;&nbsp;
<input id="operation1" name="operation1" type="hidden" value="0" />
'.
    '<input type="button" onclick="return submitit(5);" value="'.sl('m30').'" class="btn" />&nbsp;&nbsp;'.
    ($_GET['status']==JOIN_WEISHENHE ? '<input type="button" onclick="return submitit(1);" value="'.sl('o1').'" class="btn" />&nbsp;&nbsp;' :'').
    ($_GET['status']!=JOIN_YIPINGBI ? '<input type="button" onclick="return submitit(3);" value="'.sl('o2').'" class="btn" />&nbsp;&nbsp;' :'').
    ($_GET['status']==JOIN_YIPINGBI ? '<input type="button" onclick="return submitit(4);" value="'.sl('o3').'" class="btn" />&nbsp;&nbsp;' :'')

    .'
<input type="button" onclick="return submitit(2);" value="'.sl('o4').'" class="btn" />&nbsp;&nbsp;
'. $multipage);
showtablefooter(); /*Dism_taobao-com*/
showformfooter(); /*dis'.'m.tao'.'bao.com*/
?>
<script>
function submitit(type){
    if(type == 2){

        if(confirm('<?php sl('confirm_del', 1)?>')){
            $('operation1').value = '2';
            $('vlist').submit();
        }
    }else{
        $('operation1').value = type;
        $('vlist').submit();
    }
    return false;
}
</script>