<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/9/3
 * Time: 17:31
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/admincp/menu.php';
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/common.php';
$now = $_G['timestamp'];

if($_GET['actype'] && in_array($_GET['actype'], array('join', 'joinlist', 'votelog'))){
    $vid = intval($_GET['vid']);
    $data = C::t('#xigua_vote#xigua_vote')->fetch_by_vid($vid);
    $joinfield = $data['joinfield'];
    include $_GET['actype'].'.inc.php';
    exit;
}

if($_GET['setdefault'] && submitcheck('formhash')){
    $vid = intval($_GET['vid']);
    if(C::t('#xigua_vote#xigua_vote')->set_default($vid)){
        cpmsg(sl('update_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&vid=$vid", 'succeed');
    }
    cpmsg(sl('update_error'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&vid=$vid", 'succeed');
}

if(submitcheck('formhash')){
    $del = array_values(array_filter($_GET['delvid']));
    $vid = intval($del[0]);
    if(C::t('#xigua_vote#xigua_vote')->delete($vid)){
        cpmsg(sl('del_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&vid=$vid", 'succeed');
    }else{
        cpmsg(sl('del_error'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list", 'error');
    }
}

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

$list = C::t('#xigua_vote#xigua_vote')->fetch_list_by_page($start_limit, $lpp);
$count = C::t('#xigua_vote#xigua_vote')->fetch_count();

include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
include_once libfile('function/cache');
$updatedata = array(
    'receiveEvent::subscribe' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'subscribe'
    ),
    'receiveEvent::unsubscribe' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'unsubscribe'
    ),
    'receiveMsg::text' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'text'
    ),
);
$responsehook = WeChatHook::updateResponse($updatedata, 551);

$multipage = multi($count, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&lpp=$lpp", 0, 10);

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&page=$page",'','vlist');
showtableheader(sl('manage'));
showtablerow('class="header"', array(), array(
    'ID',
    sl('m3'),
    sl('m0'),
    sl('o5'),
    sl('o6'),
    sl('o7'),
    sl('o8'),
    sl('o9'),
    sl('n17')
));
foreach ($list as $row) {
    $setdefaultlink = 'plugin.php?id=xigua_vote:index&vid='.$row['vid'].'&setdefault=1&formhash='.FORMHASH;
    $previewlink = 'plugin.php?id=xigua_vote:index&vid='.$row['vid'];
    $baominglink = ADMINSCRIPT ."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=joinlist&vid=$row[vid]&backpage=$page&status=";
    if($now<=$row['joinend']){
        $injoin = sl('o10');
    }else{
        $injoin = sl('o11');
    }
    if($now<=$row['voteend']){
        $invote = sl('o12');
    }else{
        $invote = sl('o13');
    }
    $rs = $row['isdefault'] ? '<b color="gray">'.sl('o14').'</b>' : '<a href="javascript:;" onclick="return setdefault('.$row['vid'].')">'.sl('o14').'</a>';

    if($row['checksignup']){
        $weishenhe = C::t('#xigua_vote#xigua_join')->get_uncheck_count($row['vid']);
        $yipingbi  = C::t('#xigua_vote#xigua_join')->get_pingbi_count($row['vid']);
        $yishenhe  = $row['joins'] - $weishenhe-$yipingbi;
        $baimingguanli = "
        <a href='$baominglink".JOIN_YISHENHE."'>".sl('n9')."($yishenhe)</a>&nbsp;&nbsp;
        <a href='$baominglink".JOIN_WEISHENHE."'>".sl('n10')."($weishenhe)</a>&nbsp;&nbsp;
        <a href='$baominglink".JOIN_YIPINGBI."'>".sl('n11')."($yipingbi)</a>";
    }else{
        $yipingbi  = C::t('#xigua_vote#xigua_join')->get_pingbi_count($row['vid']);
        $yishenhe  = $row['joins']-$yipingbi;
        $baimingguanli = "<a href='$baominglink".JOIN_YISHENHE."'>".sl('n12')."($yishenhe)</a>
        &nbsp;&nbsp;<a href='$baominglink".JOIN_YIPINGBI."'>".sl('n11')."($yipingbi)</a>
        ";
    }

    showtablerow('', array(), array(
        $row['vid'],
        $tpls[$row['tpl']],
        $row['title'],
        $baimingguanli,
        $row['votes'],
        $row['views'],
        date('Y-m-d H:i:s', $row['crts']),
        $injoin.'<br>'.$invote,
        $rs.'&nbsp;&nbsp;
        <span>'.sl('click').': XVOTE_'.$row['vid'].'</span>&nbsp;&nbsp;
        <a href="'.$previewlink.'" target="_blank">'.sl('o15').'</a>&nbsp;&nbsp;
        <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=add&vid=".$row['vid'].'&backpage='.$page.'">'.sl('n19').'</a>&nbsp;&nbsp;
        <input name="delvid[]" id="delvid'.$row['vid'].'" value="" type="hidden"/><a style="cursor:pointer" onclick="delvid(\''.$row['vid'].'\')">'.sl('o4').'</a>'
    ));
}
showtablerow('', 'colspan="99"', $multipage);
showtablefooter(); /*Dism_taobao-com*/
showformfooter(); /*dis'.'m.tao'.'bao.com*/
?>
<script>
    function delvid(vid){
        if(confirm('<?php sl('confirm_del', 1)?>')){
            $('delvid'+vid).value = vid;
            $('vlist').submit();
        }
    }
    function setdefault(vid){
        $('vlist').action = $('vlist').action+'&setdefault=1&vid='+vid;
        $('vlist').submit();
        return false;
    }
</script>
