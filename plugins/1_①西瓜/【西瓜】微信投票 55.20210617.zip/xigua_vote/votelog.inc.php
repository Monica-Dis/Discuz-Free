<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/11/18
 * Time: 21:45
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$jid = intval($_GET['jid']);

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

$url = "plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=votelog&vid=$vid&jid=$jid&lpp=$lpp&page=$page&backpage=$_GET[backpage]";
$exporturl = ADMINSCRIPT."?action=$url&export=1";
$backurl = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&actype=joinlist&vid=$vid&page=$_GET[backpage]&status=".JOIN_YISHENHE;

if(submitcheck('export', 1)){

    $detail = '';
    $exlist  = C::t('#xigua_vote#xigua_votelog')->fetch_by_page($vid, $jid, 0, 99999);
    $ipres = array();
    $c = count($exlist);
    $f = 100000;

    foreach ($exlist as $index => $item) {
        foreach ($item as $idx => $vtm) {
            $item[$idx] = str_replace(array("\n",','), '', $vtm);
        }
        if($index==0){
            if($c<=$f) {
                $detail .= implode(',', array_keys($item)) . ",ipaddress\n";
            }else{
                $detail .= implode(',', array_keys($item)) . "\n";
            }
        }

        $item['time'] = date('Y-m-d H:i:s', $item['ts']);
        unset( $item['ts']);

        if($c<=$f){
            if(0 && !$ipres[$item['ip']]){
                $api = "http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=json&ip=".$item['ip'];
                $api = "http://ip.taobao.com/service/getIpInfo.php?ip=".$item['ip'];
                if($ipres = json_decode(dfsockopen($api), true)) {
                    $ipres[$item['ip']] = diconv($ipres['data']['region'], 'utf-8') .'-'. diconv($ipres['data']['city'], 'utf-8');
                }
            }
            $item['ipaddress'] = $ipres[$item['ip']];
        }

        $detail.= implode(',', $item)."\n";
    }

    $filename = date('YmdHis', TIMESTAMP).'.csv';

    ob_end_clean();
    header('Content-Encoding: none');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.$filename);
    header('Pragma: no-cache');
    header('Expires: 0');
    if($_G['charset'] != 'gbk') {
        $detail = diconv($detail, $_G['charset'], 'GBK');
    }
    echo $detail;
    exit;
}

if(submitcheck('srch') && $_GET['searchtxt']){
    $txt = stripsearchkey($_GET['searchtxt']);

    $list  = C::t('#xigua_vote#xigua_votelog')->fetch_by_page($vid, $jid, $start_limit, 999999, " (  ip LIKE '%$txt%' ) ");
//    $count = count($list);
//    $multipage = multi($count, $count, $page, ADMINSCRIPT."?action=$url");
    $_GET['formhash'] = '';
}else{
    $list  = C::t('#xigua_vote#xigua_votelog')->fetch_by_page($vid, $jid, $start_limit, $lpp);
    $count = C::t('#xigua_vote#xigua_votelog')->fetch_count($vid, $jid);
}
if(submitcheck('formhash')){
    $i = 0;
    $jids = dintval($_GET['lids'], true);
    foreach ($jids as $jid => $lids) {
        $j = 0;
        foreach ($lids as $v) {
            if(C::t('#xigua_vote#xigua_votelog')->delete($v)){
                $j ++;
                $i ++;
            }
        }
        C::t('#xigua_vote#xigua_join')->incr_vote($jid, -$j);
    }
    C::t('#xigua_vote#xigua_vote')->incr_vote($vid, -$i);
    cpmsg(sl('del_succeed'), "action=".str_replace("&page=$page","&page=".($page-1), $url), 'succeed');
}


$multipage = multi($count, $lpp, $page, ADMINSCRIPT."?action=$url");


if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_vote'];
showformheader($url,'','vform');
echo '<div><input type="text" id="searchtxt" name="searchtxt" value="'.$txt.'" class="txt" placeholder="IP" /> <input name="srch" value="1" type="hidden" /> <input type="submit" onclick="if($(\'searchtxt\').value==\'\'){$(\'searchtxt\').focus();return false;}" class="btn" value="'.cplang('search').'" /></div>';
showformfooter(); /*dis'.'m.tao'.'bao.com*/


showformheader($url,'','vlist');

showtableheader(sl('manage_votelog')." (ID:$vid)" .
    "<a class='fr' href=\"$exporturl\">&nbsp;&nbsp;".cplang('export')."&nbsp;&nbsp;</a>".
    "<a class='fr' href=\"$backurl\">".sl('back')."</a>"
);

$rowhead = array(
    sl('o21'),
    sl('n15'),
    sl('o22'),
    sl('o23'),
    sl('o24'),
    sl('o8'),
);

showtablerow('class="header"', array(), $rowhead);

foreach ($list as $row) {
    if($row['openid']){
        $openids[] = $row['openid'];
    }
}
$users = C::t('#xigua_vote#xigua_user')->fetch_by_openids($openids);

$ipres = array();

foreach ($list as $index => $row) {
    if(!$ipres[$row['ip']]){
        $api = "http://ip.taobao.com/service/getIpInfo.php?ip=".$row['ip'];
        if($ipres = json_decode(dfsockopen($api), true)) {
            $ipres[$row['ip']] = diconv($ipres['data']['region'], 'utf-8') .'-'. diconv($ipres['data']['city'], 'utf-8');
        }
    }

    $rowbody = array(
        '<input type="checkbox" class="checkbox" name="lids['.$row['jid'].'][]" value="'.$row['lid'].'"  />'.$row['lid'],
        ($users[$row['openid']]['headimgurl'] ? '<img class="headimgurl" src="'.$users[$row['openid']]['headimgurl'].'" />' : '').
        ' '.
        ($users[$row['openid']]['nickname'] ? $users[$row['openid']]['nickname'] : $row['openid']),
        $row['jid'],
        "<b>[{$ipres[$row['ip']]}]</b> ".$row['ip'],
        $row['type']=='text' ? sl('o25') : sl('o26'),
        date('Y-m-d H:i:s', $row['ts']),

    );
    showtablerow('', array(), $rowbody);
}

showtablerow('', 'colspan="99"', '
<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'lids\')"><label for="chkall">'.sl('n20').'</label>&nbsp;&nbsp;
<input type="button" onclick="return submitit();" value="'.sl('o4').'" class="btn" />&nbsp;&nbsp;
'. $multipage);
showtablefooter(); /*Dism_taobao-com*/
showformfooter(); /*dis'.'m.tao'.'bao.com*/
?>
<script>
    function submitit(){
        if(confirm('<?php sl('confirm_del', 1)?>')){
            $('vlist').submit();
        }
        return false;
    }
</script>