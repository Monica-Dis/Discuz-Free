<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginid = 'xigua_vote';

$Hooks = array(
    'forumdisplay_topBar',
);

$data = array();
foreach($Hooks as $Hook) {
    $data[] = array(
        $Hook => array(
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid,
            'method' => $Hook,
            'order'  => 0,
        )
    );
}

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);



$updatedata = array(
    'receiveEvent::subscribe' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'subscribe'
    ),
    'receiveEvent::unsubscribe' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'unsubscribe'
    ),
    'receiveMsg::text' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'text'
    ),
    'receiveEvent::click' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'click'
    ),
    'receiveEvent::scan' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'scan'
    ),
);
$responsehook = WeChatHook::updateResponse($updatedata, 551);


$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_join` (
 `jid` int(11) NOT NULL AUTO_INCREMENT,
 `openid` varchar(80) NOT NULL,
 `vid` int(11) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
 `profile` varchar(2000) NOT NULL,
 `pic` varchar(2000) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `status` tinyint(1) NOT NULL,
 `totalvotes` int(11) unsigned NOT NULL,
 `totalviews` int(11) unsigned NOT NULL,
 `ext1` varchar(255) NOT NULL DEFAULT '',
 `ext2` varchar(255) NOT NULL DEFAULT '',
 `ext3` varchar(255) NOT NULL DEFAULT '',
 `ext4` varchar(255) NOT NULL DEFAULT '',
 `ext5` varchar(255) NOT NULL DEFAULT '',
 `ext6` varchar(255) NOT NULL DEFAULT '',
 `ext7` varchar(255) NOT NULL DEFAULT '',
 `ext8` varchar(255) NOT NULL DEFAULT '',
 `ext9` varchar(255) NOT NULL DEFAULT '',
 `ext10` varchar(255) NOT NULL DEFAULT '',
 `ext11` varchar(255) NOT NULL DEFAULT '',
 `ext12` varchar(255) NOT NULL DEFAULT '',
 `ext13` varchar(255) NOT NULL DEFAULT '',
 `ext14` varchar(255) NOT NULL DEFAULT '',
 `ext15` varchar(255) NOT NULL DEFAULT '',
 `ext16` varchar(255) NOT NULL DEFAULT '',
 `ext17` varchar(255) NOT NULL DEFAULT '',
 `ext18` varchar(255) NOT NULL DEFAULT '',
 `ext19` varchar(255) NOT NULL DEFAULT '',
 `ext20` varchar(255) NOT NULL DEFAULT '',
 `bantimes` int(11) NOT NULL,
 `banendts` int(11) NOT NULL,
 `banminute` int(11) NOT NULL,
 PRIMARY KEY (`jid`),
 KEY `vid` (`vid`),
 KEY `status` (`status`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_xigua_vote` (
 `vid` int(11) unsigned NOT NULL AUTO_INCREMENT,
 `title` varchar(200) NOT NULL,
 `cover` varchar(5000) NOT NULL,
 `joinend` int(11) NOT NULL,
 `voteend` int(11) NOT NULL,
 `maxinjoin` int(10) NOT NULL,
 `votepreday` int(10) NOT NULL,
 `joinfield` varchar(2000) NOT NULL,
 `views` int(11) NOT NULL,
 `votes` int(10) NOT NULL,
 `joins` int(10) NOT NULL,
 `vviews` int(10) NOT NULL,
 `vvotes` int(10) NOT NULL,
 `checksignup` tinyint(1) NOT NULL,
 `content` text NOT NULL,
 `prizecontent` text NOT NULL,
 `statement` text NOT NULL,
 `crts` int(11) NOT NULL,
 `tpl` varchar(50) NOT NULL,
 `music` varchar(200) NOT NULL,
 `isdefault` tinyint(1) unsigned NOT NULL,
 `shareinfo` varchar(500) NOT NULL,
 `zanzhu` text NOT NULL,
 PRIMARY KEY (`vid`),
 KEY `isdefault` (`isdefault`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_xigua_user` (
 `openid` varchar(80) NOT NULL,
 `subscribe` tinyint(1) NOT NULL,
 `nickname` varchar(80) NOT NULL,
 `sex` tinyint(1) NOT NULL,
 `city` varchar(20) NOT NULL,
 `province` varchar(20) NOT NULL,
 `country` varchar(20) NOT NULL,
 `headimgurl` varchar(2000) NOT NULL,
 `subscribe_time` int(11) NOT NULL,
 `remark` varchar(200) NOT NULL,
 `groupid` int(11) NOT NULL,
 `language` varchar(20) NOT NULL,
 `lastvote` int(11) unsigned NOT NULL,
 `hasvotes` int(11) unsigned NOT NULL,
 PRIMARY KEY (`openid`),
 KEY `subscribe_time` (`subscribe_time`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_xigua_votelog` (
 `lid` int(11) NOT NULL AUTO_INCREMENT,
 `openid` varchar(80) NOT NULL,
 `ip` varchar(15) NOT NULL,
 `vid` int(11) NOT NULL,
 `jid` int(11) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `type` varchar(10) NOT NULL,
 PRIMARY KEY (`lid`),
 KEY `openid` (`openid`),
 KEY `ts` (`ts`),
 KEY `ip` (`ip`)
) ENGINE=MyISAM;


ALTER TABLE `pre_xigua_vote` ADD `groupconfig` VARCHAR(2000) NOT NULL AFTER `zanzhu`;

ALTER TABLE `pre_xigua_join` ADD `cgroup` VARCHAR(50) NOT NULL AFTER `banminute`;

ALTER TABLE `pre_xigua_join` ADD INDEX(`cgroup`);

ALTER TABLE `pre_xigua_vote` ADD `votestart` INT(11) NOT NULL AFTER `joinend`;

SQL;

$ar = array(
    'discuz_plugin_xigua_vote.xml',
    'discuz_plugin_xigua_vote_SC_GBK.xml',
    'discuz_plugin_xigua_vote_SC_UTF8.xml',
    'discuz_plugin_xigua_vote_TC_BIG5.xml',
    'discuz_plugin_xigua_vote_TC_UTF8.xml',
    'install.php',
    'upgrade.php',
);
foreach ($ar as $v) {
    $path = DISCUZ_ROOT . './source/plugin/xigua_vote/'.$v;
    @unlink($path);
}
$finish = TRUE;

if($sql){
    runquery($sql);
}
