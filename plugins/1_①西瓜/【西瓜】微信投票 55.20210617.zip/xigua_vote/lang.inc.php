<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2016/9/30
 * Time: 9:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/xigua_vote/common.php';

$plugin = 'xigua_vote';

loadcache('pluginlanguage_script');

if(submitcheck('dosubmit')){
    if(checkmobile()){
        cpmsg('no zuo no die!', "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=lang", 'succeed');
    }


    $cache = DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
    $data = unserialize($cache);
    $data[$plugin] = $_GET['configary1'];
    C::t('common_syscache')->update('pluginlanguage_template', $data);
    unset($data);

    $cache = DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
    $data = unserialize($cache);
    $data[$plugin] = $_GET['configary1'];
    C::t('common_syscache')->update('pluginlanguage_script', $data);


    cpmsg(sl('update_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=lang", 'succeed');
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=lang");
showtableheader(); /*dism��taobao��com*/


foreach ($_G['cache']['pluginlanguage_script'][$plugin] as $arr => $item) {
    showsetting($arr, 'configary1['.$arr.']', $item, 'text', 0, 0 );
}

showsubmit('dosubmit');
showtablefooter(); /*Dism_taobao-com*/
showformfooter(); /*dis'.'m.tao'.'bao.com*/
