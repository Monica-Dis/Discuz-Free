<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/8/18
 * Time: 15:30
 */
if(!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_vote'];
$_G['wechat']['setting'] = unserialize($_G['setting']['mobilewechat']);


$pluginversion = '20151125';
include_once DISCUZ_ROOT.'./source/plugin/xigua_vote/lib/tietuku_sdk.php';
$upload_sdk = new TTKClient();

define('JOIN_YISHENHE', 1);
define('JOIN_WEISHENHE', 0);
define('JOIN_YIPINGBI', 2);
$tpls = array(
    'black' => sl('black'),
    'pink'  => sl('pink'),
    'pink2' => sl('pink2'),
    'blue'  => sl('blue'), 
    'color'  => sl('color'), 
);
switch($config['charset'])
{
    case 'utf':
        $formfix = ' accept-charset="utf-8" ';
        break;
    case 'gbk':
        $formfix = ' accept-charset="gbk" ';
        break;
    default:
        $formfix = '';
        break;
}
$showshare = !$config['fangfeng'];

function xg_currenturl($related = 0) {
    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
    $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
    $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
    $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
    return $related ? $relate_url : $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
}

function vote_signature($noncestr, $acurl, $timestamp)
{
    global $_G;
    include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
    include_once libfile('function/cache');
    $wechat_client = new WeChatClient($_G['wechat']['setting']['wechat_appId'], $_G['wechat']['setting']['wechat_appsecret']);

    $access_token = $wechat_client->getAccessToken(1);

    $key = 'xigua_vote_jsapi_ticket';
    if(! $ret = xg_readcache($key)) {
        $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=$access_token&type=jsapi";
        $ret = dfsockopen($url);

        $ret = json_decode($ret, TRUE);
        if($ret['errcode'] == 0){
            xg_writecache($key, $ret, $ret['expires_in']);
        }
    }
    $string1 = "jsapi_ticket=$ret[ticket]&noncestr=$noncestr&timestamp=$timestamp&url=$acurl";

    $signature = sha1( $string1 );
    return $signature;
}

function xg_writecache($script, $array = array(), $expirein = 7200)
{
    $expirein = $expirein - 100;
    $datas = array(
        'expireat' => time()+$expirein,
        'data'     => $array
    );
    $cachedata = " return ".var_export($datas, true).";";

    global $_G;

    $dir = DISCUZ_ROOT.'./source/plugin/xigua_vote/cache/';
    if(!is_dir($dir)) {
        dmkdir($dir, 0777);
    }
    if($fp = @fopen("$dir$script.php", 'wb')) {
        fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: ".md5($script.'.php'.$cachedata.$_G['config']['security']['authkey'])."\n\n$cachedata?>");
        fclose($fp);
    } else {
        exit('Can not write to cache files, please check directory ./source/plugin/xigua_vote/cache/ .');
    }
}

function xg_readcache($script)
{
    $dir = DISCUZ_ROOT.'./source/plugin/xigua_vote/cache/';
    if(!is_dir($dir)) {
        dmkdir($dir, 0777);
    }

    $ret = array();

    if(is_file("$dir$script.php")){
        $rets =  include "$dir$script.php";
        $ret = $rets['data'];
        if(time()>= $rets['expireat'] )
        {
            $ret = array();
        }
    }
    return $ret;
}


function sl($lang, $echo = 0){
    global $config;
    global $_G;
    if (!$_G['cache']['plugin']) {
        loadcache('plugin');
    }
    $config = $_G['cache']['plugin']['xigua_vote'];
    $langs[$lang] = lang('plugin/xigua_vote', $lang);

    if($config['tougai']){
        $langs[$lang] = str_replace(lang('plugin/xigua_vote', 'toupiao'), $config['tougai'],$langs[$lang]);
    }
    if($echo){
        echo $langs[$lang];
        return TRUE;
    }else{
        return $langs[$lang];
    }
}

function get_sex($sexno){
    $sex = array(
        0=> sl('woman'),
        1=> sl('man'),
        );
    return $sex[$sexno];
}

function run_upload_multi($file_data)
{
    $ret = $data = array();
    foreach ($file_data['error'] as $k => $error) {
        $data[$k]['name']     = $file_data['name'][$k];
        $data[$k]['type']     = $file_data['type'][$k];
        $data[$k]['tmp_name'] = $file_data['tmp_name'][$k];
        $data[$k]['error']    = $file_data['error'][$k];
        $data[$k]['size']     = $file_data['size'][$k];
    }
    foreach ($data as $k => $row) {
        $ret[$k] = run_upload($row);
    }
    return $ret;
}

function run_upload($file_data, $imgtype = array('.gif', '.jpg', '.jpeg', '.png',), $dir = 'source/plugin/xigua_vote/cache/')
{
    global $_G, $config, $upload_sdk;
    $errors = array(
        UPLOAD_ERR_OK         => sl('UPLOAD_ERR_OK',        0),
        UPLOAD_ERR_INI_SIZE   => sl('UPLOAD_ERR_INI_SIZE',  0),
        UPLOAD_ERR_FORM_SIZE  => sl('UPLOAD_ERR_FORM_SIZE', 0),
        UPLOAD_ERR_PARTIAL    => sl('UPLOAD_ERR_PARTIAL',   0),
        UPLOAD_ERR_NO_FILE    => sl('UPLOAD_ERR_NO_FILE',   0),
        UPLOAD_ERR_NO_TMP_DIR => sl('UPLOAD_ERR_NO_TMP_DIR',0),
        UPLOAD_ERR_CANT_WRITE => sl('UPLOAD_ERR_CANT_WRITE',0),
        99                    => sl('ONLY_IMAGE_ALLOW',     0),
    );
    $error = $file_data['error'];
    if($error != UPLOAD_ERR_OK){
        return array(
            'error' => $error,
            'message' => $errors[$error]
        );
    }

    $type = '.'.addslashes(strtolower(substr(strrchr($file_data['name'], '.'), 1, 10)));
    $t = array_search($type, $imgtype);
    $filetype = $imgtype[$t];
    if($t === false || ! $filetype) {
        return array(
            'error' => 99,
            'message' => $errors[99]
        );
    }

    dmkdir($dir);
    $filena = uniqid(time()) . $filetype;
    $file_attach = $dir. $filena;
    $saved_file = DISCUZ_ROOT . $file_attach;

    if(is_uploaded_file($file_data['tmp_name']))
    {
        if(
            @copy($file_data['tmp_name'], $saved_file) ||
            @move_uploaded_file($file_data['tmp_name'], $saved_file)
        ){
            @unlink($file_data['tmp_name']);
            $imgurl = str_replace('source/plugin/xigua_vote/lib/', '', $_G['siteurl']) . $file_attach;

            $saved_file = DISCUZ_ROOT.$file_attach;
            if($config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET']){
                include_once DISCUZ_ROOT.'source/plugin/xigua_vote/lib/OSS/Common.php';
                if ($surl = vote_sso_upload($filena, $saved_file)) {
                    $imgurl = $surl;
                    @unlink($saved_file);
                }
            }

            return array(
                'error' => 0,
                'url' => $imgurl,
            );
        }else{
            return array(
                'error' => UPLOAD_ERR_CANT_WRITE,
                'message' => $errors[UPLOAD_ERR_CANT_WRITE]
            );
        }
    }
    return array(
        'error' => UPLOAD_ERR_NO_FILE,
        'message' => $errors[UPLOAD_ERR_NO_FILE]
    );
}


function parse_vote_media( $url, $att = ''){

    global $_G;
    if( stripos($url, '.mp3')!==false){
        return "<audio style='width:100%' src='$url' controls='controls'></audio>";
    }
    if( stripos($url, '.mp4')!==false){
        return "<video style='width:100%;height:240px' src='$url' controls='controls'></video>";
    }

    if(
        (strpos($url, 'http://')===false &&strpos($url, 'https://')===false)
        ||
        (strpos($url, 'youku.com')===false &&
            strpos($url, 'tudou.com')===false &&
            strpos($url, '.qq.')===false &&
            strpos($url, 'youtube.')===false &&
            strpos($url, 'youtu.')===false &&
            strpos($url, 'qq.')===false)
    ){
        return $url;
    }
    $data = daddslashes(array(
        'attr' => $att,
        'url'  => $url,
        'formhash' => FORMHASH
    ));
    $link = $_G['siteurl']. 'plugin.php?id='.urlencode('xigua_media:fetchid').'&param='. urlencode(base64_encode(http_build_query($data)));
    $h = checkmobile() ? $_G['cache']['plugin']['xigua_media']['height']: ($_G['cache']['plugin']['xigua_media']['height']*2);
    return <<<VIDEO
<div style="width:100%" class="xigua_media"><iframe style="width:100%;height:{$h}px" frameborder="0" scrolling="no" allowfullscreen="false" src="$link"></iframe></div>
VIDEO;
}