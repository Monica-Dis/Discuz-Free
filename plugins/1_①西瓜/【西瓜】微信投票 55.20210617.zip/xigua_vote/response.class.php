<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/11/15
 * Time: 21:07
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/common.php';

class XGResponse
{
    public $config;

    public function unsubscribe($param)
    {
        global $_G;
        $openid = $param[0]['from'];
        if($openid){
            $this->common();
            C::t('#xigua_vote#xigua_user')->unsubscribe($openid, $this->config['kouchu']);
            if($this->config['kouchu']){

                $vdata = C::t('#xigua_vote#xigua_vote')->fetch_default_vid();
                $now = $_G['timestamp'];
                $voteend = ($now> $vdata['voteend_ts']);
                if(!$voteend){
                    C::t('#xigua_vote#xigua_user')->clear_by_openid($openid);
                }
            }
        }
    }

    public function scan($param)
    {
        list($data) = $param;
        $openid = $data['from'];
        if (is_numeric($data['key'])){
            global $_G;
            if(!$_G['cache']['plugin']){
                loadcache('plugin');
            }
            $config = $_G['cache']['plugin']['xigua_vote'];

            $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_jid($data['key']);
            $needreplace = array(
                '{title}',
                '{name}',
                '{jid}',
                '{totalvotes}',
            );
            $replaced = array(
                $data['title'],
                $jdata['name'],
                $data['key'],
                $jdata['totalvotes'],
            );
            $title = str_replace($needreplace, $replaced, $config['lapt']);
            $navdesc = str_replace($needreplace, $replaced, $config['lapd']);

            $exopenid = urlencode($openid);
            $list[0] = array(
                'title' => $title,
                'desc'  => $navdesc,
                'pic'   => $jdata['pic'][0],
                'url'   => $_G['siteurl'].'plugin.php?id=xigua_vote:index&ac=view&jid='.$data['key'].'&vid='.$jdata['vid'].'&openid='.$exopenid,
            );
            if($jdata){
                echo WeChatServer::getXml4RichMsgByArray($list);
            }
        }
    }

    public function subscribe($param)
    {
        list($data) = $param;
        $openid = $data['from'];
        if($openid){

            global $_G;
            include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
            include_once libfile('function/cache');
            $wechat_client = new WeChatClient($_G['wechat']['setting']['wechat_appId'], $_G['wechat']['setting']['wechat_appsecret']);
            $userinfo = $wechat_client->getUserInfoById($openid);
            unset($userinfo['unionid']);
            foreach ($userinfo as $index => $item) {
                $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
            }
            if($userinfo){
                C::t('#xigua_vote#xigua_user')->insert($userinfo);
            }

            C::t('#xigua_vote#xigua_user')->subscribe($openid);
        }
        $canshow = 1;
        /* if no guanzhu text */
        if (is_numeric($data['key'])){
            global $_G;
            if(!$_G['cache']['plugin']){
                loadcache('plugin');
            }
            $config = $_G['cache']['plugin']['xigua_vote'];

            $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_jid($data['key']);
            $needreplace = array(
                '{title}',
                '{name}',
                '{jid}',
                '{totalvotes}',
            );
            $replaced = array(
                $data['title'],
                $jdata['name'],
                $data['key'],
                $jdata['totalvotes'],
            );
            $title = str_replace($needreplace, $replaced, $config['lapt']);
            $navdesc = str_replace($needreplace, $replaced, $config['lapd']);

            $exopenid = urlencode($openid);
            if($jdata){
            $list[0] = array(
                'title' => $title,
                'desc'  => $navdesc,
                'pic'   => $jdata['pic'][0],
                'url'   => $_G['siteurl'].'plugin.php?id=xigua_vote:index&ac=view&jid='.$data['key'].'&vid='.$jdata['vid'].'&openid='.$exopenid,
            );
            echo WeChatServer::getXml4RichMsgByArray($list);
            $canshow = 0;
            }
        }

        if($openid && $canshow){
            global $_G;
            $list = array();
            $datalist = C::t('#xigua_vote#xigua_vote')->fetch_runing_by_page(0, 10);
            $exopenid = urlencode($openid);
            foreach ($datalist as $item) {
                $list[] = array(
                    'title' => $item['title'],
                    'desc'  => '',
                    'pic'   => $item['cover'][0],
                    'url'   => $_G['siteurl'].'plugin.php?id=xigua_vote:index&vid='.$item['vid'].'&openid='.$exopenid,
                );
            }
            if($list){
                echo WeChatServer::getXml4RichMsgByArray($list);
            }
        }
    }

    function click($param) {
        global $_G;
        if(!$_G['wechat']['setting']) {
            $_G['wechat']['setting'] = unserialize($_G['setting']['mobilewechat']);
        }
        list($data) = $param;
        $openid = $data['from'];

        /*hook start */
        global $_G;
        $wechat_client = new WeChatClient($_G['wechat']['setting']['wechat_appId'], $_G['wechat']['setting']['wechat_appsecret']);
        $userinfo = $wechat_client->getUserInfoById($openid);
        unset($userinfo['unionid']);
        foreach ($userinfo as $index => $item) {
            $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
        }
        $userinfo['openid'] = $openid;
        $userinfo['subscribe'] = 1;

        if($userinfo){
            C::t('#xigua_vote#xigua_user')->insert($userinfo);
        }
        C::t('#xigua_vote#xigua_user')->subscribe($openid);
        /*hook end */
        $data['key'] = strtoupper($data['key']);
        if(strpos($data['key'], 'XVOTE_') !== false) {
            $vid = str_replace('XVOTE_', '', $data['key']);

            $list = array();
            $vdata = C::t('#xigua_vote#xigua_vote')->fetch_by_vid($vid);
            if(!$vdata){
                $vdata = C::t('#xigua_vote#xigua_vote')->fetch_default_vid();
            }
            $exopenid = urlencode($openid);
            $list[0] = array(
                'title' => $vdata['title'],
                'desc'  => '',
                'pic'   => $vdata['cover'][0],
                'url'   => $_G['siteurl'].'plugin.php?id=xigua_vote:index&vid='.$vdata['vid'].'&openid='.$exopenid,
            );
            echo WeChatServer::getXml4RichMsgByArray($list);
        }
    }

    public function text($param)
    {
        list($data1) = $param;

        $openid = $data1['from'];

        global $_G;
        $wechat_client = new WeChatClient($_G['wechat']['setting']['wechat_appId'], $_G['wechat']['setting']['wechat_appsecret']);
        $userinfo = $wechat_client->getUserInfoById($openid);
        unset($userinfo['unionid']);
        foreach ($userinfo as $index => $item) {
            $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
        }
        $userinfo['openid'] = $openid;
        $userinfo['subscribe'] = 1;

        if($userinfo){
            C::t('#xigua_vote#xigua_user')->insert($userinfo);
        }
        C::t('#xigua_vote#xigua_user')->subscribe($openid);


        global $_G;
        $content = diconv($data1['content'], 'UTF-8');
        $this->common();
        if($content == $this->config['baomingtxt']){
            $vdata = C::t('#xigua_vote#xigua_vote')->fetch_default_vid();
            $exopenid = urlencode($openid);
            $baominghref = $_G['siteurl'].'plugin.php?id=xigua_vote:index&ac=signup&openid='.$exopenid.'&vid='.intval($vdata['vid']);
//            echo WeChatServer::getXml4Txt('<a href="'.$baominghref.'">'.($this->config['xiangyingtxt']).'</a>');
            $list[0] = array(
                'title' => $vdata['title'],
                'desc' => '',
                'pic' => $vdata['cover'][0],
                'url' => $baominghref,
            );
            echo WeChatServer::getXml4RichMsgByArray($list);
        } else
        if(strpos($content, $this->config['gongzhong'])!==false){
            $ar = array(
            );
            if($ar[$content]){
                $vdata = C::t('#xigua_vote#xigua_vote')->fetch_by_vid($ar[$content]);
            }else{
                $vid = str_replace($this->config['gongzhong'], '', $content);
                if(is_numeric($vid)){
                    $vdata = C::t('#xigua_vote#xigua_vote')->fetch_by_vid($vid);
                }else{
                    $vdata = C::t('#xigua_vote#xigua_vote')->fetch_default_vid();
                }
            }
            $exopenid = urlencode($openid);
            $list[0] = array(
                'title' => $vdata['title'],
                'desc' => '',
                'pic' => $vdata['cover'][0],
                'url' => $_G['siteurl'].'plugin.php?id=xigua_vote:index&vid='.$vdata['vid'].'&openid='.$exopenid,
            );
            echo WeChatServer::getXml4RichMsgByArray($list);
        }else if(is_numeric($content)){

            $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_jid($content);
            if($jdata){
                $vdata = C::t('#xigua_vote#xigua_vote')->fetch_by_vid($jdata['vid']);
            }else{
                $vdata = C::t('#xigua_vote#xigua_vote')->fetch_default_vid();
            }
            $now = $_G['timestamp'];
            $joinend = ($now> $vdata['joinend_ts']);
            $voteend = ($now> $vdata['voteend_ts']);
            $response = C::t('#xigua_vote#xigua_join')->votenow($data1['from'], $vdata['vid'], $content, $voteend, $joinend, $this->config, $vdata, 'text');

            $lang = sl($response['msg']);
            if($response['msg'] == 'notintime'){
                $lang = sprintf(sl("notintime"), $this->config['xiantime']);
            }else if($response['msg'] == 'xianguanzhu'){
                $lang = sprintf(sl("xianguanzhu"), $this->config['gongzhonghao']);
            }

            if($response['error']==0){
                $href = $_G['siteurl'].'plugin.php?id=xigua_vote:index&ac=view&jid='.$content.'&openid='. urlencode($openid).'&vid='.intval($vdata['vid']);

                $pic = $response['jdata']['pic'][0] ? $response['jdata']['pic'][0] : $vdata['cover'][0];
                if($pic && strpos($pic, 'http:')===false){
                    $pic = $_G['siteurl'].$pic;
                }
                $list[0] = array(
                    'title' => $lang,
                    'desc' => $response['successmsg'] ? $response['successmsg'] : $lang,
                    'pic' => $pic,
                    'url' => $href,
                );
                echo WeChatServer::getXml4RichMsgByArray($list);
            }else{
            echo WeChatServer::getXml4Txt($lang);
            }
        }
    }

    public function common(){
        global $_G;
        if (!$_G['cache']['plugin']) {
            loadcache('plugin');
        }
        $this->config = $_G['cache']['plugin']['xigua_vote'];
    }
}


