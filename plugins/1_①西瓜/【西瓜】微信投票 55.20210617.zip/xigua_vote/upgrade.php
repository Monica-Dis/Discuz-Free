<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginid = 'xigua_vote';


$sql = '';

$ar = array(
    'discuz_plugin_xigua_vote.xml',
    'discuz_plugin_xigua_vote_SC_GBK.xml',
    'discuz_plugin_xigua_vote_SC_UTF8.xml',
    'discuz_plugin_xigua_vote_TC_BIG5.xml',
    'discuz_plugin_xigua_vote_TC_UTF8.xml',
    'install.php',
    'upgrade.php',
);
foreach ($ar as $v) {
    $path = DISCUZ_ROOT . './source/plugin/xigua_vote/'.$v;
    @unlink($path);
}


$Hooks = array(
    'forumdisplay_topBar',
);

$data = array();
foreach($Hooks as $Hook) {
    $data[] = array(
        $Hook => array(
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid,
            'method' => $Hook,
            'order'  => 0,
        )
    );
}

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);



$updatedata = array(
    'receiveEvent::subscribe' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'subscribe'
    ),
    'receiveEvent::unsubscribe' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'unsubscribe'
    ),
    'receiveMsg::text' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'text'
    ),
    'receiveEvent::click' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'click'
    ),
    'receiveEvent::scan' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'scan'
    ),
);
$responsehook = WeChatHook::updateResponse($updatedata, 551);

$finish = TRUE;

if($sql){
    runquery($sql);
}