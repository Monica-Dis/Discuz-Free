<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z DisM.Taobao.Com $
 */


if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginid = 'xigua_vote';

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::delAPIHook($pluginid);

$sql = <<<EOT
  DROP TABLE pre_xigua_join;
  DROP TABLE pre_xigua_vote;
  DROP TABLE pre_xigua_user;
  DROP TABLE pre_xigua_votelog;
EOT;

if($sql){
    runquery($sql);
}

$ar = array(
    'discuz_plugin_xigua_vote.xml',
    'discuz_plugin_xigua_vote_SC_GBK.xml',
    'discuz_plugin_xigua_vote_SC_UTF8.xml',
    'discuz_plugin_xigua_vote_TC_BIG5.xml',
    'discuz_plugin_xigua_vote_TC_UTF8.xml',
    'uninstall.php',
    'install.php',
    'api.class.php',
    'common.php',
    'index.inc.php',
    'list.inc.php',
);

foreach ($ar as $v) {
    $path = DISCUZ_ROOT . './source/plugin/xigua_vote/'.$v;
    @unlink($path);
}

xg_votedel(DISCUZ_ROOT . './source/plugin/xigua_vote', true);
@rmdir(DISCUZ_ROOT . './source/plugin/xigua_vote');

$finish = TRUE;

function xg_votedel($directory, $empty = false, $strict = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return true;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    $ret = xg_votedel($path, $empty, $strict);
                    if($strict && !$ret){
                        return false;
                    }
                } else {
                    if(!@unlink($path)){
                        if($strict){
                            return false;
                        }
                    }
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}