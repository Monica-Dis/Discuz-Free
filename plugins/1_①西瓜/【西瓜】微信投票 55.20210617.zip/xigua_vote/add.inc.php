<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/9/3
 * Time: 17:31
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/admincp/menu.php';
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/common.php';

if($gvid = intval($_GET['vid'])){
    $data = C::t('#xigua_vote#xigua_vote')->fetch_by_vid($gvid);
    if(!$data){
        $gvid = 0;
    }
}

if(submitcheck('dosubmit') && !$gvid){
    $cover_data = array();
    $cover = run_upload_multi($_FILES['cover']);
    foreach ($cover as $item) {
        if($item['error'] == 0){
            $cover_data[] = $item['url'];
        }
    }
    $add = $_GET['add'];
    $add['joinfield'] = serialize($add['joinfield']);
    $add['checksignup'] = intval($add['checksignup']);
    $add['cover'] = serialize($cover_data);
    $add['crts'] = $_G['timestamp'];
    $add['isdefault'] = 0;
    foreach (array( 'joinend', 'voteend', 'votestart') as $item) {
        $add[$item] = strtotime($add[$item]);
    }

    $vid = C::t('#xigua_vote#xigua_vote')->insert($add, true);
    if($vid){
        cpmsg(sl('add_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=add&vid=$vid", 'succeed');
    }else{
        cpmsg(sl('add_error'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=add", 'error');
    }
}else if(submitcheck('dosubmit') && $gvid){
    $add = $_GET['add'];

    $cover_data = (array)$add['oldcover'];
    $cover = run_upload_multi($_FILES['cover']);
    foreach ($cover as $item) {
        if($item['error'] == 0){
            $cover_data[] = $item['url'];
        }
    }
    unset($add['oldcover']);
    $add['joinfield'] = serialize($add['joinfield']);
    $add['checksignup'] = intval($add['checksignup']);
    $add['cover'] = serialize($cover_data);
    $add['crts'] = $_G['timestamp'];
    foreach (array( 'joinend', 'voteend', 'votestart') as $item) {
        $add[$item] = strtotime($add[$item]);
    }

    $ret = C::t('#xigua_vote#xigua_vote')->update($gvid, $add);
    if($ret){
        cpmsg(sl('update_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=add&vid=$gvid", 'succeed');
    }else{
        cpmsg(sl('update_error'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=add", 'error');
    }
}

$formheader = "plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=add&vid=$gvid";
echo showformheader($formheader, 'enctype');

$backurl = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_vote&pmod=list&page=".$_GET['backpage'];
?>
<link rel="stylesheet" href="./source/plugin/xigua_vote/static/kindeditor/themes/default/default.css" />
<table class="tb tb2 fixpadding">
    <tbody>
    <tr>
        <th colspan="15" class="partition"><?php echo ($data ? sl('edit_vote').' (ID:'.$gvid.")" : sl('add_vote')) . "<a class='fr' href=\"$backurl\">".sl('back').sl('list')."</a>";?></th>
    </tr>
    <tr>
        <td colspan="2" class="td27"><?php echo sl('biaoti')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <input name="add[title]" value="<?php echo $data['title']?>" type="text" class="txt">
        </td>
        <td class="vtop tips2"><?php echo sl('biaoti1') ?></td>
    </tr>


    <tr>
        <td colspan="2" class="td27"><?php echo sl('m1')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform vm">
            <input name="add[shareinfo]" type="text" class="txt" value="<?php echo isset($data['shareinfo']) ? $data['shareinfo'] : ''?>"  />
        </td>
        <td class="vtop tips2"><?php echo sl('m2')?></td>
    </tr>


    <tr>
        <td colspan="2" class="td27"><?php echo sl('m3')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <select name="add[tpl]" >
                <?php foreach ($tpls as $tpl => $tplname) {
                    if($data['tpl'] == $tpl){
                        $chk = 'selected';
                    }else{
                        $chk = '';
                    }
                   echo '<option value="'.$tpl.'" '.$chk.'>'.$tplname.'</option>';
                }?>
            </select>
        </td>
        <td class="vtop tips2"><?php echo sl('m4')?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m5')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform" >
            <input name="add[music]" value="<?php echo $data['music']?>" type="text" class="txt" placeholder="http://">
        </td>
        <td class="vtop tips2"><?php echo sl('m7') ?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m8')?></td>
    </tr>
    <tr class="noborder">
        <td colspan="2" class="vtop rowform" id="cover">
            <div style="margin-bottom:5px">
                <?php foreach ((array)$data['cover'] as $k => $item) {
                    if(!$item){continue;}
                    echo "<span id='w1$k'><a href='$item' target='_blank'><img class=\"imgi\" src=\"$item\" onmouseover=\"$('p1$k').style.display='block'\" onmouseout=\"$('p1$k').style.display='none'\" /></a><img class='imgprevew' src=\"$item\" id='p1$k' /> <input name='add[oldcover][]'  value='$item' type='text'><a onclick='$(\"w1$k\").parentNode.removeChild($(\"w1$k\"))' class='closeX'>X&nbsp;&nbsp;</a></span>";
                }?>
            </div>

            <div id="coverdiv">
                <input name='cover[]' type='file' class='txt uploadbtn marginbot'>
                <a class="block" style="cursor:pointer" onclick="add_cover(this);return false;"><?php echo sl('m9') ?></a>
            </div>
        </td>
    </tr>
    <tr>
        <td colspan="2" class="td27"><?php echo sl('m10')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform">
            <input type="text" class="txt" name="add[joinend]" value="<?php
            echo isset($data['joinend']) ? $data['joinend'] : date('Y-m-d H:i', strtotime('+1 week'));
            ?>"  onclick="showcalendar(event, this, true)">
        </td>
        <td class="vtop tips2"><?php echo sl('m11')?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m112')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform">
            <input type="text" class="txt" name="add[votestart]" value="<?php
            echo isset($data['votestart']) ? date('Y-m-d H:i',$data['votestart']) : date('Y-m-d H:i', strtotime('+1 week'));
            ; ?>"  onclick="showcalendar(event, this, true)">
        </td>
        <td class="vtop tips2"><?php echo sl('m1121')?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m12')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform">
            <input type="text" class="txt" name="add[voteend]" value="<?php
            echo isset($data['voteend']) ? $data['voteend'] : date('Y-m-d H:i', strtotime('+1 month'));
            ; ?>"  onclick="showcalendar(event, this, true)">
        </td>
        <td class="vtop tips2"><?php echo sl('m13')?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m14')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform">
            <input name="add[maxinjoin]" type="number" class="txt" value="<?php echo isset($data['maxinjoin']) ? $data['maxinjoin'] : 10?>"  />
        </td>
        <td class="vtop tips2"><?php echo sl('m15')?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m16')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform vm">
            <ul class="vlist">
                <li>
                    <input name="add[votepreday]" type="number" class="txt" value="<?php echo isset($data['votepreday']) ? $data['votepreday'] : 3?>"  />
                </li>
            </ul>
        </td>
        <td class="vtop tips2"><?php echo sl('m17')?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m18')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform vm">
            <ul>
                <li >
                    <input class="checkbox" type="checkbox" name="add[joinfield][name][require]" <?php if($data['joinfield']['name']['require']){echo 'checked';} ?> value="1"><?php echo sl('name') ?>
                    <input type="text" class="txt stxt" name="add[joinfield][name][etc]" placeholder="<?php echo sl('m19') ?>" value="<?php echo $data ? $data['joinfield']['name']['etc'] : sl('mengbao')?>" />
                </li>
                <li>
                    <input class="checkbox" type="checkbox" name="add[joinfield][mobile][require]" <?php if($data['joinfield']['mobile']['require']){echo 'checked';} ?> value="1"><?php echo sl('mobile') ?>
                    <input type="text" class="txt stxt" name="add[joinfield][mobile][etc]" placeholder="<?php echo sl('m19') ?>" value="<?php echo $data ? $data['joinfield']['mobile']['etc'] : sl('mobileno')?>" />
                </li>
                <li>
                    <input class="checkbox" type="checkbox" name="add[joinfield][sex][require]" <?php if($data['joinfield']['sex']['require']){echo 'checked';} ?> value="1"><?php echo sl('sex') ?>
                    <input type="text" class="txt stxt" name="add[joinfield][sex][etc]" placeholder="<?php echo sl('m19') ?>" value="<?php echo $data ? $data['joinfield']['sex']['etc'] : sl('sex')?>" />
                    <input type="checkbox" name="add[joinfield][sex][show]" value="1" <?php echo $data['joinfield']['sex']['show'] ? 'checked="checked"' : ''; ?>><?php echo sl('disnone') ?>
                </li>
                <li>
                    <input class="checkbox" type="checkbox" name="add[joinfield][profile][require]" <?php if($data['joinfield']['profile']['require']){echo 'checked';} ?> value="1"><?php echo sl('profile') ?>
                    <input type="text" class="txt stxt" name="add[joinfield][profile][etc]" placeholder="<?php echo sl('m19') ?>" value="<?php echo $data ? $data['joinfield']['profile']['etc'] :  sl('profile1')?>" />
                    <input type="checkbox" name="add[joinfield][profile][show]" value="1" <?php echo $data['joinfield']['profile']['show'] ? 'checked="checked"' : ''; ?>><?php echo sl('disnone') ?>

                </li>
                <li>
                    <input class="checkbox" type="checkbox" name="add[joinfield][pic][require]" <?php if($data['joinfield']['pic']['require']){echo 'checked';} ?> value="1"><?php echo sl('pic') ?>
                    <input type="text" class="txt stxt" name="add[joinfield][pic][etc]" placeholder="<?php echo sl('m19') ?>" value="<?php echo $data ? $data['joinfield']['pic']['etc'] : sl('pic1')?>" />
                    <input type="checkbox" name="add[joinfield][pic][show]" value="1" <?php echo $data['joinfield']['pic']['show'] ? 'checked="checked"' : ''; ?>><?php echo sl('disnone') ?>
                </li>



                <?php for($i=1; $i<=20;$i++){ $fi = 'ext'.$i;?>
                <li>
                    <input class="checkbox" type="checkbox" name="add[joinfield][<?php echo $fi?>][require]" <?php if($data['joinfield'][$fi]['require']){echo 'checked';} ?> value="1"><?php echo $fi ?>
                    <input type="text" class="txt stxt" name="add[joinfield][<?php echo $fi?>][etc]" placeholder="" value="<?php echo $data ? $data['joinfield'][$fi]['etc'] : ''?>" />
                    <input type="checkbox" name="add[joinfield][<?php echo $fi?>][show]" value="1" <?php echo $data['joinfield'][$fi]['show'] ? 'checked="checked"' : ''; ?>><?php echo sl('disnone') ?>
                    <input type="checkbox" name="add[joinfield][<?php echo $fi?>][must]" value="1" <?php echo $data['joinfield'][$fi]['must'] ? 'checked="checked"' : ''; ?>><?php echo sl('must') ?>
                </li>
                <?php }?>



            </ul>
        </td>
        <td class="vtop tips2"><?php echo sl('ext') ?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m20')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform vm">
            <ul onmouseover="altStyle(this);">
                <li ><input class="checkbox" type="checkbox" name="add[checksignup]" <?php echo $data['checksignup'] ? 'checked' : ''?> value="1"><?php echo sl('m21') ?></li>
            </ul>
        </td>
        <td class="vtop tips2"><?php echo sl('m22') ?></td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('m23')?></td>
    </tr>
    <tr class="noborder">
        <td colspan="2" class="vtop rowform vm">
            <textarea id="c11" name="add[content]" style="width:100%;height:300px;visibility:hidden;"><?php echo $data ? $data['content'] : sl('default1')?></textarea>
        </td>
    </tr>
    <tr>
        <td colspan="2" class="td27"><?php echo sl('m24')?></td>
    </tr>
    <tr class="noborder">
        <td colspan="2" class="vtop rowform vm">
            <textarea id="c12" name="add[prizecontent]" style="width:100%;height:200px;visibility:hidden;"><?php echo $data ? $data['prizecontent'] : sl('default2')?></textarea>
        </td>
    </tr>
    <tr>
        <td colspan="2" class="td27"><?php echo sl('m25')?></td>
    </tr>
    <tr class="noborder">
        <td colspan="2" class="vtop rowform vm">
            <textarea id="c13" name="add[statement]" style="width:100%;height:200px;visibility:hidden;"><?php echo $data ? $data['statement'] : sl('default3')?></textarea>
        </td>
    </tr>

    <tr>
        <td colspan="2" class="td27"><?php echo sl('zanzhu')?></td>
    </tr>
    <tr class="noborder">
        <td colspan="2" class="vtop rowform vm">
            <textarea id="c14" name="add[zanzhu]" style="width:100%;height:100px;visibility:hidden;"><?php echo $data ? $data['zanzhu'] : sl('default4')?></textarea>
        </td>
    </tr>


    <tr>
        <td colspan="2" class="td27"><?php echo sl('m26')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform vm">
            <input name="add[vviews]" type="number" class="txt" value="<?php echo isset($data['vviews']) ? $data['vviews'] : 0?>"  />
        </td>
        <td class="vtop tips2"><?php echo sl('m27') ?></td>
    </tr>
    <tr>
        <td colspan="2" class="td27"><?php echo sl('m28')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform vm">
            <input name="add[vvotes]" type="number" class="txt" value="<?php echo isset($data['vvotes']) ? $data['vvotes'] : 0?>"  />
        </td>
        <td class="vtop tips2"><?php echo sl('m29') ?></td>
    </tr>


    <tr>
        <td colspan="2" class="td27"><?php echo sl('upconf')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform vm">
            <textarea class="txt"  name="add[groupconfig]"><?php echo isset($data['groupconfig']) ? $data['groupconfig'] : ''?></textarea>
        </td>
        <td class="vtop tips2"><?php echo sl('geshi') ?></td>
    </tr>


    <tr>
        <td colspan="2" class="td27">
            <input name="dosubmit" value="<?php echo sl('m30') ?>" type="submit" class="btn" />
        </td>
    </tr>
    </tbody>
</table>
<?php showformfooter(); /*dis'.'m.tao'.'bao.com*/?>
<script charset="utf-8" src="./source/plugin/xigua_vote/static/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="./source/plugin/xigua_vote/static/kindeditor/lang/zh_CN.js"></script>
<script>
    function add_cover(obj){
        var i = document.createElement('input');
        i.name = 'cover[]';
        i.type = 'file';
        i.className = 'txt uploadbtn marginbot';
        $('coverdiv').insertBefore(i, obj);
        return false;
    }
    var uploadurl = '<?php echo $_G['site_url']?>source/plugin/xigua_vote/lib/UPLOAD.php';
    var ritems = [
        'source', '|', 'undo', 'redo', '|', 'preview', 'template', 'cut', 'copy', 'paste',
        'plainpaste', 'wordpaste', '|', 'justifyleft', 'justifycenter', 'justifyright',
        'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
        'superscript', 'clearhtml', 'quickformat', 'selectall', '|', 'fullscreen', '/',
        'formatblock', 'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold',
        'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'image', 'multiimage', 'table', 'hr', 'emoticons', 'baidumap', 'pagebreak',
        'anchor', 'link', 'unlink'
    ];
    var config = {
        uploadJson : uploadurl,
        allowFileManager: false,
        items : ritems
    };
    KindEditor.ready(function(K) {
        editor1 = K.create('#c11', config);
        editor2 = K.create('#c12', config);
        editor3 = K.create('#c13', config);
        editor4 = K.create('#c14', config);
    });
</script>