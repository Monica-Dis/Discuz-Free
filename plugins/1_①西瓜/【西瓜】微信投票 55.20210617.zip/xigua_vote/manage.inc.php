<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/11/20
 * Time: 00:34
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/admincp/menu.php';
include_once DISCUZ_ROOT. 'source/plugin/xigua_vote/common.php';
include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
include_once libfile('function/cache');


$updatedata = array(
    'receiveEvent::subscribe' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'subscribe'
    ),
    'receiveEvent::unsubscribe' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'unsubscribe'
    ),
    'receiveMsg::text' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'text'
    ),
    'receiveEvent::click' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'click'
    ),
    'receiveEvent::scan' => array(
        'plugin' => 'xigua_vote',
        'include' => 'response.class.php', 'class' => 'XGResponse', 'method' => 'scan'
    ),
);
$responsehook = WeChatHook::updateResponse($updatedata, 551);


showtableheader(sl('api'));
$rowhead = array(
sl('o16'),
sl('o17')
);
showtablerow('class="header"', array(), $rowhead);
foreach ($updatedata as $k => $v) {
    showtablerow('', array(), array(
        sl($v['method']),
        sl($v['method'].'use'),
    ));
}
showtablefooter(); /*Dism_taobao-com*/
