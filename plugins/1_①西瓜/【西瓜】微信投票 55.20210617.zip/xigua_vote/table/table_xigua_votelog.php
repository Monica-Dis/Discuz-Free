<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/11/2
 * Time: 10:37
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_votelog extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_votelog';
        $this->_pk = 'lid';

        parent::__construct();
    }

    public function today_votes($openid, $vid, $jid = 0){
        global $_G;
        $date = dgmdate($_G['timestamp'], 'Y-m-d');
        $start = strtotime($date);
        $end = $start+86400;

        if($jid){
            $ext = "jid=$jid AND vid=$vid";
        }else{
            $ext = "vid=$vid";
        }
        return DB::result_first("SELECT count(*) as num FROM %t WHERE openid=%s AND $ext AND ts>%d AND ts<%d ", array(
            $this->_table,
            $openid,
            $start,
            $end
        ));
    }

    public function minute_votes($vid, $jid){
        global $_G;
        $start = $_G['timestamp']-61;
        $end = $_G['timestamp']+1;

        return DB::result_first("SELECT count(*) as num FROM %t WHERE jid=$jid AND vid=$vid AND ts>%d AND ts<%d ", array(
            $this->_table,
            $start,
            $end
        ));
    }

    public function ip_check($vid, $per = 0){
        global $_G;

        if($per){
            $start = strtotime(dgmdate($_G['timestamp'], 'Y-m-d'));
            return DB::result_first("SELECT count(*) as num FROM %t WHERE ip=%s AND vid=%d AND ts>=%d", array(
                $this->_table,
                $_G['clientip'],
                $vid,
                $start
            ));
        }else{
            return DB::result_first("SELECT count(*) as num FROM %t WHERE ip=%s AND vid=%d ", array(
                $this->_table,
                $_G['clientip'],
                $vid,
            ));
        }
    }



    public function fetch_by_page($vid, $jid, $start_limit , $lpp, $ext_where = '')
    {
        $vid = intval($vid);
        if($jid = intval($jid)){
            $ext = " AND jid=$jid ";
        }
        if($ext_where){
            $ext_where = " AND $ext_where ";
        }
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE vid=$vid $ext $ext_where ORDER BY lid DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }
    public function fetch_count($vid, $jid = 0){
        $vid = intval($vid);
        if($jid = intval($jid)){
            $ext = " AND jid=$jid ";
        }

        $result = DB::result_first('SELECT count(*) as c FROM '.DB::table($this->_table). " WHERE vid=$vid $ext ");
        return $result;
    }

    public function fetch_all_log_by_openid($openid)
    {
        $result = DB::fetch_all('SELECT jid,vid FROM %t WHERE openid=%s', array(
            $this->_table,
            $openid
        ));
        return $result;
    }

    public function fetch_count_by_openid($openid, $jid)
    {
        $result = DB::result_first('SELECT count(*) AS num FROM %t WHERE openid=%s AND jid=%d', array(
            $this->_table,
            $openid,
            $jid
        ));
        return $result;
    }

    public function delete_by_openid($openid)
    {
        return DB::delete($this->_table, array('openid' => $openid));
    }

    public function get_last_votets($jid, $openid)
    {
        $result = DB::result_first('SELECT ts FROM %t WHERE openid=%s AND jid=%d ORDER BY ts DESC', array(
            $this->_table,
            $openid,
            $jid
        ));
        return $result;
    }
}