<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/11/3
 * Time: 15:09
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_user extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_user';
        $this->_pk = 'openid';

        parent::__construct();
    }

    public function insert($data, $return_id = 0)
    {
        $field = array(
            'openid',
            'subscribe',
            'nickname',
            'sex',
            'city',
            'province',
            'country',
            'headimgurl',
            'subscribe_time',
            'remark',
            'groupid',
            'language',
            'lastvote',
            'hasvotes',
        );
        foreach ($data as $index => $item) {
            if(!in_array($index, $field)){
                unset($data[$index]);
            }
        }

        if(DB::result_first('SELECT openid FROM %t WHERE `openid`=%s LIMIT 1', array($this->_table, $data['openid']))){
            return DB::update($this->_table, $data, array('openid' => $data['openid']));
        }

        if(parent::insert($data, $return_id)){
            return true;
        }
        return false;
    }

    public function unsubscribe($openid, $kouchu = 0)
    {
        if($kouchu){
            $cond = array('subscribe' => 0, 'lastvote' => 0, 'hasvotes' => 0);
        }else{
            $cond = array('subscribe' => 0);
        }
        return DB::update($this->_table, $cond, array('openid' => $openid));
    }

    public function subscribe($openid)
    {
        return DB::update($this->_table, array('subscribe' => 1, 'subscribe_time' => time()), array('openid' => $openid));
    }

    public function update_voteinfo($openid)
    {
        global $_G;
        return DB::query("UPDATE %t SET lastvote=%d, `hasvotes`=`hasvotes`+1 WHERE openid=%s", array(
            $this->_table,
            $_G['timestamp'],
            $openid
        ));
    }

    public function fetch_by_openids($openids)
    {
        return parent::fetch_all($openids);
    }



    public function fetch_by_page($start_limit , $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " ORDER BY hasvotes DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_count(){
        $result = DB::result_first('SELECT count(*) as c FROM '.DB::table($this->_table));
        return $result;
    }

    public function clear_by_openid($openid){
        //clear vote log
        $vjids = C::t('#xigua_vote#xigua_votelog')->fetch_all_log_by_openid($openid);
        $vids = $jids = array();
        foreach ($vjids as $v) {
            $vids[$v['vid']]++;
            $jids[$v['jid']]++;
        }
        //del jid vote
        foreach ($jids as $vv => $num) {
            C::t('#xigua_vote#xigua_join')->incr_vote($vv, -$num);
        }
        //del vid vote
//        foreach ($vids as $vv => $num) {
//            C::t('#xigua_vote#xigua_vote')->incr_vote($vv, -$num);
//        }
        //del vote log
        C::t('#xigua_vote#xigua_votelog')->delete_by_openid($openid);
        return true;
    }

    public function fetch_subscribe($openid)
    {
        return DB::result_first('SELECT subscribe FROM %t WHERE openid=%s LIMIT 1', array(
            $this->_table,
            $openid
        ));
    }
}