<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/11/3
 * Time: 15:09
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_join extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_join';
        $this->_pk = 'jid';

        parent::__construct();
    }

    public function fetch_totalvotes($vid)
    {
        $ret = DB::result_first('SELECT SUM(totalvotes) FROM %t WHERE vid=%d', array($this->_table, $vid));
        return $ret;
    }

    public function insert($data, $return_insert_id = true, $ignore_openid = false)
    {
        if(!$ignore_openid){
            if(!$data['openid'] || !$data['vid']){
                return 0;
            }
            if(DB::result_first('SELECT openid FROM %t WHERE openid=%s AND vid=%d ', array(
                $this->_table,
                $data['openid'],
                $data['vid']
            ))){
                return 0;
            }
        }
//       ALTER TABLE `pre_xigua_join` ADD `bsid` int(11) NOT NULL;
//        $data['bsid'] = DB::result_first("select count(*) as ord_num from %t a where a.vid=%d", array($this->_table, $data['vid']));
//        $data['bsid'] = $data['bsid'] + 1;
        return parent::insert($data, $return_insert_id);
    }

    public function incr_vote($jid, $num)
    {
        return DB::query("UPDATE %t SET `totalvotes`=`totalvotes`+ %d WHERE jid=%d", array(
            $this->_table,
            $num,
            $jid
        ));
    }

    public function update($data, $condition)
    {
        return DB::update($this->_table, $data, $condition);
    }

    public function update_status($jids, $status = JOIN_YISHENHE){
        $jids = dintval($jids, 1);
        return DB::update($this->_table, array('status' => $status), 'jid IN ('.implode(',', $jids).')');
    }

    public function fetch_by_jid($jid)
    {
        $data = DB::fetch_first('SELECT * FROM %t WHERE `jid`=%d LIMIT 1', array($this->_table, $jid));
        if($data){
            $data['crts'] = date('Y-m-d H:i:s', $data['crts']);
            $data['pic'] = unserialize($data['pic']);
        }
        return $data;
    }

    public function fetch_by_openid($openid, $vid)
    {
        $data = DB::fetch_first('SELECT * FROM %t WHERE openid=%s AND vid=%d LIMIT 1', array($this->_table, $openid, $vid));
        if($data){
            $data['crts'] = date('Y-m-d H:i:s', $data['crts']);
            $data['pic'] = unserialize($data['pic']);
        }
        return $data;
    }

    public function fetch_by_search($vid, $keyword){
        $keyword = stripsearchkey($keyword);
        if(!$keyword){
            return array();
        }
        if(is_numeric($keyword)){
            $ext = " jid=".intval($keyword);
        }else{
            $ext = " ( name LIKE '%$keyword%' OR profile LIKE '%$keyword%' OR mobile LIKE '%$keyword%' ) ";
        }

        $vid = intval($vid);
        $result = DB::fetch_all('SELECT * FROM '. DB::table($this->_table) . " WHERE vid=$vid AND ".$ext);
        foreach ($result as $key => $item) {
            $result[$key]['crts'] = date('Y-m-d H:i:s', $result[$key]['crts']);
            $result[$key]['pic'] = unserialize($result[$key]['pic']);
        }
        return $result;
    }

    public function fetch_joinlist_by_page($vid, $start_limit , $lpp, $order = 'time', $all = 0)
    {
        if($all){
            $all = ' AND status='.intval($_GET['status']);
        }else{
            $all = ' AND status='.JOIN_YISHENHE;
        }
        $rank = $start_limit+1;
        if($order == 'time'){
            $od = "$this->_pk DESC ";
        }else{
            $od = "totalvotes DESC ";
        }

        $cgroup = '';
        if($_GET['cgr'] && isset($GLOBALS['cgroup'][$_GET['cgr']])){
            $cgroup = " AND cgroup='{$_GET['cgr']}'";
        }

        $vid = intval($vid);
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE vid=$vid $cgroup $all ORDER BY $od " . DB::limit($start_limit, $lpp));
        foreach ($result as $key => $item) {
            $result[$key]['crts'] = date('Y-m-d H:i:s', $result[$key]['crts']);
            $result[$key]['pic'] = unserialize($result[$key]['pic']);
            $result[$key]['rank'] = $rank++;
        }
        return $result;
    }
    public function fetch_count($vid, $all = 0){
        $vid = intval($vid);
        if($all){
            $all = ' AND status='.intval($_GET['status']);
        }else{
            $all = ' AND status='.JOIN_YISHENHE;
        }
        $cgroup = '';
        if($_GET['cgr'] && isset($GLOBALS['cgroup'][$_GET['cgr']])){
            $cgroup = " AND cgroup='{$_GET['cgr']}'";
        }
        $result = DB::result_first('SELECT count(*) as c FROM '.DB::table($this->_table). " WHERE vid=$vid $cgroup $all");
        return $result;
    }

    public function votenow($openid, $vid, $jid, $voteend, $joinend, $config, $data, $type='page')
    {
        $jid = intval($jid);
        $vid = intval($vid);
        global $_G;
        if(!$config['qudao1'] && $type =='page'){
            $response['msg'] = 'notexists_huifu';
            $response['error'] = 15;
            return $response;
        }
        if($data['votestart']&&$data['votestart']> TIMESTAMP){
            $response['msg'] = 'notstart';
            $response['error'] = 17;
            return $response;
        }
        if(!$config['qudao2'] && $type !='page'){
            $response['msg'] = 'notexists_huifu';
            $response['error'] = 15;
            return $response;
        }

        if(!$openid){
            $response['msg'] = 'xianguanzhu';
            $response['error'] = 14;
            return $response;
        }

        //check xiantime
        if($config['xiantime']){
            $times_ = explode('~', str_replace(':', '', $config['xiantime']));
            $now = date('Hi', $_G['timestamp']);
            if(!($now>$times_[0] && $now <$times_[1])){
                $response['msg'] = 'notintime';
                $response['error'] = 11;
                return $response;
            }
        }

        //check ipadress
        if($type=='page' && $config['ipadress']){
            $api = "http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=json&ip=".$_G['clientip'];
            $api = "http://ip.taobao.com/service/getIpInfo.php?ip=".$_G['clientip'];
            if($ipres = json_decode(dfsockopen($api), true)){
                $ipres['province'] = diconv($ipres['data']['region'], 'utf-8');
                $ipres['city']     = diconv($ipres['data']['city'], 'utf-8');
                $config['ipadress'] = array_filter(explode(',', $config['ipadress']));
                if(($ipres['province'] || $ipres['city']) &&
                    !(
                        in_array($ipres['province'], $config['ipadress']) ||
                        in_array($ipres['city'], $config['ipadress'])
                    )
                ){
                    $retmsg = str_replace(array('{province}', '{city}'), array($ipres['province'], $ipres['city']), $config['ipban']);
                    $response['msg'] = diconv($retmsg, CHARSET, 'utf-8');
                    $response['error'] = 13;
                    return $response;
                }
            }
        }else if($type!='page' &&  $config['ipadress']){
            $users = C::t('#xigua_vote#xigua_user')->fetch_by_openids(array($openid));
            $userinfo = $users[$openid];
            $config['ipadress'] = array_filter(explode(',', $config['ipadress']));
            if(
            ($userinfo['city'] && !in_array($userinfo['city'], $config['ipadress'])) &&
            ($userinfo['province'] && !in_array($userinfo['province'], $config['ipadress']))
            ){
                $retmsg = str_replace(array('{province}', '{city}'), array($userinfo['province'], $userinfo['city']), $config['ipban']);
                $response['msg'] = $retmsg;
                $response['error'] = 13;
                return $response;
            }
        }

        //check guanzhu
        if($type=='page' && $config['xianguanzhu']){
            $issubscribe = C::t('#xigua_vote#xigua_user')->fetch_subscribe($openid);
            if(!$issubscribe){
                $wechat_client = new WeChatClient($_G['wechat']['setting']['wechat_appId'], $_G['wechat']['setting']['wechat_appsecret']);
                $userinfo = $wechat_client->getUserInfoById($openid);
                if(!$userinfo['subscribe']){
                    $response['msg'] = 'xianguanzhu';
                    $response['error'] = 14;
                    return $response;
                }
            }
        }

        if($voteend){
            $response['msg'] = 'voteend';
            $response['error'] = 2;
            return $response;
        }else{

            $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_jid($jid);

            //check exists
            if(!isset($jdata['status'])){
                $response['msg'] = 'notexists';
                $response['error'] = 7;
                return $response;
            }

            //checkstatus
            if($jdata['status']!=JOIN_YISHENHE){
                $response['msg'] = 'weishenhe';
                $response['error'] = 6;
                return $response;
            }

//            if($type=='page' && $config['zbeishu']>0 && strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false){
//                $config['iplimit']    = $config['iplimit'] * $config['zbeishu'];
//                $config['iplimitper'] = $config['iplimitper'] * $config['zbeishu'];
//                $config['maxprejoinday'] = $config['maxprejoinday'] * $config['zbeishu'];
//                $config['maxatvote'] = $config['maxatvote'] * $config['zbeishu'];
//                $data['maxinjoin']    = $data['maxinjoin'] * $config['zbeishu'];
//                $data['votepreday']    = $data['votepreday'] * $config['zbeishu'];
//            }

            //check ip
            if($type=='page' && $config['iplimit'] && C::t('#xigua_vote#xigua_votelog')->ip_check($vid)>=$config['iplimit']){
                $response['msg'] = 'iplimit';
                $response['error'] = 5;
                return $response;
            }

            //check ip iplimitper
            if($type=='page' && $config['iplimitper'] && C::t('#xigua_vote#xigua_votelog')->ip_check($vid, 1)>=$config['iplimitper']){
                $response['msg'] = 'iplimit';
                $response['error'] = 5;
                return $response;
            }

            //check in join
            if($data['maxinjoin'] && !$joinend){
                if($jdata['totalvotes']>=$data['maxinjoin']){
                    $response['msg'] = 'maxinjoin';
                    $response['error'] = 4;
                    return $response;
                }
            }

            //check jiange
            if($config['jiange']){
                $lastts = C::t('#xigua_vote#xigua_votelog')->get_last_votets($jid, $openid);
                if($_G['timestamp'] - $lastts<=$config['jiange']){
                    $response['msg'] = 'jiangetaiduan';
                    $response['error'] = 12;
                    return $response;
                }
            }

            //check maxprejoinday
            if($config['maxprejoinday'] && (C::t('#xigua_vote#xigua_votelog')->today_votes($openid, $vid, $jid)>=$config['maxprejoinday'])){
                $response['msg'] = 'maxprejoinday';
                $response['error'] = 9;
                return $response;
            }

            //check maxatvote
            if($config['maxatvote'] && (C::t('#xigua_vote#xigua_votelog')->fetch_count_by_openid($openid, $jid))>=$config['maxatvote']){
                $response['msg'] = 'maxatvote';
                $response['error'] = 10;
                return $response;
            }


            //check today
            if($data['votepreday'] && (C::t('#xigua_vote#xigua_votelog')->today_votes($openid, $vid))>=$data['votepreday']){
                $response['msg'] = 'votepreday';
                $response['error'] = 3;
                return $response;
            }

            /*check max one minute*/
            //20=5|60|9999
            if($config['maxone']){
                //����Ƿ���ͣͶƱ
                if($jdata['banendts']>= $_G['timestamp']){  //��ͣ��
                    $response['msg'] = str_replace('{n}', $jdata['banminute'], $config['maxoneword']);
                    if($type=='page'){
                        $response['msg'] = diconv($response['msg'], CHARSET, 'utf-8');
                    }
                    $response['error'] = 16;
                    return $response;
                }

                list($maxone, $tary) = explode('=', trim($config['maxone']));
                if($maxone && C::t('#xigua_vote#xigua_votelog')->minute_votes($vid, $jid)>= ($maxone-1)){ //����
                    $tary = explode('|', trim($tary));
                    $maxsub = count($tary)-1;
                    $bantimes = intval($jdata['bantimes']);
                    $banminute = isset($tary[$bantimes]) ? $tary[$bantimes] : $tary[$maxsub];
                    if(!$banminute){
                        $banminute = 10;
                    }
                    //��ͣͶƱ �ӳ���ͣͶƱʱ��
                    DB::query("UPDATE %t SET `bantimes`=`bantimes`+1,`banendts`=%d,`banminute`=%d WHERE jid=%d", array(
                        $this->_table,
                        ($_G['timestamp']+$banminute*60),
                        $banminute,
                        $jid,
                    ));
                }
            }

            $prenum = 1;
            $in_app = stripos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false;

            if($type=='page' && $config['zbeishu']>0 && $in_app){  //Appbyme QianFan
                $prenum = intval($prenum * $config['zbeishu']);
            }

            if(!$in_app && $config['onlyvoteapp']){
                $response['msg'] = 'xianguanzhu';
                $response['error'] = 14;
                return $response;
            }

            if(C::t('#xigua_vote#xigua_join')->incr_vote($jid, $prenum)){

                $lid = C::t('#xigua_vote#xigua_votelog')->insert(array(
                    'openid' => $openid,
                    'ip' => $_G['clientip'],
                    'vid' => $vid,
                    'jid' => $jid,
                    'ts'  => $_G['timestamp'],
                    'type' => $type
                ), true);

                C::t('#xigua_vote#xigua_vote')->incr_vote($vid, $prenum);
                C::t('#xigua_vote#xigua_user')->update_voteinfo($openid);
                $response['msg'] = 'succeed';
                $response['error'] = 0;


                $jdata = C::t('#xigua_vote#xigua_join')->fetch_by_jid($jid);
                if ($jdata['openid'] != $openid && $config['kefumsg']) {
                    $paiming = DB::result_first('SELECT count(*) AS num FROM %t WHERE totalvotes>=%d AND vid=%d AND status=%d ORDER BY totalvotes DESC,jid ASC', array(
                        $this->_table,
                        $jdata['totalvotes'],
                        $vid,
                        JOIN_YISHENHE
                    ));

                    $chaju = 0;
                    if ($paiming > 1) {
                        $chaju = DB::result_first('SELECT totalvotes FROM %t WHERE vid=%d AND status=%d ORDER BY totalvotes DESC,jid ASC LIMIT %d,1', array(
                            'xigua_join',
                            $vid,
                            JOIN_YISHENHE,
                            $paiming - 2,
                        ));
                        $chaju = $chaju - $jdata['totalvotes'];
                    }

                    $url = $_G['siteurl'] . 'plugin.php?id=xigua_vote:index&ac=view&jid=' . $jid . '&vid=' . $vid . '&openid=' . urlencode($openid);
                    $users = C::t('#xigua_vote#xigua_user')->fetch_by_openids(array($openid));
                    $userinfo = $users[$openid];

                    $successmsg = str_replace(array(
                        '{nickname}',
                        '{name}',
                        '{votes}',
                        '{paiming}',
                        '{chaju}',
                        '{url}',
                    ), array(
                        $userinfo['nickname'],
                        $jdata['name'],
                        $jdata['totalvotes'],
                        $paiming,
                        $chaju,
                        $url
                    ), $config['successmsg']);
                    $kfmsg = str_replace(array(
                        '{nickname}',
                        '{name}',
                        '{votes}',
                        '{paiming}',
                        '{chaju}',
                        '{url}',
                    ), array(
                        $userinfo['nickname'],
                        $jdata['name'],
                        $jdata['totalvotes'],
                        $paiming,
                        $chaju,
                        $_G['siteurl'] . 'plugin.php?id=xigua_vote:index&ac=view&jid=' . $jid . '&vid=' . $vid . '&openid=' . urlencode($jdata['openid'])
                    ), $config['kefumsg']);
                    self::sendmessage(sl($kfmsg), $jdata['openid']);
                }

                if($type != 'page'){
                    $response['successmsg'] = strip_tags(sl($successmsg));
                    $response['jdata'] = $jdata;
                }
                return $response;
            }
            $response['msg'] = 'notexists';
            $response['error'] = 7;
            return $response;
        }
    }

    public function get_uncheck_count($vid)
    {
        return DB::result_first('SELECT count(*) AS num FROM %t WHERE vid=%d AND status=%d', array(
            $this->_table,
            $vid,
            JOIN_WEISHENHE
        ));
    }

    public function get_pingbi_count($vid)
    {
        return DB::result_first('SELECT count(*) AS num FROM %t WHERE vid=%d AND status=%d', array(
            $this->_table,
            $vid,
            JOIN_YIPINGBI
        ));
    }





    public function sendmessage($content, $openid)
    {
        $content = diconv($content, CHARSET, 'utf-8');
        global $_G;
        include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
        include_once libfile('function/cache');
        $wechat_client = new WeChatClient($_G['wechat']['setting']['wechat_appId'], $_G['wechat']['setting']['wechat_appsecret']);

        $access_token    = $wechat_client->getAccessToken();

        $data            = '{
						"touser":"' . $openid . '",
						"msgtype":"text",
						"text":{
							"content":"'.$content.'"
                        }
					}';
        $url   = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" . $access_token;
        $it = self::ihttp_post($url, $data);
        $tmp  = json_decode($it, true);
        if($tmp['errcode']){

            $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$_G['wechat']['setting']['wechat_appId']}&secret={$_G['wechat']['setting']['wechat_appsecret']}";
            $json = dfsockopen($url);
            if(!$json){
                $json = file_get_contents($url);
            }
            $access_data = json_decode($json, true);
            $access_token = $access_data['access_token'];

            if($access_token){
                savecache( 'wechatat_' . $_G['wechat']['setting']['wechat_appId'], array(
                    'token' => $access_token,
                    'expiration' => time() + 6200,
                ));
            }

            $url   = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" . $access_token;
            $it = self::ihttp_post($url, $data);
        }
        return $it;
    }

    public static function ihttp_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }

    public function multi_update_cgroup($cgroups)
    {
        foreach ($cgroups as $jid => $row) {
            DB::update($this->_table, array('cgroup' => $row), array($this->_pk => $jid));
        }
        return TRUE;
    }

}