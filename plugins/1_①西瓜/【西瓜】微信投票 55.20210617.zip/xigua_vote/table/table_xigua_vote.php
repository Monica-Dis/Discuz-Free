<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/11/2
 * Time: 10:37
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_vote extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_vote';
        $this->_pk = 'vid';

        parent::__construct();
    }

    public function incr_vote($vid, $votenum, $joinnum = 0)
    {
        $join = '';
        if($joinnum){
            $join = " ,`joins`=`joins`+ ".intval($joinnum);
        }
        return DB::query("UPDATE %t SET `votes`=`votes`+ %d $join WHERE vid=%d", array(
            $this->_table,
            $votenum,
            $vid
        ));
    }

    public function update_totalvotes($vid)
    {
        $total = C::t('#xigua_vote#xigua_join')->fetch_totalvotes($vid);
        return DB::query('UPDATE %t SET `votes`=%d WHERE vid=%d LIMIT 1', array($this->_table, $total, $vid));
    }

    public function update_joins_by_vid($vid, $num){
        return DB::query("UPDATE %t SET `joins`=`joins`+ %d WHERE vid=%d", array(
            $this->_table,
            $num,
            $vid
        ));
    }

    private function proc($data, $vid){
        if($data){
            $data['joinend_ts'] = $data['joinend'];
            $data['voteend_ts'] = $data['voteend'];
            $data['joinend'] = date('Y-m-d H:i', $data['joinend']);
            $data['voteend'] = date('Y-m-d H:i', $data['voteend']);
            $data['cover']   = unserialize($data['cover']);
            $data['joinfield'] = unserialize($data['joinfield']);
        }
        DB::query('UPDATE %t SET `views`=`views`+1 WHERE vid=%d', array(
            $this->_table,
            $vid
        ));
        return $data;
    }

    public function fetch_by_vid($vid)
    {
        $data = DB::fetch_first('SELECT * FROM %t WHERE `vid`=%d LIMIT 1', array($this->_table, $vid));
        $data = $this->proc($data, $vid);
        return $data;
    }

    public function fetch_list_by_page($start_limit , $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_runing_by_page($start_limit , $lpp)
    {
        $result = DB::fetch_all('SELECT title,cover,vid FROM ' . DB::table($this->_table) . " WHERE voteend>".time()." ORDER BY isdefault DESC,$this->_pk DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index]['cover']   = unserialize($item['cover']);
        }
        return $result;
    }
    public function fetch_count(){
        $result = DB::result_first('SELECT count(*) as c FROM '.DB::table($this->_table));
        return $result;
    }

    public function set_default($vid){
        DB::query('UPDATE %t SET `isdefault`=0 WHERE 1', array(
            $this->_table,
            $vid
        ));
        return DB::query('UPDATE %t SET `isdefault`=1 WHERE vid=%d', array(
            $this->_table,
            $vid
        ));
    }

    public function fetch_default_vid()
    {
        $data =  DB::fetch_first('SELECT * FROM %t WHERE isdefault=1 LIMIT 1', array($this->_table));
        $data = $this->proc($data, $data['vid']);
        return $data;
    }
}