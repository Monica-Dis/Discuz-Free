<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_good` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `shid` varchar(1000) NOT NULL,
 `title` varchar(200) NOT NULL,
 `usetime` int(11) NOT NULL,
 `shname` varchar(80) NOT NULL,
 `hy` varchar(200) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `stock` int(11) NOT NULL,
 `sellnum` int(11) NOT NULL,
 `fee_type` int(11) NOT NULL,
 `tprice` decimal(10,2) NOT NULL,
 `dprice` decimal(10,2) NOT NULL,
 `disprice` decimal(10,2) NOT NULL,
 `danci` int(11) NOT NULL,
 `zong` int(11) NOT NULL,
 `ptmin` int(11) NOT NULL,
 `ptshixian` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `jieshao` text NOT NULL,
 `append_img` text NOT NULL,
 `append_text` text NOT NULL,
 `album` text NOT NULL,
 `status` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `srange` varchar(512) NOT NULL,
 `jtt` varchar(2000) NOT NULL,
 `spgg` text NOT NULL,
 `stat` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`),
 KEY `stat` (`stat`),
 KEY `shid` (`shid`(255)),
 KEY `uid` (`uid`),
 KEY `title` (`title`),
 KEY `hangye_id1` (`hangye_id1`),
 KEY `hangye_id2` (`hangye_id2`),
 KEY `status` (`status`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_good_price` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `name` varchar(200) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `stock` int(11) NOT NULL,
 `price_pt` decimal(10,2) NOT NULL,
 `price_dm` decimal(10,2) NOT NULL,
 `price_sc` decimal(10,2) NOT NULL,
 `sellnum` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `gid_2` (`gid`,`name`),
 KEY `displayorder` (`displayorder`),
 KEY `gid` (`gid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_order` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `buy_type` int(11) NOT NULL,
 `tuan_id` int(11) NOT NULL,
 `gnum` int(11) NOT NULL,
 `tuan_num` int(11) NOT NULL,
 `pay_money` decimal(10,2) NOT NULL,
 `addrid` int(11) NOT NULL,
 `addr` varchar(500) NOT NULL,
 `pay_ts` int(11) NOT NULL,
 `fa_ts` int(11) NOT NULL DEFAULT '-1',
 `shou_ts` int(11) DEFAULT '-1',
 `tui_ts` int(11) NOT NULL,
 `tuicfm_ts` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `priceid` int(11) NOT NULL,
 `priceinfo` varchar(2000) NOT NULL,
 `goodinfo` text NOT NULL,
 `note` varchar(500) NOT NULL,
 `yunfee` decimal(10,2) NOT NULL,
 `title` varchar(200) NOT NULL,
 `pay_endts` int(11) NOT NULL,
 `mobile` varchar(200) NOT NULL,
 `realname` varchar(200) NOT NULL,
 `status` int(11) NOT NULL,
 `pt_success_ts` int(11) NOT NULL,
 `cmtid` int(11) NOT NULL DEFAULT '-1',
 `shid` int(11) NOT NULL,
 `unit_price` decimal(10,2) NOT NULL,
 `shixian` int(11) NOT NULL,
 `yundan` varchar(200) NOT NULL,
 `yundan_gs` varchar(200) NOT NULL,
 `upts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `tuan_id` (`tuan_id`),
 KEY `order_id` (`order_id`),
 KEY `pay_endts` (`pay_endts`),
 KEY `cmtid` (`cmtid`),
 KEY `shid` (`shid`),
 KEY `buy_type` (`buy_type`),
 KEY `crts` (`crts`),
 KEY `pay_ts` (`pay_ts`),
 KEY `fa_ts` (`fa_ts`),
 KEY `shou_ts` (`shou_ts`),
 KEY `gid` (`gid`),
 KEY `status` (`status`),
 KEY `shid_2` (`shid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_yf` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `dist1` varchar(80) NOT NULL,
 `dist2` varchar(80) NOT NULL,
 `yunfei` decimal(10,2) NOT NULL,
 `crts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `shids` varchar(1000) NOT NULL,
 `stid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_refund` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `ptlogid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `danhao` varchar(200) NOT NULL,
 `gongsi` varchar(200) NOT NULL,
 `note` varchar(500) NOT NULL,
 `status` int(11) NOT NULL DEFAULT '-1' COMMENT '-1new2success',
 `order_status` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `refund_info` varchar(2000) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `crts` (`crts`),
 KEY `odid` (`ptlogid`),
 KEY `shid` (`shid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

SQL;



runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_pt/discuz_plugin_xigua_pt.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_pt/discuz_plugin_xigua_pt_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_pt/discuz_plugin_xigua_pt_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_pt/discuz_plugin_xigua_pt_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_pt/discuz_plugin_xigua_pt_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_pt/install.php');

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'youhui\'', array('xigua_pt_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good` ADD `youhui` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}



$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hxuid\'', array('xigua_pt_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_order` ADD `hxuid` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_pt_order` ADD `hxcrts` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_pt_order` ADD `hxnote` VARCHAR(500) NOT NULL;
ALTER TABLE `pre_xigua_pt_order` ADD `hxcode` VARCHAR(20) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'refund\'', array('xigua_pt_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_order` ADD `refund` VARCHAR(800) NOT NULL;

SQL;
    runquery($sql);
}



$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'custom_ticheng\'', array('xigua_pt_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good` ADD `custom_ticheng` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'custom_ticheng2\'', array('xigua_pt_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good` ADD `custom_ticheng2` DECIMAL(10,2) NOT NULL AFTER custom_ticheng;

SQL;
    runquery($sql);
}



$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'chengben\'', array('xigua_pt_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good` ADD `chengben` DECIMAL(10,2) NOT NULL;

ALTER TABLE `pre_xigua_pt_order` ADD `chengben` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'price_cb\'', array('xigua_pt_good_price'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good_price` ADD `price_cb` DECIMAL(10,2) NOT NULL DEFAULT '0.00';

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'refund2\'', array('xigua_pt_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_order` ADD `refund2` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'lat\'', array('xigua_pt_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good` ADD `lat` VARCHAR(20) NOT NULL;

ALTER TABLE `pre_xigua_pt_good` ADD `lng` VARCHAR(20) NOT NULL;

ALTER TABLE `pre_xigua_pt_good` ADD INDEX( `lat`, `lng`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'backprice\'', array('xigua_pt_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good` ADD `backprice` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_pt_good` ADD `province` VARCHAR(20) NOT NULL;
ALTER TABLE `pre_xigua_pt_good` ADD `city` VARCHAR(20) NOT NULL;
ALTER TABLE `pre_xigua_pt_good` ADD `district` VARCHAR(20) NOT NULL;
ALTER TABLE `pre_xigua_pt_good` ADD INDEX(`province`);
ALTER TABLE `pre_xigua_pt_good` ADD INDEX(`city`);
ALTER TABLE `pre_xigua_pt_good` ADD INDEX(`district`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'refund_id\'', array('xigua_pt_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_order` ADD `refund_id` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'allowrefund\'', array('xigua_pt_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good` ADD `allowrefund` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'shou_confirm_ts\'', array('xigua_pt_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_order` ADD `shou_confirm_ts` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'price_hk1\'', array('xigua_pt_good_price'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_pt_good_price` ADD `price_hk1` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_pt_good_price` ADD `price_hk2` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_pt_good` ADD `pricehk1` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_pt_good` ADD `pricehk2` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}