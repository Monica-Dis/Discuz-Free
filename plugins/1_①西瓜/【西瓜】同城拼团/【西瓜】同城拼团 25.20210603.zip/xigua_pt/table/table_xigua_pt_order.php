<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * Class table_xigua_pt_order
 */
class table_xigua_pt_order extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_pt_order';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        global $good, $_G;
        if($good['danci']>0 && $data['gnum']>$good['danci']){
            hb_message(lang_pt('dancigmbn',0).$good['danci'].lang_pt('fen',0), 'error');
            return false;
        }
        if($good['zong']>0){
            $myz = DB::result_first("select count(*) from %t where status in(2,6) AND uid=%d AND gid=%d ", array($this->_table, $_G['uid'], $data['gid']));
            if(($myz+$data['gnum'])>$good['zong']){
                hb_message(lang_pt('zdyx',0).$good['zong'].lang_pt('fen',0), 'error');
                return false;
            }
        }
        return DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $need_user = 0, $need_sh = 0)
    {
        global $_G, $SCRITPTNAME,$urlext;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));

        $uids = $shids = array();


        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
            $shids[] = $item['shid'];
        }
        if($need_user && $uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['username'] = $users[$item['uid']]['username'];
            }
        }
        if(($need_sh||$GLOBALS['need_sh']) && $shids){
            $shs = DB::fetch_all('SELECT shid,`name`,logo FROM %t WHERE shid IN (%n)', array('xigua_hs_shanghu', $shids), 'shid');
            foreach ($result as $index => $item) {
                $result[$index]['sh'] = $shs[$item['shid']];
            }
        }
        return $result;
    }
    public function fetch_count_by_where($wherearr)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first("SELECT count(*) as cnt FROM " . DB::table($this->_table) . " $wheresql ");
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_by_gid($gid)
    {
        $ret = $this->fetch($gid);
        $ret = self::prepare($ret);


        return $ret;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        global $_G, $SCRITPTNAME,$urlext,$tuan_id;
        if($v){

            if($tuan_id || $_GET['tuan_id'] || $_GET['tuanid']){
                $v['youhui'] = 0;
            }
            if($_GET['buy_type']==1){
                $v['youhui'] = 0;
            }

            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i:s', $v['crts']) : '';
            $v['pay_ts_u'] = $v['pay_ts']>0 ? date('Y-m-d H:i:s', $v['pay_ts']) : '';
            $v['shou_ts_u'] = $v['shou_ts']>0 ? date('Y-m-d H:i:s', $v['shou_ts']) : '';
            $v['tuicfm_ts_u'] = $v['tuicfm_ts']>0 ? date('Y-m-d H:i:s', $v['tuicfm_ts']) : '';
            $v['shixian_u'] = $v['shixian'] ? date('Y-m-d H:i:s', $v['shixian']) : '';
            $v['priceshot'] = unserialize($v['priceinfo']);
            $v['goodshot'] = unserialize($v['goodinfo']);

            if($v['order_id'] && $v['status'] == 1){
                $order_id = $v['order_id'];
                $rl = urlencode($_G['siteurl'].$SCRITPTNAME."?id=xigua_pt&ac=order_profile$urlext&ptlog_id=".$v['id']);
                $v['jumpurl'] = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
            }
            if($v['pay_endts']<TIMESTAMP && $v['status'] == 1){
                DB::update('xigua_pt_order', array(
                    'status' => 4  //��ʱδ֧��
                ), array('id' => $v['id']));
            }

            $v['allowtk'] = $v['needback'] = 0;
            $pt_config = $_G['cache']['plugin']['xigua_pt'];
            if(!$_GET['manage'] &&$v['goodshot']['allowrefund'] && in_array($v['status'], array(2,6))){
                if($v['goodshot']['fee_type']==1){
                    $v['allowtk'] = ($v['shou_ts']<=0&&$v['fa_ts']<=0) || ($v['shou_ts']>0 && (TIMESTAMP-$v['shou_ts']<=$pt_config['tckts']*86400));
                    $v['needback'] = $v['fa_ts']>0;
                }else{
                    $v['allowtk'] = $v['shou_ts']<=0;
                }
            }
        }
        return $v;
    }

    public function fetch_by_tuanid($tuanid, $withtuanzhang = 1)
    {
        if($withtuanzhang){
            $result = DB::fetch_all("SELECT * FROM " . DB::table($this->_table) . " WHERE buy_type=2 AND pay_ts>0 AND ( id=%d OR  tuan_id=%d ) ORDER BY tuan_id ASC", array(
                $tuanid,
                $tuanid,
            ));
        }else{
            $result = DB::fetch_all("SELECT * FROM " . DB::table($this->_table) . " WHERE buy_type=2 AND pay_ts>0 AND ( tuan_id=%d ) ORDER BY tuan_id ASC", array(
                $tuanid,
            ));
        }
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_only_tuanzhang($tuanid)
    {
        $result = DB::fetch_all("SELECT * FROM " . DB::table($this->_table) . " WHERE buy_type=2 AND pay_ts>0 AND status=5 AND id=%d ", array(
            $tuanid,
        ));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
}