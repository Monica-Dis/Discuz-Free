<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_pt_good_price extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_pt_good_price';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function update_price($data){
        $r = DB::fetch_first('select * from %t WHERE gid=%d AND `name`=%s', array(
            $this->_table,
            $data['gid'],
            $data['name'],
        ));
        if($r){
            unset($data['gid']);
            unset($data['name']);
            unset($data['crts']);
            DB::update($this->_table, $data, array('id' => $r['id']));
        }else{
            parent::insert($data);
        }
        return true;
    }
    public function fetch($id){
        $r = parent::fetch($id);
        $r = self::prepare($r);
        return $r;
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
            $this->_table,
             $id,
             $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $keyfield = '')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        if($keyfield){
            $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp), array(), $keyfield);
        }else{
            $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        }
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            if($_GET['buy_type']==1 || $_GET['form']['buy_type']==1){
                $v['price_pt'] = $v['price_dm'];
            }elseif($_GET['buy_type'] ==2 || $_GET['form']['buy_type']==2){
                $v['price_dm'] = $v['price_pt'];
            }

            $v['price_pt_old'] = $v['price_pt'];
            $v['price_dm_old'] = $v['price_dm'];

            global $_G;
            if($_G['cache']['plugin']['xigua_hk'] && ($v['price_hk1']>0 || $v['price_hk2']>0) && !defined('IN_ADMINCP')&& $_GET['ac']!='spgg'){
                $card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid']);
                if($card && $_G['uid']){
                    $v['price_pt'] = $v['price_hk1']>0 ? $v['price_hk1'] : $v['price_pt'];
                    $v['price_dm'] = $v['price_hk2']>0 ? $v['price_hk2'] : $v['price_dm'];
                }
            }
        }
        return $v;
    }

    public function fetch_by_stock($id, $num)
    {
        $res = DB::fetch_first('SELECT * FROM %t WHERE '.$this->_pk.'=%d AND stock>=%d', array(
            $this->_table,
            $id,
            $num
        ));
        $res = self::prepare($res);
        return $res;
    }
    public function update_stock($id, $num)
    {
        DB::query('update %t set stock=stock-%d WHERE '.$this->_pk.'=%d AND stock>=%d', array(
            $this->_table,
            $num,
            $id,
            $num,
        ));
        return DB::affected_rows();
    }
}