<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_pt_good extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_pt_good';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false)
    {
        $data['stid']      = intval($_GET['st']);
        $data['backprice'] = 0;

        $r = parent::insert($data, $return_insert_id, $replace, $silent);

        if($return_insert_id && !defined('IN_ADMINCP')){
            global $_G;
            include_once DISCUZ_ROOT.'source/plugin/xigua_pt/function.php';
            /*default ggname*/
            $dftspgg = lang('plugin/xigua_pt', 'ggdft');
            $spgg = array();
            foreach (explode("\n", $dftspgg) as $index => $item) {
                list($name, $value) = explode("=", trim($item));
                $value = explode(',', trim($value));
                if($name&&$value){
                    $spgg[] = array(
                        'id' => $index,
                        'name' => $name,
                        'ggtext' => $value
                    );
                }
            }
            C::t('#xigua_pt#xigua_pt_good')->update($r, array('spgg' => serialize($spgg)));

            $price_list = $pow = array();
            $ggtest = $n = array();
            foreach ($spgg as $str => $item) {
                $ggtest[] = $item['ggtext'];
            }
            $ggtest = combination($ggtest);
            foreach ($ggtest as $index => $item) {
                $updata = array(
                    'crts' => TIMESTAMP,
                    'upts' => TIMESTAMP,
                    'uid'  => $_G['uid'],
                    'gid'  => $r
                );
                $updata['price_pt'] = $data['tprice'];
                $updata['price_dm'] = $data['dprice'];
                $updata['price_sc'] = $data['disprice'];
                $updata['price_hk1'] = $data['pricehk1'];
                $updata['price_hk2'] = $data['pricehk2'];
                $updata['stock']    = $data['stock'];
                $updata['name']     = is_array($item) ? implode('###', $item) : $item;
                C::t('#xigua_pt#xigua_pt_good_price')->update_price($updata);
            }
            /*default ggname*/
        }

        return $r;
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        if($data['backprice']>5){
            $data['backprice'] = 0;
        }
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
            $this->_table,
             $id,
             $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $pt_config;
        if($pt_config['allowfz'] && is_array($wherearr) && !defined('IN_ADMINCP')){
            $wherearr[] = 'stid='.intval($_GET['st']);
            global $_G;
            if(!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']){
                array_pop($wherearr);
            }
        }
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if('id DESC' == $orderby){
            $orderby = 'displayorder DESC, id DESC';
        }

        if($_GET['order'] == 'near' && $_GET['lat']){
            $lat = floatval($_GET['lat']);
            $lng = floatval($_GET['lng']);
            $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
            $fields = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
            $orderby = 'distance ASC, displayorder DESC, id DESC';
        }

        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_by_gid($gid, $with= 1)
    {
        $gid = intval($gid);
        $ret = $this->fetch($gid);
        $ret = self::prepare($ret);

        if($with){
            $ret['price_list'] = C::t('#xigua_pt#xigua_pt_good_price')->fetch_all_by_where(array("gid=".$gid), 0, 9999, '', '*');

            $showprice = array();
            $price_dm_min = $price_pt_min = 999999;
            $price_sc_max = $price_dm_max =  $price_pt_max = 0.01;
            foreach ($ret['price_list'] as $key => $val) {

                $showprice[] = $val['price_pt_old'];
                $showprice[] = $val['price_dm_old'];

                $price_pt_min = min($price_pt_min, $val['price_pt']);
                $price_pt_max = max($price_pt_max, $val['price_pt']);
                $price_dm_min = min($price_dm_min, $val['price_dm']);
                $price_dm_max = max($price_dm_max, $val['price_dm']);
                $price_sc_max = max($price_sc_max, $val['price_sc']);
                $ret['price_list'][$key]['name'] = diconv($ret['price_list'][$key]['name'], CHARSET, 'UTF-8');
            }

            $price_pt_min = floatval($price_pt_min);
            $price_pt_max = floatval($price_pt_max);
            $price_dm_min = floatval($price_dm_min);
            $price_dm_max = floatval($price_dm_max);
            $price_sc_max = floatval($price_sc_max);

            $ret['price_pt_min'] = $price_pt_min;
            $ret['price_pt_max'] = $price_pt_max;
            if($price_pt_min == $price_pt_max){
                $ret['price_pt'] = $price_pt_max;
            }else{
                $ret['price_pt'] = $price_pt_min.'-'.$price_pt_max;
            }

            $ret['price_dm_min'] = $price_dm_min;
            $ret['price_dm_max'] = $price_dm_max;
            if($price_pt_min == $price_dm_max){
                $ret['price_dm'] = $price_dm_max;
            }else{
                $ret['price_dm'] = $price_dm_min.'-'.$price_dm_max;
                $ret['price_pt'] = $price_pt_min.'-'.$price_dm_max;
            }

            $ret['price_sc_max'] = $price_sc_max;

            $tmp1 = min($showprice);
            $tmp2 = max($showprice);
            $ret['price_pt_old'] =  $tmp1==$tmp2 ? $tmp1 : $tmp1.'-'.$tmp2;
        }

        return $ret;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            $v['append_img_ary'] = unserialize($v['append_img']);
            $v['append_text_ary'] = unserialize($v['append_text']);
            $v['jtt_ary'] = unserialize($v['jtt']);
            $v['spgg_ary'] = unserialize($v['spgg']);
            $v['album'] = unserialize($v['album']);
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['usetime_u'] = $v['usetime'] ? date('Y-m-d H:i', $v['usetime']) : '';
            $v['srange_ary'] = array_filter(explode("\t", trim($v['srange'])));
            $v['tprice'] = floatval($v['tprice']);

            if($GLOBALS['tuan_id'] || $_GET['tuan_id'] || $_GET['tuanid']|| $_GET['form']['tuanid']==1|| $_GET['form']['tuan_id']==1){
                $v['youhui'] = 0;
            }
            if($_GET['buy_type']==1 || $v['buy_type']==1 || $_GET['form']['buy_type']==1){
                $v['youhui'] = 0;
            }

            if($v['distance']){
                $distance = intval($v['distance']);
                if($distance<=1000){
                    $distance = intval($distance). 'm';
                }else if($distance>1000){
                    $distance = round($distance/1000, 1). 'km';
                }
                $v['distance'] = $distance;
            }
        }
        return $v;
    }
}