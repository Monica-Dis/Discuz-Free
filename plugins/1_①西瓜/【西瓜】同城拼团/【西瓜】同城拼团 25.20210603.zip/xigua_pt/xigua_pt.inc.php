<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_pt/function.php';
$pt_config = $_G['cache']['plugin']['xigua_pt'];
$status_font = array(1 => lang_pt('status_1', 0), 2 => lang_pt('status_2', 0), 3 => lang_pt('status_3', 0), 4 => lang_pt('status_4', 0), 5 => lang_pt('status_5', 0), 6 => lang_pt('status_6', 0), 7 => lang_pt('status_7', 0));
$svicerange = array();
foreach (explode("\n", trim($pt_config['svicerange'])) as $index => $item) {
	$svicerange[] = trim($item);
}
$aclist = array('index', 'good', 'add', 'add_area', 'add_area_li', 'none', 'manage', 'good_li', 'spgg', 'view', 'confirm', 'buy', 'shisuan', 'order', 'order_li', 'order_profile', 'cat_li', 'cat', 'com', 'invite', 'cate', 'cancel_order', 'order_manage', 'help', 'chosecity', 'tuihuo');
$aclist_login = array('add', 'manage', 'spgg', 'buy', 'confirm', 'order_li', 'order', 'order_profile', 'invite', 'cancel_order', 'order_manage', 'tuihuo');
$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
$isself = in_array($ac, $aclist_login) || !(strpos($ac, 'my') === false) && !$_G['uid'];
if ($isself && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$gid = intval($_GET['gid']);
$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $pt_config['pcolor'];
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
switch ($ac) {
	case 'chosecity':
		if ($_GET['ctid']) {
			$rlist = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($_GET['ctid']);
			include template('xigua_hb:header_ajax');
			include template('xigua_pt:chosecity');
			include template('xigua_hb:footer_ajax');
		}
		break;
	case 'index':
		if ($pt_config['allowindexnav']) {
			$hyobj = C::t('#xigua_pt#xigua_pt_hangye');
			$list_all = $hyobj->list_all();
			$hyobj->init($list_all);
			$cat_tree_init = $cat_tree = $hyobj->get_tree_array(0);
			$cat_tree = array_values($cat_tree);
			$catname = lang_hb('quanbu', 0);
			$subcat = $cat_tree;
			$_key = 'hbIdist' . intval($_GET['st']);
			loadcache($_key);
			if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
				$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
				$GLOBALS['nojson'] = 1;
				$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
				C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
				$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
				foreach ($dist0 as $index => $item) {
					C::t('#xigua_hb#xigua_hb_district')->empty_child();
					$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
				}
				savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
			} else {
				$dist0 = $_G['cache'][$_key]['variable'][0];
				$jsary = $_G['cache'][$_key]['variable'][1];
			}
		}
		$midnavslider = $topnavslider = array();
		$topnavslider = hb_parse_set($pt_config['loopbanner']);
		$cat_list = C::t('#xigua_pt#xigua_pt_hangye')->list_by_pid(0, true);
		$indexlist = C::t('#xigua_pt#xigua_pt_index')->list_by_pid(0, true);
		$jing_list = array_values($indexlist);
		if ($jing_list) {
			$jing_count = range(0, ceil(count($jing_list) / 10) - 1);
		}
		$navtitle = $pt_config['title'];
		$desc = $pt_config['desc'];
		break;
	case 'cate':
		$navtitle = lang_pt('ss', 0);
		$cat_list = C::t('#xigua_pt#xigua_pt_hangye')->list_by_pid(0, true);
		foreach ($cat_list as $index => $item) {
			$cat_list[$index]['child'] = C::t('#xigua_pt#xigua_pt_hangye')->get_childs_by_pids($item['id']);
		}
		$catlist = array_values($cat_list);
		$nowcat = $cat_list[$_GET['catid']] ? $cat_list[$_GET['catid']] : $catlist[0];
		break;
	case 'cat':
		if ($keyword = $_GET['keyword']) {
		}
		$cat_list = C::t('#xigua_pt#xigua_pt_hangye')->list_by_pid(0, true);
		$jing_list = C::t('#xigua_pt#xigua_pt_hangye')->get_childs_by_pids($_GET['catid']);
		$navtitle = $desc = $cat_list[$_GET['catid']]['name'];
		break;
	case 'cat_li':
		$where = array();
		$where[] = 'stat=1';
		if ($_GET['hyid']) {
			$_GET['catid'] = $_GET['hyid'];
		}
		if ($ctid = intval($_GET['catid'])) {
			$where[] = ' (hangye_id1=' . $ctid . ' OR hangye_id2=' . $ctid . ') ';
		}
		if ($shidd = intval($_GET['shid'])) {
			$where[] = ' shid=' . $shidd . ' ';
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$where[] = ' (title LIKE \'%' . $keyword . '%\' OR shname LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\') ';
		}
		if ($city = daddslashes($_GET['city'])) {
			if ($city != '-1') {
				$where[] = ' (province=\'' . $city . '\' OR  city=\'' . $city . '\' OR district=\'' . $city . '\') ';
			}
		}
		$list = C::t('#xigua_pt#xigua_pt_good')->fetch_all_by_where($where, $start_limit, $lpp, 'id DESC');
		if ($_GET['shid'] && count($list) % 2 != 0) {
			$_GET['from'] = 'index';
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_pt:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'good':
		break;
	case 'add':
		$navtitle = lang_pt('fbsp', 0);
		if ($_G['cache']['plugin']['xigua_hs']) {
			$where = array();
			$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
		}
		if ($gid = $_GET['gid']) {
			$old_data = C::t('#xigua_pt#xigua_pt_good')->fetch_G($gid);
			if (!$old_data) {
				dheader('Location: ' . $SCRITPTNAME . '?id=xigua_pt&ac=manage');
			}
		}
		if (submitcheck('formhash')) {
			$data = $srg = $append_img = $append_text = array();
			$form = $_GET['form'];
			$required = array('title', 'shname', 'tprice', 'dprice', 'disprice', 'ptmin', 'jieshao');
			foreach ($required as $index => $item) {
				$form[$item] = trim($form[$item]);
				if (!$form[$item]) {
					hb_message(lang_pt($item . '_tip', 0), 'error');
				}
			}
			if (!($sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']))) {
				hb_message(lang_pt('shname_tip', 0), 'error');
			}
			if ($form['disprice'] < $form['tprice']) {
				hb_message(lang_pt('bnda', 0), 'error');
			}
			foreach ($svicerange as $index => $item) {
				if ($form['tagid'][$index]) {
					list($_rangt, $_rangd) = explode('#', $item);
					$srg[] = $_rangt;
				}
			}
			foreach ($form['append_img'] as $index => $item) {
				$append_img[] = $item;
				$append_text[] = $form['append_text'][$index];
			}
			$up = $form['id'] > 0;
			if ($up) {
				$data['upts'] = TIMESTAMP;
			} else {
				$data['uid'] = $_G['uid'];
				$data['crts'] = TIMESTAMP;
			}
			$data['title'] = $form['title'];
			$data['usetime'] = intval(strtotime($form['usetime']));
			$data['shname'] = $sh['name'];
			$data['shid'] = $sh['shid'];
			$data['lat'] = $sh['lat'];
			$data['lng'] = $sh['lng'];
			$hy_ret = C::t('#xigua_pt#xigua_pt_hangye')->fetch_by_name(array_filter(explode(' ', trim($form['hy']))));
			$hangye_ids = array_keys($hy_ret);
			$data['hy'] = $form['hy'];
			$data['hangye_id1'] = $hangye_ids[0];
			$data['hangye_id2'] = $hangye_ids[1];
			$data['stock'] = $form['stock'];
			$data['sellnum'] = $form['sellnum'];
			$data['fee_type'] = $form['fee_type'];
			$data['tprice'] = $form['tprice'];
			$data['dprice'] = $form['dprice'];
			$data['pricehk1'] = $form['pricehk1'];
			$data['pricehk2'] = $form['pricehk2'];
			$data['disprice'] = $form['disprice'];
			$data['danci'] = $form['danci'];
			$data['zong'] = $form['zong'];
			$data['youhui'] = $form['youhui'];
			$data['ptmin'] = $form['ptmin'];
			$data['ptshixian'] = $form['ptshixian'];
			$data['srange'] = implode('	', $srg);
			$data['jieshao'] = $form['jieshao'];
			$data['append_img'] = serialize($append_img);
			$data['append_text'] = serialize($append_text);
			$data['album'] = serialize($form['album']);
			$data['crts'] = TIMESTAMP;
			$data['stat'] = 1;
			$data['stid'] = intval($_GET['st']);
			$data['province'] = $form['province'];
			$data['city'] = $form['city'];
			$data['district'] = $form['district'];
			$data['allowrefund'] = $form['allowrefund'];
			$jp = $SCRITPTNAME . '?id=xigua_pt&ac=manage';
			if ($pt_config['needshen']) {
				$data['stat'] = 2;
				$jp .= '&stat=2';
			}
			if ($up) {
				$gid = $form['id'];
				$rs = C::t('#xigua_pt#xigua_pt_good')->update_G($form['id'], $data);
			} else {
				$data['upts'] = $data['crts'];
				$gid = $rs = C::t('#xigua_pt#xigua_pt_good')->insert($data, 1);
			}
			if ($rs) {
				hb_message(lang_pt('ptfbcg', 0), 'success', $SCRITPTNAME . '?id=xigua_pt&ac=spgg&gid=' . $gid . $urlext);
			}
		} else {
			$hyobj = C::t('#xigua_pt#xigua_pt_hangye');
			$hyobj->init($hyobj->list_json());
			$jsary = $hyobj->get_tree_array(0);
			$jsary = array_values($jsary);
			$default_hy = diconv($jsary[0]['name'] . ' ' . $jsary[0]['sub'][0]['name'], 'utf-8', CHARSET);
			$cityjson = json_encode($jsary);
			if ($old_data['hy']) {
				$default_hy = $old_data['hy'];
			}
		}
		break;
	case 'view':
		$v = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($gid);
		if ($v['stat'] != 1) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_pt');
		}
		$navtitle = $v['title'];
		$desc = $v['jieshao'];
		$sh = $v['sh'] = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid']);
		$ti = TIMESTAMP;
		$wher = array(' (buy_type=2 AND status=5 AND tuan_id=0 AND gid=' . $gid . ' AND shixian>=' . $ti . ' ) ');
		$pting = C::t('#xigua_pt#xigua_pt_order')->fetch_all_by_where($wher, 0, 10, 'id DESC', '*', 1);
		$pting_num = C::t('#xigua_pt#xigua_pt_order')->fetch_count_by_where($wher);
		$cat_list = C::t('#xigua_pt#xigua_pt_hangye')->list_by_pid(0, true);
		if ($tuan_id = intval($_GET['tuan_id'])) {
			$ptuserlist = C::t('#xigua_pt#xigua_pt_order')->fetch_only_tuanzhang($tuan_id);
			if ($ptuserlist) {
				$tuanzhang = getuserbyuid($ptuserlist[0]['uid']);
			}
		}
		if ($pt_config['showreal']) {
			$lw = array(' ( status in (2,5,6) AND gid=' . $gid . ' ) ');
			$v['logs'] = C::t('#xigua_pt#xigua_pt_order')->fetch_all_by_where($lw, 0, 8, 'id DESC', 'id,uid,crts', 1);
			$v['logs_count'] = C::t('#xigua_pt#xigua_pt_order')->fetch_count_by_where($lw);
		}
		if ($_G['uid'] > 0) {
			$mytuan = DB::fetch_first('select id,tuan_id from %t where buy_type=2 AND status=5 AND uid=%d AND gid=' . $gid . ' AND shixian>=' . $ti, array('xigua_pt_order', $_G['uid']));
			$mytuan_id = $mytuan['tuan_id'] ? $mytuan['tuan_id'] : $mytuan['id'];
		}
		if ($pt_config['kefulink'] && (IN_MAGAPP || IN_QIANFAN)) {
			$shmember = getuserbyuid($sh['uid']);
			$shavat = avatar($sh['uid'], 'middle', true);
			$kefulink = str_replace(array('{uid}', '{username}', '{avatar}'), array($sh['uid'], $shmember['username'], $shavat), $pt_config['kefulink']);
		} else {
			$kefulink = $SCRITPTNAME . '?id=xigua_hb&ac=chat&touid=' . $sh['uid'];
		}
		break;
	case 'invite':
		$need_side = 1;
		$navtitle = lang_pt('ddxq', 0);
		$back_to_overwrite = $SCRITPTNAME . ('?id=xigua_pt&ac=order&status=5' . $urlext);
		$ptlog_id = $_GET['ptlog_id'];
		$cat_list = C::t('#xigua_pt#xigua_pt_hangye')->list_by_pid(0, true);
		if ($v = C::t('#xigua_pt#xigua_pt_order')->fetch_G($ptlog_id)) {
			$navtitle = lang_pt('yqhy', 0);
		} else {
			$v = C::t('#xigua_pt#xigua_pt_order')->fetch_by_gid($ptlog_id);
			if (!$v || $v['uid'] == $_G['uid']) {
				exit(0);
			}
			$joinmode = 1;
			$navtitle = lang_pt('cypt', 0);
		}
		$tuan_id = intval($v['tuan_id'] ? $v['tuan_id'] : $v['id']);
		$ptuserlist = C::t('#xigua_pt#xigua_pt_order')->fetch_by_tuanid($tuan_id);
		$v['sh'] = DB::fetch_first('SELECT * FROM %t WHERE shid =%d', array('xigua_hs_shanghu', $v['shid']));
		$good = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($v['gid']);
		if ($navtitle == lang_pt('yqhy', 0)) {
			$username = DB::result_first('select username from %t where uid=%d', array('common_member', $v['uid']));
			if ($pt_config['yqtitle']) {
				$navtitle = str_replace(array('{username}', '{title}', '{price}'), array($username, $v['title'], $good['tprice']), $pt_config['yqtitle']);
			}
			if ($pt_config['yqdesc']) {
				$desc = str_replace(array('{username}', '{title}', '{price}'), array($username, $v['title'], $good['tprice']), $pt_config['yqdesc']);
			}
		}
		break;
	case 'order_profile':
		$navtitle = lang_pt('ddxq', 0);
		$ptlog_id = $_GET['ptlog_id'];
		$cat_list = C::t('#xigua_pt#xigua_pt_hangye')->list_by_pid(0, true);
		if ($_GET['code']) {
			$v = DB::fetch_first('select * from %t WHERE id=%d AND hxcode=%s', array('xigua_pt_order', $ptlog_id, $_GET['code']));
			$gid = $v['gid'];
			$shid = $v['shid'];
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
			$good = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($gid);
			$access = 0;
			if (IS_ADMINID) {
				$access = 1;
			} else {
				if ($v['uid'] == $_G['uid']) {
					$access = 0;
				} elseif ($good['uid'] == $_G['uid']) {
					$access = 1;
				}
			}
			if (!$access) {
				$yuaninfo = C::t('#xigua_hs#xigua_hs_yuan')->fetch_yuan_by_shid_uid($shid, $_G['uid']);
				if ($yuaninfo) {
					$access = 1;
				}
			}
			if (!$access) {
				if ($coki = authcode(getcookie('hstax' . $shid), 'DECODE')) {
					$shv = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
					if ($shv['hxpwd'] == $coki) {
						$access = 1;
					}
				}
			}
			if (!$access) {
				include template('xigua_pt:scan');
				exit(0);
			}
			$_GET['manage'] = 1;
			$v = C::t('#xigua_pt#xigua_pt_order')->prepare($v);
		} elseif ($_GET['manage']) {
			$shids = get_shids_by_uid();
			$v = DB::fetch_first('select * from %t WHERE shid IN(%n) AND id=%d ', array('xigua_pt_order', $shids, $ptlog_id));
			$v = C::t('#xigua_pt#xigua_pt_order')->prepare($v);
		} else {
			$v = C::t('#xigua_pt#xigua_pt_order')->fetch_G($ptlog_id);
		}
		if (!$v) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_pt&mobile=2' . $urlext);
		}
		$tuan_id = intval($v['tuan_id'] ? $v['tuan_id'] : $v['id']);
		$ptuserlist = C::t('#xigua_pt#xigua_pt_order')->fetch_by_tuanid($tuan_id);
		$v['sh'] = DB::fetch_first('SELECT * FROM %t WHERE shid =%d', array('xigua_hs_shanghu', $v['shid']));
		$v['username'] = DB::result_first('select username from %t where uid=%d', array('common_member', $v['uid']));
		$need_side = 1;
		$back_to_overwrite = $SCRITPTNAME . '?id=xigua_pt&ac=order' . ($_GET['manage'] ? '&manage=1' : '') . $urlext;
		break;
	case 'order_li':
		$wherearr = array();
		if ($_GET['manage']) {
			$shids = get_shids_by_uid();
			if ($shids) {
				$wherearr[] = 'shid in (' . implode(',', $shids) . ')';
			}
		} else {
			$wherearr[] = 'uid=' . $_G['uid'];
		}
		if ($_GET['status']) {
			$sta = dintval(explode(',', $_GET['status']), 1);
			$wherearr[] = 'status IN ( ' . implode(',', $sta) . ' )';
		}
		if ($_GET['shou_ts'] == 0 - 1) {
			$wherearr[] = 'shou_ts=-1';
		} elseif ($_GET['shou_ts'] == 1) {
			$wherearr[] = 'shou_ts>1';
		}
		if ($_GET['fa_ts'] == 0 - 1) {
			$wherearr[] = 'fa_ts=-1';
		} elseif ($_GET['fa_ts'] == 1) {
			$wherearr[] = 'fa_ts>1';
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR order_id LIKE \'%' . $keyword . '%\') ';
		}
		$GLOBALS['need_sh'] = 1;
		$list = C::t('#xigua_pt#xigua_pt_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, 'id DESC', '*', 1);
		include template('xigua_hb:header_ajax');
		include template('xigua_pt:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'order':
		$navtitle = lang_pt('wddd1', 0);
		if ($_GET['manage']) {
			$navtitle = lang_pt('ddgl1', 0);
		}
		$keyword = stripsearchkey($_GET['keyword']);
		$need_side = 1;
		break;
	case 'cancel_order':
		$ordid = intval($_GET['ordid']);
		if (submitcheck('ordid')) {
			$ov = C::t('#xigua_pt#xigua_pt_order')->fetch_G($ordid);
			if (!$ov || $ov['status'] != 1) {
				hb_message('error', 'error');
			}
			C::t('#xigua_pt#xigua_pt_order')->update_G($ordid, array('status' => 4, 'tuicfm_ts' => TIMESTAMP, 'tui_ts' => TIMESTAMP));
			DB::query('UPDATE %t SET stock=stock+%d WHERE id=%d', array('xigua_pt_good_price', intval($ov['gnum']), $ordid));
			if ($ov['pay_ts'] > 0) {
				C::t('#xigua_hb#xigua_hb_moneylog')->insert(array('uid' => $ov['uid'], 'crts' => TIMESTAMP, 'size' => floatval($ov['pay_money']), 'note' => lang_pt('qxddytk', 0), 'link' => ''));
				C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($ov['uid'], 'money', $ov['pay_money']);
			}
			hb_message(lang_pt('ddyqx', 0), 'success', 'reload');
		}
		break;
	case 'buy':
		if (submitcheck('formhash')) {
			$form = $_GET['form'];
			$priceid = intval($form['pid']);
			$num = intval($form['item_num']);
			if ($num < 1) {
				hb_message(lang_pt('slcw', 0), 'error');
			}
			$gid = intval($form['gid']);
			$addrid = intval($form['addrid']);
			$tuan_id = intval($form['tuan_id']);
			$note = strip_tags($form['note']);
			$good = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($gid, 0);
			$good_price = C::t('#xigua_pt#xigua_pt_good_price')->fetch_by_stock($priceid, $num);
			if (!$good_price) {
				hb_message(lang_pt('kcbz', 0), 'error');
			}
			$yf = 0;
			if ($good['fee_type'] == 1) {
				$yfary = C::t('#xigua_hs#xigua_hs_yf')->fetch($addrid);
				$yf = floatval($yfary['yunfei']);
				if (!$form['dist3']) {
					hb_message(lang_pt('qszshdz', 0), 'error');
				}
				if (!$form['mobile']) {
					hb_message(lang_hb('mobile_tip', 0), 'error');
				}
			}
			$price_last = floatval($num * $good_price['price_pt'] + $yf - $good['youhui']);
			if ($good['stat'] != 1) {
				hb_message(lang_pt('spyxj', 0), 'error');
			}
			$totalprice = $price_last;
			if ($totalprice <= 0) {
				hb_message(lang_pt('error', 0), 'error');
			}
			$title = $good['title'] . str_replace('###', ',', $good_price['name']) . $num . ' ' . lang_pt('fen', 0);
			$pay_end = TIMESTAMP + $pt_config['paywait'];
			$ptlog = array('crts' => TIMESTAMP, 'uid' => $_G['uid'], 'order_id' => '', 'buy_type' => $form['buy_type'], 'pay_money' => $totalprice, 'addrid' => $addrid, 'addr' => $form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'], 'mobile' => $form['mobile'], 'realname' => $form['realname'], 'gid' => $gid, 'priceid' => $priceid, 'priceinfo' => serialize($good_price), 'goodinfo' => serialize($good), 'note' => $note, 'yunfee' => $yf, 'title' => $title, 'gnum' => $num, 'status' => 1, 'pay_endts' => $pay_end, 'tuan_id' => $tuan_id, 'tuan_num' => 1, 'shid' => $good['shid'], 'chengben' => $good['chengben'], 'unit_price' => $good_price['price_pt']);
			$ptlog_id = C::t('#xigua_pt#xigua_pt_order')->insert($ptlog, true);
			$location = $_G['siteurl'] . $SCRITPTNAME . ('?id=xigua_pt&ac=order_profile&ptlog_id=' . $ptlog_id . $urlext);
			$ptlog['id'] = $ptlog_id;
			$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_pt', array('data' => $ptlog, 'callback' => array('file' => 'source/plugin/xigua_pt/function.php', 'method' => 'callback_pt_pay'), 'location' => $location, 'referer' => $SCRITPTNAME . '?id=xigua_pt&ac=view&gid=' . $gid . $urlext, 'tip' => $good['backprice'] > 0 ? lang_pt('backprice1', 0) . $good['backprice'] . lang_pt('yuan', 0) : ''), $pay_end);
			C::t('#xigua_pt#xigua_pt_order')->update($ptlog_id, array('order_id' => $order_id));
			$rl = urlencode($location);
			$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
			hb_message(lang_pt('jumppay', 0), 'loading', $jumpurl);
		}
		break;
	case 'confirm':
		if (submitcheck('confrm')) {
			$form = $_GET['form'];
			$priceid = intval($form['price_id']);
			$num = intval($form['item_num']);
			$buy_type = intval($form['buy_type']);
			$tuan_id = intval($form['tuan_id']);
			if (!$priceid) {
				hb_message(lang_pt('qxzgg', 0), 'error');
			}
			$good_price = C::t('#xigua_pt#xigua_pt_good_price')->fetch($priceid);
			if ($tuan_id) {
				$t = '&tuan_id=' . $tuan_id;
				if (!$pt_config['allowself']) {
					$tuan = C::t('#xigua_pt#xigua_pt_order')->fetch($tuan_id);
					if ($tuan['uid'] == $_G['uid']) {
						hb_message(lang_pt('btxzjct', 0), 'error');
					}
				}
			}
			$jumpurl = $SCRITPTNAME . '?id=xigua_pt&ac=confirm&num=' . $num . '&buy_type=' . $buy_type . '&pid=' . $priceid . '&gid=' . $gid . $t . '&note=' . $form['item_note'] . $urlext;
			if ($pt_config['mustmobile']) {
				$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
				if (!$user['mobile']) {
					hb_message(lang_pt('qtxsjhm', 0), 'loading', $SCRITPTNAME . '?id=xigua_hb&ac=myzl&referer=' . urlencode($jumpurl) . $GLOBALS['urlext']);
				}
			}
			hb_message(lang_pt('tzz', 0), 'loading', $jumpurl);
		} else {
			$navtitle = lang_pt('qrdd', 0);
			$priceid = intval($_GET['pid']);
			$num = intval($_GET['num']);
			$v = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($gid, 0);
			$good_price = C::t('#xigua_pt#xigua_pt_good_price')->fetch($priceid);
			$v['price_name'] = explode('###', $good_price['name']);
			$dft = C::t('#xigua_hb#xigua_hb_user_addr')->fetch_dft($_G['uid']);
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($v['shid']);
			$rf = $SCRITPTNAME . '?id=xigua_pt&ac=view&gid=' . $gid . $urlext;
			$yf = 0;
			if ($v['fee_type'] == 1) {
				$dft['address'] = daddslashes($dft['address']);
				$dft['dist1'] = daddslashes($dft['dist1']);
				$dft['dist2'] = daddslashes($dft['dist2']);
				$dft['dist3'] = daddslashes($dft['dist3']);
				$addr = C::t('#xigua_hs#xigua_hs_yf')->fetch_all_by_query('( LOCATE(dist1,\'' . $dft['address'] . '\')>0 OR dist1=\'' . $dft['dist3'] . '\' OR dist1=\'' . $dft['dist2'] . '\' OR dist1=\'' . $dft['dist1'] . '\' ) ' . ' and FIND_IN_SET(' . $v['shid'] . ', shids)');
				$yf = floatval($addr['yunfei']);
			}
			$price_last = floatval($num * $good_price['price_pt'] + $yf - $v['youhui']);
		}
		break;
	default:
		if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_pt/include/c_' . $ac . '.php'))) {
			include DISCUZ_ROOT . ('source/plugin/xigua_pt/include/c_' . $ac . '.php');
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_pt/template/touch/' . $ac . '.php'))) {
	include template('xigua_pt:' . $ac);
}