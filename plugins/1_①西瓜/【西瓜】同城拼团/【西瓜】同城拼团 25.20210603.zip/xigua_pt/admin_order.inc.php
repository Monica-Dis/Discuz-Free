<?php
/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_pt/function.php';
$status_font = array(
    1 => lang_pt('status_1',0),
    2 => lang_pt('status_2',0),
    3 => lang_pt('status_3',0),
    4 => lang_pt('status_4',0),
    5 => lang_pt('status_5',0),
    6 => lang_pt('status_6',0),
    7 => lang_pt('status_7',0),
);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$sta = $status_font;

function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}



$page = max(1, intval($_GET['page']));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 10;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('ptlogid')){
    $ptlogid = $_GET['ptlogid'];
    if($_GET['yundan_gs'] && $_GET['yundan']){
        DB::update('xigua_pt_order', array(
            'fa_ts' => TIMESTAMP,
            'yundan_gs' => $_GET['yundan_gs'],
            'yundan' => $_GET['yundan'],
        ), array(
            'id' => $ptlogid
        ));
        unset($_GET['yundan_gs']);
        unset($_GET['yundan']);
        unset($_GET['formhash']);
        unset($_GET['permsubmit']);
        unset($_GET['ptlogid']);
        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_order".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
    }
}

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_pt#xigua_pt_order')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            if($item['shou_ts']==1){
                $old = C::t('#xigua_pt#xigua_pt_order')->fetch($index);
                if($old['shou_ts']<=1 &&!$old['shou_confirm_ts']){
                    $item['shou_ts'] = TIMESTAMP;
                    $item['shou_confirm_ts'] = TIMESTAMP;
                    $shid = $old['shid'];
                    include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                    $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                    $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                    $insxf   = intval(abs($vipinfo['insxf']))/100;
                    if($shdata['shinsxf']){
                        $insxf  = intval(abs($shdata['shinsxf']))/100;
                    }

                    $sxfee = round($insxf*$old['pay_money'], 2);
                    $money = $old['pay_money']-$sxfee;

                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', $money);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid'  => $shdata['uid'],
                        'crts' => TIMESTAMP,
                        'size' => $money,
                        'note' => lang_pt('ddh',0).$old['order_id'],
                        'link' => "$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id={$old['id']}&manage=1".$urlext,
                    ));
                }else{
                    unset($item['shou_ts']);
                }
            }
            if($item['status']>=97){
                unset($item['status']);
            }
            if($item['yundan'] || $item['yundan_gs']){
                $item['fa_ts'] = TIMESTAMP;
            }
            C::t('#xigua_pt#xigua_pt_order')->update($index, $item);
        }
    }
    unset($_GET['formhash']);
    unset($_GET['r']);
    unset($_GET['permsubmit']);
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_order".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = " ( uid='$keyword' or tuan_id='$keyword' ) ";
}elseif($keyword){
    $wherearr[] = " ( mobile like '%$keyword%' OR realname like '%$keyword%' OR title like '%$keyword%' OR goodinfo like '%$keyword%' ) ";
}
$sta[97] = lang_pt('hx1',0);
$sta[98] = lang_pt('hx2',0);
$sta[99] = lang_pt('hx3',0);

$order = 'id desc';
if($_GET['status'] == 97){
    $wherearr[] = "status IN ( 2,6 ) AND fa_ts=-1";
    $order = 'pay_ts desc';

}elseif($_GET['status'] == 98){
    $wherearr[] = "status IN ( 2,6 ) AND fa_ts>1";
    $order = 'fa_ts desc';

}elseif($_GET['status'] == 99){
    $wherearr[] = "status IN ( 2,6 ) AND shou_ts>1";
    $order = 'shou_ts desc';
}

if($_GET['status']&&$_GET['status']<97){
    $wherearr[] = "status='".intval($_GET['status'])."'";
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_order");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_pt('searchinput',0).'" value="'.$_GET['keyword'].'" class="txt"  style="width: 220px;"/> ';

echo '<select name="status"><option value="0">'.lang_pt('qb',0).'</option>';
foreach ($sta as $index => $item) {
    $chk = isset($_GET['status']) && $_GET['status']==$index ? 'selected':'';
    echo " <option value=\"$index\" $chk>$item</option>";
}
echo '</select>';
/*
$cus = array(
    1 => lang_pt('hx1',0),
    2 => lang_pt('hx2',0),
    3 => lang_pt('hx3',0),
);
echo '&nbsp;&nbsp;&nbsp;';
foreach ($cus as $index => $_v) {
    echo '<label><input type="radio" name="cus" value="'.$index.'" ' . ($_GET['cus']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
}*/

echo '&nbsp;&nbsp;&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(1,10, 20, 50, 100, 200, 500, 1000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;

echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_order".' class="btn" >'.cplang('reset').'</a> ';

echo ' <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_order&".http_build_query($_GET).'&doexport=1" class="btn" >'.lang_pt('dc', 0).'</a> ';

echo '</div>';

showtableheader(lang_pt('tichengmanage', 0));
$ress = array();

showtablerow('class="header"',array(),$ress[] = array(
    lang_hb('del', 0),
    lang_pt('ID', 0),
    lang_pt('tuan_id', 0),
    lang_pt('fkyh', 0).'/'.
    lang_pt('ddxinxi', 0),
    lang_pt('status', 0),
    lang_pt('spxx', 0),
    lang_pt('fhxx', 0),
    lang_pt('shdz', 0),
    lang_pt('qrsh', 0),
));

$res = C::t('#xigua_pt#xigua_pt_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order);
$icount = C::t('#xigua_pt#xigua_pt_order')->fetch_count_by_where($wherearr);

$uids =$priceids = $ordersns= array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['hxuid'];
    $priceids[] = $v['priceid'];
    $ordersns[] = $v['order_id'];
    $refunds[] = $v['refund_id'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $tcusers = DB::fetch_all('SELECT uid,realname,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}
if($refunds){
    $refunds = DB::fetch_all('SELECT * FROM %t WHERE id IN (%n)', array('xigua_pt_refund', $refunds), 'id');
    foreach ($refunds as $index => $refund) {
        $refunds[$index] = C::t('#xigua_pt#xigua_pt_refund')->prepare($refund);
    }
}
if($priceids){
    $prices = DB::fetch_all('SELECT id,price_cb FROM %t WHERE id IN (%n)', array('xigua_pt_good_price', $priceids), 'id');
}
if($ordersns){
    $ordersns = DB::fetch_all('SELECT order_id,order_sn FROM %t WHERE order_id IN (%n)', array('xigua_hb_order', $ordersns), 'order_id');
}
$kdgs = lang_pt('kdgs',0);
$kddh = lang_pt('kddh',0);
foreach ($res as $k => $v) {
    $v['mobile'] = !$v['mobile'] ? $tcusers[$v['uid']]['mobile'] :$v['mobile'];
    $v['realname'] = !$v['realname'] ? $tcusers[$v['uid']]['realname'] :$v['realname'];

    $v['refund'] = str_replace(array('array (', ')',',',"\n",'\'','=>'), array('', '','<br>','','', ':'), $v['refund']);
    if(strpos($v['refund'], 'result_code : SUCCESS')!==false){
        $v['refund'] = '<p style="color:forestgreen;font-weight:bold">'.lang_pt('tkcg',0).'</p>'.$v['refund'];
    }
    $v['refund'] = trim($v['refund']);

    $id = $v['id'];
    $uid = $v['uid'];
    $info = $v['info'];
    if(!is_array($info['info'])){
        $info['info'] = unserialize($info['info']);
    }

    $fromuid = $info['fromuid'];

    $sel = $seltype = '';
    foreach ($sta as $index => $item) {

        if(in_array($index, array(97,98,99))){
            if($_GET['status']==$index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }else{
            if($v['status'] == $index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }
    }
    $crts = date('Y-m-d H:i:s', $v['crts']);
    $goodinfo = unserialize($v['goodinfo']);
    $priceinfo = unserialize($v['priceinfo']);

    $pingbi = $v['shou_ts']>1 ? 'checked' : '';
    $unpingbi = $pingbi ? '' : 'checked';

    $shouinfo = '';
    if($v['hxcode']){
        $img = pt_qrcode_make($v['id'], $v['hxcode']);
        $shouinfo .= $v['hxcrts'] ? lang_pt('yhxhxsj',0).date('Y-m-d H:i:s', $v['hxcrts']) : lang_pt('yfkdhx',0);
        $shouinfo .= '<br>';
        $shouinfo .= lang_pt('hxm',0).' : '. $v['hxcode'] . "<a target=\"_blank\" href=\"$img\"><img style=\"width:100px;height:100px;vertical-align:middle\" src=\"$img\"></a>";
        $shouinfo .= '<br>';
        $shouinfo .= lang_pt('hxuid',0).' : '. ($v['hxuid'] ? " [UID: {$v['hxuid']}] " . $users[$v['hxuid']]['username'] : '-');
    } else{
        $shouinfo = lang_pt('fhsj',0).': '.($v['fa_ts']>1 ? date('Y-m-d H:i:s', $v['fa_ts']) :'-').
            '<br>'.lang_pt('ydxx',0) . ' :'. ($v['yundan'] ? $v['yundan_gs'].' '.$v['yundan'] :'-');
    }
$ret_tk = '';
if($v['refund_id']>0 ){
    $rr = $refunds[$v['refund_id']];
    $tkyy = lang_pt('tkyy',0);
    $sqsj = lang_pt('sqsj',0);
    $tkqrsj = lang_pt('tkqrsj',0);
    if($v['yundan']){
        $p1 = '<p>'.lang_pt('khysh',0).'</p>';
    }
    if($rr['status']==2){
        $p2 = "<p>$tkqrsj: {$rr['upts_u']}</p>";
    }

    $ret_tk = <<<HTML
<p>$tkyy: {$rr['note']}</p>
<p>$sqsj: {$rr['crts_u']}</p>
$p1
$p2
<p>{$v['refund']}</p>
HTML;
}

    showtablerow('', array(), $res_ = array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        $v['tuan_id']?$v['tuan_id'] :' ' ,
        "UID: $uid <br><a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a><br>".

        lang_hb('orderid',0).' : <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_order&keyword=".$v['order_id']."&note=0&page=1".'">'.$v['order_id'] . '</a><br>'.
        ($ordersns[$v['order_id']]['order_sn'] ? lang_hb('ordersn',0).': '.$ordersns[$v['order_id']]['order_sn'] . '<br>' : '').
        lang_pt('crts',0).': '.$crts.'<br>'.
        ($v['pay_ts_u'] ? '<b style="color:orangered">'.lang_pt('zfje',0).$v['pay_money'] . '</b><br>'.
        lang_pt('zfsj',0).$v['pay_ts_u'] . '<br>' : '').
    '',
        '<div style="max-width:400px">'.
        lang_pt('gmlx',0).':' .($v['buy_type']==1? '<b style="color:orangered;">'.lang_pt('dm',0).'</b>':'<b style="color:#2366A8;">'.lang_pt('pt',0).'</b>').
        '<b style="color:red;">&nbsp;'.$sta[$v['status']].'</b><br><br>'.
        "<select name='r[$id][status]' $dis>$sel</select><br>".$ret_tk.($v['refund']&&!$v['refund_id'] ? lang_pt('zdtkxq',0).":".$v['refund']:'')
    .'</div>',

        '<span style="color:#2366A8">('.$goodinfo['shname'].') </span>'. $goodinfo['title'].'[ID: '.$goodinfo['id'].']<br>'.
        implode(' ', explode('###', $priceinfo['name'])).'<br>'.
        lang_pt('bz',0).': '.$v['note'] . '<br>'.

        '<b style="color:#2366A8;">'.
        lang_pt('dj',0).': '.$v['unit_price'].' x '.
        lang_pt('sl',0).': '.$v['gnum'].' + '.
        lang_pt('yunfee',0).$v['yunfee'] . ' = '.$v['pay_money'].
        '</b><br>'.
        lang_pt('price_cb',0) .':'.$prices[$v['priceid']]['price_cb'].''
    ,
        $v['realname'].'<br>'.$v['mobile'].'<br>'.$v['addr'].

        ($v['hxcode'] ? '-' : ((in_array($v['status'], array(2,6))) ? (

            "
        <table class=\"tb tb2 \">
            <tr class=\"hover\">
                <td align=\"left\"><div style='width:60px'>$kdgs</div></td>
                <td><textarea name=\"r[$id][yundan_gs]\" style='width:100px;height:20px;'>{$v['yundan_gs']}</textarea></td>
            </tr>
            <tr class=\"hover\">
                <td align=\"left\"><div style='width:60px'>$kddh</div></td>
                <td><textarea name=\"r[$id][yundan]\" style='width:100px;height:20px;'>{$v['yundan']}</textarea></td>
            </tr>
        </table>".
                "<br><a style='font-weight:bold;display:none' href=\"javascript:;\" onclick='return _show_company_profile1($id);'>". lang_pt('djfh', 0) . "</a>"

        ): ''))
    ,



        $shouinfo,

        "<input name='r[$id][shou_ts]' type='radio' value='1' $pingbi />".cplang('yes').
        "<input name='r[$id][shou_ts]' type='radio' value='-1' $unpingbi />".cplang('no').
        ($v['shou_ts']>0 ? ('<br>'.date('Y-m-d H:i:s', $v['shou_ts'])) : ''),

    ));
    unset($res_[0]);
    unset($res_[6]);
    unset($res_[5]);
    unset($res_[7]);

    $res_[4] = '['.$v['order_id'].']';

    $res_ = array_values($res_);
    array_pop($res_);



    $res_[] = $v['realname'];
    $res_[] = $v['mobile'];
    $res_[] = $v['addr'].$shouinfo;

    $res_[] = $v['buy_type']==1? lang_pt('dm',0) : lang_pt('pt',0);

    $res_[] = $sta[$v['status']] .' '.($v['refund'] ? lang_pt('zdtkxq',0).":".$v['refund']:'');

    $res_[] = $goodinfo['title'].'[ID: '.$goodinfo['id'].']';
    $res_[] = $goodinfo['shname'].'[ID: '.$goodinfo['shid'].']';
    $res_[] = implode(' ', explode('###', $priceinfo['name']));
    $res_[] = $v['unit_price'];
    $res_[] = $v['gnum'];
    $res_[] = $v['yunfee'];
    $res_[] = $v['pay_money'];
    $res_[] = $v['note'];

    $res_[] = $crts;
    $res_[] = $v['pay_ts_u'];
    $res_[] = $prices[$v['priceid']]['price_cb'];
    $res_[] = ' ';



    foreach ($res_ as $index => $item) {
        $item = nl2br($item);
        $item= str_replace('<br>', '   ', $item);
        $item= str_replace('<br />', '   ', $item);
        $item= str_replace(',', '  ', $item);
        $item= str_replace(array("\t","\n","\r"), '  ', $item);
        $res_[$index] = trim(strip_tags($item));
    }
    $ress[] = $res_;
}

if($_GET['doexport']==1){
    $title_arr= array();
    unset($ress[0][0]);
    unset($ress[0][5]);
    unset($ress[0][6]);
    unset($ress[0][7]);
    array_pop($ress[0]);
    foreach ($ress[0] as $index => $item) {
        $title_arr[] = $item;
    }

    $title_arr[] = lang_pt('zsxm',0);
    $title_arr[] = lang_pt('mobile',0);
    $title_arr[] = lang_pt('shdz',0);

    $title_arr[] = lang_pt('gmlx', 0);
    $title_arr[] = lang_pt('status', 0);

    $title_arr[] = lang_pt('title',0);
    $title_arr[] = lang_pt('oinfo5',0);
    $title_arr[] = lang_pt('ggm',0);
    $title_arr[] = lang_pt('dj',0);
    $title_arr[] = lang_pt('sl',0);
    $title_arr[] = lang_pt('yunfee',0);
    $title_arr[] = lang_pt('zfje',0);
    $title_arr[] = lang_pt('bz',0);

    $title_arr[] = lang_pt('crts',0);
    $title_arr[] = lang_pt('zfsj',0);
    $title_arr[] = lang_pt('chengben',0);
    $title_arr[] = ' ';

    unset($ress[0]);
    $ress = array_values($ress);

    export_csv($ress, $title_arr);
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_order&lpp=$lpp".http_build_query($_GET).'&doexport=0', 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/

?>
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>


<div id="rsel_menu" class="custom cmain" style="display:none;width:400px;height:250px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"><?php lang_pt('wanshan');?></h3>
    </div>
    <div id="rsel_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_order&".http_build_query($_GET)."&page=$page&lpp=$lpp");
        ?>
        <table class="tb tb2 ">
            <tr class="hover">
                <td align="left"><?php lang_pt('kdgs');?></td>
                <td><textarea name="yundan_gs" cols="30" rows="2"></textarea></td>
            </tr>
            <tr class="hover">
                <td align="left"><?php lang_pt('kddh');?></td>
                <td><textarea name="yundan" cols="30" rows="2"></textarea></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="ptlogid" id="ptlogid" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php lang_pt('djfh');?>" />
                </td>
            </tr>
        </table>
        <?php showformfooter(); /*Dism_taobao_com*/?>
    </div>
</div>
<script>
    function _show_company_profile1(ptlogid) {
        showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
        $('ptlogid').value = ptlogid;
    }
</script>