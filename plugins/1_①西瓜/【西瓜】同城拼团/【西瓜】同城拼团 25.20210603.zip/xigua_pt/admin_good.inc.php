<?php
/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_pt/function.php';
$status_font = array(
    1 => lang_pt('status_1',0),
    2 => lang_pt('status_2',0),
    3 => lang_pt('status_3',0),
    4 => lang_pt('status_4',0),
    5 => lang_pt('status_5',0),
    6 => lang_pt('status_6',0),
    7 => lang_pt('status_7',0),
);

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$statuss = array(
 1=> lang_pt('ysj',0),
 2=> lang_pt('dsh',0),
 3=> lang_pt('yxj',0),
);

$pt_config = $_G['cache']['plugin']['xigua_pt'];
$svicerange = array();
foreach (explode("\n", trim($pt_config['svicerange'])) as $index => $item) {
    $svicerange[] = trim($item);
}

if($gid = intval($_GET['price_id'])) {

    if(submitcheck('initsubmit')){


        $old_data = C::t('#xigua_pt#xigua_pt_good')->fetch($gid);
        $old_data = C::t('#xigua_pt#xigua_pt_good')->prepare($old_data);

        $editform  = array();
        $spgg = array();
        $spggtmp = array();
        foreach (explode("\n", trim($_GET['spgg'])) as $index => $item) {
            list($name, $value) = explode("=", trim($item));
            $value = explode(',', trim($value));
            if($name&&$value){
                $spgg[] = array(
                    'id' => $index,
                    'name' => $name,
                    'ggtext' => $value
                );
            }
        }
        $editform['spgg'] = serialize($spgg);

        $rs = C::t('#xigua_pt#xigua_pt_good')->update($gid, $editform);

        if($spgg){
            DB::delete('xigua_pt_good_price', array('gid' => $gid));
            $price_list = $pow = array();
            $ggtest = $n = array();
            foreach ($spgg as $str => $item) {
                $ggtest[] = $item['ggtext'];
            }
            $ggtest = combination($ggtest);
            foreach ($ggtest as $index => $item) {
                $data = array();
                $data = array(
                    'crts' => TIMESTAMP,
                    'upts' => TIMESTAMP,
                    'uid' => $item['uid']?$item['uid']:$sh['uid'],
                    'gid' => $gid
                );
                $data['price_pt'] = $old_data['tprice'];
                $data['price_dm'] = $old_data['dprice'];
                $data['price_sc'] = $old_data['disprice'];
                $data['price_hk1'] = $old_data['pricehk1'];
                $data['price_hk2'] = $old_data['pricehk2'];
                $data['price_cb'] = $old_data['disprice'];
                $data['stock']    = $old_data['stock'];
                $data['name']     = is_array($item) ? implode('###', $item) : $item;
                C::t('#xigua_pt#xigua_pt_good_price')->update_price($data);

            }
        }elseif(!$spgg){
            DB::delete('xigua_pt_good_price', array('gid' => $gid));
        }
        cpmsg(lang_pt('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&price_id={$_GET['price_id']}&page=$page", 'succeed');
    }
    if(submitcheck('permsubmit')){
        $form  = $_GET['r'];
        $names = array();
        foreach ($form as $index => $item) {
            $names[] = $item['name'];
        }


        if($names){
            DB::query("DELETE FROM %t WHERE gid=%d AND `name` NOT IN (%n)", array('xigua_pt_good_price', $gid, $names));
        }
        foreach ($form as $index => $item) {
            $data = array();
            $data = array(
                'upts' => TIMESTAMP,
                'gid' => $gid
            );
            $data['price_pt'] = $item['price_pt'];
            $data['price_dm'] = $item['price_dm'];
            $data['price_sc'] = $item['price_sc'];
            $data['price_hk1'] = $item['price_hk1'];
            $data['price_hk2'] = $item['price_hk2'];
            $data['price_cb'] = $item['price_cb'];
            $data['stock']    = $item['stock'];
            $data['name']     = $item['name'];

            C::t('#xigua_pt#xigua_pt_good_price')->update_price($data);
        }
        C::t('#xigua_pt#xigua_pt_good')->update($gid, array(
            'pricehk1' => $data['price_hk1'],
            'pricehk2' => $data['price_hk2'],
        ));
        cpmsg(lang_pt('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&price_id={$_GET['price_id']}&page=$page", 'succeed');
    }else{
        $old_data = C::t('#xigua_pt#xigua_pt_good')->fetch($gid);
        $old_data = C::t('#xigua_pt#xigua_pt_good')->prepare($old_data);
        $list = $old_data['spgg_ary'];
        $tc = 1;
        $pow = array();
        $ggtest = $n = array();
        foreach ($list as $str => $item) {
            $ggtest[] = $item['ggtext'];
        }
        $ggtest = combination($ggtest);
        $price_list = C::t('#xigua_pt#xigua_pt_good_price')->fetch_all_by_where(array("gid=".$gid), 0, 9999, '', '*', 'name');


        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&price_id={$gid}");
        showtableheader(lang_pt('spggdesc',0) );

        $re = unserialize($old_data['spgg']);
        $ret = '';
        foreach ($re as  $item) {
            $ret .= $item['name'].'=';
            $retmp = array();
            foreach ($item['ggtext'] as $itemm) {
                $retmp[] = $itemm;
            }
            $ret .= implode(',', $retmp) . "\n";
        }
        $ret = trim($ret);

        echo "<td>
<textarea name='spgg' style='width:500px;height:200px'>{$ret}</textarea>
</td>";
        showsubmit('initsubmit', lang_pt('sycgg',0));
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&price_id={$gid}");
        showtableheader($old_data['title']." [ID: {$old_data['id']} ] " ."  <a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good'> ".lang_pt('back',0)."</a>" );
        showtablerow('class="header"', array(), array(
            lang_pt('ID', 0),
            lang_pt('ggtitle', 0),
            lang_pt('stock', 0),
            lang_pt('price_pt', 0),
            lang_pt('price_dm', 0),
            lang_pt('price_sc', 0),
            lang_pt('price_hk1', 0),
            lang_pt('price_hk2', 0),
            lang_pt('price_cb', 0),
            lang_pt('crts', 0),
            lang_pt('upts', 0),
        ));
        foreach ($price_list as $index => $item) {
            $id = $item['id'];
            showtablerow('', array(), array(
                $id,
                $item['name']."<input name='r[$id][name]' type='hidden' class='txt' value='{$item['name']}' />",
                "<input name='r[$id][stock]' class='txt' value='{$item['stock']}' />",
                "<input name='r[$id][price_pt]' class='txt' value='{$item['price_pt']}' />",
                "<input name='r[$id][price_dm]' class='txt' value='{$item['price_dm']}' />",
                "<input name='r[$id][price_sc]' class='txt' value='{$item['price_sc']}' />",
                "<input name='r[$id][price_hk1]' class='txt' value='{$item['price_hk1']}' />",
                "<input name='r[$id][price_hk2]' class='txt' value='{$item['price_hk2']}' />",
                "<input name='r[$id][price_cb]' class='txt' value='{$item['price_cb']}' />",
                date('Y-m-d H:i:s', $item['crts']),
                date('Y-m-d H:i:s', $item['upts']),
            ));
        }
        showsubmit('permsubmit', 'submit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/

    }

}elseif($secid = intval($_GET['secid'])){

    $res = C::t('#xigua_pt#xigua_pt_good')->fetch($secid);
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $res = array (
                    'crts' => TIMESTAMP,
                    'displayorder' => '0',
                    'uid' => '',
                    'shid' => '',
                    'title' => '',
                    'shname' => '',
                    'hy' => '',
                    'hangye_id1' => '0',
                    'hangye_id2' => '0',
                    'stock' => '0',
                    'sellnum' => '0',
                    'fee_type' => '1',
                    'tprice' => '0.00',
                    'dprice' => '0.00',
                    'disprice' => '0.00',
                    'danci' => '0',
                    'zong' => '0',
                    'ptmin' => '2',
                    'ptshixian' => '24',
                    'upts' => TIMESTAMP,
                    'jieshao' => '',
                    'append_img' => '',
                    'append_text' => '',
                    'album' => '',
                    'status' => '2',
                    'stid' => '0',
                    'srange' => '',
                    'jtt' => '',
                    'spgg' => '',
                    'stat' => '2',
                    'youhui' => '0.00',
                    'allowrefund' => '0',
            );
            $neww = 1;
        }
        unset($res['shixian']);
        unset($res['chengben']);
        unset($res['hangye_id1']);
        unset($res['hangye_id2']);
        if($neww!=1){
            unset($res['spgg']);
        }

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_pt('spgl',0) . ($secid>0?$secid:''). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good'> ".lang_pt('back',0)."</a>");

        foreach ($res as $index => $re) {
            if(in_array($index, array('bigweek','bigdate','bigrate','shname', 'not_start', 'end','srange_ary','xiajia','shen', 'quan', 'yuanprice','id','color_title', 'is_end', 'shares','status','jtt'))){
                continue;
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('crts', 'upts', 'usetime'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('stat'))){
                $cs = '<select name="editform[stat]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shid'))){
                $cs = '<select name="editform[shid]">';
                foreach (DB::fetch_all('select shid,`name` from %t WHERE display=1 AND endts>=%d', array(
                    'xigua_hs_shanghu',
                    TIMESTAMP
                ), 'shid') as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['name']}[".lang_pt('sh',0)."ID:{$c['shid']}]</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('yuyue' ,'gongkai','showdis', 'selfdis', 'orderdis','allowrefund'))){
                $tp = 'radio';
            }elseif(in_array($index, array('srange'))){
                $re = explode("\t", $re);
                $cs = '<select name="editform[srange][]" multiple="multiple">';
                foreach ($svicerange as $__v) {
                    $shortv = explode('#', $__v);
                    $shortv = $shortv[0];
                    $s = '';
                    if(in_array($shortv, $re)){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$shortv'>$shortv</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }

            if (in_array($index, array('album', 'append_img', 'append_text'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $hs_config = $_G['cache']['plugin']['xigua_hs'];
                $loopnum = $pt_config['maximg'];
                if ($index == 'append_text') {
                    $tp = 'text';
                }
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_pt($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_pt($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }elseif($index == 'spgg'){
                $re = unserialize($re);
                $tp = 'textarea';

                $ret = '';
                foreach ($re as  $item) {
                    $ret .= $item['name'].'=';
                    $retmp = array();
                    foreach ($item['ggtext'] as $itemm) {
                        $retmp[] = $itemm;
                    }
                    $ret .= implode(',', $retmp) . "\n";
                }
                showsetting(lang_pt($index.'desc', 0), "editform[$index]", trim($ret), $tp, '', 0, $cmt, $_extra);
            }else{
                if($index=='hy'){
                    $cmt = lang_pt('gsts', 0);
                }
                showsetting(lang_pt($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js?121212"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['stat'] = intval($editform['stat']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach (array('crts', 'upts', 'usetime') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        $editform['jieshao'] = ($editform['jieshao']);
        $editform['append_text'] = array_slice($editform['append_text'], 0, count($editform['append_img']));

        foreach (array('album', 'append_text', 'append_img') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
        if(!$sh){
            cpmsg(lang_pt('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&secid=$secid", 'error');
        }


        $hy_ret = C::t('#xigua_pt#xigua_pt_hangye')-> fetch_by_name(array_filter(explode(' ', trim($editform['hy']))));
        $hangye_ids = array_keys($hy_ret);

        $editform['shname']     = $sh['name'];
        $editform['shid']       = $sh['shid'];
        $editform['hangye_id1'] = $hangye_ids[0];
        $editform['hangye_id2'] = $hangye_ids[1];



        $srg = array();
        foreach ($editform['srange'] as $index => $item) {
            list($_rangt, $_rangd) = explode("#", $item);
            $srg[] = $_rangt;
        }

        $editform['srange']     = implode("\t", $srg);

        if($secid>0){

            $old_data = C::t('#xigua_pt#xigua_pt_good')->fetch($secid);
            $old_data = C::t('#xigua_pt#xigua_pt_good')->prepare($old_data);

            $rs = C::t('#xigua_pt#xigua_pt_good')->update($secid, $editform);
            $gid = $secid;
        }else{
            $spgg = array();
            $spggtmp = array();
            foreach (explode("\n", trim($editform['spgg'])) as $index => $item) {
                list($name, $value) = explode("=", trim($item));
                $value = explode(',', trim($value));
                if($name&&$value){
                    $spgg[] = array(
                        'id' => $index,
                        'name' => $name,
                        'ggtext' => $value
                    );
                }
            }
            $editform['spgg'] = serialize($spgg);

            $gid = C::t('#xigua_pt#xigua_pt_good')->insert($editform, 1);
            if($spgg){
                DB::delete('xigua_pt_good_price', array('gid' => $gid));
                $price_list = $pow = array();
                $ggtest = $n = array();
                foreach ($spgg as $str => $item) {
                    $ggtest[] = $item['ggtext'];
                }
                $ggtest = combination($ggtest);
                foreach ($ggtest as $index => $item) {
                    $data = array();
                    $data = array(
                        'crts' => TIMESTAMP,
                        'upts' => TIMESTAMP,
                        'uid' => $item['uid']?$item['uid']:$sh['uid'],
                        'gid' => $gid
                    );
                    $data['price_pt'] = $editform['tprice'];
                    $data['price_dm'] = $editform['dprice'];
                    $data['price_sc'] = $editform['disprice'];
                    $data['price_hk1'] = $editform['pricehk1'];
                    $data['price_hk2'] = $editform['pricehk2'];
                    $data['price_cb'] = $editform['disprice'];
                    $data['stock']    = $editform['stock'];
                    $data['name']     = is_array($item) ? implode('###', $item) : $item;
                    C::t('#xigua_pt#xigua_pt_good_price')->update_price($data);

                }
            }
        }
        cpmsg(lang_pt('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&secid=$secid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_pt#xigua_pt_good')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_pt#xigua_pt_good')->update($id, array('displayorder' => $item['displayorder'], 'stat' => $item['stat']));
        }

        cpmsg(lang_pt('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey($keyword)) {
        $wherearr[] = " (title LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR append_text LIKE '%$keyword%') ";
    }
    if(isset($_GET['stat'])){
        $wherearr[] = 'stat=' . intval($_GET['stat']);
    }

    $ob = ' displayorder DESC';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_pt('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($statuss as $index => $_v) {
        echo '<label><input type="radio" name="stat" value="'.$index.'" ' . (isset($_GET['stat'])&&$_GET['stat']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good".' class="btn" >'.cplang('reset').'</a> ';
//    echo " </div>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&secid=-1\" class=\"btn\">".lang_pt('tjsp',0)."</a></div>";

    showtableheader(lang_pt('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_pt('del', 0),
        lang_pt('displayorder', 0),
        lang_pt('thumb', 0),
        lang_pt('title', 0),
        lang_pt('author', 0),
        lang_pt('hsname', 0),
        lang_pt('crendts', 0),
        lang_pt('spzt', 0),
        lang_pt('caozuo', 0),
    ));


    $res = C::t('#xigua_pt#xigua_pt_good')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_pt#xigua_pt_good')->fetch_count_by_page($wherearr);

    $shids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $shids[$v['shid']] = $v['shid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $shid = $v['shid'];
        $thumb = $v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0];
        $stat = lang_pt('jxz',0);
        if($v['not_start']){
            $stat =lang_pt( 'wks',0);
        }elseif ($v['isend']){
            $stat = lang_pt('yjs',0);
        }
        if($v['stock']<=0){
            $stat = lang_pt('ysw',0);
        }


        $checked = $v['display'] ? 'checked' : '';

        $appeend = '';
        foreach ($v['append_img_ary'] as $__k => $__v) {
            $appeend .= "<p><img style='width:180px;display:block' src=\"{$__v}\" /></p>";
            $appeend .= "<p>" . nl2br($v['append_text_ary'][$__k]) . "</p>";
        }

        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $status_u = "<select name=\"row[$id][stat]\">";
        foreach ($statuss as $k => $vv) {
            if($v['stat']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input type='text' name='row[$id][displayorder]' value='{$v['displayorder']}' style='width:50px' />",
            "<img src='$thumb' style='width:70px;height:40px' />",
            $v['title'],
            'UID: '.$v['uid'].' '.$users[$v['uid']]['username'],
            "<a target='_blank' href='".ADMINSCRIPT."?action=plugins&operation=config&do=&identifier=xigua_hs&pmod=admin_shanghu&shid=".$v['shid']."'>".$shinfos[$v['shid']]['name'].'</a>',

            $v['crts_u'],

            $status_u,

            '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&secid=$id" . '">' . lang_pt('edit', 0) . '</a> '.
            '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&price_id=$id" . '">' . lang_pt('price_edit', 0) . '</a> '.
        '',
        ));
    }
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_good&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    /*echo '<pre>';
    print_r($res);
    echo '</pre>';*/
}