<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/9/4
 * Time: 15:33
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($do == 'ptuserlist'){

    $tuan_id = intval($_GET['tuan_id']);
    $ptuserlist = C::t('#xigua_pt#xigua_pt_order')->fetch_by_tuanid($tuan_id, 0 );
    $ret = '';
    foreach ($ptuserlist as $index => $item) {
        $AVA = avatar($item['uid'], 'small', 1);
        $ret .= "<div class=\"z pr\"><img class=\"share_tz\" src=\"$AVA\"/></div>";
    }

    include template('xigua_hb:header_ajax');
    echo $ret;
    include template('xigua_hb:footer_ajax');
}elseif($do == 'tuan_profile'){

    $tuan_id = intval($_GET['tuan_id']);
    $ptuserlist = C::t('#xigua_pt#xigua_pt_order')->fetch_by_tuanid($tuan_id, 1 );
    foreach ($ptuserlist as $item) {
        $uids[$item['uid']] = $item['uid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    $ret = '';
    foreach ($ptuserlist as $index => $item) {
        $AVA = avatar($item['uid'], 'small', 1);
        $username = $users[$item['uid']]['username'];

        $ret .=<<<HTML
<div class="weui-cell" style="padding:10px 0">
    <div class="weui-cell__hd"><img src="$AVA" class="tuan_p_img"></div>
    <div class="weui-cell__bd">
        <p class="f14 tl">{$username}</p>
    </div>
    <div class="weui-cell__ft f12">{$item['pay_ts_u']}</div>
</div>
HTML;

    }
    include template('xigua_hb:header_ajax');
    echo $ret;
//    print_r(    $ptuserlist);
    include template('xigua_hb:footer_ajax');
}elseif($do == 'tuans'){

    $v = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($gid);
    $ti = TIMESTAMP;
    $wher = array(" (buy_type=2 AND status=5 AND tuan_id=0 AND gid=$gid AND shixian>=$ti ) ");
    $pting = C::t('#xigua_pt#xigua_pt_order')->fetch_all_by_where($wher, 0, 20, 'id DESC', '*', 1);

    $ret = '';
    $langhc = lang_pt('hc',0);
    $langr = lang_pt('r',0);
    $langpc = lang_pt('pc',0);
    $langshy = lang_pt('shy',0);

    $langcy = lang_pt('cy',0);
    $langdpd = lang_pt('dpd',0);
    $langqpd = lang_pt('qpd',0);

    foreach ($pting as  $pt_k => $pt_usr) {
        $le = $v['ptmin']-$pt_usr['tuan_num'];
        $AVA = avatar($pt_usr['uid'], 'small', 1);
        $ret .=<<<HTML
<div class="weui-cell" style="padding:10px 0">
    <div class="weui-cell__hd">
        <img src="$AVA" style="width:20px;height:20px;border-radius:20px;vertical-align:middle;display:inline-block" >
        <span class="f14">$pt_usr[username]</span>
    </div>
    <div class="weui-cell__bd ctli">
        <p>$langhc<em class="ptcolor">{$le}$langr</em>$langpc</p>
        <p class="hmt" data-start="{$pt_usr[pay_ts_u]}" data-end="{$pt_usr['shixian_u']}">$langshy<span class="timer"></span></p>
    </div>
    <div class="weui-cell__ft">
        <a href="javascript:;" class="ptbtn joinpt" data-type="2"  data-uid="{$pt_usr[uid]}" data-tuan_id="{$pt_usr[id]}" data-title="$langcy{$pt_usr[username]}$langdpd" data-text="ctli_{$pt_k}">$langqpd</a>
    </div>
</div>
HTML;
    }

    include template('xigua_hb:header_ajax');
    echo $ret;
//    print_r(    $ptuserlist);
    include template('xigua_hb:footer_ajax');
}elseif($do == 'sxj'){
    $stat = intval($_GET['stat']);
    $gid = intval($_GET['gid']);
    $v = C::t('#xigua_pt#xigua_pt_good')->fetch_G($gid);
    if($v['stat'] == 2){
        hb_message(lang_pt('shzwf',0), 'error');
    }
    if(!in_array($stat, array(1,3))){
        hb_message('error', 'error');
    }
    C::t('#xigua_pt#xigua_pt_good')->update_G($gid, array(
        'stat' => $stat
    ));
    hb_message(lang_pt('czcg',0),'success', 'reload');
}elseif($do=='fahuo'){
    $ptlogid = intval($_GET['ptlogid']);
    $shids = get_shids_by_uid();
    $v = DB::fetch_first("select * from %t WHERE shid IN(%n) AND id=%d ", array(
        'xigua_pt_order',
        $shids,
        $ptlogid
    ));
    if($v){
        if(!$_GET['yundan_gs']||!$_GET['yundan']){
            hb_message('error','error');
        }
        DB::update('xigua_pt_order', array(
            'fa_ts' => TIMESTAMP,
            'yundan_gs' => $_GET['yundan_gs'],
            'yundan' => $_GET['yundan'],
        ), array(
            'id' => $ptlogid
        ));

        $v = C::t('#xigua_pt#xigua_pt_order')->fetch($ptlogid);

        notification_add($v['uid'],'system', "<a href=\"{url}\">".$v['title'].lang_pt('yfh',0).'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&ptlog_id='.$v['id']),1);

        hb_message(lang_pt('fhcg',0), 'success', 'reload');
    }
}elseif($do=='shouhuo'){
    $ptlogid = intval($_GET['ptlogid']);

    $old = C::t('#xigua_pt#xigua_pt_order')->fetch($ptlogid);
    $aff = C::t('#xigua_pt#xigua_pt_order')->update_G($ptlogid, array(
        'shou_ts' => TIMESTAMP,
        'shou_confirm_ts' => TIMESTAMP,
    ));
    if($aff && $old['shou_ts']<=1&& $old['shou_confirm_ts']<=1){
        $v = C::t('#xigua_pt#xigua_pt_order')->fetch($ptlogid);

        $shid = $v['shid'];

        include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
        $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
        $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
        $insxf   = intval(abs($vipinfo['insxf']))/100;
        if($shdata['shinsxf']){
            $insxf  = intval(abs($shdata['shinsxf']))/100;
        }

        $sxfee = round($insxf*$v['pay_money'], 2);
        $money = $v['pay_money']-$sxfee;

        global $_G;
        $pt_config = $_G['cache']['plugin']['xigua_pt'];
        if($pt_config['jiesuantype']=='cb'){
            $price_cb = DB::result_first('SELECT price_cb FROM %t WHERE id=%d', array('xigua_pt_good_price', $v['priceid']));
            if($price_cb> 0){
                $money = $price_cb*$v['gnum']+$v['yunfee'];
            }
        }

        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', $money);
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid'  => $shdata['uid'],
            'crts' => TIMESTAMP,
            'size' => $money,
            'note' => lang_pt('ddh',0).$v['order_id'],
            'link' => "$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
        ));

        hb_message(lang_pt('qrshcg',0), 'success', 'reload');
    }
    hb_message(lang_pt('qrshsb',0), 'error', 'reload');
}elseif($do == 'showqr'){

    $v = C::t('#xigua_pt#xigua_pt_order')->fetch($_GET['ptlog_id']);
    if($v['hxcode']){
        if($r = pt_qrcode_make($v['id'], $v['hxcode'])){
            dheader("Location: $r");
        }
    }
}elseif($do == 'upscan'){
    if(submitcheck('code')) {
        $ptlog_id = intval($_GET['ptlog_id']);
        $v = DB::fetch_first("select * from %t WHERE id=%d AND hxcode=%s AND status IN(2,6) AND hxcrts=0", array(
            'xigua_pt_order',
            $ptlog_id,
            $_GET['code']
        ));
        if(!$v){
            hb_message(lang_pt('hxerror',0), 'error');
        }
        $gid = $v['gid'];
        $shid = $v['shid'];

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
        $good = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($gid);

        $access = 0;
        if (IS_ADMINID) {
            $access = 1;
        } elseif ($v['uid'] == $_G['uid']) {
            $access = 1;
        } elseif ($good['uid'] == $_G['uid']) {
            $access = 1;
        }
        if (!$access) {
            $yuaninfo = C::t('#xigua_hs#xigua_hs_yuan')->fetch_yuan_by_shid_uid($shid, $_G['uid']);
            if ($yuaninfo) {
                $access = 1;
            }
        }
        if (!$access) {
            if ($coki = authcode(getcookie('hstax' . $shid), 'DECODE')) {
                $shv = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
                if ($shv['hxpwd'] == $coki) {
                    $access = 1;
                }
            }
        }
        if (!$access) {
            hb_message('noaccess', 'error');
        }

        if(!in_array($v['status'], array(2, 6))){
            hb_message('error', 'error');
        }
        if($v['hxuid']>0){
            hb_message('error', 'error');
        }

        $aff = C::t('#xigua_pt#xigua_pt_order')->update($ptlog_id, array(
            'shou_ts' => TIMESTAMP,
            'fa_ts' => TIMESTAMP,
            'hxuid' => $_G['uid'],
            'hxcrts' => TIMESTAMP,
        ));

        include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
        $shdata =  $sh;
        $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
        $insxf   = intval(abs($vipinfo['insxf']))/100;
        if($shdata['shinsxf']){
            $insxf  = intval(abs($shdata['shinsxf']))/100;
        }

        $sxfee = round($insxf*$v['pay_money'], 2);
        $money = $v['pay_money']-$sxfee;

        global $_G;
        $pt_config = $_G['cache']['plugin']['xigua_pt'];
        if($pt_config['jiesuantype']=='cb'){
            $price_cb = DB::result_first('SELECT price_cb FROM %t WHERE id=%d', array('xigua_pt_good_price', $v['priceid']));
            if($price_cb> 0){
                $money = $price_cb;
                $money = $price_cb*$v['gnum']+0;
            }
        }

        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', $money);
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid'  => $shdata['uid'],
            'crts' => TIMESTAMP,
            'size' => $money,
            'note' => lang_pt('hxcgdhh',0).$v['order_id'],
            'link' => "$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
        ));

        hb_message(lang_pt('hxcg',0), 'success', 'reload');


    }
}