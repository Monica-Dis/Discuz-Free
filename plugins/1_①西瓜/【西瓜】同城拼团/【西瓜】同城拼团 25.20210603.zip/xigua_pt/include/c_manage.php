<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/4/18
 * Time: 16:58
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!$_G['uid']){
    hb_jump_login();
}
$navtitle = lang_pt('qggl',0);
if($_G['cache']['plugin']['xigua_hs']){
    $where = array();
    $where[] = 'uid='.$_G['uid'].' and display=1 and endts>='.TIMESTAMP;
    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
}
$need_side = 1;