<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/12/10
 * Time: 19:07
 */

function pt_get_shids_by_uid(){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    return $shids;
}

if($_GET['do']=='backrefund') {
    if(submitcheck('formhash')) {
        $ptlogid = intval($_GET['ptlogid']);
        $order = C::t('#xigua_pt#xigua_pt_order')->fetch($ptlogid);
        $refund_log = C::t('#xigua_pt#xigua_pt_refund')->fetch_by_ptlogid($ptlogid);

        C::t('#xigua_pt#xigua_pt_order')->update($ptlogid, array('status' => $refund_log['order_status'], 'refund_id' => 0));

        hb_message(lang_pt('qxtkcg',0), 'success', 'reload');
    }

}else if($_GET['do']=='confirmtk'){
    if(submitcheck('formhash')){
        $rid = intval($_GET['redund_id']);
        if (discuz_process::islocked('xiguasptk'.$_G['uid'].'_'.$rid, 10)) {
            hb_message(lang_pt('czpf',0), 'error');
        }
        $rv = C::t('#xigua_pt#xigua_pt_refund')->fetch_by_id($rid);
        $v = C::t('#xigua_pt#xigua_pt_order')->fetch($rv['ptlogid']);
        $ptorder = C::t('#xigua_pt#xigua_pt_order')->prepare($v);

        if(in_array($rv['shid'], pt_get_shids_by_uid()) || IS_ADMINID){

            $hborder = C::t('#xigua_hb#xigua_hb_order')->fetch($v['order_id']);
            if($hborder['fromopenid']){

                $out_trade_no = $v['order_id'];
                $total_fee = intval($v['pay_money']*100);
                $refund_fee = $total_fee;
                $tkprofile= '<br>'.lang('plugin/xigua_pt', 'tkje').floatval($refund_fee/100).'<br>'.lang('plugin/xigua_pt', 'zfje').floatval($total_fee/100);

                try{
                    $input = new WxPayRefundSF();
                    $input->SetOut_trade_no($out_trade_no);
                    $input->SetTotal_fee($total_fee);
                    $input->SetRefund_fee($refund_fee);
                    $refund_order = substr(md5($out_trade_no), 0,8).date("YmdHis");
                    $input->SetOut_refund_no($refund_order);
                    $input->SetOp_user_id(WxPayConfigSF::MCHID);

                    $rett = WxPayApiSF::refund($input, 10);
                    $ret1 = diconv(var_export($rett, 1), 'UTF-8', CHARSET);
                    $ret2 = lang('plugin/xigua_pt', 'tkxq').lang('plugin/xigua_pt', $rett['return_code']).diconv($rett['return_msg'],'UTF-8', CHARSET);
                    if($rett["return_code"] == "SUCCESS" && $rett["result_code"] == "SUCCESS"){
                        C::t('#xigua_pt#xigua_pt_refund')->update($rid, array('upts' => TIMESTAMP, 'status' => 2));
                        C::t('#xigua_pt#xigua_pt_order')->update($rv['ptlogid'], array('status' => 4,'refund' => lang('plugin/xigua_pt', 'dh').$refund_order.'<br>'.$ret1,));

                        notification_add($v['uid'],'system', lang_pt('tksq_tip2', 0),array(
                            'url' => "$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id={$rv['ptlogid']}$urlext",
                        ),1);

                        if($_G['cache']['plugin']['xigua_hh']) {
                            DB::query("DELETE FROM " . DB::table('xigua_hh_income') . " WHERE info LIKE '%{$v['order_id']}%' and reach<>1 LIMIT 2");
                        }
                        if($ptorder['shou_ts']>0 && $ptorder['shou_confirm_ts']>0){
                            $shid = $ptorder['shid'];
                            include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                            $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                            $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                            $insxf   = intval(abs($vipinfo['insxf']))/100;
                            if($shdata['shinsxf']){
                                $insxf  = intval(abs($shdata['shinsxf']))/100;
                            }
                            $sxfee = round($insxf*$ptorder['pay_money'], 2);
                            $money = $ptorder['pay_money']-$sxfee;
                            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', -$money);
                            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                                'uid'  => $shdata['uid'],
                                'crts' => TIMESTAMP,
                                'size' => -$money,
                                'note' => lang_pt('tkcg',0).$ptorder['order_id'],
                                'link' => "$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id={$ptorder['id']}&manage=1".$urlext,
                            ));
                        }

                        hb_message(lang_pt('tkcg',0), 'success', 'reload');
                    }else{
                        hb_message($ret2, 'error');
                    }
                }catch (Exception $e){
                    hb_message(lang('plugin/xigua_pt', 'tkxq').diconv($e->getMessage(), 'UTF-8', CHARSET), 'error');
                }
            }else{
                C::t('#xigua_pt#xigua_pt_refund')->update($rid, array('upts' => TIMESTAMP, 'status' => 2));
                C::t('#xigua_pt#xigua_pt_order')->update($rv['ptlogid'], array('status' => 4,'refund' => '',));

                C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                    'uid' => $v['uid'],
                    'crts' =>TIMESTAMP,
                    'size' => $v['pay_money'],
                    'note' => lang_pt('tkcg',0),
                    'link' => "",
                ));
                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['uid'], 'money', $v['pay_money']);
                if($_G['cache']['plugin']['xigua_hh']) {
                    DB::query("DELETE FROM " . DB::table('xigua_hh_income') . " WHERE info LIKE '%{$v['order_id']}%' and reach<>1 LIMIT 2");
                }

                if($ptorder['shou_ts']>0 && $ptorder['shou_confirm_ts']>0){
                    $shid = $ptorder['shid'];
                    include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                    $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                    $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                    $insxf   = intval(abs($vipinfo['insxf']))/100;
                    if($shdata['shinsxf']){
                        $insxf  = intval(abs($shdata['shinsxf']))/100;
                    }
                    $sxfee = round($insxf*$ptorder['pay_money'], 2);
                    $money = $ptorder['pay_money']-$sxfee;
                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', -$money);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid'  => $shdata['uid'],
                        'crts' => TIMESTAMP,
                        'size' => -$money,
                        'note' => lang_pt('tkcg',0).$ptorder['order_id'],
                        'link' => "$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id={$ptorder['id']}&manage=1".$urlext,
                    ));
                }

                notification_add($v['uid'],'system', lang_pt('tksq_tip3', 0),array(
                    'url' => "$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id={$rv['ptlogid']}$urlext",
                ),1);
                hb_message(lang_pt('tkcg',0), 'success', 'reload');
            }
        }else{
            hb_message('ERROR!', 'error');
        }
    }
}else if($_GET['do']=='getrefund'){
    $rid = $_GET['refund_id'];
    $tkyy = lang_pt('tkyy',0);
    $sqsj = lang_pt('sqsj',0);

    $r = C::t('#xigua_pt#xigua_pt_refund')->fetch_by_id($rid);
    $order = C::t('#xigua_pt#xigua_pt_order')->fetch($r['ptlogid']);

    if($order['yundan']){
        $p = '<p>'.lang_pt('khysh',0).'</p>';
    }

    $ret = <<<HTML
<p>$tkyy: {$r[note]}</p>
<p>$sqsj: {$r[crts_u]}</p>$p
HTML;
    hb_message($ret, 'success');
}else{

    if(submitcheck('formhash')){
        $ptlogid = intval($_GET['ptlogid']);
        $order = C::t('#xigua_pt#xigua_pt_order')->fetch($ptlogid);
        $order = C::t('#xigua_pt#xigua_pt_order')->prepare($order);
        if(!$order['allowtk']){
            hb_message(lang_pt('qqrshhztk',0), 'error');
        }

        $rid = C::t('#xigua_pt#xigua_pt_refund')->insert(array(
            'ptlogid' => $ptlogid,
            'crts' => TIMESTAMP,
            'uid' => $_G['uid'],
            'danhao' => '',
            'gongsi' => '',
            'note' => $_GET['input'],
            'status' => '-1',
            'order_status' => $order['status'],
        ), 1);

        C::t('#xigua_pt#xigua_pt_order')->update($ptlogid, array('status' => 3, 'refund_id' => $rid));

        $shinfo = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($order['shid']);

        notification_add($shinfo['uid'],'system', lang_pt('tksq_tip', 0),array(
            'url' => "$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id=$ptlogid$urlext",
            'username'=>$_G['username']
        ),1);

        hb_message(lang_pt('sqcg',0), 'success', "$SCRITPTNAME?id=xigua_pt&ac=order&keyword={$_GET['keyword']}&status=3,4,7");
    }
}