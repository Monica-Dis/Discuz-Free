<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/9/4
 * Time: 15:33
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$navtitle = lang_pt('ddgl1',0);
$need_side = 1;
$keyword = stripsearchkey($_GET['keyword']);
