<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/4/19
 * Time: 11:41
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$viewtype = $_GET['viewtype'];
if(!$viewtype){
    $viewtype = $orderby = $_GET['orderby'];
}
$manage = IS_ADMINID && $ac == 'manage';
$field = '*';
$where = array();
$where[] = "uid=".intval($_G['uid']);
$stat = intval($_GET['stat']);
if(!$stat){
    $stat = 1;
}
$where[] = "stat=".intval($stat);

$list = C::t('#xigua_pt#xigua_pt_good')->fetch_all_by_where($where, $start_limit, $lpp, 'id desc', $field);


include template('xigua_hb:header_ajax');
include template('xigua_pt:'.$ac);
include template('xigua_hb:footer_ajax');