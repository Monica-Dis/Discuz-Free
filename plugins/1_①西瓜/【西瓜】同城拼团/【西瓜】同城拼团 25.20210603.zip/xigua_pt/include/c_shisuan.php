<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/8/29
 * Time: 16:02
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$price = floatval($_GET['price']);
$num = intval($_GET['num']);
$ret = floatval($price* $num+$_GET['yf']-$_GET['youhui']);


include template('xigua_hb:header_ajax');
echo $ret;
include template('xigua_hb:footer_ajax');