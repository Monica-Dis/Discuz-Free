<?php
/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_pt/function.php';
$status_font = array(
    1 => lang_pt('status_1',0),
    2 => lang_pt('status_2',0),
    3 => lang_pt('status_3',0),
    4 => lang_pt('status_4',0),
    5 => lang_pt('status_5',0),
    6 => lang_pt('status_6',0),
    7 => lang_pt('status_7',0),
);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$pt_hangye_class = C::t('#xigua_pt#xigua_pt_hangye');
$page = max(1, intval($_GET['page']));
$lpp = 5;
$start_limit = ($page - 1) * $lpp;
$cat__id = intval($_GET['cat__id']);
if($cat__id){
    $cat_indo = $pt_hangye_class->fetch_by_catid($cat__id);
}
$GLOBALS['needchild'] = 1;
if(1){
    if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
        $ret = $pt_hangye_class->do_delete(intval($_GET['catid']));
        if($ret){
            cpmsg(
                lang_hs('delcat_succeed', 0),
                "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_hangye&page=$page",
                'succeed'
            );
        }else{
            cpmsg(
                lang_hs('delcat_error', 0),
                "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_hangye&page=$page",
                'error'
            );
        }
    }
    if(submitcheck('dosubmit')){
        if($new = $_GET['n']){
            $newrow = array();
            foreach ($new['name'] as $k => $v) {
                if(is_array($v)){
                    foreach ($v as $kk => $string) {
                        $newrow[] = array(
                            'pid'  => $k,
                            'name' => $string,
                            'o'    => $new['o'][$k][$kk],
                            'ts'   => TIMESTAMP,
                            'cat_ids'   => trim($new['cat_ids'][$k][$kk]),
                            'price'  => $new['price'][$k][$kk],
                            'telprice'  => $new['telprice'][$k][$kk],
                            'stids'  => $new['stids'][$k][$kk],
                        );
                    }
                } else {
                    $newrow[] = array(
                        'pid' => 0,
                        'name' => $v,
                        'o'  => $new['o'][$k],
                        'ts'   => TIMESTAMP,
                        'cat_ids'   => trim($new['cat_ids'][$k]),
                        'price'  => $new['price'][$k],
                        'telprice'  => $new['telprice'][$k],
                        'stids'  => $new['stids'][$k],
                    );
                }
            }
            foreach ($newrow as $value) {
                $pt_hangye_class->insert($value);
            }
        }

        if($_FILES['icon'] || $_FILES['adimage']){
            $icons = hb_uploads($_FILES['icon']);
            $adimage = hb_uploads($_FILES['adimage']);
        }
        if($r = $_GET['r']){
            foreach ($r['name'] as $cid => $name) {
                $data = array();

                $data['name']   = $name;
                $data['o']      = $r['o'][$cid];
                $data['cat_ids']= $r['cat_ids'][$cid];
                $data['adlink'] = $r['adlink'][$cid];
                $data['price']  = $r['price'][$cid];
                $data['telprice']  = $r['telprice'][$cid];
                $data['stids']  = $r['stids'][$cid];
                $data['tag']    = trim($r['tag'][$cid]);
                $data['placehoder']    = trim($r['placehoder'][$cid]);
                if($_FILES['adimage']['error'][$cid] === UPLOAD_ERR_OK){
                    $data['adimage']= ($adimage[$cid]['errno'] == 0 ? $adimage[$cid]['error'] : '');
                }
                if($_FILES['icon']['error'][$cid] === UPLOAD_ERR_OK) {
                    $data['icon'] = ($icons[$cid]['errno'] == 0 ? $icons[$cid]['error'] : '');
                }

                $pt_hangye_class->update($cid, $data);
            }
        }
        if($delimg = $_GET['delimg']){
            foreach ($delimg as $catid_ => $fields_) {
                $data_ = array();
                if($fields_['icon'] == 1){
                    $data_['icon'] = '';
                }
                if($fields_['adimage'] == 1){
                    $data_['adimage'] = '';
                }
                if($data_){
                    $pt_hangye_class->update(intval($catid_), $data_);
                }
            }
        }
        cpmsg(
            lang_hs('succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_hangye&page=$page",
            'succeed'
        );
    }

    $listinfo = $pt_hangye_class->fetch_all_by_page($start_limit, $lpp);
    $pt_hangye_class->init($listinfo);
    $list = $pt_hangye_class->get_tree_array(0);

    $totalcount = $pt_hangye_class->count_by_page();
    $multipage = multi(
        $totalcount, $lpp, $page,
        ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_hangye&page=$page"
    );

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_hangye&page=$page", 'enctype');
    $alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_pub&catadd";

    showtips(lang_pt('category_tip', 0));
    ?>
    <style>
        .imgi{height:20px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
        .short{width:150px}
        .td23 input{width:120px!important;}
    </style>
    <div style="height:30px;line-height:30px;padding-left:25px">
        <a href="javascript:;" onclick="show_all()"><?php echo cplang('show_all')?></a> | <a href="javascript:;" onclick="hide_all()"><?php echo cplang('hide_all')?></a>
    </div>
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th>&nbsp;</th>
            <th><?php lang_hs('hangye_id')?></th>
            <th><?php lang_hs('order')?></th>
            <th><?php lang_pt('cat_name')?></th>
            <th><?php lang_pt('cat_icon')?></th>
            <th><?php lang_pt('cat_ad')?></th>
<!--            <th>--><?php //lang_hs('price')?><!--</th>-->
            <th><?php lang_hs('stids1')?></th>
            <th><?php lang_hs('caozuo')?></th>
        </tr>
        </tbody>
        <?php foreach ($list as $v) { ?>
            <tbody>
            <tr class="hover">
                <td class="td25" onclick="toggle_group('group_<?php echo $v['id']?>', $('a_group_<?php echo $v['id']?>'))"><a href="javascript:;" id="a_group_<?php echo $v['id']?>">[-]</a></td>
                <td class="td25"><?php echo $v['id']?></td>
                <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $v['id']?>]" value="<?php echo $v['o']?>" /></td>
                <td class="td23">
                    <div class="parentboard"><input type="text" name="r[name][<?php echo $v['id']?>]" value="<?php echo $v['name']?>" class="txt" /></div>
                </td>
                <td>
                    <input class="short" name="icon[<?php echo $v['id']?>]" type="file" />
                    <?php if($v['icon']){?>
                        <span class="sp">
     <img class="imgi" src="<?php echo $v['icon']?>" onmouseover="$('icon<?php echo $v['id']?>').style.display='block'" onmouseout="$('icon<?php echo $v['id']?>').style.display='none'" />
     <img id="icon<?php echo $v['id']?>" src="<?php echo $v['icon']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][icon]" value="1" /><?php lang_hs('delshort')?></label>
 </span>
                    <?php }?>
                </td>
                <td>
                    <p>
                        <input class="short"  name="adimage[<?php echo $v['id']?>]" type="file" />
                        <input type="text" class="txt short" name="r[adlink][<?php echo $v['id']?>]" value="<?php echo $v['adlink'] ? $v['adlink'] : ''; ?>" />
                        <?php if($v['adimage']){?>
                            <span class="sp">
    <img class="imgi" src="<?php echo $v['adimage']?>" onmouseover="$('ad<?php echo $v['id']?>').style.display='block'" onmouseout="$('ad<?php echo $v['id']?>').style.display='none'"  />
    <img id="ad<?php echo $v['id']?>" src="<?php echo $v['adimage']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][adimage]" value="1" /><?php lang_hs('delshort')?></label>
</span>
                        <?php }?>
                    </p>
                </td>
                <!--<td>
                    <input type="text" class="txt" name="r[price][<?php /*echo $v['id']*/?>]"  value="<?php /*echo $v['price']*/?>" />
                </td>-->
                <td>
                    <input type="text" class="txt" name="r[stids][<?php echo $v['id']?>]"  value="<?php echo $v['stids']?>" />
                </td>
                <td>
                    <a href="javascript:;" onclick="return _delid(<?php echo $v['id']?>,'<?php echo str_replace('&#039;', '', $v['name'])?>') "><?php lang_hs('del')?></a>
                </td>
            </tr>
            </tbody>
            <tbody id="group_<?php echo $v['id']?>">
            <?php foreach ($v['child'] as $c) { ?>
                <tr class="hover">
                    <td class="td25"></td>
                    <td class="td25"><?php echo $c['id']?></td>
                    <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $c['id']?>]" value="<?php echo $c['o']?>" /></td>
                    <td class="td23">
                        <div class="board">
                            <input type="text" name="r[name][<?php echo $c['id']?>]" value="<?php echo $c['name']?>" class="txt" />
                        </div>
                    </td>
                    <td>
                        <input class="short" name="icon[<?php echo $c['id']?>]" type="file" />
                        <?php if($c['icon']){?>
                            <span class="sp">
     <img class="imgi" src="<?php echo $c['icon']?>" onmouseover="$('icon<?php echo $c['id']?>').style.display='block'" onmouseout="$('icon<?php echo $c['id']?>').style.display='none'" />
     <img id="icon<?php echo $c['id']?>" src="<?php echo $c['icon']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $c['id']?>][icon]" value="1" /><?php lang_hs('delshort')?></label>
 </span>
                        <?php }?>
                    </td>
                    <td>&nbsp;</td>
                    <!--<td>
                        <input type="text" class="txt" name="r[price][<?php /*echo $c['id']*/?>]"  value="<?php /*echo $c['price']*/?>" />
                    </td>-->
                    <td>
                        <input type="text" class="txt" name="r[stids][<?php echo $c['id']?>]"  value="<?php echo $c['stids']?>" />
                    </td>
                    <td>
                        <a href="javascript:;" onclick="return _delid(<?php echo $c['id']?>, '<?php echo str_replace('&#039;', '', $c['name'])?>') "><?php lang_hs('del')?></a>
                    </td>
                </tr>
                <?php
            }
            ?>
            </tbody>


            <tbody>
            <tr>
                <td></td>
                <td colspan="4">
                    <div class="lastboard">
                        <a href="javascript:;" onclick="addrow(this, 1, <?php echo $v['id']?>)" class="addtr"><?php lang_pt('ad_child_cat')?></a>
                    </div></td>
                <td>&nbsp;</td>
            </tr>
            </tbody>
        <?php }?>

        <tbody>
        <tr>
            <td>&nbsp;</td>
            <td colspan="99"><div>
                    <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_pt('ad_new_cat')?></a>
                </div></td>
        </tr>
        <?php
        if($multipage){
            showtablerow('', 'colspan="99"', $multipage);
        }
        showsubmit('dosubmit', 'submit', 'td');
        ?>
        </tbody>
    </table>
    </form>
    <script>
        var rowtypedata = [
            [
                [1, ''],
                [1, ''],
                [1,'<input type="text" class="txt" name="n[o][]" value="0" />', 'td25'],
                [5,'<div><input name="n[name][]" value="<?php lang_hs('new_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hs('del')?></a></div>']
            ],
            [
                [1, ''],
                [1, ''],
                [1,'<input type="text" class="txt" name="n[o][{1}][]" value="0" />', 'td25'],
                [5,'<div class="board"><input name="n[name][{1}][]" value="<?php lang_hs('child_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hs('del')?></a></div>']
            ]
        ];
        function _delid(id, name){
            if(confirm('<?php lang_hs('del_confirm')?>' + name + '?')){
                window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_pt&pmod=admin_hangye&page=$page&del=1&formhash=".FORMHASH.'&catid='?>"+id;
            }
        }
    </script><?php } ?>