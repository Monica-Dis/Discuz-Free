function load_fee_type() {
    if($('.fee_type').val()==1){
        $('#yxq').hide();
        $('#yfmb').show();
    }else{
        $('#yxq').show();
        $('#yfmb').hide();
    }
}
if($('.fee_type').length>0){
    load_fee_type();
}

function compress(file, callback){
    var reader = new FileReader();
    reader.onload = function (e) {
        var image = $('<img/>');
        image.on('load', function () {
            var square = 640;
            var canvas = document.createElement('canvas');
            if (this.width > this.height) {
                canvas.width = Math.round(square * this.width / this.height);
                canvas.height = square;
            } else {
                canvas.height = Math.round(square * this.height / this.width);
                canvas.width = square;
            }
            var context = canvas.getContext('2d');
            context.clearRect(0, 0, square, square);
            var imageWidth = canvas.width;
            var imageHeight = canvas.height;
            var offsetX = 0;
            var offsetY = 0;
            context.drawImage(this, offsetX, offsetY, imageWidth, imageHeight);
            var data = canvas.toDataURL('image/jpeg', 0.8);
            console.log([imageWidth,imageHeight]);
            callback(data);
        });
        image.attr('src', e.target.result);
    };
    reader.readAsDataURL(file);
}

function setSpgg(id, obj) {
    var par = $(obj).parent();
    var tgo = par.find('.tag-on');
    if(tgo.length> 0){
        tgo.removeClass('tag-on');
        par.find('input').val('0');
    }

    if ($(obj).hasClass('tag-on')) {
        $(obj).removeClass('tag-on');
        $('input[name="form[tagid][' + id + ']"]').val('0');
    } else {
        $(obj).addClass('tag-on');
        $('input[name="form[tagid][' + id + ']"]').val(id);
    }
    changePrice(id, obj);
}

function changePrice(id, obj){
    var price_name = [];
    $('.gginput').each(function () {
        var that = $(this);
        if(that.val() != '0'){
            price_name.push(that.val());
        }
    });
    priceName = price_name.join('###');
    var show_price_name = YIXUAN+': '+price_name.join('&nbsp;');
    console.log(price_name);
    if(PRICE_LIST){
        for(var i=0; i <PRICE_LIST.length; i++){
            if(PRICE_LIST[i].name == priceName){
                console.log(PRICE_LIST[i]);
                if(PRICE_LIST[i].stock<=0){
                    $(obj).removeClass('tag-on');
                    $('input[name="form[tagid][' + id + ']"]').val('0');
                    $.toast(KCBZ, "cancel");
                    return false;
                }
                $('#spggname').html(show_price_name + '&nbsp;&nbsp;'+KC1+': '+PRICE_LIST[i].stock);
                $('#pricePt').html(PRICE_LIST[i].price_pt);
                $('#priceDm').html(PRICE_LIST[i].price_dm);
                $('#price_id').val(PRICE_LIST[i].id);
            }
        }
    }
    return true;
}


function pt_jump(jpurl){
    if(typeof mag !== 'undefined'){
        mag.newWin(GSITE+jpurl);
        return false;
    }
    if(typeof wx !=='undefined' && jpurl.indexOf('javascript')===-1){
        if (window.__wxjs_environment === 'miniprogram') {
            GSITE = GSITE.replace(/http:\/\//, 'https://');
            var needfix = (jpurl.indexOf('http://')===-1&&jpurl.indexOf('https://')===-1) ? (GSITE+''+jpurl) : jpurl;
            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(needfix)});
            return false;
        }
    }
    window.location.href = jpurl;
}

function ptclock(){
    $('.hmt').each(function () {
        var that = $(this);
        pt_GetRunTime(that.data('start'),that.data('end'), that);
    });
}

function pt_GetRunTime( mallstart, mallend, itimer, step){
    var endtime= new Date(mallend.replace(/-/g,'/'));
    var starttime= new Date(mallstart.replace(/-/g,'/'));
    var keeptime = endtime - starttime;
    var nowtime = new Date();
    var t = endtime.getTime() - nowtime.getTime();
    var st = starttime.getTime()-nowtime.getTime();
    var tit = '';
    if(typeof noTit!=='undefined'){
        tit = '';
    }
    if(t<=0){
        itimer.html('<span class="timer">'+mallend+'</span>');
        return;
    }
    if(st>0){
        t = st;
    }
    tit = SHY+' ';
    var dd = t/1000;

    var d=Math.floor(dd/3600/24);
    var h=Math.floor(dd/3600%24);
    var m=Math.floor(dd/60%60);
    var s=Math.floor(dd%60);
    var o = '';
    if(h<10){h = '0'+h;}
    if(m<10){m = '0'+m;}
    if(s<10){s = '0'+s;}
    if(step ===10){
        o= Math.floor(t/10%100);
        if(o<10){o = '0'+o;}
        o = "<i>"+o+"</i>";
    }
    var width = t/keeptime*100;

    var ddis = '', hdis = '', mdis = '', sdis = '';
    if(d>0){
        ddis = '<i>'+d+'</i>' + ':'
    }
    hdis = '<i>'+h+'</i>' + ':';
    mdis = '<i>'+m+'</i>' + ':';
    sdis = '<i>'+s+'</i>';
    itimer.html(tit+'<span class="timer">'+ddis + hdis + mdis + sdis+o+'</span>');
    setTimeout(function(){
        pt_GetRunTime( mallstart, mallend, itimer, step);
    }, step||1000);
}


function pt_getparget(){
    var rst = '';
    var $_GET = (function(){
        var url = loadingurl.toString();
        var u = url.split("?");
        if(typeof(u[1]) === "string"){
            u = u[1].split("&");
            var get = {};
            for(var i in u){
                var j = u[i].split("=");
                if(typeof j[0] !=='undefined' && typeof j[1] !=='undefined'){
                    get[j[0]] = j[1];
                }
            }
            return get;
        } else {
            return {};
        }
    })();
    for(var i in $_GET){
        rst += i+"="+$_GET[i]+"&";
    }
    return '?'+rst;
}

function loadpt_index(that, ext){
    page = 1;
    lm = false;
    loadingurl = _APPNAME+pt_getparget()+ext+'&page=';
    if(that!==null){
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
    }
    DOAPPEND = 0;
    $.ajax({
        type: 'get',
        url: loadingurl+''+page,
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('#loading-show').addClass('hidden');
            if(!s){
                $('#loading-show').addClass('hidden');
                $('#loading-none').removeClass('hidden');
                setTimeout(function () {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                }, 300);
                $("#list").html(s);
                page = -1;
                return ;
            }
            $("#list").html(s);
            page ++;
        },
        error: function() {
        }
    });
}

$(function () {

    $(document).on('click','.pt_good', function () {
        var that = $(this);
        var jmpurl = _APPNAME +'?id=xigua_pt&ac=order_profile&ptlog_id='+that.data('id')+(that.data('manage') ? '&manage=1':'')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        pt_jump(jmpurl);
    });

    $(document).on('click', '.jump_pt', function () {
        var that = $(this);
        var jmpurl = _APPNAME +'?id=xigua_pt&ac=view&gid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        if(typeof mag !== 'undefined'){
            mag.newWin(GSITE+jmpurl);
            return false;
        }
        if(typeof wx !=='undefined'){
            if (window.__wxjs_environment === 'miniprogram') {
                wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
                return false;
            }
        }
        window.location.href = jmpurl;
        return false;
    });

    $(document).on('click','.buynow', function () {
        var that = $(this);
        $('#buy_type').val(that.data('type'));
        if(that.data('type') == 1){
            $('#pricePt').hide();
            $('#priceDm').show();
            $('#weuiAgree').hide();
        }else{
            if(that.data('tuan_id')){
                if(!ALLOWSELF){
                    if(UID==that.data('uid')){
                        $.alert(BTXZJCT);
                        return false;
                    }
                }
                $('#tuan_id').val(that.data('tuan_id'));
                $('#weuiAgree').hide();
            }else{
                $('#weuiAgree').show();
            }
            $('#pricePt').show();
            $('#priceDm').hide();
        }
        $('#popup_item').popup();
    });

    $(document).on('click','#pay_address', function () {
        hb_setcookie('seckill_wait', window.location.href, 1200);
        window.location.href = _APPNAME+'?id=xigua_hb&ac=myaddr'+_URLEXT;
    });

    $(document).on('click','.inc-num', function () {
        var ipt = $('.inc-input'), that = $(this);
        var num = parseInt(ipt.val());
        if(parseInt(that.data('step'))===1){
            if (!ipt.data('max') || num <ipt.data('max')) {
                ipt.val(++num);
            }
        }else{
            if (num > 1) {
                ipt.val(--num);
            }
        }
        if(typeof incNum !=='undefined'){
            incNum();
        }
    });

    $(document).on('click','.joinpt', function () {
        var that = $(this), s = '';
        var text = $('#'+that.data('text'));
        $.ajax({
            type: "POST",
            url: _APPNAME+"?id=xigua_pt&ac=com&do=ptuserlist&inajax=1&tuan_id="+that.data('tuan_id'),
            async: false,
            dataType: "xml",
            success: function (data) {
                if(null==data){ return false;}
                s = data.lastChild.firstChild.nodeValue;
            }
        });
        text.find('.other_tuanyuan').html(s);
        $.modal({
            title: that.data('title'),
            text: text.html(),
            buttons: [
                { text: QXQX, className: "default", onClick: function(){ } },
                { text: CYPT, className: "buynow\" data-type='2' data-uid='"+that.data('uid')+"' data-tuan_id='"+that.data('tuan_id')+"' ", onClick: function(){ } },
            ]
        });
        ptclock();
    });

    $(document).on('click','.ajax_cat', function () {
        var that = $(this);
        page = 1;
        loadingurl = window.location.href+'&ac=cat_li&inajax=1&catid='+that.data('id')+'&page=';
        if(that.data('loadingurl')){
            loadingurl = that.data('loadingurl');
        }
        that.addClass('ajax_cat_cur').siblings().removeClass('ajax_cat_cur');
        DOAPPEND = 0;
        $.ajax({
            type: 'get',
            url: loadingurl+''+page,
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $('#loading-show').addClass('hidden');
                if(!s){
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                    setTimeout(function () {
                        $('#loading-show').addClass('hidden');
                        $('#loading-none').removeClass('hidden');
                    }, 300);
                    $("#list").html(s);
                    page = -1;
                    return ;
                }
                $("#list").html(s);
                page ++;
            },
            error: function() {
            }
        });
    });

    ptclock();

    $(document).on('click','.cate_item', function () {
        var that = $(this);
        pt_jump(_APPNAME+'?id=xigua_pt&ac=cat&subid='+that.data('id')+'&catid='+that.data('pid')+(typeof _URLEXT!=='undefined'? _URLEXT : ''));
    });

    $(document).on('click','#dosearch', function () {
        if($('#searchInput').val()){
            $('#dosearchform').submit();
        }
    });
    $(document).on('click','#searchCancel', function () {
        pt_jump(_APPNAME + '?id=xigua_pt&ac=cate'+(typeof _URLEXT!=='undefined'? _URLEXT : ''));
    });

    $(document).on('click','.cancel_order', function () {
        var that = $(this);
        $.confirm(QDYX, function () {
            $.showLoading();
            $.ajax({
                type: "POST",
                url: _APPNAME+"?id=xigua_pt&ac=cancel_order&inajax=1&ordid="+that.data('id'),
                data:{formhash:FORMHASH},
                dataType: "xml",
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                }
            });
        }, function () {
        });
    });

    $(document).on('click','.tuan_profile', function () {
        var that = $(this), s = '';
        var text = $('#tuan_profile');
        $.ajax({
            type: "POST",
            url: _APPNAME+"?id=xigua_pt&ac=com&do=tuan_profile&inajax=1&tuan_id="+that.data('tuan_id'),
            async: false,
            dataType: "xml",
            success: function (data) {
                if(null==data){ return false;}
                s = data.lastChild.firstChild.nodeValue;
            }
        });
        text.find('.weui-cells').html(s);
        $.alert(text.html(), that.data('title'));
        ptclock();
    });

    $(document).on('click','.sxj', function () {
        var that = $(this);
        var gid = that.data('gid');
        $.modal({
            title: that.data('title'),
            text: that.data('text'),
            buttons: [
                { text: SHANGJIA, onClick: function(){
                        $.showLoading();
                        $.ajax({
                            type: "POST",
                            url: _APPNAME+"?id=xigua_pt&ac=com&do=sxj&stat=1&inajax=1&gid="+gid,
                            async: false,
                            dataType: "xml",
                            success: function (data) {
                                $.hideLoading();
                                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            }
                        });
                    } },
                { text: XIAJIA, onClick: function(){

                        $.showLoading();
                        $.ajax({
                            type: "POST",
                            url: _APPNAME+"?id=xigua_pt&ac=com&do=sxj&stat=3&inajax=1&gid="+gid,
                            async: false,
                            dataType: "xml",
                            success: function (data) {
                                $.hideLoading();
                                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            }
                        });

                    } },
                { text: QXQX, className: "default", onClick: function(){ console.log(3)} },
            ]
        });
    });

    $(document).on('click','.fahuo', function () {
        var that = $(this);

        $.prompt({
            title: that.data('title'),
            empty: false,
            onOK: function (input) {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_pt&ac=com&do=fahuo&inajax=1',
                    data:{formhash:FORMHASH, yundan_gs : input, yundan:$('#actfield').val(), ptlogid:that.data('id')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });

        $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="text" id="weui-prompt-input" placeholder="'+KDGS+'" />');
        setTimeout(function(){
            $('.weui-dialog__bd').after('<div class="dialog_custom"><div><input id="actfield" class="weui-input needsclick_input" type="text" placeholder="'+KDDH+'"></div></div>');
        }, 150);
        document.getElementById('weui-prompt-input').focus();
    });

    $(document).on('click','.qrsh', function () {
        var that = $(this);
        $.confirm(that.data('title'), function () {
            $.showLoading();
            $.ajax({
                type: 'post',
                url: _APPNAME+'?id=xigua_pt&ac=com&do=shouhuo&inajax=1',
                data:{formhash:FORMHASH,  ptlogid:that.data('id')},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }, function () {
        });
    });

    $(document).on('click','.tuan_more', function () {
        var that = $(this);
        var gid = that.data('gid');

        var text = $('#tuan_more');
        $.ajax({
            type: "POST",
            url: _APPNAME+"?id=xigua_pt&ac=com&do=tuans&inajax=1&gid="+gid,
            async: false,
            dataType: "xml",
            success: function (data) {
                if(null==data){ return false;}
                s = data.lastChild.firstChild.nodeValue;
            }
        });
        text.find('.weui-cells').html(s);
        $.alert(text.html(), that.data('title'));
        ptclock();
    });

    $(document).on('click','.commentto', function () {
        var that = $(this);
        PLZINPUT = HIKEFU;
        do_comment(0, that.data('uid'), LXKF, 1);
        $('#c_icon_'+that.data('id')).trigger('click');
        return false;
    });

    $(document).on('click', '#v_openLocation', function () {
        var that = $(this);
        if((HB_INWECHAT&&HS_MULTIUPLOAD)==1){
            wx.openLocation({
                latitude: that.data('lat'),
                longitude: that.data('lng'),
                name: that.data('name'),
                address: that.data('addr'),
                scale: 14,
                infoUrl:window.location.href
            });
        }else if(GOOGLE){
            window.location.href = _APPNAME+'?id=xigua_hs&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng');
        }else{
            window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
        }
        return false;
    });

    $(document).on('click','.use-btn', function () {
        var that = $(this);
        var _id = that.data('id');
        if(that.data('src')){
            $.alert("<img style='width:180px' src='"+that.data('src')+"' /><br>"+that.data('tip'), that.data('chushi'),function() {
            });
            return false;
        }
    });
});




var pt_toutiao_timeout;
function pt_noti_toutiao(text, duration, index) {
    if(!text){
        return ;
    }
    var $t = $('.noti');
    $t.html(text);

    clearTimeout(pt_toutiao_timeout);

    if(!$t.hasClass('noti_visible')) {
        $t.addClass('noti_visible');
    }

    pt_toutiao_timeout = setTimeout(function() {
        $t.removeClass('noti_visible').transitionEnd(function() {
            pt_noti_toutiao(PT_TOUTIAOS[index+1], duration, index+1);
        });
    }, duration);
}
if(typeof PT_TOUTIAOS !== 'undefined'){
    if(PT_TOUTIAOS){
        pt_noti_toutiao(PT_TOUTIAOS[0], 3000, 0);
    }
}