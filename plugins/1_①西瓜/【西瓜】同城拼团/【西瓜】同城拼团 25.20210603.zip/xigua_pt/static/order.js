
$(document).on('click','.dotuikuan', function () {
    var that = $(this);
    var ptlogid = that.data('ptlogid');
    console.log(ptlogid);
    $.prompt({
        title:qrtk_,
        text: qrtk_desc_,
        empty: false,
        onOK: function (input) {
            console.log(input);$.showLoading();
            $.ajax({
                type: 'post',
                url: _APPNAME+'?id=xigua_pt&ac=tuihuo&inajax=1',
                data: {'formhash':FORMHASH, 'input':input, 'ptlogid' : ptlogid},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if (null == data) {
                        tip_common('error|' + ERROR_TIP);
                        return false;
                    }
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {$.hideLoading();}
            });
        },
        onCancel: function () {
        }
    });
});

$(document).on('click','.canceltuikuan', function () {
    var that = $(this);
    var ptlogid = that.data('ptlogid');
    $.confirm(qrqxtk_, function () {$.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_pt&ac=tuihuo&do=backrefund&inajax=1',
            data: {'formhash':FORMHASH, 'ptlogid' : ptlogid},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) {
                    tip_common('error|' + ERROR_TIP);
                    return false;
                }
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {$.hideLoading();}
        });
    }, function () {});
});

$(document).on('click','.dotk', function () {
    var that = $(this);
    var redund = that.data('redund');
    $.showLoading();
    $.ajax({
        type: 'GET', url: _APPNAME+'?id=xigua_pt&ac=tuihuo&do=getrefund&inajax=1', data: {'refund_id':redund}, dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if (null == data) {tip_common('error|' + ERROR_TIP);return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $.modal({
                title:cltk_,
                text: s.split('|')[1],
                buttons: [
                    { text:tytk_, onClick: function(){$.showLoading();
                            $.ajax({
                                type: 'post',
                                url: _APPNAME+'?id=xigua_pt&ac=tuihuo&do=confirmtk&inajax=1',
                                data: {'formhash':FORMHASH, 'redund_id' : redund},
                                dataType: 'xml',
                                success: function (data) {
                                    $.hideLoading();
                                    if (null == data) {
                                        tip_common('error|' + ERROR_TIP);
                                        return false;
                                    }
                                    var s = data.lastChild.firstChild.nodeValue;
                                    tip_common(s);
                                },
                                error: function () {$.hideLoading();}
                            });
                        }},
                    { text:qx_, className: "default", onClick: function(){} },
                ]
            });
        },
        error: function () {$.hideLoading();}
    });
});