<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd">
    <form action="$SCRITPTNAME?id=xigua_pt&ac=add" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="form[id]" value="{$old_data[id]}" >
        <input type="hidden" name="st" value="{$_GET[st]}" >

    <div class="weui-cells__title">
        <!--{if $old_data}-->
        {lang xigua_pt:bjsp}{$old_data[title]}
        <!--{else}-->{lang xigua_pt:tjsp}
        <!--{/if}-->
    </div>
    <div class="weui-cells ">
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_pt:title}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[title]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:title}" value="{$old_data[title]}">
            </div>
        </div>
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_pt:spfl}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[hy]" id="hangye" type="text" value="$default_hy" placeholder="">
            </div>
            <div class="weui-cell__ft"></div>
        </div>

        <!--{if $sh}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_pt:sydp}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input choose_ctrl" name="form[shname]" type="text" value="{echo $old_data?$old_data['shname']:$dftshname}" placeholder="{lang xigua_pt:qxzsydp}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{/if}-->

        <!--{if $pt_config[diquxuanz]}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:sjdq}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[diqu]" id="diqu" type="text" value="{echo $old_data['district'] ? $old_data[province].' '.$old_data[city].' '.$old_data[district] :'';}" placeholder="{lang xigua_hs:qxzsjdq}">
            </div>
            <div class="weui-cell__ft" id="needdiqu"></div>
        </div>
        <!--{/if}-->

        <div class="weui-cell" style="display:none">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:spkc}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="tel" name="form[stock]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:spkc}" value="{$old_data[stock]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:jian}</div>
        </div>
        <!--{if $old_data}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:spxl}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="tel" name="form[sellnum]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:spxl}" value="{$old_data[sellnum]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:jian}</div>
        </div>
        <!--{/if}-->
        <div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__hd">
                <label for="" class="weui-label">{lang xigua_pt:psfs}</label>
            </div>
            <div class="weui-cell__bd">
                <select class="weui-select fee_type" name="form[fee_type]" onchange="load_fee_type();" >
                    <option value="1" <!--{if $old_data[fee_type]==1}-->selected<!--{/if}-->>{lang xigua_pt:kdfy}</option>
                    <option value="2" <!--{if $old_data[fee_type]==2}-->selected<!--{/if}-->>{lang xigua_pt:ddhx}</option>
                </select>
            </div>
        </div>
        <div class="weui-cell" id="yxq" <!--{if !$old_data || $old_data[fee_type]==1}-->style="display:none"<!--{/if}-->>
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_pt:syjz}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input time_ctrl" name="form[usetime]" type="text" placeholder="{lang xigua_pt:plzyxq}" value="{$old_data[usetime_u]}">
            </div>
        </div>
    </div>

    <a href="$SCRITPTNAME?id=xigua_hs&ac=add_area" class="weui-agree" id="yfmb">
        <b class="weui-agree__text main_color">{lang xigua_pt:szyfmb}</b>
    </a>


<div class="weui-cells__title">{lang xigua_pt:jgsz}</div>
    <div class="weui-cells ">
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:ptj}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[tprice]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:ptjd}" value="{$old_data[tprice]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:yuan}</div>
        </div>
        <!--{if $_G['cache']['plugin']['xigua_hk']}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:pricehk1}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[pricehk1]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:pricehk1}" value="{$old_data[pricehk1]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:yuan}</div>
        </div>
        <!--{/if}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:dmj}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[dprice]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:dmj}" value="{$old_data[dprice]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:yuan}</div>
        </div>
        <!--{if $_G['cache']['plugin']['xigua_hk']}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:pricehk2}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[pricehk2]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:pricehk2}" value="{$old_data[pricehk2]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:yuan}</div>
        </div>
        <!--{/if}-->

        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:scj}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[disprice]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:scj}" value="{$old_data[disprice]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:yuan}</div>
        </div>

        <div class="weui-cell weui-cell_switch">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_pt:yxtk}</label></div>
            <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_pt:yxtk_tip}</span></div>
            <div class="weui-cell__ft" style="height:32px">
                <input class="weui-switch" type="checkbox" name="form[allowrefund]" value="1" <!--{if $old_data[allowrefund]}-->checked<!--{/if}-->>
            </div>
        </div>
    </div>



    <div class="weui-cells__title">{lang xigua_pt:ptsz}</div>
    <div class="weui-cells ">
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:jrp}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[ptmin]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:jrpd}" value="{$old_data[ptmin]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:ren}</div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:ptsx}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[ptshixian]" placeholder="{lang xigua_pt:qtx}{lang xigua_pt:ptsx}" value="{$old_data[ptshixian]}">
            </div>
            <div class="well-cell__ft">{lang xigua_pt:xs}</div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:tzyh}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[youhui]" placeholder="{lang xigua_pt:tzyhed}" value="{$old_data[youhui]}">
            </div>
            <div class="weui-cell__ft">{lang xigua_pt:yuan}</div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:dcsx}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[danci]" placeholder="{lang xigua_pt:danci}" value="{$old_data[danci]}">
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_pt:zlsx}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[zong]" placeholder="{lang xigua_pt:zong}" value="{$old_data[zong]}">
            </div>
        </div>
    </div>

    <div class="weui-cells__title">{lang xigua_pt:jjxq}</div>
    <div class="weui-cells ">

        <div class="weui-cell weui-cell_access" onclick='$("#edit_jieshao").popup();'>
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_pt:jjxq}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" id="edit_jieshao_holder" value="{$old_data[jieshao]}" readonly placeholder="{lang xigua_pt:djspxq}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>

        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{lang xigua_pt:splbt}</p>
                        <div class="weui-uploader__info">{echo str_replace('n', $pt_config['maximg'], lang_pt('zuiduozhao',0))}
                        </div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-max="{$pt_config['maximg']}" data-maxtip="{echo str_replace('n', $pt_config['maximg'], lang_pt('zuiduozhao',0))}">
                            <!--{loop $old_data[album] $img}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/>
                                <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                            </li>
                            <!--{/loop}-->
                        </ul>
                        <div class="weui-uploader__input-box">
                            <!--{if HB_INWECHAT && $config[multiupload]}-->
                            <a class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--{if $svicerange}-->
        <div class="weui-cell" style="padding-bottom:6px;">
            <div class="weui-cell__bd">
                <div class="post-tags cl" id="post-typeid">
                    <!--{loop $svicerange $_rangk $_rangv}-->
                    <!--{eval list($_rangt, $_rangd) = explode("#", $_rangv);}-->
                    <a class="weui-btn weui-btn_mini weui-btn_default <!--{if in_array($_rangt, $old_data[srange_ary])}-->tag-on<!--{/if}-->" href="javascript:;" onclick="return setTypeid('{$_rangk}', this);">$_rangt</a>
                    <input name="form[tagid][{$_rangk}]" type="hidden" value="<!--{if in_array($_rangt, $old_data[srange_ary])}-->1<!--{else}-->0<!--{/if}-->">
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <!--{/if}-->
    </div>

    <div class="fix-bottom mt10" style="position:relative">
        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}"/>
        <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_hb:back}</a>
    </div>


        <div id="edit_jieshao" class="weui-popup__container" style="z-index:1000">
            <div class="weui-popup__modal bgf8">
                <div class="fixpopuper">
                    <div class="weui-cells__title">{lang xigua_pt:bjsp}</div>
                    <div class="weui-cells ">
                        <div class="weui-cell">
                            <div class="weui-cell__bd">
                        <textarea class="weui-textarea" name="form[jieshao]" id="jieshao" placeholder="{lang xigua_pt:txspxq}"
                                  rows="3">{$old_data[jieshao]}</textarea>
                            </div>
                        </div>
                    </div>

                    <div class="weui-cells before_none nobg center_upload">
                        <div class="weui-cell" id="first_append_img">
                            <div class="weui-cell__bd">
                                <div class="weui-uploader">
                                    <div class="weui-uploader__bd">
                                        <div class="weui-uploader__input-box">
                                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                            <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                            <!--{else}-->
                                            <input class="center_upload__input" data-name="form[append_img]" type="file">
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--{loop $old_data[append_text_ary] $__k $__v}-->
                        <div class="weui-cell bgf" id="arear_{$__k}">
                            <ul id="cimg_{$__k}" data-only="1">
                                <li class="weui-uploader__file weui-uploader__file_status"
                                    style="background-image:url({$old_data['append_img_ary'][$__k]})">
                                    <input type="hidden" name="form[append_img][{$__k}]"
                                           value="{$old_data['append_img_ary'][$__k]}">
                                    <div class="weui-uploader__file-content"><i
                                                class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                            </ul>
                            <div class="weui-cell__bd">
                        <textarea class="weui-textarea" placeholder="{lang xigua_pt:inputtext}" rows="3"
                                  name="form[append_text][{$__k}]">{$__v}</textarea>
                            </div>
                            <a class="iconfont icon-guanbijiantou closeHt" data-index="{$__k}"></a>
                        </div>
                        <div class="weui-cell" id="cell_{$__k}">
                            <div class="weui-cell__bd">
                                <div class="weui-uploader">
                                    <div class="weui-uploader__bd">
                                        <div class="weui-uploader__input-box">
                                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                            <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                            <!--{else}-->
                                            <input class="center_upload__input" data-name="form[append_img]" type="file">
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--{/loop}-->
                    </div>

                    <div class="fix-bottom" id="center_upload_btn" style="position:relative">
                        <a class="mt0 weui-btn weui-btn_default" onclick='return edit_finish();'
                           href="javascript:;">{lang xigua_pt:wcbj}</a>
                    </div>
                </div>
            </div>
        </div>

    </form>
</div>

<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>

<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div class="masker" onclick='$(".choose_ctrl").select("close")'></div>
<script> +function($){  $.rawCitiesData = $cityjson; }($);</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script>
var itar = [];
<!--{loop $sh $_sh}--><!--{if $_sh[name]}-->itar.push({title:'{$_sh[name]}'});<!--{/if}--><!--{/loop}-->
$(".choose_ctrl").select({
    title: "{lang xigua_pt:qxzsydp}",
    items: itar,
    onOpen:function () {
        $('.masker').fadeIn();
    },
    beforeClose:function () {
        $('.masker').fadeOut(300);
        return true;
    }
});
$("#hangye").cityPicker({
    title: "{lang xigua_pt:qxzspfl}",
    showDistrict: false,
    onChange: function (picker, values, displayValues) {
        console.log(values);
    }
});
function cropCallback(){
    $("#new_popup").popup();
    return false;
}
function edit_finish(){
    $.closePopup();
    $("#edit_jieshao_holder").val($('#jieshao').val());
    return cropCallback();
}
</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_pt:footer}-->
<!--{template xigua_pt:enter_up}-->

<!--{if $pt_config[diquxuanz]}-->
<!--{eval
$_key = 'hscityIdist'.intval($_GET['st']);
loadcache($_key);
$jsary1 = $_G['cache'][$_key]['variable'][1];
if(!json_encode($jsary1) || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000)) :
    $GLOBALS['nojson'] = 0;
    $dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
    $list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
    C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
    $jsary1 = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    foreach ($dist0 as $index => $item) :
        C::t('#xigua_hb#xigua_hb_district')->empty_child();
        $dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
    endforeach;
    savecache($_key, array('variable' => array($dist0, $jsary1), 'expiration' => TIMESTAMP));
endif;
$jsary1 = array_values($jsary1);
$pickercityjson = json_encode($jsary1);
$pickerdefault = diconv($jsary1[0]['name'].' '. $jsary1[0]['sub'][0]['name'].' '.$jsary1[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
}-->
<script> +function($){  $.rawCitiesData1 = $pickercityjson; }($); var DFTFIELD = '$pickerdefault';</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/picker.js?_{VERHASH}" charset="utf-8"></script>
<script>
    $("#diqu").cityPicker1({
        title: "{lang xigua_hs:qxzsjdq}",
        onChange: function (picker, values, displayValues) {
            console.log(displayValues);
            $('#needdiqu').html("<input type=\"hidden\" name=\"form[province]\" value=\""+displayValues[0]+"\">\n" +
                "<input type=\"hidden\" name=\"form[city]\" value=\""+displayValues[1]+"\">\n" +
                "<input type=\"hidden\" name=\"form[district]\" value=\""+displayValues[2]+"\">");
        }
    });
</script>
<!--{/if}-->