<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script src="source/plugin/xigua_pt/static/pt.js?{VERHASH}"></script>