<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->

    <!--{template xigua_pt:order_top}-->


<!--{if $v[goodshot]['fee_type']==1}-->
    <div class="weui-cells before_none after_none mt0">
        <a class="weui-cell weui-cell_access after_none" href="javascript:;" <!--{if $v[status]==1||$v[status]==5}-->id="pay_address"<!--{/if}--> >
        <div class="weui-cell__hd">
            <label class="weui-label mr8" style="width:auto"><i class="f22 c3 iconfont icon-mudedi vm"></i></label>
        </div>
        <div class="weui-cell__bd c3">
            <div class="f12 "><span class="f14">{$v[realname]}</span>&nbsp;{$v[mobile]}</div>
            <div class="f12 mt3">{$v[addr]}</div>
        </div>
        <!--{if $v[status]==1||$v[status]==5}-->
        <div class="weui-cell__ft"></div>
        <!--{/if}-->
        <div class="addrbx"></div>
        </a>
    </div>
<!--{elseif $v[goodshot]['fee_type']==2}-->
<!--{eval $sh = $v['sh'];}-->
    <div class="weui-cells f15 before_none after_none mt0">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <span class="main_color">{lang xigua_pt:gmhqdd} <!--{if $v[goodshot][usetime]}-->{lang xigua_pt:usetime} {echo date('Y-m-d H:i:s', $v[goodshot][usetime])}<!--{/if}--></span>
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="{$sh[logo]}"></a></div>
            <div class="weui-cell__bd">
                <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
                <p class="f13 c9">{lang xigua_pt:yysj}: <em>{$sh[opentime]}</em></p>
            </div>
            <div class="weui-cell__ft">
                <a href="javascript:;" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_pt:smj}", "{lang xigua_pt:wxzca}");'><i class="iconfont icon-sixin2 mr15 main_color f24"></i></a>
                <a class="shtel" <!--{if $sh[teljs]}-->$sh[teljs]<!--{else}-->href="tel:{$sh[tel]}"<!--{/if}-->><i class="iconfont icon-unie607 main_color f24"></i></a>
            </div>
        </div>

        <a class="weui-cell weui-cell_access" href="javascript:;" id="v_openLocation" data-lat="{$sh[lat]}" data-lng="{$sh[lng]}" data-name="{$sh[name]}" data-addr="{$sh[addr]}">
            <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
            <div class="weui-cell__bd">
                <p class="f14">{$sh[addr]}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
    </div>
<!--{/if}-->

    <div class="pt_order_li mt10">
        <div class="pt_shlink">
            <a class="sh_jump" data-id="{$v['shid']}"> <img class="confirm_shlogo" src="{$v['sh'][logo]}"/>
                <span class="f13">{$v['sh'][name]}</span> <i class="f13 iconfont icon-jinrujiantou"></i> </a>
        </div>
        <div class="jump_pt weui-cell weui-cell_access before_none after_none" style="display:block;overflow:hidden" data-id="$v[gid]">
            <div class="weui-cell__hd z">
                <label class="weui-label " style="width:95px">
                    <img style="width: 80px;height: 80px;" src="{echo $v[goodshot][album][0] ? $v[goodshot][album][0] : $v[goodshot][append_img_ary][0]}"/>
                </label>
            </div>
            <div class="weui-cell__bd ">
                <p class="f14 c3">{$v[goodshot][title]}</p>
                <!--{eval $price_name = explode('###', $v[priceshot]['name'])}-->
                <!--{loop $v[goodshot][spgg_ary] $_spk $_spn}-->
                <p class="f12 c9">{$_spn[name]}: {$price_name[$_spk]}</p>
                <!--{/loop}-->
                <div class="f14 cl">&yen;{$v[unit_price]} / {lang xigua_pt:j} <span class="y">x {$v[gnum]}</span></div>
            </div>
        </div>
        <div class="pt_func  weui-cell">
            <div class="weui-cell__bd f12">
                {lang xigua_pt:sfk}:
                <em class="ptcolor">&yen;{$v[pay_money]}</em> (<!--{if $v[yunfee]>0}--> {lang xigua_pt:yf}: {$v[yunfee]} {lang xigua_pt:yuan}<!--{else}--> {lang xigua_pt:myf}<!--{/if}--> )
            </div>
            <div class="weui-cell__ft">

                <!--{template xigua_pt:order_status}-->
            </div>
        </div>
    </div>

    <!--{template xigua_pt:viewtools}-->

    <!--{if $_GET['manage'] && $_GET['code']}-->
    <div class="fix-bottom" style="position: relative;box-shadow:none">
        <!--{if $v[hxcrts]>0}-->
        <a href="javascript:;" class="weui-btn weui-btn_default">{lang xigua_pt:hxcg}</a>
        <!--{elseif $v[status]==2 || $v[status]==6}-->
        <a href="javascript:;" class="weui-btn weui-btn_primary upscan">{lang xigua_pt:djhx}</a>
        <!--{/if}-->
    </div>
    <!--{/if}-->

    <!--{template xigua_pt:ptuserlist}-->


    <div class="weui-cells before_none after_none">

        <div class="weui-cell before_none after_none">

            <div class="weui-cell__hd f14">
                {lang xigua_pt:gmyh} :
            </div>
            <div class="weui-cell__bd f14">
                <img src="{avatar($v[uid], middle, true)}" class="pt_usr" style="width:24px;height:24px;margin-left:10px" > $v['username']
            </div>
        </div>
        <div class="weui-cell before_none after_none">

            <div class="weui-cell__hd f14">
                {lang xigua_hb:bind_mobile} :
            </div>
            <div class="weui-cell__bd f14">
                <!--{eval
                $mobile = $v['mobile'];
                if(!$mobile):
                    $__profile = C::t('#xigua_hb#xigua_hb_user')->fetch($v['uid']);
                    $mobile = $__profile['mobile'];
                endif;
                if(!$mobile):
                    $__profile = C::t('common_member_profile')->fetch($v['uid']);
                    $mobile = $__profile['mobile'];
                endif;
                }-->{$mobile}
            </div>
        </div>
        <!--{if $v['note']}-->
        <div class="weui-cell before_none after_none">

            <div class="weui-cell__hd f14">
                {lang xigua_pt:bz} :
            </div>
            <div class="weui-cell__bd f14">
                $v['note']
            </div>
        </div>
        <!--{/if}-->

        <div class="weui-cell before_none after_none">

            <div class="weui-cell__hd f14">
                {lang xigua_pt:ddbh} :
            </div>
            <div class="weui-cell__bd f14">
                $v['order_id']
            </div>
        </div>

        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_pt:xdsj} :
            </div>
            <div class="weui-cell__bd f14">
                $v['crts_u']
            </div>
        </div>
        <!--{if $v['pay_ts_u']}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_pt:zfsj_} :
            </div>
            <div class="weui-cell__bd f14">
                $v['pay_ts_u']
            </div>
        </div>
        <!--{/if}-->
        <!--{if $v['tuicfm_ts_u']}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_pt:tksj} :
            </div>
            <div class="weui-cell__bd f14">
                $v['tuicfm_ts_u']
            </div>
        </div>
        <!--{/if}-->
    </div>

</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_pt:footer}-->
<script>
ptclock();
setTimeout(function(){
    ptclock();
}, 1000);
<!--{if $_GET['code'] && $v[hxcrts]>0}-->
$.alert('{lang xigua_pt:hxerror}');
<!--{/if}-->
$(document).on('click','.upscan', function () {
    $.showLoading();
    $.ajax({
        type: "POST",
        url: _APPNAME+"?id=xigua_pt&ac=com&do=upscan&inajax=1&code={$_GET['code']}&ptlog_id={$v[id]}",
        data:{formhash:FORMHASH},
        dataType: "xml",
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {
            $.hideLoading();
        }
    });
});
</script>
<script src="source/plugin/xigua_pt/static/order.js?{VERHASH}"></script>