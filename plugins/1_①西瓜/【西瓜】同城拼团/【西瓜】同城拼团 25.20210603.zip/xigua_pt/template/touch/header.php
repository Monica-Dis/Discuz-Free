<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_hb:common_header}-->
<!--{eval $config[showguide]=1;}-->
<link rel="stylesheet" href="source/plugin/xigua_pt/static/pt.css?{VERHASH}" />
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}.swipe-wrap img{max-height:80vh}</style>
<script>var YIXUAN = '{lang xigua_pt:yx}', KCBZ='{lang xigua_pt:kcbz}', KC1='{lang xigua_pt:kc1}', SHY='{lang xigua_pt:shy}', QXQX='{lang xigua_pt:qx}',CYPT = '{lang xigua_pt:cypt}',QDYX = '{lang xigua_pt:qdyx}' ,SHANGJIA = '{lang xigua_pt:s}' ,XIAJIA = '{lang xigua_pt:x}' ,KDGS = '{lang xigua_pt:kdgs}' ,KDDH = '{lang xigua_pt:kddh}' ,HIKEFU = '{lang xigua_pt:hikefu}' ,LXKF = '{lang xigua_pt:lxkf}',ALLOWSELF={eval echo intval($pt_config[allowself]);}, BTXZJCT = '{lang xigua_pt:btxzjct}';
var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
var GOOGLE = "{$_G['cache']['plugin']['xigua_hs']['google']}", PUB_VARID = 0, IGNORETIP = 0;
var qrtk_ = '{lang xigua_pt:qrtk}', qrtk_desc_ = '{lang xigua_pt:qrtk_desc}', qrqxtk_ = '{lang xigua_pt:qrqxtk}', qx_ = '{lang xigua_pt:qx}', cltk_ = '{lang xigua_pt:cltk}', tytk_ = '{lang xigua_pt:tytk}';
</script>