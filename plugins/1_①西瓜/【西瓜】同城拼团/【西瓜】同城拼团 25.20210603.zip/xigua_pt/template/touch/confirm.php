<?php exit('Author: https://dism.taobao.com/?@xigua 西瓜先生 客服QQ 1628585958 微信wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<div class="page__bd">
<form  action="$SCRITPTNAME?id=xigua_pt&ac=buy&st={$_GET['st']}" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <!--{loop $_GET $gk $gv}-->
    <input type="hidden" name="form[$gk]" value="{$gv}">
    <!--{/loop}-->
<!--{if $v['fee_type']==1}-->
    <div class="weui-cells before_none after_none mt0">
        <a class="weui-cell weui-cell_access after_none" href="javascript:;" id="pay_address">
            <div class="weui-cell__hd">
                <label class="weui-label mr8" style="width:auto"><i class="f22 c3 iconfont icon-mudedi vm"></i></label>
            </div>
            <div class="weui-cell__bd c3">
                <!--{if $dft[mobile]}-->
                <div class="f12 "><span class="f14">{$dft[realname]}</span>&nbsp;{$dft[mobile]}</div>
                <div class="f12 mt3">{$dft[dist1]}&nbsp;{$dft[dist2]}&nbsp;{$dft[dist3]}&nbsp;{$dft[address]}</div>
                <input type="hidden" name="form[dist1]" value="$dft[dist1]">
                <input type="hidden" name="form[dist2]" value="$dft[dist2]">
                <input type="hidden" name="form[dist3]" value="$dft[dist3]">
                <input type="hidden" name="form[address]" value="$dft[address]">
                <input type="hidden" name="form[realname]" value="$dft[realname]">
                <input type="hidden" name="form[mobile]" value="$dft[mobile]">
                <input type="hidden" name="form[addrid]" value="$addr[id]">
                <!--{else}-->
                <div class="f14">{lang xigua_pt:djszshdz}</div>
                <!--{/if}-->
            </div>
            <div class="weui-cell__ft">
            </div>
            <div class="addrbx"></div>
        </a>
    </div>
<!--{elseif $v['fee_type']==2}-->
<div class="weui-cells f15 before_none after_none mt0">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <span class="main_color">{lang xigua_pt:gmhqdd}</span>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="{$sh[logo]}"></a></div>
                <div class="weui-cell__bd">
                    <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
                    <p class="f13 c9">{lang xigua_pt:yysj}: <em>{$sh[opentime]}</em></p>
                </div>
                <div class="weui-cell__ft">
                    <a href="javascript:;" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_pt:smj}", "{lang xigua_pt:wxzca}");'><i class="iconfont icon-sixin2 mr15 main_color f24"></i></a>
                    <a class="shtel" <!--{if $sh[teljs]}-->$sh[teljs]<!--{else}-->href="tel:{$sh[tel]}"<!--{/if}-->><i class="iconfont icon-unie607 main_color f24"></i></a>
                </div>
            </div>

            <a class="weui-cell weui-cell_access" href="javascript:;" id="v_openLocation" data-lat="{$sh[lat]}" data-lng="{$sh[lng]}" data-name="{$sh[name]}" data-addr="{$sh[addr]}">
                <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{$sh[addr]}</p>
                </div>
                <div class="weui-cell__ft"></div>
            </a>

        </div>
<!--{/if}-->

    <div class="weui-cells before_none after_none ">
        <div class="weui-cell weui-cell_access after_none" style="display:block;overflow:hidden">
            <div class="mb8">
                <img class="confirm_shlogo" src="$sh[logo]" />
                <span class="f12">$sh[name]</span>
            </div>
            <div class="weui-cell__hd z">
                <label class="weui-label " style="width:95px">
                    <img style="width: 80px;height: 80px;" src="{$v[album][0]}" />
                </label>
            </div>
            <div class="weui-cell__bd ">
                <p class="f14 c3">{$v[title]}</p>
                <!--{loop $v[spgg_ary] $_spk $_spn}-->
                <p class="f12 c9">{$_spn[name]}: {$v['price_name'][$_spk]}</p>
                <!--{/loop}-->
                <p class="f14">&yen;{$good_price[price_pt]} / {lang xigua_pt:j}</p>
            </div>
        </div>



        <div class="weui-cell " >
            <div class="weui-cell__bd">
                <p class="f14">{lang xigua_pt:sl}</p>
            </div>
            <div class="weui-cell__ft main_color">
                <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                <input class="inc-input" type="tel" name="form[item_num]" id="item_num" value="{$_GET['num']}" data-max="{$v[danci]}" readonly="readonly">
                <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
            </div>
        </div>

        <div class="weui-cell ">
            <div class="weui-cell__hd"><label class="weui-label f14">{lang xigua_pt:bz}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input f14" name="form[item_note]" id="item_note" type="text" placeholder="{lang xigua_pt:xt}" value="{echo diconv($_GET['note'], 'utf-8', CHARSET);}">
            </div>
        </div>

    </div>
    <!--{if $v[youhui]>0}-->
    <label id="weuiAgree" class="weui-agree tr">
        <span class="weui-agree__text ptcolor ">{lang xigua_pt:ktlj}{$v[youhui]}{lang xigua_pt:yuan}</span>
    </label>
    <!--{/if}-->



    <div class="footer_fix"></div>
    <div class="fix-bottom" style="padding:0">

        <div class="confirm_foot">
            <div class="confirm_foot_d">
                <em>{lang xigua_pt:sfk}:</em>
                <span class="price">&yen;<a id="price_last">{$price_last}</a>  </span>
                <em class="ptcolor f12">
                    <!--{if $yf>0}-->{lang xigua_pt:yf}: $yf {lang xigua_pt:yuan}<!--{else}-->{lang xigua_pt:myf}<!--{/if}-->
                </em>
            </div>
            <input class="confirm_foot_btn" value="{lang xigua_pt:ljzf}" id="dosubmit" name="dosubmit" type="submit">
        </div>

    </div>
</form>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_pt:footer}-->

<script>

/*$(function () {
    if (window.history && window.history.pushState) {
        $(window).on('popstate', function () {
            window.history.pushState('forward', null, window.location.href);
            window.history.forward(1);

            $.modal({
                title: "{lang xigua_pt:qrfq}",
                text: "{lang xigua_pt:hyyb}",
                buttons: [
                    { text: "{lang xigua_pt:wzxx}", className: "ptcolor",onClick: function(){ console.log(1)} },
                    { text: "{lang xigua_pt:qyyj}", className: "default", onClick: function(){
                            window.location.href = "$rf";
                        } }
                ]
            });
        });
        window.history.pushState('forward', null,  window.location.href);
    }
});*/

function incNum(){
    var ipt = $('.inc-input');
    console.log(ipt.val());

    $.ajax({
        type: 'GET',
        url: _APPNAME + '?id=xigua_pt&ac=shisuan&num='+ipt.val()+'&price={$good_price[price_pt]}&yf=$yf&youhui={$v[youhui]}&inajax=1'+_URLEXT,
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            console.log(s);
            if(s){
                $('#price_last').html(s);
            }
        },
        error: function () {
            $.hideLoading();
        }
    });
}


</script>