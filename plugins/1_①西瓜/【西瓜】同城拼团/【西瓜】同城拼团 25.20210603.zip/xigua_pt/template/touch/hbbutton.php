<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{eval

if($_G['cache']['plugin']['xigua_hh']):
    if(in_array('common_pt', unserialize($_G['cache']['plugin']['xigua_hh']['openmodule']))):
        $hu = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
        if(!$hu['end'] && $hu['display']):
            $hhrname = $hu[joininfo][name];
            $hhrpercent = $hu[joininfo][percentage];
        endif;
    endif;
endif;
$hbword = lang_pt('haibao',0) ."<em class='iconfont icon-jinrujiantou f12'></em>";
if($v[custom_ticheng]>0 && $hhrname):
    $v[custom_ticheng] = floatval($v[custom_ticheng]);
    $hbword = "<em class='iconfont icon-shouru f13'></em> ".lang_pt('zhuan',0).$v[custom_ticheng].lang_pt('yuan',0)."<em class='iconfont icon-jinrujiantou f12'></em>";
    $bword = "<div style='margin-bottom:10px;font-size:12px'>".lang_pt("fxcgz", 0)."<em class=main_color>".$v[custom_ticheng].lang_pt("yuan", 0)."</em></div>";
endif;
}-->
<!--{if 0}-->
    <a href="javascript:;" class="hbzd" onclick="return mag_share();" data-url="{$_G[siteurl]}$SCRITPTNAME?id=xigua_pt:qrcode&gid=$gid&tuan_id=$mytuan_id">$hbword</a>
<!--{else}-->
    <a href="javascript:;" class="hbzd" onclick="return pt_newewm();">$hbword</a>
<!--{/if}-->
<script>
    function pt_newewm(){
        $.showLoading();
        html2canvas(document.querySelector(".shot_in")).then(canvas => {
            var dataURL = canvas.toDataURL();
            COMCLAS = 'shot_outer';
            $.hideLoading();
            $.alert("<img src='" + dataURL + "' />  <!--{if $bword}-->{$bword}<!--{elseif $hhrname}--><div style='margin-bottom:10px'><p class='f12'>{lang xigua_pt:hhrdj} : <em class=main_color>$hhrname</em></p><p class='f12'>{lang xigua_pt:bl} : <em class=main_color>{$hhrpercent}</em></p></div><!--{/if}-->", '{lang xigua_pt:fxqg}');
            $('.weui-dialog__title').css('font-size', '14px');
            COMCLAS = '';
        });
        return false;
    }
    <!--{if 0}-->
    function mag_share(){
        $.showLoading();
        html2canvas(document.querySelector(".shot_in")).then(canvas => {
            var dataURL = canvas.toDataURL();
            COMCLAS = 'shot_outer';
            hpp_doupload(dataURL);
            COMCLAS = '';
        });
        return false;
    }
    function hpp_doupload(cmp_photo){
        var img = cmp_photo.split(',')[1];
        img = window.atob(img);
        var ia = new Uint8Array(img.length);
        for (var i = 0; i < img.length; i++) {
            ia[i] = img.charCodeAt(i);
        }
        var blob = new Blob([ia], {type:"image/jpeg"});
        var formdata=new FormData();
        formdata.append('file',blob);

        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_hb&ac=uploader&inajax=1&formhash='+FORMHASH,
            data :  formdata,
            processData : false,
            contentType : false,
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    var SHAREIMG = s.split('|')[1];
                    mag.setData({shareData: {
                            type: 1, imageurl:SHAREIMG, picurl:  SHAREIMG
                        }});
                    mag.share('ALL', function(res){},function(){ });
                } else {
                    tip_common(s);
                }
            }
        });
    }
<!--{/if}-->
</script>