<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $v[buy_type]==2}-->
<!--{eval $le = $v[goodshot][ptmin] - count($ptuserlist);}-->
<div class="weui-cells before_none after_none">
    <div class="weui-cell before_none after_none">
        <div class="weui-cell__bd" style="display: -webkit-flex; -webkit-justify-content: center; -webkit-align-items: center;">
            <!--{if $v[status]==5}-->
            <p class="f14">{lang xigua_pt:dfx},
                <span>{lang xigua_pt:hc}<em class="ptcolor">{$le}{lang xigua_pt:r}</em>{lang xigua_pt:pc}</span>
                <span class="hmt" data-start="{$ptuserlist[0][pay_ts_u]}" data-end="{$ptuserlist[0]['shixian_u']}">{lang xigua_pt:shy}<span class="timer"></span></span>
            </p>
            <!--{elseif $v[status]==6}-->
            <p class="f16">
                <span class="ptcolor">{lang xigua_pt:ptcg}</span>
            </p>
            <!--{elseif $v[status]==7}-->
            <div class="f16" style="width:100%;">
                <div>{lang xigua_pt:pdsbytk} <span class="f12 c9">{lang xigua_pt:iferr}</span></div>
                <div class="main_color f12">$v[refund2]</div>
            </div>
            <!--{/if}-->
        </div>
    </div>

    <div class="weui-cell before_none after_none">
        <div class="weui-cell__bd" <!--{if $ac!='order_profile'}-->style="display: -webkit-flex; -webkit-justify-content: center; -webkit-align-items: center;margin-top: -12px;"<!--{/if}-->>
            <div class="share_list cl">
                <!--{loop $ptuserlist $loopk $loopin}-->
                <div class="z">
                    <img class="share_tz" src="{avatar($loopin['uid'], 'small', 1)}"/> <!--{if !$loopin[tuan_id]}--><em>{lang xigua_pt:tz}</em><!--{/if}-->
                </div>
                <!--{/loop}-->
                <!--{eval for($i = 0; $i <$le; $i++):}-->
                <div class="z"> <img src="source/plugin/xigua_pt/static/empty.png"/> </div>
                <!--{eval endfor;}-->
            </div>
        </div>

<!--{if $ac=='order_profile'}-->
        <!--{if $v[status]==5}-->
        <div class="weui-cell__ft ">
            <a class="ptbtn " href="$SCRITPTNAME?id=xigua_pt&ac=invite&ptlog_id=$v[id]{$urlext}">{lang xigua_pt:yqhy}</a>
        </div>
        <!--{elseif $v[status]==6}-->
    <div class="weui-cell__ft ">
        <a class="ptbtn tuan_profile" data-tuan_id="$tuan_id" data-title="{lang xigua_pt:ptxx}" href="javascript:;">{lang xigua_pt:ckxq}</a>
    </div>
        <!--{/if}-->
<!--{/if}-->

    </div>
<div id="tuan_profile" style="display:none"><div class="weui-cells before_none after_none mt0"></div></div>
<!--{if $ac!='order_profile'}-->
    <!--{if $v[status]==5}-->
        <!--{if $joinmode}-->
        <div class="fix-bottom" style="position: relative;box-shadow:none">
            <a href="$SCRITPTNAME?id=xigua_pt&ac=view&gid=$v[gid]&tuan_id=$tuan_id" class="weui-btn weui-btn_primary ">{lang xigua_pt:wycypt}</a>
        </div>
        <!--{else}-->
        <div class="fix-bottom" style="position: relative;box-shadow:none">
            <a  class="weui-btn weui-btn_primary we_share">{lang xigua_pt:djyqhypt}</a>
        </div>
        <!--{/if}-->
    <!--{else}-->
        <div class="fix-bottom" style="position: relative;box-shadow:none">
            <a href="$SCRITPTNAME?id=xigua_pt&ac=view&gid=$v[gid]" class="weui-btn weui-btn_primary ">{lang xigua_pt:zcgm}</a>
        </div>
    <!--{/if}-->
<!--{/if}-->


    <a href="$SCRITPTNAME?id=xigua_pt&ac=help{$urlext}" class="weui-cell weui-cell_access after_none">
        <div class="weui-cell__bd f14">
            {lang xigua_pt:ptgz}
        </div>
        <div class="weui-cell__ft f14">
            {lang xigua_pt:ptgzd}
        </div>
    </a>

</div>
<!--{/if}-->