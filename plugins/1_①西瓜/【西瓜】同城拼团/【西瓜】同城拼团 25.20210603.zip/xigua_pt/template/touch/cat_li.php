<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $_GET[from]=='index' && $pt_config[indexstyle]==1}-->
<!--{loop $list $v}-->
<div class="row_list">
<div class="item">
    <a class="jump_pt" href="javascript:;" data-id="{$v[id]}">
        <div class="cover bg_stamp">
            <img class="ll_fadeIn" src="{echo $v[album][0] ? $v[album][0] : $v[append_img_ary][0]}">
            <!--{if $pt_config[showover] && DB::result_first('SELECT sum(stock) FROM %t WHERE gid=%d', array('xigua_pt_good_price', $v[id]))<=0}-->
            <div class="sellout"></div>
            <img src="source/plugin/xigua_pt/static/shouqing.png?{VERHASH}" class="sellout_img">
            <!--{/if}-->
            <div class="stamp bg_red">{$v[ptmin]}{lang xigua_pt:rp}</div>
            <!--{if $v['distance']}-->
            <div class="stamp " style="right: 0;left: auto;background: rgba(0,0,0,.6);border-radius: 0!important;">$v['distance']</div>
            <!--{/if}-->
        </div>
        <div class="info">
            <div class="name">{$v[title]}</div>
            <div class="tags">
                <!--{loop $v[srange_ary] $_v}-->
                <span>{eval $rv= explode('#', $_v);echo $rv[0];}</span>
                <!--{/loop}-->
            </div>
            <div class="price">
                <span>&yen;<em class="f16">{$v[tprice]}</em></span>
                <del class="c9">&yen;{$v[disprice]}</del>
            </div>
            <div class="desc">{lang xigua_pt:yp}{$v[sellnum]}{lang xigua_pt:j}</div>
            <div class="btn"><!--{if $v[ptmin]==1}-->{lang xigua_pt:qgm}<!--{else}-->{lang xigua_pt:qpd}<!--{/if}--></div>
        </div>
    </a>
</div>
</div>
<!--{/loop}-->
<!--{else}-->
<!--{loop $list $v}-->
<li>
    <div class="jump_pt" data-id="{$v[id]}">
        <div class="">
            <div class="goodimg">
                <img src="{echo $v[album][0] ? $v[album][0] : $v[append_img_ary][0]}" class="">
                <!--{if $pt_config[showover] && DB::result_first('SELECT sum(stock) FROM %t WHERE gid=%d', array('xigua_pt_good_price', $v[id]))<=0}-->
                <div class="sellout"></div>
                <img src="source/plugin/xigua_pt/static/shouqing.png?{VERHASH}" class="sellout_img">
                <!--{/if}-->
            </div>
            <div class="p57">
                <p class="goodtit f12">
                    {$v[title]}
                </p>

                <!--<div class="goodflex">
                    <span class="del_price f10">&yen;25.00</span>
                    <div class="seckill_logs">
                        <div> <img src=""> </div>
                        <div> <img src=""> </div>
                    </div>
                </div>-->

                <div class="goodflex">
                    <span class="stamp_three stamp_mini">{$v[ptmin]}{lang xigua_pt:rp}</span>
                    <span class="main_color f16" style="flex:1"><em class="f10">&yen;</em>{$v[tprice]}</span>
                    <span class="f12 gray">{lang xigua_pt:yp}{$v[sellnum]}{lang xigua_pt:j}</span>
                </div>
            </div>
        </div>
    </div>
</li>
<!--{/loop}-->
<!--{/if}-->