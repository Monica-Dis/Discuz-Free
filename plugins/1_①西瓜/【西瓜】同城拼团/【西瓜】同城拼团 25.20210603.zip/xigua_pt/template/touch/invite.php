<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<!--{if $pt_config[yqimg]}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$pt_config[yqimg]" /></div><!--{/if}-->
<div style="width:0px;height:0px;overflow:hidden;display:none"><img src="{echo $good[album][0] ? $good[album][0] : $good[append_img_ary][0]}" /></div>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="pt_order_li">
        <div class="pt_shlink">
            <a class="sh_jump" data-id="{$v['shid']}"> <img class="confirm_shlogo" src="{$v['sh'][logo]}"/>
                <span class="f13">{$v['sh'][name]}</span> <i class="f13 iconfont icon-jinrujiantou"></i> </a>
        </div>
        <div class="jump_pt weui-cell weui-cell_access before_none after_none" style="display:block;overflow:hidden" data-id="$v[gid]">
            <div class="weui-cell__hd z">
                <label class="weui-label " style="width:95px">
                    <img style="width: 80px;height: 80px;" src="{echo $good[album][0] ? $good[album][0] : $good[append_img_ary][0]}"/>
                </label>
            </div>
            <div class="weui-cell__bd ">
                <p class="f14 c3">{$good[title]}</p>

                <div class="weui-flex">
                    <div class="weui-flex__item" style="position: relative">
                        <span class="tprice"><em class="f12">&yen;</em>$good[price_pt]</span>
                        <span class="c9 f12"><s><em class="f12">&yen;</em>$good[price_sc_max]</s></span>
                        <span class="tnums f12">{lang xigua_pt:yp}{$good[sellnum]}{lang xigua_pt:j}</span>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <!--{template xigua_pt:viewtools}-->
    <!--{template xigua_pt:ptuserlist}-->

    <div class="tuan_recommend">
        <div class="tuan_recommend_title"><span class="tuan_recommend_title_text">{lang xigua_pt:wntj}</span></div>

        <div class="weui-cells fixbanner before_none mt0">

            <div class="weui-navbar weui-banner nobg fixbanner_in">
                <a href="$SCRITPTNAME?id=xigua_pt&mobile=2" class="weui-navbar__item weui_bar__item_on ">
                    <span>{lang xigua_pt:tj}</span>
                </a>

                <!--{loop $cat_list $cat}-->
                <a href="$SCRITPTNAME?id=xigua_pt&ac=cat&catid={$cat[id]}" class="weui-navbar__item ">
                    <span>$cat[name]</span>
                </a>
                <!--{/loop}-->
            </div>

        </div>
        <ul class="goodlist mt0" id="list" style="padding-top:0"> </ul>
    </div>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_pt:footer}-->
<script>
    var loadingurl = window.location.href+'&ac=cat_li&inajax=1&page=';
    ptclock();
    setTimeout(function(){
        ptclock();
    }, 1000);
</script>