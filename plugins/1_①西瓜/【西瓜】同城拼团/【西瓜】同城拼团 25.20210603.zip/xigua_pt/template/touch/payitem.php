<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<div id="popup_item" class="weui-popup__container popup-bottom" style="z-index:1001">
    <div class="weui-popup__overlay"></div>



    <div class="weui-popup__modal" style="overflow: inherit;overflow-y: inherit;">

        <a href="javascript:;" class="picker-button close-popup close-pay"><i class="iconfont icon-guanbijiantou"></i></a>


        <div class="cl bgf">

            <div class="buy-item"> <img src="{$v[album][0]}"> </div>
            <div class="buy-title">
                <div class="tprice2 pt8"><em class="f12">&yen;</em><em id="pricePt">{$v[price_pt]}</em><em id="priceDm" style="display:none;">{$v[price_dm]}</em></div>
                <div class=" f12" id="spggname">{lang xigua_pt:qxz} <!--{loop $v[spgg_ary] $_spn}--> {$_spn[name]} <!--{/loop}--></div>
            </div>

        </div>

        <div class="modal-content" style="padding-top: 0">
<form  action="$SCRITPTNAME?id=xigua_pt&ac=confirm&st={$_GET['st']}" method="post" id="form">
<input name="formhash" value="{FORMHASH}" type="hidden">
<input name="gid" value="{$gid}" type="hidden">
<input name="confrm" value="confrm" type="hidden">
<input name="form[type]" value="pt" type="hidden">
<input name="form[price_id]" id="price_id" value="0" type="hidden">
<input name="form[buy_type]" id="buy_type" value="1" type="hidden">
<input name="form[tuan_id]" id="tuan_id" value="0" type="hidden">
            <div class="weui-cells before_none after_none" style="padding-bottom: 10px;max-height: 72vh;overflow-y:auto">
                <!--{eval $spcount = 0;}-->
                <!--{loop $v[spgg_ary] $_spk $_spn}-->
                <div class="weui-cell ">
                    <div class="weui-cell__bd">
                        <p class="f14 c3 mb5">{$_spn[name]}</p>
                        <div class="post-tags buy-tags cl">
                            <!--{loop $_spn[ggtext] $_ggk $_ggt}-->
                            <a class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;" onclick="return setSpgg('$_ggt', this);">$_ggt</a>
                            <input class="gginput" name="form[tagid][$_ggt]" type="hidden" value="0">
                            <!--{eval $spcount++;}-->
                            <!--{/loop}-->
                        </div>
                    </div>
                </div>
                <!--{/loop}-->

                <div class="weui-cell " >
                    <div class="weui-cell__bd">
                        <p class="f14">{lang xigua_pt:sl}</p>
                    </div>
                    <div class="weui-cell__ft main_color">
                        <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                        <input class="inc-input" type="tel" name="form[item_num]" id="item_num" value="1" data-max="{$v[danci]}" readonly="readonly">
                        <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
                    </div>
                </div>

                <div class="weui-cell ">
                    <div class="weui-cell__hd"><label class="weui-label f14">{lang xigua_pt:bz}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input f14" name="form[item_note]" id="item_note" type="text" placeholder="{lang xigua_pt:xt}">
                    </div>
                </div>

                <!--{if $v[youhui]>0}-->
                <label id="weuiAgree" class="weui-agree tr">
                    <span class="weui-agree__text ptcolor ">{lang xigua_pt:ktlj}{$v[youhui]}{lang xigua_pt:yuan}</span>
                </label>
                <!--{/if}-->
            </div>
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary br0" value="{lang xigua_hb:queding}" />
</form>
        </div>
    </div>
</div>
<!--{if $v[price_list]}-->
<script>var PRICE_LIST = {eval echo json_encode($v[price_list])};</script>
<!--{else}-->
<script>var PRICE_LIST = [];</script>
<!--{/if}-->