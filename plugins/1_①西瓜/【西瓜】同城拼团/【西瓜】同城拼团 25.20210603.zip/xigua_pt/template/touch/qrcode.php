<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<script src="source/plugin/xigua_pt/static/html2canvas.min.js"></script>
<!--{template xigua_pt:hbbutton}-->
<!--{eval $shot_img = $v[album][0]?$v[album][0]:$v[append_img_ary][0];}-->
<!--{eval
$shot_file = 'source/plugin/xigua_pt/cache/'.md5($shot_img).'.png';
if(strpos($shot_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$shot_file)):
        file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
    endif;
    $shot_img = $shot_file;
endif;
}-->
<div id="shot" style="position:absolute;top:-100000px">
    <div class="shot_in" style="width:100vw;">
        <div class="qr_pr">
            <img src="{$shot_img}" crossOrigin="anonymous" class="qr_img_src" style="width:100%;max-width:100vw"/>
        </div>
        <div class="cl bgf">
            <!--{if $config[qraut]}-->
            <img src="$SCRITPTNAME?id=xigua_hb:qrauto&ode=pt_{$gid}__{$mytuan_id}{$urlext}" class="z" style="width:5rem;height:5rem;">
            <!--{else}-->
            <img src="$SCRITPTNAME?id=xigua_pt:qrcode&gid=$gid&tuan_id=$mytuan_id{$urlext}" class="z" style="width:5rem;height:5rem;">
            <!--{/if}-->
            <div class="cl " style="padding:5px 10px 0 10px;">
                <p class="f15"> <span class="stamp_three f12" style="border-radius:3px;">{$v[ptmin]}{lang xigua_pt:rp} </span> {$v[title]}{lang xigua_pt:zhixu}{$v[price_pt_min]}{lang xigua_pt:yuan}</p>
                <p class="c9 f14">{$_G[username]}{lang xigua_pt:xntbtj}</p>
            </div>
        </div>
    </div>
</div>


<!--{if $pt_config[qzgz] && !getcookie('miniprogram') && ($config['secert']||$config['magapp_secret'])&& HB_INWECHAT}-->
<!--{eval
$wxpay = $config['appid'] && $config['appsecert'] && $config['key'];
if(HB_INWECHAT && $wxpay):
$openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
    if(!$openid):
      $tools = new JsApiPaySF();
      $opendata = $tools->GetFollowOpenid(hb_currenturl().'&oauth=yes');
      if($openid = $opendata['openid']):
        dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 86400);
      endif;
    endif;
endif;
}-->
<!--{if $openid}-->
<script>var OPENID='$openid';</script>
<!--{/if}-->
<!--{/if}-->