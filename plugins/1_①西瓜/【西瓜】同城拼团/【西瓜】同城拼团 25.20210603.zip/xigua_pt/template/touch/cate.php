<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<div class="page__bd ">

    <!--{template xigua_pt:search}-->

    <div class="cate cate_pgapp">
        <div class="scroll-view level1 scroll-y">
            <!--{loop $catlist $lpk $loopin}-->
            <div data-index="{$loopin[id]}" id="tab_{$loopin[id]}" class="tab <!--{if ($lpk==0&&!isset($_GET[catid])) || $_GET[catid]==$loopin[id] }-->cur<!--{/if}-->">{$loopin[name]}</div>
            <!--{/loop}-->
        </div>
        <div class="scroll-view level2 scroll-y">
            <div class="level2__content">
                <!--{loop $catlist $loopin}-->
                <div class="cate_blcok" id="cate_{$loopin[id]}">
                    <div class="header">{$loopin[name]}
                        <a class="y c9" href="$SCRITPTNAME?id=xigua_pt&ac=cat&catid={$loopin[id]}">{lang xigua_pt:ckqb}<i class="f13 iconfont icon-jinrujiantou"></i></a>
                    </div>
                    <!--{if $loopin['adimage']}-->
                    <div><a href="{echo $loopin['adlink'] ? $loopin['adlink'] : "$SCRITPTNAME?id=xigua_pt&ac=cat&catid=".$loopin['id'].$urlext}"><img src="$loopin['adimage']" style="width: calc(100% - 15px);max-width: 640px;"></a></div>
                    <!--{/if}-->

                    <div class="lister">
                        <!--{loop $loopin[child] $vv}-->
                        <div class="list_item">
                            <div class="img cate_item" data-id="{$vv[id]}" data-pid="{$vv[pid]}">
                                <div class="wqvue-image item_img">
                                    <div class="item_cate">
                                        <img src="{$vv[icon]}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'">
                                    </div>
                                </div>
                            </div>
                            <div class="name line2 cate_item" data-id="{$vv[id]}" data-pid="{$vv[pid]}">{$vv[name]}</div>
                        </div>
                        <!--{/loop}-->
                    </div>
                </div>
                <!--{/loop}-->
            </div>
        </div>
    </div>

</div>
<!--{eval $pt_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_pt:footer}-->
<script>
    $('.tab').on('click', function (e) {
        e.preventDefault();
        var tb = $(this);
        $('.tab').removeClass('cur');
        tb.addClass('cur');

        var top = Math.abs($('.level2').scrollTop() + $('#cate_'+tb.data('index')).offset().top) - 63;
        console.log(top);
        $('.level2').scrollTop(top);
    });
    <!--{if $_GET[catid]}-->
    $('#tab_{$_GET[catid]}').trigger('click');
    <!--{/if}-->
</script>