<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<div class="page__bd">
    <div class="weui-cells__title">{$old_data[title]} {$navtitle}, {lang xigua_pt:zhsc}</div>

    <div class="weui-cells">

        <div class="mod-post x-postlist p0">
            <!--{loop $list $k $v}-->
            <div class="weui-cell weui-cell_swiped">
                <div class="weui-cell__bd">
                    <div class="weui-cell">
                        <div class="weui-cell__bd">
                            <p><b class="main_color">{$v[name]}</b></p>
                        </div>
                        <div class="weui-cell__ft start_popup" data-field="poup_$k"><!--{if $v[ggtext]}-->{lang xigua_pt:djbj}{echo count($v[ggtext])}{lang xigua_pt:xiang}<!--{else}-->{lang xigua_pt:djtxgz}<!--{/if}--></div>
                    </div>
                </div>
                <div class="weui-cell__ft">
                    <a class="weui-swiped-btn weui-swiped-btn_warn delete-swipeout" data-id="$k" href="javascript:">{lang xigua_pt:shanchu}</a>
                </div>
            </div>
            <!--{/loop}-->

            <!--{eval $_k = 0; $list[] = array();}-->
            <!--{loop $list $__k $_vv}-->
            <div id="poup_{$__k}" class="weui-popup__container popup-bottom">
                <div class="weui-popup__overlay"></div>
                <div class="weui-popup__modal">
                    <div class="toolbar">
                        <div class="toolbar-inner">
                            <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:quxiao}</a>
                            <h1 class="title"><em class="titem"></em>{lang xigua_pt:xzgg}</h1>
                        </div>
                    </div>
                    <div class="modal-content">
                        <form action="$SCRITPTNAME?id=xigua_pt&ac=spgg&type1=$__k" method="post" id="form" enctype="multipart/form-data">
                            <input type="hidden" name="formhash" value="{FORMHASH}">
                            <input type="hidden" name="form[id]" value="{$old_data[id]}" >
                            <input type="hidden" name="gid" value="{$old_data[id]}" >
                            <div class="weui-cells before_none after_none center_upload">
                                <div class="weui-cell">
                                    <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_pt:ggm}</label></div>
                                    <div class="weui-cell__bd">
                                        <input class="weui-input" type="text" name="form[name]" placeholder="{lang xigua_pt:ryscc}" value="{$_vv[name]}">
                                    </div>
                                </div>
                                <!--{loop $_vv[ggtext] $k $v}-->
                                <!--{eval $_k++;}-->
                                <div class="weui-cell bgf" id="arear_{$_k}">
                                    <ul id="cimg_{$_k}" data-only="1">
                                        <!--{if $_vv[ggimg][$k]}-->
                                        <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($_vv[ggimg][$k])">
                                            <input type="hidden" name="form[ggimg][]" value="$_vv[ggimg][$k]">
                                            <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                        </li>
                                        <!--{/if}-->
                                    </ul>
                                    <div class="weui-cell__bd">
                                        <textarea class="weui-textarea" placeholder="{lang xigua_pt:crggx}" rows="3" name="form[ggtext][]">{echo $_vv[ggtext][$k]}</textarea>
                                    </div>
                                    <a class="iconfont icon-guanbijiantou closeHt" data-index="$_k"></a>
                                </div>
                                <!--{/loop}-->
                                <a class="weui-cell weui-cell_access first_append_img" href="javascript:;">
                                    <div class="weui-cell__bd">
                                        <p>{lang xigua_pt:crggx}</p>
                                    </div>
                                    <div class="weui-cell__ft"></div>
<!--                                    <input class="center_upload__input" data-max="10" data-maxtip="{lang xigua_pt:zdszx}" data-name="form[ggimg]" type="file">-->
                                    <div class="center___input" style="position: absolute;z-index: 1;top: 0;left: 0;width: 100%;height: 100%;opacity: 0;-webkit-tap-highlight-color: transparent;" data-max="10" data-maxtip="{lang xigua_pt:zdszx}" data-name="form[ggimg]" type="file"></div>
                                </a>
                                <div class="fix-bottom" style="position:relative"><input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}"></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!--{/loop}-->

            <a href="javascript:void(0);" class="weui-cell weui-cell_link start_popup" data-field="poup_{$__k}">
                <div class="weui-cell__bd">{lang xigua_pt:xzgg}</div>
            </a>
        </div>
    </div>

    <form action="$SCRITPTNAME?id=xigua_pt&ac=spgg" method="post" id="form" enctype="multipart/form-data">
        <input name="spjg" value="1" type="hidden">
        <input name="gid" value="$_GET['gid']" type="hidden">
        <input name="formhash" value="{FORMHASH}" type="hidden">
        <div class="weui-cells__title">{lang xigua_pt:hxhdbj}</div>
        <div class="g_table cl">
            <div class="weui-flex">
                <!--{loop $list $k $v}-->
                <!--{if $v}-->
                <div class="weui-flex__item g_table_h">
                    <div class="border_top">{echo is_array($v) ? $v[name] : $v}</div>
                    <!--{loop $ggtest $iv}-->
                    <div class='border_top'>{echo is_array($iv) ? $iv[$k] : $iv}</div>
                    <!--{/loop}-->
                </div>
                <!--{/if}-->
                <!--{/loop}-->
                <!--{loop $field_price $k $v}-->
                <div class="weui-flex__item">
                    <div class='border_top'>$v</div>
                    <!--{loop $ggtest $kk $iv}-->
                    <!--{eval $impv = is_array($iv) ? implode('###', $iv) : $iv;}-->
                    <div class="border_top">
                        <input class="weui-input border_full" type="text" name="form[$kk][$k][v]" value="{$price_list[$impv][$k]}">
                        <input type="hidden" name="form[$kk][$k][k]" value="<!--{$impv}-->">
                    </div>
                    <!--{/loop}-->
                </div>
                <!--{/loop}-->
            </div>
        </div>
        <div class="fix-bottom mt10" style="position: relative">
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_pt:bc}">
            <a class="weui-btn weui-btn_default" href="$SCRITPTNAME?id=xigua_pt&ac=manage{$urlext}">{lang xigua_pt:back}</a>
        </div>
        <div class="footer_fix"></div>
    </form>



</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_pt:footer}-->
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script src="source/plugin/xigua_pt/static/pt.js?{VERHASH}"></script>
<script>
    $('#loading-show').addClass('hidden');
    $('#loading-none').removeClass('hidden');

    var loadingCallback = function () {
        $('.weui-cell_swiped').swipeout();
    };
    $('.weui-cell_swiped').swipeout();
    $(document).on('click','.delete-swipeout', function () {
        var yfid = $(this).data('id');
        $.confirm({
            title: '{lang xigua_pt:sfsc}',
            onOK: function () {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_pt&ac=spgg&gid={$gid}&delete=' +yfid+ '&inajax=1',
                    data:{formhash:FORMHASH },
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });
    });
    var loadingImg ='<li id="loadingimg" class="weui-uploader__file weui-uploader__file_status"><div class="weui-uploader__file-content"><img src="source/plugin/xigua_hb/static/img/loading.gif"/></div></li>', ICnt = {echo intval($_k);};

    $(document).on('touchstart', '.center___input', function () {
        ICnt ++;
        console.log(ICnt);
        var _that = $(this).parent(), _this = $(this);
        var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
            ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_pt:qtxxmm}" rows="1" name="form[ggtext][]"></textarea></div>' +
            '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
        _that.after(arear+ '<div class="weui-cell weui-cell_access" id="cell_'+ICnt+'">'+_that.html()+'</div>');
        _that.hide();
    });
    $(document).on('change', '.center_upload__input', function () {
        ICnt ++;
        console.log(ICnt);
        var _that = $(this).parent(), _this = $(this);
        if(_that.parent().find('.closeHt').length>= _this.data('max')){
            $.toast(_this.data('maxtip'), 'error');
            return false;
        }
        var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
            ' <ul id="cimg_'+ICnt+'" data-only="1">'+loadingImg+'</ul>' +
            ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_pt:qtxxmm}" rows="3" name="form[ggtext][]"></textarea></div>' +
            '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
        _that.after(arear+ '<div class="weui-cell weui-cell_access" id="cell_'+ICnt+'">'+_that.html()+'</div>');
        _that.hide();
        filedname = _this.data('name');
        var files = this.files;
        if (files && files.length) {
            file = files[0];
            if (/^image\/\w+$/.test(file.type)) {
                boxer = $('#cimg_'+ICnt);
                compress(file, function(TMP){
                    hs_doupload(TMP,function(){
                    });
                });
            } else {
                $.toptip('Please choose an image file.', 'error');
            }
        }
    });
    $(document).on('click', '.closeHt', function () {
        var idx = $(this).data('index');
        $.confirm('{lang xigua_pt:qdsccgg}', function () {
            $('#arear_'+idx).remove();
            /*$('#cell_'+idx).remove();*/
        }, function () {
        });
        return false;
    });
    $(document).on('click','.start_popup', function () {
        var that = $(this);
        var fdb = $("#"+that.data('field'));
        ICnt = $('.closeHt').length;
        console.log(ICnt);
        fdb.find('.titem').html(that.find('.weui-label').html());
        fdb.popup();
    });
</script>