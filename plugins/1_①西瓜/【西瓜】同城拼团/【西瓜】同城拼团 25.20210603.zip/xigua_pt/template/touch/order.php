<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
<!--{eval $mang = $_GET['manage']? '&manage=1':'';}-->

    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">

            <input name="id" value="xigua_pt" type="hidden">
            <input name="ac" value="order" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">

            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_pt:spmcddh}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_pt:spmcddh}</span>
            </label>
        </form>
        <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_pt:search}</a>
        <a href="$SCRITPTNAME?id=xigua_pt&ac=order{$mang}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_pt:qx}</a>
    </div>

    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_pt&ac=order&keyword=$keyword{$mang}" class="weui-navbar__item <!--{if !$_GET[status]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_pt:qb}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_pt&ac=order&keyword=$keyword&status=1{$mang}" class="weui-navbar__item <!--{if $_GET[status]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{$status_font[1]}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_pt&ac=order&keyword=$keyword&status=5{$mang}" class="weui-navbar__item <!--{if $_GET[status]==5}-->weui_bar__item_on<!--{/if}-->">
            <span>{$status_font[5]}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_pt&ac=order&keyword=$keyword&status=2,6&shou_ts=-1{$mang}" class="weui-navbar__item <!--{if $_GET[status]=='2,6'&&$_GET['shou_ts']==-1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_pt:dshuo}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_pt&ac=order&keyword=$keyword&status=2,6&shou_ts=1{$mang}" class="weui-navbar__item <!--{if $_GET[status]=='2,6'&&$_GET['shou_ts']==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_pt:ywc}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_pt&ac=order&keyword=$keyword&status=3,4,7{$mang}" class="weui-navbar__item <!--{if $_GET[status]=='3,4,7'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_pt:yqx}</span>
        </a>
    </div>

    <!--{template xigua_pt:viewtools}-->


    <div  id="list" class="weui-cells p0 mt0 before_none after_none" style="background:transparent"></div>



    <!--{template xigua_hb:loading}-->
</div>

<script>
    var loadingurl = window.location.href+'&ac=order_li&inajax=1&page=';
    var noTit = true;
</script>
<!--{eval $pt_tabbar=1;$tabbar=0;}-->
<!--{template xigua_pt:footer}-->
<script src="source/plugin/xigua_pt/static/order.js?{VERHASH}"></script>