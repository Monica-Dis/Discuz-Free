<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $v[logs]}-->
<script>
    var PT_TOUTIAOS = [];
    <!--{loop $v[logs] $vvv}-->
    PT_TOUTIAOS.push("<a href=\"javascript:;\" class='f12'> <img src=\"{avatar($vvv[uid], 'middle', true)}\" class='avt' /> <em>{$vvv[username]}</em> {echo date('m-d H:i', $vvv[crts])} {lang xigua_pt:gmlbsp}</a>");
    <!--{/loop}-->
</script>
<!--{/if}-->
<div class="noti"></div>