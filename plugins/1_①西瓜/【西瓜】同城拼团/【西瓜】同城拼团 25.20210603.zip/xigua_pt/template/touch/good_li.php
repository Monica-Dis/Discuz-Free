<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{loop $list $v}-->
<div class="dis_list">
    <div class="dis_row jump_pt" data-id="{$v[id]}">
        <div class="dis_pic">
            <img src="{$v[album][0]}">
            <div class="dis_mask"><div class="title">{$v[title]}</div></div>
        </div>
        <div class="dis_pir weui-flex">
            <div class="weui-flex__item">
                <p class="price">
                    <span class="ptcolor">

                    <span class="stamp_three stamp_mini">{$v[ptmin]}{lang xigua_pt:rp}</span>
                    &yen;<em class="f18">{$v[tprice]}</em></span>
                    <span class="f12 gray y">{lang xigua_pt:yp}{$v[sellnum]}{lang xigua_pt:j}</span>
                </p>
            </div>
        </div>
    </div>
    <div class="button-sp-area">
        <a href="$SCRITPTNAME?id=xigua_pt&ac=add&gid={$v[id]}" class="weui-btn weui-btn_mini hm_c_btn ">{lang xigua_pt:xg}</a>
<!--        <a href="$SCRITPTNAME?id=xigua_pt&ac=jtt&gid={$v[id]}" class="weui-btn weui-btn_mini hm_c_btn "></a>-->
        <a href="$SCRITPTNAME?id=xigua_pt&ac=spgg&gid={$v[id]}" class="weui-btn weui-btn_mini hm_c_btn ">{lang xigua_pt:spgg}</a>

        <a href="javascript:;" data-gid="{$v[id]}" data-title="{lang xigua_pt:sxj}" data-text="$v[title]<br>{lang xigua_pt:sxjd}" class="weui-btn weui-btn_mini hm_c_btn sxj">{lang xigua_pt:sxj}</a>
    </div>
</div>
<!--{/loop}-->