<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<style>.fixbanner_in .ajaxcat{min-width:1.4rem}</style>
<!--{if $pt_config[pindaologo]&&strpos($pt_config['logoindex'],'/')!==false}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$pt_config[pindaologo]" /></div><!--{/if}-->
<div class="page__bd">
<!--{if $_GET[indextopstyle]}-->
<!--{eval $pt_config[indextopstyle] = $_GET[indextopstyle];}-->
<!--{/if}-->
<!--{if $pt_config[indextopstyle]==3}-->
<div class="weui-cells fixbanner before_none mt0" style="position:fixed;z-index:1">
    <div class="weui-navbar weui-banner nobg fixbanner_in">
        <!--{if $_G['cache']['plugin']['xigua_pt']['allowfz'] && $_G['cache']['plugin']['xigua_st']['showfz']}-->
        <a href="$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_pt");}{$urlext}" class="weui-navbar__item">
            <span>{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
        </a>
        <!--{/if}-->
        <a href="$SCRITPTNAME?id=xigua_pt&mobile=2" class="weui-navbar__item weui_bar__item_on ">
            <span>{lang xigua_pt:tj}</span>
        </a>
        <!--{loop $cat_list $cat}-->
        <a href="$SCRITPTNAME?id=xigua_pt&ac=cat&catid={$cat[id]}" class="weui-navbar__item ">
            <span>$cat[name]</span>
        </a>
        <!--{/loop}-->
    </div>
</div>
<div style="width:100%;height:2.4rem"></div>
<!--{elseif $pt_config[indextopstyle]!=3}-->
<!--{eval $config[intopindex]=0}--><!--{if $pt_config[indextopstyle]==2}--><!--{eval $config[intopindex]=1}--><!--{/if}-->
<!--{if !$config[intopindex]}--><div style="width:100%;height:2.1rem"></div><!--{/if}-->
<header class="x_header bgcolor_11 cl  weui-flex f15" <!--{if $config[intopindex]}-->style="background:transparent!important;position:absolute"<!--{/if}-->>
    <!--{if $_G['cache']['plugin']['xigua_pt']['allowfz'] && $_G['cache']['plugin']['xigua_st']['showfz'] }-->
    <a class="z x_logo" href="javascript:;" onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_pt{$urlext}&mobile=2");}{$urlext}'">
        <span class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
    </a>
    <!--{else}-->
    <a class="z x_logo" href="$SCRITPTNAME?id=xigua_pt$urlext">
        <!--{if strpos($pt_config['logoindex'],'/')!==false}--><img src="$pt_config['pindaologo']" />
        <!--{else}--><span style="margin:0 .75rem">$pt_config['pindaologo']</span><!--{/if}--></a>
    <!--{/if}-->

    <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
        <input type="hidden" name="id" value="xigua_pt"> <input type="hidden" name="ac" value="cat">
        <input type="hidden" name="st" value="$_GET[st]"> <input type="hidden" name="idu" value="$_GET[idu]">
        <input name="keyword" class="x_logo_input" type="text" value="" placeholder="{echo $keyword ? $keyword : $pt_config[schtxt]}" x-webkit-speech="" style="background: rgba(255,255,255,.8)">
        <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
    </form>
</header>
<!--{/if}-->

    <!--{if $topnavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->

    <!--{if $jing_list}-->
    <nav class=" nav-list cl swipe" style="padding-top:3px">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $jing_list $k $n}-->
                    <!--{if $k && $k%10==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li>
                        <a href="{$n['adlink']}">
                            <span>
                                <img src="$n['icon']"/>
                            </span>
                            <em class="m-piclist-title">{$n['name']}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{/if}-->

    <!--{if $pt_config['allowindexnav']}-->
    <!--{template xigua_pt:filter}-->
    <!--{else}-->
    <div class="pro-wrap-title mt10"></div>
    <!--{/if}-->
    <ul class="goodlist" id="list" style="padding-top:0"> </ul>
    <!--{template xigua_hb:loading}-->
</div>

<!--{if $pt_config['needgeo']}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script>
var loadingurl = window.location.href+'&ac=cat_li&from=index&inajax=1&order=near&page=';
scrollto = 1;
function loadindex(){
    hs_getlocation(function (position) {
        var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
        page = 1;
        loadingurl = loadingurl+'&lat='+lat+'&lng='+lng+'&page=';
        DOAPPEND = 0;
        $.ajax({
            type: 'get',
            url: loadingurl+''+page,
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $('#loading-show').addClass('hidden');
                if(!s){
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                    setTimeout(function () {
                        $('#loading-show').addClass('hidden');
                        $('#loading-none').removeClass('hidden');
                    }, 300);
                    $("#list").html(s);
                    page = -1;
                    return ;
                }
                $("#list").html(s);
                page ++;
            },
            error: function() {
            }
        });
    });
}
if(typeof wx !=='undefined') {wx.ready(function () { loadindex();});}else{setTimeout(function () { loadindex(); }, 300);}
</script>
<!--{else}-->
<script>var loadingurl = window.location.href+'&ac=cat_li&from=index&inajax=1&page=';</script>
<!--{/if}-->
<!--{eval $pt_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_pt:footer}-->