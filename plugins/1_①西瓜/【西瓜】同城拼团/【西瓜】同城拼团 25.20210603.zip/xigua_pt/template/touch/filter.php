<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<div class="weui-navbar mt10" style="z-index:0">
    <style>.nav_expand_panel{top:0;height:100vh}</style>
    <a data-id="2" id="ftb2" class="filter_nav weui-navbar__item">
        <span class="block border_right"><em data-html="{lang xigua_pt:qbfl}">{lang xigua_pt:qbfl}</em><i class="iconfont icon-xiangxia f12"></i></span>
    </a>
    <a data-id="3" id="ftb3" class="filter_nav weui-navbar__item">
        <span><em data-html="{lang xigua_pt:qbsq}">{lang xigua_pt:qbsq}</em><i class="iconfont icon-xiangxia f12"></i></span>
    </a>
</div>
<div class="dist_show">
    <div id="dist_show_2" class="nav_expand_panel hp_panel border_top">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <ul>
                    <li class="first_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&hyid=0">{lang xigua_hb:quanbu}{lang xigua_pt:fenlei}</a></li>
                    <!--{loop $cat_tree $k $v}-->
                    <!--{if !$v[adlink]}-->
                    <li class="first_cat_check border_bfull" <!--{if $v[sub]}--> data-id="$v[id]"<!--{/if}-->><a <!--{if !$v[sub]}--> class="ftb" data-idid="2" data-sort="&hyid={$v[id]}"<!--{/if}-->>$v[name]</a></li>
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="weui-flex__item checked">
                <!--{loop $cat_tree $k $v}-->
                <ul class="sub_cat_cheker <!--{if !($hyid==$v[id]||$pid==$v[id])}-->none<!--{/if}-->" id="sub_cat_cheker_$v[id]">
                    <li class="sub_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&hyid={$v[id]}" data-orihtml="{$v[name]}">{lang xigua_hb:quanbu}</a></li>
                    <!--{loop $v[sub] $vv}-->
                    <li class="sub_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&hyid={$vv[id]}">$vv[name]</a></li>
                    <!--{/loop}-->
                </ul>
                <!--{/loop}-->
            </div>
        </div>
    </div>
    <div id="dist_show_3" class="nav_expand_panel hp_panel border_top">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <ul>
                    <li class="first_check border_bfull"><a class="ftb" data-idid="3" data-sort="&city=-1" href="javascript:;">{lang xigua_hb:quanbu}{lang xigua_pt:sq}</a></li>
                    <!--{loop $dist0 $v}-->
                    <li class="first_check border_bfull" data-id="$v[id]"><a>{$v[name]}</a></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="weui-flex__item checked">
                <!--{loop $dist0 $k $v}-->
                <ul class="sub_cheker <!--{if $city_id!=$v['id']}-->none<!--{else}-->checked<!--{/if}-->" id="sub_cheker_$v[id]">
                    <li class="sub_check border_bfull"><a class="ftb color-red" data-idid="3" data-sort="&city={$v[name]}" href="javascript:;" data-orihtml="{$v[name]}">{lang xigua_hb:quan}{$v[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
                    <!--{loop $v[child] $vv}-->
                    <li class="sub_check border_bfull <!--{if $dist==$vv[name]&&$_GET[dist]}-->checked main_color<!--{/if}-->"><a href="javascript:;" id="sub_check{$vv[id]}" data-id="$vv[id]" onclick="getnext($vv[id],'$vv[name]')">$vv[name]</a></li>
                    <!--{/loop}-->
                </ul>
                <!--{/loop}-->
            </div>
            <div class="weui-flex__item checked" id="ajaxbox" style="position:relative;height:65vh"> <ul class="ajaxbox_cheker"></ul> </div>
        </div>
    </div>
</div>

<script>
var loadingurl = window.location.href+'&ac=cat_li&inajax=1&page=';
scrollto = 1;
var lockIng = 0;
$(document).on('click','.ftb', function () {
    var that = $(this);
    that.parent().parent().find('.checked').removeClass('checked main_color');
    that.parent().addClass('checked main_color');
    $('.mask').trigger('click');

    var oem = $('#ftb'+that.data('idid')).find('em');
    var showhtm = that.html();
    if(that.data('orihtml')){
        showhtm = that.data('orihtml');
    }
    oem.data('html', oem.html()).html(showhtm);

    var lnk = that.data('sort');
    loadpt_index(that, lnk);
});

$(document).on('click','.filter_nav', function () {
    $(this).addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
    var curt = $('#dist_show_'+$(this).data('id'));
    curt.siblings().removeClass('show');
    curt.toggleClass('show');
    if(curt.hasClass('show')){
        $(this).parent().addClass('filter_top');
        $(this).find('em').html($(this).find('em').data('html'));
        $('.mask').show();
    }else{
        $(this).parent().removeClass('filter_top');
        $('.mask').hide();
    }
    if(IN_APP==='magapp'){
        $('#backtotop').trigger('click');
    }
    return false;
});
$(document).on('click','.mask', function () {
    $('.filter_top').removeClass('filter_top');
    $('.dist_show').find('.nav_expand_panel').removeClass('show');
    $(this).hide();
});
function getnext(id, name) {
    $('.sub_check a').removeClass('checked').removeClass('main_color');
    $('#sub_check'+id).addClass('checked').addClass('main_color');
    $.ajax({
        type: 'get',
        url: _APPNAME + '?id=xigua_pt&ac=chosecity&name='+name+'&ctid='+id+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('.ajaxbox_cheker').html(s);
        }
    });
}
</script>