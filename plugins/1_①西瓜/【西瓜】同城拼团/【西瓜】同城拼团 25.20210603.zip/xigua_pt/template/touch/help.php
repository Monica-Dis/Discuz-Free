<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<div class="page__bd">

    <!--{template xigua_hb:common_nav}-->

    <img src="source/plugin/xigua_pt/static/help.jpg" style="width:100%"/>
    <style>
        .tuan_subprogress {
            margin-top: 15px;
            padding-bottom: 17px;
            position: relative;
        }

        .tuan_subprogress .tuan_subprogress_title {
            height: 46px;
            line-height: 46px;
            font-size: 20px;
            color: #fff;
            display: inline-block;
            padding: 0 41px 0 30px;
            border-top-right-radius: 50px;
            border-bottom-right-radius: 50px;
            background: #e4393c;
        }

        .tuan_subprogress .tuan_subprogress_step {
            font-size: 0;
            padding: 27px 0 0 30px;
        }

        .tuan_subprogress .tuan_subprogress_step li {
            margin-bottom: 10px;
            position: relative;
            padding-left: 46px;
        }

        .tuan_subprogress .tuan_subprogress_step .tuan_subprogress_step_num {
            width: 30px;
            height: 30px;
            line-height: 30px;
            background: #e4393c;
            color: #fff;
            font-size: 20px;
            text-align: center;
            position: absolute;
            left: 0;
            right: 0;
        }

        .tuan_subprogress .tuan_subprogress_step .tuan_subprogress_step_txt {
            font-size: 12px;
            color: #333;
            padding-right: 5px;
        }

        .tuan_subprogress .tuan_subprogress_step .tuan_subprogress_step_img {
            margin: 12px 30px 0 0;
        }

        .tuan_subprogress .tuan_subprogress_step .tuan_subprogress_step_img img {
            width: 100%;
        }

        .tuan_subprogress .tuan_subprogress_step li:before {
            content: '';
            width: 1px;
            position: absolute;
            left: 15px;
            top: 29px;
            bottom: 0;
            background: #e4393c;
        }

        .tuan_subinfo {
            padding: 13px 30px 20px;
            color: #333;
            font-size: 12px;
        }
    </style>
    <div class="tuan_subprogress ">
        <div class="tuan_subprogress_title bg_1">{lang xigua_pt:ktlc}</div>
        <ul class="tuan_subprogress_step">

            <li>
                <div class="tuan_subprogress_step_num">1</div>
                <div class="tuan_subprogress_step_txt">{lang xigua_pt:ktlc1}</div>
                <div class="tuan_subprogress_step_img">
                    <img src="source/plugin/xigua_pt/static/1.jpg">
                </div>
            </li>

            <li>
                <div class="tuan_subprogress_step_num">2</div>
                <div class="tuan_subprogress_step_txt">{lang xigua_pt:ktlc2}</div>
                <div class="tuan_subprogress_step_img">
                    <img class="orderImg" src="source/plugin/xigua_pt/static/2.jpg">
                </div>
            </li>

            <li>
                <div class="tuan_subprogress_step_num">3</div>
                <div class="tuan_subprogress_step_txt">{lang xigua_pt:ktlc3}</div>
                <div class="tuan_subprogress_step_img">
                    <img src="source/plugin/xigua_pt/static/3.jpg">
                </div>
            </li>
            <li>
                <div class="tuan_subprogress_step_num">4</div>
                <div class="tuan_subprogress_step_txt">{lang xigua_pt:ktlc4}</div>
            </li>
        </ul>
    </div>
    <div class="tuan_subprogress join_subprogress">
        <div class="tuan_subprogress_title bg_1">{lang xigua_pt:ctlc}</div>
        <ul class="tuan_subprogress_step">

            <li>
                <div class="tuan_subprogress_step_num">1</div>
                <div class="tuan_subprogress_step_txt">{lang xigua_pt:djpd}</div>
                <div class="tuan_subprogress_step_img">
                    <img src="source/plugin/xigua_pt/static/1.jpg">
                </div>
            </li>

            <li>
                <div class="tuan_subprogress_step_num">2</div>
                <div class="tuan_subprogress_step_txt">{lang xigua_pt:tjcgzfd}</div>
                <div class="tuan_subprogress_step_img">
                    <img class="orderImg" src="source/plugin/xigua_pt/static/2.jpg">
                </div>
            </li>
            <li>
                <div class="tuan_subprogress_step_num">3</div>
                <div class="tuan_subprogress_step_txt">{lang xigua_pt:djcypt}</div>
                <div class="tuan_subprogress_step_img">
                    <img class="orderImg" src="source/plugin/xigua_pt/static/4.jpg">
                </div>
            </li>
            <li>
                <div class="tuan_subprogress_step_num">4</div>
                <div class="tuan_subprogress_step_txt">{lang xigua_pt:djcypt1}</div>
            </li>
        </ul>
    </div>
    <div class="tuan_subinfo">
    {lang xigua_pt:qtsm}
    </div>

</div>

<!--{eval $tabbar=0;$pt_tabbar=1;}-->
<!--{template xigua_pt:footer}-->