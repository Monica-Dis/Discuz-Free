<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<div class="none view_tools_mask"></div>
<div class="none view_tools animated">
    <ul>
        <li class="border_bottom" ><a href="$SCRITPTNAME?id=xigua_pt"><i class="vm iconfont icon-index "></i> {lang xigua_pt:sy}</a></li>
        <li><a href="$SCRITPTNAME?id=xigua_hb&ac=my"><i class="vm iconfont icon-xiaolian2 "></i> {lang xigua_pt:grzx}</a></li>
        <li><a href="$SCRITPTNAME?id=xigua_hb&ac=qianbao"><i class="vm iconfont icon-qianbao2  "></i> {lang xigua_pt:wdqb}</a></li>
        <li><a href="$SCRITPTNAME?id=xigua_pt&ac=order"><i class="vm iconfont icon-createtask "></i> {lang xigua_pt:wddd1}</a></li>
        <!--{if get_shids_by_uid()}-->
        <li><a href="$SCRITPTNAME?id=xigua_pt&ac=order_manage"><i class="vm iconfont icon-jieshao1   "></i> {lang xigua_pt:ddgl1}</a></li>
        <li><a href="$SCRITPTNAME?id=xigua_pt&ac=manage"><i class="vm iconfont icon-fenlei  "></i> {lang xigua_pt:spgl1}</a></li>
        <li><a href="$SCRITPTNAME?id=xigua_hs&ac=shcenter"><i class="vm iconfont icon-shop   "></i> {lang xigua_hs:shcenter}</a></li>
        <!--{/if}-->
    </ul>
</div>
