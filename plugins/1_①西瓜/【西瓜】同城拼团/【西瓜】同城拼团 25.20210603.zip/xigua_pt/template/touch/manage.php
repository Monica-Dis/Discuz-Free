<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{eval
if(!$sh[0][name]):
dheader('Location:'.$SCRITPTNAME.'?id=xigua_pt&ac=none');
endif;
}--><!--{template xigua_pt:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_pt&ac=manage&stat=1" class="weui-navbar__item <!--{if 1==$_GET[stat]||!$_GET[stat]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_pt:jxz}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_pt&ac=manage&stat=2" class="weui-navbar__item <!--{if $_GET[stat]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_pt:dsh}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_pt&ac=manage&stat=3" class="weui-navbar__item <!--{if $_GET[stat]==3}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_pt:yxj}</span> </a>
    </div>

    <div>
        <div id="list" class="mod-post x-postlist p0"></div>
        <!--{template xigua_hb:loading}-->
    </div>

    <div class="footer_fix"></div>
    <!--{template xigua_pt:viewtools}-->
</div>
<a href="$SCRITPTNAME?id=xigua_pt&ac=add" class="float_btn"><i class="iconfont icon-zengjia"></i> {lang xigua_pt:fbsp}</a>

<script>
    var loadingurl = window.location.href+'&ac=good_li&inajax=1&page=';
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_pt:footer}-->