<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_pt:header}-->
<div class="page__bd view_bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="view_num we_share"><i class="iconfont icon-ico_fenxiang"></i></div>
    <div class="cl_swipe cl" style="transition: all .3s;position:relative;margin:0;overflow:hidden">
        <div class="swipe-wrap" style="transition: all .3s;-webkit-transition: all .3s">
            <!--{if !$v[album]}-->
            <!--{eval $v[album] = $v[append_img_ary];}-->
            <!--{/if}-->
            <!--{loop $v[album] $slider}-->
            <div class="swp"><img src='$slider' style="min-height:60vw;max-height:120vw" /></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $v[album] $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}--> ></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <div class="weui-cells mt0 before_none view_top after_none">
        <!--{if DB::result_first('SELECT sum(stock) FROM %t WHERE gid=%d', array('xigua_pt_good_price', $gid))<=0}-->
        <img src="source/plugin/xigua_pt/static/shouqing2.png?{VERHASH}" class="sellout2">
        <!--{/if}-->
        <div class="cl view_cell">
            <div class="weui-flex">
                <div class="weui-flex__item" style="position: relative">
                    <span class="stamp_three stamp_middle">{$v[ptmin]}{lang xigua_pt:rp}</span>
                    <span class="tprice"><em class="f12">&yen;</em>$v[price_pt_old]</span>
                    <span class="c9 f12"><s><em class="f12">&yen;</em>$v[price_sc_max]</s></span>
                    <!--{if $v[pricehk1]>0}-->
                    <span class="hksp" style="float:none;display:inline-block">{$_G['cache']['plugin']['xigua_hk']['cardname']}{$v[pricehk1]}{lang xigua_hb:yuan}</span>
                    <!--{/if}-->
                    <span class="tnums f12">{lang xigua_pt:yp}{$v[sellnum]}{lang xigua_pt:j}</span>
                </div>
            </div>
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <span class="f15 c3">$v[title]</span>
                </div>
            </div>
            <div class="weui-flex">
                <div class="weui-flex__item f13 aten" >
                    {lang xigua_pt:ktyqhy}{$v[ptshixian]}{lang xigua_pt:xsbzzd}
                </div>
            </div>
        </div>
        <!--{if $v[srange_ary]}-->
        <a class="weui-cell" href="javascript:;" onclick="return $('#poup_srange_ary').popup();">
            <div class="weui-cell__bd">
                <ul class="arguments-treatment">
                    <!--{loop $v[srange_ary] $_v}--><li style="float:left;"><i class="iconfont icon-duigou2 main_color"></i> {$_v}</li><!--{/loop}-->
                </ul>
            </div>
            <div class="weui-cell__ft">
                <i class="f13 iconfont icon-jinrujiantou"></i>
            </div>
        </a>
        <!--{/if}-->


        <!--{if $pt_config[showreal]&&$v[logs]}-->
        <a class="weui-cell" href="javascript:;">
            <div class="weui-cell__bd f14">
                <ul class="seckill_logs z">
                    <!--{loop $v[logs] $_u}-->
                    <li><img src="{avatar($_u[uid], 'middle', true)}" /></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="weui-cell__ft f14">
                {lang xigua_pt:yyou}{echo intval($v[logs_count])}{lang xigua_pt:rgm}
            </div>
        </a>
        <!--{/if}-->
        <!--{template xigua_pt:slider}-->
    </div>

    <div class="weui-cells f15 before_none after_none">
        <a href="$SCRITPTNAME?id=xigua_pt&ac=help{$urlext}" ><img src="source/plugin/xigua_pt/static/help.png?1213" class="block"></a>
    </div>

    <!--{if $pting_num>0}-->
    <div id="tuan_more" style="display:none"><div class="weui-cells before_none after_none mt0" style="max-height: 50vh;overflow-y:auto;-webkit-overflow-scrolling:touch"></div></div>
    <div class="weui-cells f15 before_none after_none">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <span>{$pting_num}{lang xigua_pt:rzpd}</span>
                <a class="y c9 pr_1 tuan_more" href="javascript:;" data-title="{lang xigua_pt:zzpd}" data-gid="{$gid}">{lang xigua_pt:ckgd}<i class="f13 iconfont icon-jinrujiantou"></i></a>
            </div>
        </div>
        <div class="swiper-container" id="newsSlider" data-autoplay="3000" data-speed="4000" <!--{if count($pting)==1}-->style="height:65px"<!--{else}-->style="height:130px"<!--{/if}-->>
            <ul class="swiper-wrapper">
                <li class="swiper-slide">
        <!--{loop $pting $pt_k $pt_usr}-->
<!--{if $pt_k&&$pt_k%2==0}--></li><li class="swiper-slide"><!--{/if}-->
        <!--{eval $le = $v[ptmin]-$pt_usr[tuan_num];}-->
        <div class="weui-cell">
            <div class="weui-cell__hd mr15">
                <img src="{avatar($pt_usr[uid], middle, true)}" class="pt_usr" >
                <span class="f14">$pt_usr[username]</span>
            </div>
            <div class="weui-cell__bd ctli">
                <p>{lang xigua_pt:hc}<em class="ptcolor">{$le}{lang xigua_pt:r}</em>{lang xigua_pt:pc}</p>
                <p class="hmt" data-start="{$pt_usr[pay_ts_u]}" data-end="{$pt_usr['shixian_u']}">{lang xigua_pt:shy}<span class="timer"></span></p>
            </div>
            <div class="weui-cell__ft">
                <div id="ctli_{$pt_k}" style="display:none">
                    <span>{lang xigua_pt:js}<em class="ptcolor">{$le}{lang xigua_pt:ge}</em>{lang xigua_pt:me}, </span><span class="hmt" data-start="{$pt_usr[pay_ts_u]}" data-end="{$pt_usr['shixian_u']}">{lang xigua_pt:shy}<span class="timer"></span></span>
                    <div class="share_list cl" style="display: -webkit-flex; -webkit-justify-content: center; -webkit-align-items: center;">
                        <div class="z pr">
                            <img class="share_tz" src="{avatar($pt_usr['uid'],  'small', 1)}"/> <em>{lang xigua_pt:tz}</em>
                        </div>
                        <div class="other_tuanyuan"></div>
                        <!--{eval for($i = 0; $i <$le; $i++):}-->
                        <div class="z"> <img src="source/plugin/xigua_pt/static/empty.png"/> </div>
                        <!--{eval endfor;}-->
                    </div>
                </div>
                <a href="javascript:;" class="ptbtn joinpt" data-type="2" data-uid="{$pt_usr[uid]}" data-tuan_id="{$pt_usr[id]}" data-title="{lang xigua_pt:cy}{$pt_usr[username]}{lang xigua_pt:dpd}" data-text="ctli_{$pt_k}">{lang xigua_pt:qpd}</a>
            </div>
        </div>
        <!--{/loop}-->
                </li>

            </ul>
        </div>
    </div>
    <!--{/if}-->

<!--{if $pt_config[showshinview]}-->
<!--{eval $sh = $v[sh]}-->
<div class="weui-cells f15 before_none after_none">
    <div class="weui-cell">
        <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="{$sh[logo]}"></a></div>
        <div class="weui-cell__bd">
            <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
            <p class="f13 c9">{lang xigua_pt:yysj}: <em>{$sh[opentime]}</em></p>
        </div>
        <div class="weui-cell__ft">
            <a href="javascript:;" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_pt:smj}", "{lang xigua_pt:wxzca}");'><i class="iconfont icon-sixin2 mr15 main_color f24"></i></a>
            <a class="shtel" <!--{if $sh[teljs]}-->$sh[teljs]<!--{else}-->href="tel:{$sh[tel]}"<!--{/if}-->><i class="iconfont icon-unie607 main_color f24"></i></a>
        </div>
    </div>

    <a class="weui-cell weui-cell_access" href="javascript:;" id="v_openLocation" data-lat="{$sh[lat]}" data-lng="{$sh[lng]}" data-name="{$sh[name]}" data-addr="{$sh[addr]}">
        <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
        <div class="weui-cell__bd">
            <p class="f14">{$sh[addr]}</p>
        </div>
        <div class="weui-cell__ft"></div>
    </a>

</div>
<!--{/if}-->

    <div class="weui-cells f15  before_none after_none">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <p>{lang xigua_pt:jieshao}</p>
            </div>
        </div>
        <!--{eval
        if(strpos($v['jieshao'], '&lt;') !== false  && strpos($v['jieshao'], '&gt;') !== false) :
            $v['jieshao'] = htmlspecialchars_decode($v['jieshao']);
            $v['jieshao'] = preg_replace(array("/<script(.*?)<\/script>/is",'/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('',''), $v['jieshao']);
        endif;
        }-->
        <article class="weui-cell weui-article f14">
            <section>
                <p>{echo hs_nl2br($v['jieshao']);}</p>
                <!--{loop $v[append_img_ary] $__k $__v}-->
                <p><img src="{$__v}" /></p>
                <p>{echo hs_nl2br($v[append_text_ary][$__k]);}</p>
                <!--{/loop}-->
            </section>
        </article>
    </div>

<!--{if $_G['cache']['plugin']['xigua_dp'] && in_array('pt', unserialize($_G['cache']['plugin']['xigua_dp']['opens']))}-->
<style>.gzbtn{background-color:$config[maincolor]}</style><div id="ptdiv2" style="display:none"></div>
<script>
    $.ajax({type: 'get',dataType: 'xml',
        url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=pt&typeid=$gid&shid={$v[shid]}&pagesize=5&page=1',
        success: function (data) {
            if(null==data){ $('#ptdiv2').remove(); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(!s){ $('#ptdiv2').remove(); return false;}
            $('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
            $('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
            $('#ptdiv2').html(s).show();
        },
        error: function () {$('#ptdiv2').remove();}
    });
</script>
<!--{/if}-->

<div class="tuan_recommend">
    <div class="tuan_recommend_title"><span class="tuan_recommend_title_text">{lang xigua_pt:wntj}</span></div>

    <div class="weui-cells fixbanner before_none mt0">

        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="$SCRITPTNAME?id=xigua_pt&mobile=2" class="weui-navbar__item weui_bar__item_on ">
                <span>{lang xigua_pt:tj}</span>
            </a>

            <!--{loop $cat_list $cat}-->
            <a href="$SCRITPTNAME?id=xigua_pt&ac=cat&catid={$cat[id]}" class="weui-navbar__item ">
                <span>$cat[name]</span>
            </a>
            <!--{/loop}-->
        </div>

    </div>
    <ul class="goodlist mt0" id="list" style="padding-top:0"> </ul>
</div>



    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_pt&mobile=2{$urlext}" class="weui-tabbar__item weui-bar__item_on">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-index weui-tabbar__icon pr-1"></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_pt:sy}</p>
            </a>
        </div>
        <div class="in_bottom_z" style="display:none">
            <a href="javascript:;" class="weui-tabbar__item">
            <span style="display: inline-block;position: relative;">
                <i class="iconfont icon-unie607 weui-tabbar__icon f22"></i>
            </span>
                <p class="weui-tabbar__label"></p>
            </a>
        </div>
        <div class="in_bottom_z">
            <!--{if $kefulink}-->
            <a href="{$kefulink}" class="weui-tabbar__item">
            <!--{else}-->
            <a href="javascript:;" class="weui-tabbar__item" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_pt:calx}", "{lang xigua_pt:lxwx}");'>
            <!--{/if}-->
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-kefu1 weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_pt:kf}</p>
            </a>
        </div>

        <!--{if $_G['cache']['plugin']['xigua_hk'] && $v[pricehk1]>0 && (!$_G['uid'] || !$card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid']))}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hk&ac=join" class="weui-tabbar__item" style="background: #2B2B2A;">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-huiyuantequan weui-tabbar__icon f22" style="color: rgb(230,220,190);"></i>
                </span>
                <p class="weui-tabbar__label" style="color: rgb(230,220,190);">{lang xigua_hk:qkk}</p>
            </a>
        </div>
        <!--{else}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_pt&ac=order" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-xiaolian2 weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_hb:wode}</p>
            </a>
        </div>
        <!--{/if}-->
        <div class="weui-flex__item in_bottom_y <!--{if $v[ptmin]==1}-->in_bottom_main<!--{else}-->in_bottom_sec<!--{/if}-->">
            <a href="javascript:;" class="bgcolor_sec mc_bg buynow" data-type="1">
                <div class="fqpd">&yen;$v[price_dm_min]</div>
                <div class="f12 lh15"> <!--{if $v[ptmin]==1}-->{lang xigua_pt:ljgm}<!--{else}-->{lang xigua_pt:ddgm}<!--{/if}--></div>
            </a>
        </div>
        <!--{if $v[ptmin]>1}-->
        <div class="weui-flex__item in_bottom_y in_bottom_main">
            <a href="javascript:;" class="bgcolor_sec mc_bg buynow" data-type="2">
                <div class="fqpd">&yen;$v[price_pt_min]</div>
                <div class="f12 lh15">{lang xigua_pt:fqpt}</div>
            </a>
        </div>
        <!--{/if}-->
    </div>

</div>

<div id="poup_srange_ary" class="weui-popup__container popup-bottom" style="z-index:1001">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:quxiao}</a>
                <h1 class="title"><em class="titem"></em>{lang xigua_pt:fwsm}</h1>
            </div>
        </div>
        <div class="modal-content paygg">
            <div class="weui-cells before_none after_none" style="padding-bottom:120px">
                <!--{eval $sviceranges = array();}-->
                <!--{loop $svicerange $_rangk $_rangv}-->
                <!--{eval
                    list($_rangt, $_rangd) = explode("#", $_rangv);
                    $sviceranges[$_rangt] = $_rangd;
                }-->
                <!--{/loop}-->
                <!--{loop $v[srange_ary] $k $__v}-->
                <div class="weui-cell before_none">
                    <div class="weui-cell__hd">
                        <i class="iconfont icon-duigou2 main_color mr15"></i>
                    </div>
                    <div class="weui-cell__bd">
                        <p class="f14">{$__v}</p>
                        <p class="f12 c9">{$sviceranges[$__v]}</p>
                    </div>
                </div>
                <!--{/loop}-->
            </div>
        </div>
    </div>
</div>

<!--{template xigua_pt:payitem}-->
<!--{eval $tabbar=0;}-->
<!--{template xigua_pt:qrcode}-->
<!--{template xigua_pt:footer}-->
<script>
var loadingurl = window.location.href+'&ac=cat_li&cat_id={$v[hangye_id1]}&inajax=1&page=';
setTimeout(function(){
    ptclock();
}, 1000);
<!--{if $ptuserlist}-->
$('#popup_item').popup();
$('#buy_type').val('2');
$('#tuan_id').val('$tuan_id');
$('#pricePt').show();
$('#priceDm').hide();
$.toptip('{$tuanzhang[username]}{lang xigua_pt:yqnpt},{$ptuserlist[0][shixian_u]}{lang xigua_pt:zqyx}', 300000 ,'warning');
$('.weui-toptips').css('z-index', '1001');
<!--{/if}-->
<!--{if $spcount<=1}-->
$('.buy-tags').each(function(){var t = $(this);t.find('a:first-child').trigger('click');});
<!--{/if}-->
$('div.cl_swipe').each(function () {
    dp_slider($(this), $(this).data('speed') || 3000)
});
var dp_seiper = null;
function dp_slider(_this, auto) {
    var bullets = _this.find('nav.bullets');
    var position = _this.find('ul.position');
    dp_seiper = new Swipe2(_this[0], {
        visibilityFullFit : true,
        startSlide: 0, speed: 500, auto: auto, continuous: true, callback: function (index) {
            if (bullets.length > 0) {
                bullets.find('em:first-child').text(index + 1);
            }
            if (position.length > 0) {
                var selectors = position[0].children;
                for (var t = 0; t < selectors.length; t++) {
                    selectors[t].className = selectors[t].className.replace("current", "");
                }
                if (typeof selectors[(index) % (selectors.length)] != 'undefined') {
                    selectors[(index) % (selectors.length)].className = "current";
                }
            }
            var H = $(".swipe-wrap .swp").eq(index).height();
            $('.cl_swipe .swipe-wrap').css('height', H);
            $('.cl_swipe').css('height', H);
        }
    });
}
var _H1 = $(".swipe-wrap .swp:first-child").height();
$('.cl_swipe .swipe-wrap').css('height', _H1);
$('.cl_swipe').css('height', _H1);
</script>