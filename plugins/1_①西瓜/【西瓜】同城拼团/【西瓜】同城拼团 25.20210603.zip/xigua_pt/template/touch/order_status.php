<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $v[goodshot][fee_type]==1}-->
    <!--{if !$_GET[manage]}-->
        <!--{if $v[jumpurl] }-->
            <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default cancel_order " data-id="$v[id]">{lang xigua_pt:qxdd}</a>
            <a href="$v[jumpurl]" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_pt:ljzf}</a>
        <!--{elseif $v[status] == 5}-->
            <a class="mt0 weui-btn weui-btn_mini weui-btn_primary" href="$SCRITPTNAME?id=xigua_pt&ac=invite&ptlog_id=$v[id]{$urlext}">{lang xigua_pt:yqhyp}</a>
        <!--{elseif in_array($v[status], array(2,6)) && ($v[shou_ts]==-1||$v[fa_ts]==-1)}-->
        <!--{if $v[fa_ts]>1}-->
            <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default qrsh" data-id="$v[id]" data-title="{lang xigua_pt:qrsh}?<p>{lang xigua_pt:qsdsphzqr}</p>">{lang xigua_pt:qrsh}</a>
        <!--{else}-->
        <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_pt:dfh}</a>
        <!--{/if}-->
        <!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->
            <a href="$SCRITPTNAME?id=xigua_pt&ac=view&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_pt:zcgm}</a>
        <!--{elseif in_array($v[status], array(3,4,7)) }-->
            <a href="$SCRITPTNAME?id=xigua_pt&ac=view&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_pt:zcgm}</a>
        <!--{/if}-->
    <!--{else}-->
        <!--{if $v[jumpurl] }-->
        <a href="javascript:;" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_pt:ddzf}</a>
        <!--{elseif $v[status] == 5}-->
        <a class="mt0 weui-btn weui-btn_mini weui-btn_primary" href="javascript:;">{lang xigua_pt:ptz}</a>
        <!--{elseif $v[status] == 3}-->
        <a class="mt0 weui-btn weui-btn_mini weui-btn_primary dotk" href="javascript:;" data-redund="$v[refund_id]">{lang xigua_pt:cltk}</a>
        <!--{elseif in_array($v[status], array(2,6)) && ($v[shou_ts]==-1||$v[fa_ts]==-1)}-->
        <!--{if $v[fa_ts]>1}-->
        <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_pt:ddqrsh}</a>
        <!--{else}-->
        <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default fahuo" data-id="$v[id]" data-title="{lang xigua_pt:qrfh}<p class='f14'>{lang xigua_pt:shr}: {$v[realname]} {$v[mobile]} <br>{lang xigua_pt:dz}: {$v[addr]}</p>">{lang xigua_pt:djfh}</a>
        <!--{/if}-->
        <!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->
        <a class="f12">{lang xigua_pt:ysh} {$v[shou_ts_u]}</a>
        <!--{elseif in_array($v[status], array(3,4,7)) }-->
        <!--{/if}-->
    <!--{/if}-->
<!--{elseif $v[goodshot][fee_type]==2}-->
    <!--{if !$_GET[manage]}-->
        <!--{if $v[jumpurl] }-->
            <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default cancel_order " data-id="$v[id]">{lang xigua_pt:qxdd}</a>
            <a href="$v[jumpurl]" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_pt:ljzf}</a>
        <!--{elseif $v[status] == 5}-->
            <a class="mt0 weui-btn weui-btn_mini weui-btn_primary" href="$SCRITPTNAME?id=xigua_pt&ac=invite&ptlog_id=$v[id]{$urlext}">{lang xigua_pt:yqhyp}</a>
        <!--{elseif in_array($v[status], array(2,6)) && ($v[shou_ts]==-1||$v[fa_ts]==-1)}-->
<!--{if $v[goodshot][usetime]<TIMESTAMP}--><a class="pt_btn_dft weui-btn weui-btn_mini">{lang xigua_pt:ygq}</a><!--{/if}-->
            <a class="pt_btn_dft weui-btn weui-btn_mini use-btn" data-tip="{lang xigua_pt:csgdy}" data-chushi="{lang xigua_pt:ddcs}" data-src="$SCRITPTNAME?id=xigua_pt&ac=com&do=showqr&ptlog_id={$v[id]}{$urlext}">{lang xigua_pt:djsy}</a>
        <!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->
            <a href="$SCRITPTNAME?id=xigua_pt&ac=view&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_pt:zcgm}</a>
        <!--{elseif in_array($v[status], array(3,4,7)) }-->
            <a href="$SCRITPTNAME?id=xigua_pt&ac=view&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_pt:zcgm}</a>
        <!--{/if}-->
    <!--{else}-->
            <!--{if $v[jumpurl] }-->
                <a href="javascript:;" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_pt:ddzf}</a>
            <!--{elseif $v[status] == 5}-->
                <a class="mt0 weui-btn weui-btn_mini weui-btn_primary" href="javascript:;">{lang xigua_pt:ptz}</a>
            <!--{elseif $v[status] == 3}-->
                <a class="mt0 weui-btn weui-btn_mini weui-btn_primary dotk" href="javascript:;" data-redund="$v[refund_id]">{lang xigua_pt:cltk}</a>
            <!--{elseif in_array($v[status], array(2,6)) && ($v[shou_ts]==-1||$v[fa_ts]==-1)}-->
                <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_pt:yfkdhx}</a>
            <!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->
                <a class="f12">{lang xigua_pt:yhxhxsj} {$v[shou_ts_u]}</a>
            <!--{/if}-->
    <!--{/if}-->
<!--{/if}-->
<!--{if $ac !='order_profile'}-->
<a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default pt_good mt0" data-id="$v[id]" <!--{if $_GET[manage]}-->data-manage="1"<!--{/if}-->>{lang xigua_pt:ddxq}</a>
<!--{/if}-->

<!--{if $v['allowtk']}-->
<a href="javascript:;" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0 dotuikuan" data-ptlogid="{$v[id]}">{lang xigua_pt:th}</a>
<!--{/if}-->

<!--{if !$_GET[manage] && $v['status']==3 && $v['refund_id']>0}-->
<a href="javascript:;" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0 canceltuikuan" data-ptlogid="{$v[id]}">{lang xigua_pt:qxtk}</a>
<!--{/if}-->