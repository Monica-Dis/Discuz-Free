<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $v[refund_id]}-->
<!--{eval $refund= C::t('#xigua_pt#xigua_pt_refund')->fetch_by_id($v[refund_id]);}-->
<!--{/if}-->
<!--{eval $status = $v[status];}-->
<!--{if $v[status]==5}-->
<div class="pro_top main_bg" style="background-image:url(source/plugin/xigua_pt/static/status_{$v[status]}.png);">
    <p>{lang xigua_pt:ptwcg}</p>
    <p>{lang xigua_pt:yqxhb}</p>
</div>
<!--{elseif in_array($v[status], array(3,4,7))}-->
<div class="pro_top main_bg">
    <p>{lang xigua_pt:ddyqx}</p>
    <!--{if $v[status]==7}-->
    <p>{lang xigua_pt:pdsbytk}</p>
    <!--{/if}-->
    <!--{if $v[status]==3}-->
    <p>{lang xigua_pt:status_3} <span class="f12">{lang xigua_pt:sqsj} $refund[crts_u]</span></p>
    <!--{/if}-->
    <!--{if $v[status]==4}-->
    <p>{lang xigua_pt:status_44} <span class="f12">{lang xigua_pt:tksj} $refund[upts_u]</span></p>
    <!--{/if}-->
</div>
<!--{elseif in_array($v[status], array(2,6))}-->
<div class="pro_top main_bg">
    <p>{$status_font[$status]}</p>
    <!--{if $v[goodshot][fee_type]==1}-->
        <!--{if $v[fa_ts]==-1}-->
        <p>{lang xigua_pt:dfh}</p>
        <!--{elseif $v[shou_ts]==-1}-->
        <p>{lang xigua_pt:dshuo}</p>
        <p>{lang xigua_pt:kd}: {$v[yundan_gs]}</p>
        <p>{lang xigua_pt:ydh}: {$v[yundan]}</p>
        <!--{elseif $v[shou_ts]>1}-->
        <p>{lang xigua_pt:ysh} {$v[shou_ts_u]}</p>
        <p>{lang xigua_pt:kd}: {$v[yundan_gs]}</p>
        <p>{lang xigua_pt:ydh}: {$v[yundan]}</p>
        <!--{/if}-->
    <!--{if $v[yundan]}-->
    <a href="https://m.kuaidi100.com/result.jsp?nu={$v[yundan]}" target="_blank">{lang xigua_pt:kdgz}&raquo;</a>
    <!--{/if}-->
    <!--{elseif $v[goodshot][fee_type]==2}-->
        <!--{if $v[fa_ts]==-1}-->
            <p>{lang xigua_pt:wsyhxm} {$v[hxcode]}</p>
        <!--{elseif $v[shou_ts]==-1}-->
            <p>{lang xigua_pt:wsyhxm} {$v[hxcode]}</p>
        <!--{elseif $v[shou_ts]>1}-->
            <p>{lang xigua_pt:yhxhxsj} {$v[shou_ts_u]}</p>
        <!--{/if}-->
    <!--{/if}-->
</div>
<!--{/if}-->



