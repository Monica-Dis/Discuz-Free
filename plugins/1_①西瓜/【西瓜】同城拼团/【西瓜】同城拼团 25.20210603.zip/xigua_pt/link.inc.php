<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2016/9/30
 * Time: 9:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$t =lang('plugin/xigua_hb','fangwen'). $_G['siteurl'].'plugin.php?id=xigua_pt&mobile=2<br><p style="display:none">'.lang('plugin/xigua_hb','jiaocheng').'http://dism.taobao.com/?@xigua_hb.plugin.75088</p>';
cpmsg($t, '','succeed');