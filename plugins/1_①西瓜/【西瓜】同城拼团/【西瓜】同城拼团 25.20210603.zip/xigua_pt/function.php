<?php
/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function lang_pt($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_pt', $lang);
    }else{
        return lang('plugin/xigua_pt', $lang);
    }
}
function get_shids_by_uid(){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){ return $shids;}
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array('xigua_hs_shanghu',$_G['uid']),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array('xigua_hs_yuan',$_G['uid']),'shid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    return $shids;
}
function pt_nl2br($txt){
    if(strpos($txt, '&lt;') !== false  && strpos($txt, '&gt;') !== false) {
        $txt = htmlspecialchars_decode($txt);
        $txt = preg_replace(array("/<script(.*?)<\/script>/is", '/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('', ''), $txt);
    }
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}
function combination($arguments){
    $array = array();
    foreach ($arguments as $argument) {
        if (is_array($argument) === true) {
            $array[] = $argument;
        } else {
            $array[] = array($argument);
        }
    }
    $size = count($array);
    if ($size === 0) {
        return array();
    } else if ($size === 1) {
        return is_array($array[0]) === true ? $array[0] : array();
    } else {
        $result = array();
        $a = $array[0];
        array_shift($array);
        if (is_array($array) === false) {
            return $result;
        }

        foreach ($a as $val) {
            $b = call_user_func_array("combination", array($array));
            foreach ($b as $c) {
                if (is_array($c) === true) {
                    $result[] = array_merge(array($val), $c);
                } else {
                    $result[] = array($val, $c);
                }
            }
        }
        return $result;
    }
}
function callback_pt_pay($param){
    global $_G;
    $data = $param['info']['data'];
    $updatestock = C::t('#xigua_pt#xigua_pt_good_price')->update_stock($data['priceid'], $data['gnum']);
    if($updatestock){
        DB::query("UPDATE %t SET sellnum=sellnum+{$data['gnum']} WHERE id=%d", array(
            'xigua_pt_good',
            $data['gid']
        ));
        if($data['buy_type'] == 1){
            $good = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($data['gid'], 0);
            $sec = array('status' => 2, 'pay_ts' => TIMESTAMP, );
            if($good['fee_type']==2){
                $sec['hxcode'] = substr(mt_rand(10000000, 99999999), 0, 8);
            }
            C::t('#xigua_pt#xigua_pt_order')->update($data['id'], $sec);
            $usr = getuserbyuid($data['uid']);
            notification_add($data['uid'],'system', "<a href=\"{url}\">".lang('plugin/xigua_pt', 'gxgmcg').$data['title'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&ptlog_id='.$data['id']),1);
            $shuid = DB::result_first('SELECT uid FROM %t WHERE shid=%d', array('xigua_hs_shanghu', $data['shid']));
            if($shuid){
                notification_add($shuid,'system', "<a href=\"{url}\">".$usr['username'].lang('plugin/xigua_pt', 'gggml').$data['title'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&manage=1&ptlog_id='.$data['id']),1);
            }
            if($good['backprice']>0 && $good['backprice']<=5){
                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($data['uid'], 'money', $good['backprice']);
                C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                    'uid'  => $data['uid'],
                    'crts' => TIMESTAMP,
                    'size' => $good['backprice'],
                    'note' => lang('plugin/xigua_pt', 'backprice1').$good['backprice'].lang('plugin/xigua_pt', 'yuan'),
                    'link' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&ptlog_id='.$data['id'],
                ));
            }
        }else{
            $good = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($data['gid'], 0);
            $hxcode = '';
            if($good['fee_type']==2){
                $hxcode = substr(mt_rand(10000000, 99999999), 0, 8);
            }
            C::t('#xigua_pt#xigua_pt_order')->update($data['id'], array('hxcode' => $hxcode, 'status' => 5, 'pay_ts' => TIMESTAMP,'shixian' => (TIMESTAMP+($good['ptshixian']*3600)) ));
            if($data['tuan_id']> 0){
                DB::query("UPDATE %t SET tuan_num=tuan_num+1 WHERE id=%d", array(
                    'xigua_pt_order',
                    $data['tuan_id']
                ));
                $tuan_num = DB::result_first("SELECT tuan_num from %t where id=%d AND pay_ts>0", array('xigua_pt_order',$data['tuan_id']));
                if($tuan_num>=$good['ptmin']){
                    C::t('#xigua_pt#xigua_pt_order')->update($data['tuan_id'],  array('status' => 6, 'pt_success_ts' => TIMESTAMP, ));
                    DB::query("update %t set status=%d, pt_success_ts=%d WHERE tuan_id=%d AND pay_ts>0", array(
                        'xigua_pt_order',
                        6,
                        TIMESTAMP,
                        $data['tuan_id']
                    ));
                }
            }elseif ($good['ptmin'] == 1){
                C::t('#xigua_pt#xigua_pt_order')->update($data['id'],  array('status' => 6, 'pt_success_ts' => TIMESTAMP, ));
            }
            if($data['tuan_id']){
                $tuanzhanglog = C::t('#xigua_pt#xigua_pt_order')->fetch($data['tuan_id']);
                $tuanzhang = getuserbyuid($tuanzhanglog['uid']);
                if($tuan_num && $good['ptmin']>$tuan_num){
                    $usr = getuserbyuid($data['uid']);

                    $ptwrd = lang('plugin/xigua_pt', 'gxpting');
                    $ptwrd = str_replace('n', $good['ptmin']-$tuan_num, $ptwrd);
                    $ptwrd = str_replace('xx', $tuanzhang['username'], $ptwrd);

                    notification_add($data['uid'],'system', "<a href=\"{url}\">".$ptwrd.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&ptlog_id='.$data['id']),1);

                    $pttuanz = lang('plugin/xigua_pt', 'pttuanz');
                    $pttuanz = str_replace('n', $good['ptmin']-$tuan_num, $pttuanz);
                    $pttuanz = str_replace('xx', $usr['username'], $pttuanz);

                    notification_add($tuanzhang['uid'],'system', "<a href=\"{url}\">".$pttuanz.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&ptlog_id='.$data['tuan_id']),1);
                }else{
                    $tuanyuans = DB::fetch_all('select id,uid,tuan_id from %t WHERE tuan_id=%d OR id=%d', array('xigua_pt_order', $data['tuan_id'], $data['tuan_id']), 'uid');

                    $ptsuccesswrd = lang('plugin/xigua_pt', 'ptsuccesswrd');
                    $ptsuccesswrd = str_replace('title', $data['title'], $ptsuccesswrd);
                    $ptsuccesswrd = str_replace('xx', $tuanzhang['username'], $ptsuccesswrd);

                    foreach ($tuanyuans as $tuanyuanuid => $tuanyuan) {

                        if($good['backprice']>0 && $good['backprice']<=5){
                            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($tuanyuanuid, 'money', $good['backprice']);
                            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                                'uid'  => $tuanyuanuid,
                                'crts' => TIMESTAMP,
                                'size' => $good['backprice'],
                                'note' => lang('plugin/xigua_pt', 'backprice1').$good['backprice'].lang('plugin/xigua_pt', 'yuan'),
                                'link' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&ptlog_id='.$tuanyuan['id'],
                            ));
                        }

                        notification_add($tuanyuanuid,'system', "<a href=\"{url}\">".$ptsuccesswrd.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&ptlog_id='.$tuanyuan['id']),1);
                    }
                    $shuid = DB::result_first('SELECT uid FROM %t WHERE shid=%d', array('xigua_hs_shanghu', $data['shid']));
                    $shptsuccess = lang('plugin/xigua_pt', 'shptsuccess');
                    $shptsuccess = str_replace('title', $data['title'], $shptsuccess);
                    $shptsuccess = str_replace('xx', $tuanzhang['username'], $shptsuccess);
                    notification_add($shuid,'system', "<a href=\"{url}\">".$shptsuccess.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&manage=1&ptlog_id='.$data['tuan_id']),1);
                    /*sh*/
                }
            }else{
                $gxfqcg = lang('plugin/xigua_pt', 'gxfqcg');
                notification_add($data['uid'],'system', "<a href=\"{url}\">".$gxfqcg.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=invite&ptlog_id='.$data['id']),1);
                $usr = getuserbyuid($data['uid']);
                $shuid = DB::result_first('SELECT uid FROM %t WHERE shid=%d', array('xigua_hs_shanghu', $data['shid']));
                $ggfqpt = lang('plugin/xigua_pt', 'ggfqpt');
                $ggfqpt = str_replace('title', $data['title'], $ggfqpt);
                $ggfqpt = str_replace('xx', $usr['username'], $ggfqpt);
                notification_add($shuid,'system', "<a href=\"{url}\">".$ggfqpt.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_pt&ac=order_profile&manage=1&ptlog_id='.$data['id']),1);
                /*sh*/
            }
        }
    }
    return true;
}

function pt_qrcode_make($ptlog_id, $code){
    global $_G, $config,$SCRITPTNAME,$urlext;
    $repath = './source/plugin/xigua_pt/cache/';
    $qrfile = $repath . $code . '.png';
    $abs_qrfile = DISCUZ_ROOT . $qrfile;
    $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_pt&ac=order_profile&ptlog_id=$ptlog_id&code=$code".$urlext;

    if(!is_file($abs_qrfile)) {
        if (!is_file($abs_qrfile)) {
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
            }
        }
    }
    return $qrfile;
}