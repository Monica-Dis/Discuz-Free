<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function job_dig_callback($param){
    global $_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];

    $jobid = intval($data['jobid']);
    $job = C::t('#xigua_job#xigua_job_job')->fetch($jobid);
    $last = intval($data['last'])*86400;
    C::t('#xigua_job#xigua_job_job')->update($jobid, array('dig_crts' => TIMESTAMP, 'dig_endts' => max($job['dig_endts'], TIMESTAMP)+$last));
    return true;
}

function job_resume_callback($param){
    global $_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];

    $rsid = intval($data['rsid']);
    $resume_v = C::t('#xigua_job#xigua_job_resume')->fetch_by_rsid($rsid);
    $last = intval($data['last'])*86400;
    C::t('#xigua_job#xigua_job_resume')->update($rsid, array(
        'digtype' => $data['last'],
        'dig_crts' => TIMESTAMP,
        'dig_endts' => max($resume_v['dig_endts'], TIMESTAMP)+$last
    ));
    return true;
}

function job_taocan_callback($param){
    global $_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];
    $data['order_id'] = $param['order_id'];
    C::t('#xigua_job#xigua_job_taocan')->insert_G($data);
    return true;
}
