<?php
/**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_job_resume extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_job_resume';
        $this->_pk = 'rsid';

        parent::__construct(); /*dism·taobao·com*/
    }

    public function get_next($id)
    {
        $rskey = $this->_pk;
        return DB::result_first("select $rskey from %t WHERE $rskey<%d order by $rskey desc", array(
            $this->_table,
            $id
        ));
    }

    public function fetch_by_rsid($rsid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE rsid=%d', array($this->_table, $rsid));
        return self::_prepare($first);
    }

    public function fetch_by_uid($uid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
        return self::_prepare($first);
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $field = '*', $orderby = 'upts DESC', $key_field = '')
    {
        global $_G;
        if($_GET['st'] && $_G['cache']['plugin']['xigua_st']['showzong']){
            $_stid = intval($_GET['st']);
            foreach ($wherearr as $index => $item) {
                if('stid='.$_stid == $item){
                    unset($wherearr[$index]);
                    break;
                }
            }
            $wherearr[] = "( stid=$_stid OR stid=0 )";
        }
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }else{
            $orderby = '';
        }
        $wherearr[] = 'qiustatus!=\''.lang('plugin/xigua_job', 'qzzt5').'\'';
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $orderby " . DB::limit($start_limit, $lpp));
        $return = array();
        foreach ($result as $index => $item) {
            if($key_field){
                $return[$item[$key_field]] = self::_prepare($item);
            }else{
                $return[$index] = self::_prepare($item);
            }
        }
        return $return;
    }

    public function get_order($viewtype)
    {
        global $job_config;
        $field = '*';
        $order_by = 'ORDER BY dig_endts DESC,upts desc';
        switch ($viewtype){
            case "upts":
                $order_by = 'upts DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                switch ($job_config['digorder']){
                    case '3':
                        $order_by = 'distance ASC, dig_crts DESC, dig_endts DESC';
                        break;
                    case '2':
                        $order_by = 'distance ASC, dig_endts DESC';
                        break;
                    default:
                        $order_by = 'distance ASC, (dig_endts-dig_crts) DESC';
                        break;
                }
                break;
            case 'guanzhu':
                $order_by = 'favs DESC';
                break;
            case 'fenxiang':
                $order_by = 'shares DESC';
                break;
            default:
                switch ($job_config['digorder']){
                    case '3':
                        $order_by = ' dig_crts DESC, dig_endts DESC, upts DESC ';
                        break;
                    case '2':
                        $order_by = 'dig_endts DESC, upts DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_crts) DESC, upts DESC ';
                        break;
                }
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['rsid']);
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        if(IS_ADMINID){
            return DB::update($this->_table, $data, array(
                'rsid'  => $id,
            ));
        }else{
            return DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                'rsid'  => $id,
            ));
        }
    }

    public static function _prepare($item)
    {
        if($item){
            global $gender_ary;
            if(!$item['realname']){
                $member = getuserbyuid($item['uid'], 1);
                if($member['username']){
                    DB::query("update %t set realname=%s WHERE rsid=%d", array('xigua_job_resume',$member['username'], $item['rsid']));
                    $item['realname'] = $member['username'];
                }
            }
            $item['goodat_ary'] = $item['goodat']?explode(',', $item['goodat']) : array();
            $item['jobwant_ary'] = explode(',', $item['jobwant']);
            $item['jobwant_str_ary'] = explode(',', $item['jobwant_str']);
            $item['areawant_ary'] = explode(',', $item['areawant']);
            $item['areawant_str_ary'] = explode(',', $item['areawant_str']);
            $item['age'] = date('Y') - $item['birth'];
            $item['gender_str'] = $gender_ary[$item['gender']];
//            $item['firstname'] = self::splitName($item['realname'], $item['gender']);
            $item['album'] = $item['album'] ? unserialize($item['album']) : array();
            $item['is_dig'] = $item['dig_endts']>TIMESTAMP ? 1:0;
            $item['dig_endts_u']  = $item['dig_endts'] ? dgmdate($item['dig_endts'], 'u') : '';
            if(!$item['is_dig'] && $item['dig_endts']){
                DB::query("update %t set dig_crts=0,dig_endts=0 WHERE rsid=%d", array('xigua_job_resume',  $item['rsid']));
            }
            $item['upts_u']  = dgmdate($item['upts'], 'u');
            $item['crts_u']  = dgmdate($item['crts'], 'u');
            $item['workexp_ary']  = $item['workexp'] ? array_filter(unserialize($item['workexp'])) : array();
            $item['eduexp_ary']  = $item['workexp'] ? array_filter(unserialize($item['eduexp'])) : array();
        }
        return $item;
    }

    public function incr($id, $field, $num = 1)
    {
        global $_G;
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }

    public function total_views()
    {
        global $_G, $config, $job_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);

        $key = 'rs_views'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return+$job_config['xnlll'];
    }

    public function total_resumes()
    {
        global $_G, $config, $job_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);

        $key = 'rs_count'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT count(*) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return+$job_config['xnjjl'];
    }

    /*public static function splitName($fullname, $gender){
        $fullname = diconv($fullname, CHARSET, 'utf-8');
        $hyphenated = array('欧阳','太史','端木','上官','司马','东方','独孤','南宫','万俟','闻人','夏侯','诸葛','尉迟','公羊','赫连','澹台','皇甫',
            '宗政','濮阳','公冶','太叔','申屠','公孙','慕容','仲孙','钟离','长孙','宇文','城池','司徒','鲜于','司空','汝嫣','闾丘','子车','亓官',
            '司寇','巫马','公西','颛孙','壤驷','公良','漆雕','乐正','宰父','谷梁','拓跋','夹谷','轩辕','令狐','段干','百里','呼延','东郭','南门',
            '羊舌','微生','公户','公玉','公仪','梁丘','公仲','公上','公门','公山','公坚','左丘','公伯','西门','公祖','第五','公乘','贯丘','公皙',
            '南荣','东里','东宫','仲长','子书','子桑','即墨','达奚','褚师');
        $vLength = mb_strlen($fullname, 'utf-8');
        $lastname = '';
        $firstname = '';
        if($vLength > 2){
            $preTwoWords = mb_substr($fullname, 0, 2, 'utf-8');
            if(in_array($preTwoWords, $hyphenated)){
                $lastname = $preTwoWords;
                $firstname = mb_substr($fullname, 2, 10, 'utf-8');
            }else{
                $lastname = mb_substr($fullname, 0, 1, 'utf-8');
                $firstname = mb_substr($fullname, 1, 10, 'utf-8');
            }
        }else if($vLength == 2){
            $lastname = mb_substr($fullname ,0, 1, 'utf-8');
            $firstname = mb_substr($fullname, 1, 10, 'utf-8');
        }else{
            $lastname = $fullname;
        }
        $lastname = $lastname.($gender==2 ? '女士': '先生');
        $lastname = diconv($lastname, 'UTF-8', CHARSET);
        return $lastname;
    }*/
}