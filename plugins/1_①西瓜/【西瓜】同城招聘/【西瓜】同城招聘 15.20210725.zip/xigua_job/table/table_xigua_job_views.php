<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_job_views extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_job_views';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }
    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first("select * from %t WHERE {$this->_pk}=%d AND uid=%d", array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::_prepare($r);
        return $r;
    }

    public function fetch_by_id($id)
    {
        $first = DB::fetch_first("SELECT * FROM %t WHERE {$this->_pk}=%d", array($this->_table, $id));
        return self::_prepare($first);
    }

    public function fetch_by_uid($uid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
        return self::_prepare($first);
    }

    public function fetch_by_jobid($uid, $jobid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE jobid=%d AND uid=%d', array($this->_table, $jobid, $uid));
        return self::_prepare($first);
    }

    public function fetch_by_uid_rsid($uid, $rsid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND rsid=%d', array($this->_table, $uid, $rsid));
        return self::_prepare($first);
    }

    public function fetch_by_uid_jobid($uid, $jobid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND jobid=%d', array($this->_table, $uid, $jobid));
        return self::_prepare($first);
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $orderby = 'id DESC', $key_field = '')
    {
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql $orderby " . DB::limit($start_limit, $lpp));
        $return = array();
        foreach ($result as $index => $item){
            if($key_field){
                $return[$item[$key_field]] = self::_prepare($item);
            }else{
                $return[$index] = self::_prepare($item);
            }
        }
        return $return;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        $KEY = $this->_pk;
        if(IS_ADMINID){
            return DB::update($this->_table, $data, array(
                $KEY  => $id,
            ));
        }else{
            return DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                $KEY  => $id,
            ));
        }
    }

    public static function _prepare($item)
    {
        if($item){
            $item['crts_u']  = dgmdate($item['crts'], 'u');
            $item['upts_u']  = $item['upts'] ? dgmdate($item['upts'], 'u') : '';
        }
        return $item;
    }
}