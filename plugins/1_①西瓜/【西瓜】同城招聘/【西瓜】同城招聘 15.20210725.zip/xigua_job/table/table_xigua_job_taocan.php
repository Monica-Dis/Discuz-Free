<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_job_taocan extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_job_taocan';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }
    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first("select * from %t WHERE {$this->_pk}=%d AND uid=%d", array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::_prepare($r);
        return $r;
    }

    function insert_G($data){
        $data['upts'] = TIMESTAMP;
        $row = $this->fetch_by_uid($data['uid']);
        if($row && !$row['is_end']){
            $endts = max(TIMESTAMP, $row['endts'])+$data['days']*86400;
            DB::query('UPDATE %t SET `name`=%s,xiazai=xiazai+%d,upts=%d,price=%s,fabu=fabu+%d,zhiding=%s,endts=%d,days=%d,order_id=%s,payts=%d WHERE id=%d', array(
                $this->_table,
                $data['name'],
                $data['xiazai'],
                TIMESTAMP,
                $data['price'],
                $data['fabu'],
                $data['zhiding'],
                $endts,
                $data['days'],
                $data['order_id'],
                TIMESTAMP,
                $row['id'],
            ));
        }else{
            $data['crts'] = TIMESTAMP;
            $data['payts'] = TIMESTAMP;
            $data['endts'] = TIMESTAMP+$data['days']*86400;
            $this->insert($data, 1, 1);
        }
    }

    public function fetch_by_id($id)
    {
        $first = DB::fetch_first("SELECT * FROM %t WHERE {$this->_pk}=%d", array($this->_table, $id));
        return self::_prepare($first);
    }

    public function fetch_by_uid($uid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
        return self::_prepare($first);
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $needuser = 0)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp));
        $uids = array();
        foreach ($result as $index => $item) {
            $uids[] = $item['uid'];
            $result[$index] = self::_prepare($item);
        }
        if($needuser && $uids){
            if($uids){
                $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            }
            foreach ($result as $index => $item) {
                $result[$index]['username'] = $users[$item['uid']]['username'];
            }
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        $KEY = $this->_pk;
        if(IS_ADMINID){
            return DB::update($this->_table, $data, array(
                $KEY  => $id,
            ));
        }else{
            return DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                $KEY  => $id,
            ));
        }
    }

    public static function _prepare($item)
    {
        if($item){
            $item['is_end'] = $item['endts']<=TIMESTAMP;
            $item['endts_u'] = $item['endts'] ? dgmdate($item['endts'], 'u') : '';
            $item['crts_u'] = $item['crts'] ? dgmdate($item['crts'], 'u') : '';
            $item['upts_u'] = $item['upts'] ? dgmdate($item['upts'], 'u') : '';
            $item['payts_u'] = $item['payts'] ? dgmdate($item['payts'], 'u') : '';

            if($item['zhiding']>0){
                $item['zhiding'] = floatval($item['zhiding']);
            }else{
                $item['zhiding'] = '';
            }
        }
        return $item;
    }

    public function incr($id, $field, $num = 1)
    {
        global $_G;
        return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
    }
}