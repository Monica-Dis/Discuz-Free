<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_job_job extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_job_job';
        $this->_pk = 'jobid';

        parent::__construct(); /*dism��taobao��com*/
    }
    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first("select * from %t WHERE {$this->_pk}=%d AND uid=%d", array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::_prepare($r);
        return $r;
    }

    public function fetch_by_id($id)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE jobid=%d', array($this->_table, $id));
        return self::_prepare($first);
    }

    public function fetch_by_uid($uid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
        return self::_prepare($first);
    }

    public function get_my_jobids($uid)
    {
        return DB::fetch_all('select * from %t where uid=%d', array($this->_table, $uid), 'jobid');
    }

    public function fetch_by_uid_type($uid, $type)
    {
        if($uid<1){
            return false;
        }
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND `type`=%s AND status=2', array($this->_table, $uid, $type));
        return self::_prepare($first);
    }

    public function fetch_hy_by_uid_type($uid, $type)
    {
        if($uid<1){
            return false;
        }
        $first = DB::fetch_all('SELECT hy,hangye_id1,hangye_id2 FROM %t WHERE uid=%d AND `type`=%s AND status=2', array($this->_table, $uid, $type));
        return $first;
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $needuser = 0, $field = '*' ,$orderby = '')
    {
        global $_G;
        if($_GET['st'] && $_G['cache']['plugin']['xigua_st']['showzong']){
            $_stid = intval($_GET['st']);
            foreach ($wherearr as $index => $item) {
                if('stid='.$_stid == $item){
                    unset($wherearr[$index]);
                    break;
                }
            }
            $wherearr[] = "( stid=$_stid OR stid=0 )";
        }
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }else{
            $orderby = '';
        }
        if(!defined('IN_ADMINCP') && $_GET['ac']=='job_li' && $_GET['shid']){
            $wherearr[] = 'shid='.intval($_GET['shid']);
            $needuser = 0;
        }
        if($_GET['nouser']){
            $needuser = 0;
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $orderby " . DB::limit($start_limit, $lpp));
        $uids = array();
        foreach ($result as $index => $item) {
            $uids[] = $item['uid'];
            $result[$index] = self::_prepare($item);
        }
        if($needuser && $uids){
            if($uids){
                $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            }
            foreach ($result as $index => $item) {
                $result[$index]['username'] = $users[$item['uid']]['username'];
            }
        }
        if($_GET['order'] == 'near'){
            foreach ($result as $k => $v) {
                $distance = intval($v['distance']);
                if($distance<=1000){
                    $distance = intval($distance). 'm';
                }else if($distance>1000){
                    $distance = round($distance/1000, 1). 'km';
                }
                $result[$k]['distance'] = $distance;
            }
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['jobid']);
        unset($data['uid']);
        unset($data['crts']);
        $KEY = $this->_pk;
        if(IS_ADMINID){
            return DB::update($this->_table, $data, array(
                $KEY  => $id,
            ));
        }else{
            return DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                $KEY  => $id,
            ));
        }
    }

    public static function _prepare($item)
    {
        global $gender_ary;
        if($item){
            if($item['dig_endts'] && $item['dig_endts']<TIMESTAMP){
                $item['dig_endts'] = 0;
                $item['dig_crts'] = 0;
                DB::query("update %t set dig_endts=0,dig_crts=0 WHERE jobid=%d", array('xigua_job_job',  $item['jobid']));
            }
            $item['type_u'] = $item['type'] == 'full' ? lang('plugin/xigua_job', 'full') :  lang('plugin/xigua_job', 'part');
            $item['upts_u']  = dgmdate($item['upts'], 'u');
            $item['crts_u']  = dgmdate($item['crts'], 'u');
            $item['endts_u']  = dgmdate($item['endts'], 'u');
            $item['dig_endts_u']  = $item['dig_endts'] ? dgmdate($item['dig_endts'], 'u') : '';
            $item['fuli_ary']  = array_filter(explode(',', $item['fuli']));
            $item['gender_u'] = $gender_ary[$item['gender']];
            $item['album'] = $item['album'] ? unserialize($item['album']) : array();
            $item['hy_ary'] = array_filter(explode(' ', $item['hy']));
            $item['is_dig'] = $item['dig_endts']>TIMESTAMP ? 1:0;
        }
        return $item;
    }

    public function get_order($viewtype)
    {
        global $job_config;
        $field = '*';
        $order_by = 'ORDER BY dig_endts DESC,upts desc';
        switch ($viewtype){
            case "upts":
                $order_by = 'upts DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                switch ($job_config['digorder']){
                    case '3':
                        $order_by = 'distance ASC, dig_crts DESC, dig_endts DESC';
                        break;
                    case '2':
                        $order_by = 'distance ASC, dig_endts DESC';
                        break;
                    default:
                        $order_by = 'distance ASC, (dig_endts-dig_crts) DESC';
                        break;
                }
                break;
            case 'guanzhu':
                $order_by = 'favs DESC';
                break;
            case 'fenxiang':
                $order_by = 'shares DESC';
                break;
            default:
                switch ($job_config['digorder']){
                    case '3':
                        $order_by = ' dig_crts DESC, dig_endts DESC, upts DESC ';
                        break;
                    case '2':
                        $order_by = ' dig_endts DESC, upts DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_crts) DESC, upts DESC ';
                        break;
                }
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }

    public function incr($id, $field, $num = 1)
    {
        global $_G;
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }
    public function total_views()
    {
        global $_G, $config, $job_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);

        $key = 'jobviews'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return+$job_config['xnlll'];
    }
    public function total_jobs()
    {
        global $_G, $config, $job_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);

        $key = 'jobcount'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT count(*) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return+$job_config['xnzw'];
    }
}