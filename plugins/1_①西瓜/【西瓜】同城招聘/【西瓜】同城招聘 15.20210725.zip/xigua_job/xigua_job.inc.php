<?php
/**
* Created by https://dism.taobao.com?/?@xigua
* Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958
* Date: 2019/1/21
* Time: 17:42
*/
if(!defined('IN_DISCUZ')){exit('Access Denied');}
$navobj = null;
if(!is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/common.php')){
exit('Please install <a href="https://dism.taobao.com?/?@xigua_hb.plugin">https://dism.taobao.com?/?@xigua_hb.plugin</a>');
}
if(!is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/function.php')){
exit('Please install <a href="https://dism.taobao.com?/?@xigua_hs.plugin">https://dism.taobao.com?/?@xigua_hs.plugin</a>');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
$job_config = $_G['cache']['plugin']['xigua_job'];
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common_status.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/function.php';
job_process();
$opens = unserialize($_G['cache']['plugin']['xigua_job']['opens']);
$pfary = $fsms = $score_names = $score_colors = array();
switch ($ac) {
case 'index':
if($_G['cookie']['is_company']){dsetcookie('is_company', 0, 0);}
$navtitle = str_replace('{tname}', $stinfo['name'], $job_config['defaulttitle']);
$desc     = str_replace('{tname}', $stinfo['name'], $job_config['defaultdesc']);
$topnavslider = hb_parse_set($job_config['topslider']);
$indexstype = job_set_parse($job_config['indexstype']);
if($indexstype> 0){
$subkp = 100/count($indexstype);
$sty_li = "style='width:$subkp%'";
}
$_key = 'job_hangye1';
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    $listjson = $hyobj->list_json();
    $hyobj->init($listjson);
    $jsary = $hyobj->get_tree_array(0);
    savecache($_key, array('variable' => array($listjson, $jsary), 'expiration' => TIMESTAMP));
} else {
    $listjson = $_G['cache'][$_key]['variable'][0];
    $jsary = $_G['cache'][$_key]['variable'][1];
}
$_key = 'hbpubIdist'.intval($_GET['st']);
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
    $distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    $distjsary = array_values($distjsary);
    savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
} else {
    $distjsary = $_G['cache'][$_key]['variable'][0];
}
if($_G['uid']){
    $myresume = $rsobj->fetch_by_uid($_G['uid']);
}
$exthy = array();
foreach ($listjson as $index => $item) {
    if($item['showindex'] && !in_array($item['oname'], $myresume['jobwant_str_ary'])){
        $exthy[$item['code']] = $item['oname'];
    }
}
if(!$_GET['type']){
    $_GET['type'] = 'full';
}
$keyword = daddslashes($_GET['keyword']);
$totalviews = $jobobj->total_views();
$totaljobs = $jobobj->total_jobs();
$total_resume = $rsobj->total_resumes();
$totalviews = job_trans($totalviews, 4,1,1);
$totaljobs = job_trans($totaljobs, 4,1,2);
$total_resume = job_trans($total_resume, 4,1,3);
break;
case 'resume_li':
$where = array();
$where[] = 'status=2';
if($_GET['type']=='full'){
    $where[] = 'fullstatus IN (-1, 1)';
}elseif($_GET['type']=='part'){
    $where[] = 'fullstatus IN (-1, 2)';
}
if($job_config['showfz']&&$_GET['st']>0){
    $where[] = 'stid='.intval($_GET['st']);
}
if($hyid = $_GET['hyid']){
    if(is_numeric($hyid)){
        $where[] = "FIND_IN_SET( $hyid ,jobwant)";
    }
}
if($paywant = $xinzi[$_GET['paywant']]){
    $paywant = daddslashes($paywant);
    $where[] = "paywant = '$paywant'";
}
if($_GET['jingyan']>0 && $_GET['jingyan']!=1 && $_jingyan = $jingyan[$_GET['jingyan']]){
    $_jingyan = daddslashes($_jingyan);
    $where[] = "jingyan = '$_jingyan'";
}
if($_GET['xueli']>0){
    $_xueli = $xueli[$_GET['xueli']];
    $_xueli = daddslashes($_xueli);
    $where[] = "xueli = '$_xueli'";
}
if($_GET['jobwant'] && strpos($_GET['jobwant'], '-1')===false){
    $_jobwant = explode(',', $_GET['jobwant']);
    $str = array();
    foreach ($_jobwant as $index => $item) {
        $item = intval($item);
        $str[] = " FIND_IN_SET($item,jobwant) ";
    }
    if($str){
        $where[] = '('.implode(' OR ', $str).')';
    }
}
if($_GET['areawant'] && strpos($_GET['areawant'], '-1')===false){
    $_areawant = explode(',', $_GET['areawant']);
    $str = array();
    foreach ($_areawant as $index => $item) {
        $item = intval($item);
        $str[] = " FIND_IN_SET($item,areawant) ";
    }
    if($str){
        $where[] = '('.implode(' OR ', $str).')';
    }
}
if($_GET['gender'] && $_GET['gender']!=-1){
    $where[] = 'gender='.intval($_GET['gender']);
}
if($keyword = stripsearchkey($_GET['keyword'])){
    $where[] = " (realname LIKE '%$keyword%' OR jobwant_str LIKE '%$keyword%' OR areawant_str LIKE '%$keyword%' OR paywant LIKE '%$keyword%' OR description LIKE '%$keyword%') ";
}
$get_order = $rsobj->get_order($_GET['order']);
$list = $rsobj->fetch_all_by_page($start_limit, $lpp, $where, $get_order['field'], $get_order['order_by']);
include template('xigua_hb:header_ajax');
include template("xigua_job:$ac");
include template('xigua_hb:footer_ajax');
break;
case 'job_li':
$where = array();
if($_GET['is_my']){
    $where[] = 'uid='.$_G['uid'];
}else{
    $where[] = 'status=2 AND endts>'.TIMESTAMP;
}
if($job_config['showfz']&&$_GET['st']>0){
    $where[] = 'stid='.intval($_GET['st']);
}
if($_GET['type']){
    $where[] = 'type=\''.daddslashes($_GET['type']).'\'';
}
if($_GET['hyid']){
    $hyid = intval($_GET['hyid']);
    $where[] = "(hangye_id2=$hyid OR hangye_id1=$hyid)";
}
if($_GET['not']){
    $notid = intval($_GET['not']);
    $where[] = "(jobid != $notid)";
}
if($paywant = $xinzi[$_GET['paywant']]){
    $paywant = daddslashes($paywant);
    $where[] = "xinzi = '$paywant'";
}
if($_GET['jingyan']>0 && $_GET['jingyan']!=1 && $_jingyan = $jingyan[$_GET['jingyan']]){
    $_jingyan = daddslashes($_jingyan);
    $where[] = "jingyan = '$_jingyan'";
}
if($_GET['xueli']>0){
    $_xueli = $xueli[$_GET['xueli']];
    $_xueli = daddslashes($_xueli);
    $where[] = "xueli = '$_xueli'";
}
if($_GET['areawant'] && strpos($_GET['areawant'], '-1')===false){
    $_areawant = explode(',', $_GET['areawant']);
    $str = array();
    foreach ($_areawant as $index => $item) {
        $item = daddslashes($item);
        $str[] = $item;
    }
    if($str){
        $str = '\''.implode(' \',\' ', $str).'\'';
        $where[] = "(province IN ($str) OR city IN ($str) OR district IN ($str))";
    }
}
if($_GET['gender'] && $_GET['gender']!=-1){
    $where[] = 'gender IN ('.intval($_GET['gender']).', -1)';
}
if($keyword = stripsearchkey($_GET['keyword'])){
    $where[] = " (name LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR fuli LIKE '%$keyword%' OR hy LIKE '%$keyword%' OR miaoshu LIKE '%$keyword%') ";
}
$getorder = $jobobj->get_order($_GET['order']);
$list = $jobobj->fetch_all_by_page($start_limit, $lpp, $where, 1, $getorder['field'],$getorder['order_by']);
if($_G['cache']['plugin']['xigua_hr']['showg'] || $_G['cache']['plugin']['xigua_hr']['showb'] ){
    $uids = $shids = array();
    foreach ($list as $index => $item) {
        $uids[] = $item['uid'];
        $shids[] = $item['shid'];
    }
    if($_G['cache']['plugin']['xigua_hr']['showg']){
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris_bysh($shids);
    }
    if($_G['cache']['plugin']['xigua_hr']['showb']){
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
    }
}
include template('xigua_hb:header_ajax');
include template("xigua_job:$ac");
include template('xigua_hb:footer_ajax');
break;
case 'choose':
$navtitle = lang_job('xzsf',0);
break;
case 'my':
$navtitle = lang_job('qzzx',0);
$custom_side = array("$SCRITPTNAME?id=xigua_hb&ac=myset",lang_job('sz',0));
$totalpub = 0;
$totalviews = 199;
$totalviewme = 200;
$no_header_fix=1;
$status_font = array(
    1 => lang_job('status_1',0),
    2 => lang_job('status_2',0),
    3 => lang_job('status_3',0),
    4 => lang_job('status_4',0),
);
$avatar = avatar($_G['uid'], 'middle', 1);
$viewsstyle = '';
$myresume = $rsobj->fetch_by_uid($_G['uid']);
if($myresume){
    $resumelink = "$SCRITPTNAME?id=xigua_job&ac=resume_view&mine=1$urlext";
}else{
    $resumelink = "$SCRITPTNAME?id=xigua_job&ac=resume$urlext";
}
if($_GET['set'] == 'company'){
    dsetcookie('is_company', 1, 8640000);
}elseif ($_GET['set']=='user'){
    dsetcookie('is_company', 0, 0);
}
if($_G['cookie']['is_company']){
    $backto = urlencode(hb_currenturl());
    $shlink = "$SCRITPTNAME?id=xigua_hs&ac=myshop&mobile=2$urlext&backto=$backto";
    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid='.$_G['uid']), 0, 1);
    if(!$sh){
        $shlink = "$SCRITPTNAME?id=xigua_hs&ac=enter$urlext&backto=$backto";
    }
    $navtitle = lang_job('zpzx',0);
    $taocan = $tcobj->fetch_by_uid($_G['uid']);
    $resumelink = $shlink;
    $qianbao   = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
    $job_ary = $jobobj->get_my_jobids($_G['uid']);
    if(!$job_ary){$job_ary = array(0);}
    $where = array('is_xiazai!=1 AND jobid IN('. implode(',', array_keys($job_ary)) .')');
    $total_rec = C::t('#xigua_job#xigua_job_xiazai')->fetch_count_by_page($where);
    $where2 = array('is_xiazai=1 AND uid='.$_G['uid']);
    $total_xz = C::t('#xigua_job#xigua_job_xiazai')->fetch_count_by_page($where2);
    $total_view = C::t('#xigua_job#xigua_job_views')->fetch_count_by_page(array('uid='.$_G['uid'].' AND rsid>0'));
}else{
    $totaltoudi = C::t('#xigua_job#xigua_job_xiazai')->fetch_count_by_page(array('uid='.$_G['uid'].' AND jobid>0'));
    $total_view = C::t('#xigua_job#xigua_job_views')->fetch_count_by_page(array('uid='.$_G['uid'].' AND jobid>0'));
    $views = $myresume['views'];
}
break;
case 'my_company':
$navtitle = lang_job('fabuguanli',0);
if($job_config['topad1']){
    $topad1 = explode('|', trim($job_config['topad1']));
}
$where = array();
$where[] = 'uid='.$_G['uid'];
$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);

$custom_side = array("$SCRITPTNAME?id=xigua_job&ac=my",lang_job('zpzx',0));
$zhiding_rate = 1;
if($_G['uid']){
    $taocan = $tcobj->fetch_by_uid($_G['uid']);
    $zhiding_rate = $taocan['zhiding']>0?$taocan['zhiding']/10:1;
}
$dig_prices = array();
if($job_config['digtys']){
    foreach (explode("\n", trim($job_config['digtys'])) as $item) {
        list($tmp_type, $tmp_price) = explode('=', trim($item));
        $tmp_lang = lang_hb('days_'.$tmp_type, 0);
        $realprice = round($zhiding_rate*$tmp_price, 2);

        $yuan = lang_hb('yuan', 0);
        $s = "<s class='c9'>$tmp_price$yuan</s>";

        $dig_prices[$tmp_type] = array(
            'type'  => $tmp_type,
            'title' => lang_hb('zhiding', 0). ($tmp_lang == "days_$tmp_type" ? $tmp_type. lang_hb('day', 0) : $tmp_lang) ."(<b class='main_color'>$realprice$yuan</b> $s)",
            'price' => $realprice,
        );
    }
}
break;
case 'mytd':
if($_GET['do']=='li'){
    $where = array();
    $where[] = 'jobid>0 AND uid='.$_G['uid'];
    if($_GET['type'] && $_GET['type']!='yy'){
        $where[] = 'type=\''.daddslashes($_GET['type']).'\'';
    }
    if($_GET['type']=='yy'){
        $where[] = 'status=2';
    }
    $mytd_list = C::t('#xigua_job#xigua_job_xiazai')->fetch_all_by_page($start_limit, $lpp, $where, 'id DESC', 'jobid');
    if($mytd_list){
        $list = $jobobj->fetch_all_by_page($start_limit, $lpp, array('jobid in ('.implode(',', array_keys($mytd_list)).')'), 1, '*');
    }
    include template('xigua_hb:header_ajax');
    include template("xigua_job:job_li");
    include template('xigua_hb:footer_ajax');
}else{
    $navtitle = lang_job('wdtd',0);
    $custom_side = array("$SCRITPTNAME?id=xigua_job&ac=my",lang_hb('wode', 0));
}
break;
case 'resumes':
if(!$_G['cookie']['is_company']){
    dsetcookie('is_company', 1, 8640000);
}
$type = $_GET['type'] ? $_GET['type']:$_GET['form']['type'];
if(!$type){
    $type = $_GET['type'] = 'full';
}
if($type=='full'){
    $navtitle = lang_job('zhao',0).lang_job('full',0);
}elseif($type=='part'){
    $navtitle = lang_job('zhao',0).lang_job('part',0);
}
$desc = str_replace('{tname}', $stinfo['name'], $job_config['defaultdesc']);
$resumenavslider = hb_parse_set($job_config['resume_full']);

$hasjob = $jobobj->fetch_by_uid_type($_G['uid'], $type);

$hys = array();
$_hys = $jobobj->fetch_hy_by_uid_type($_G['uid'], $type);
foreach ($_hys as $index => $_hy) {
    list($_hy1, $_hy2) = explode(' ', $_hy['hy']);
    $hys[$_hy['hangye_id2']] = $_hy2;
}
$_key = 'job_hangye1';
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    $listjson = $hyobj->list_json();
    $hyobj->init($listjson);
    $jsary = $hyobj->get_tree_array(0);
    savecache($_key, array('variable' => array($listjson, $jsary), 'expiration' => TIMESTAMP));
} else {
    $listjson = $_G['cache'][$_key]['variable'][0];
    $jsary = $_G['cache'][$_key]['variable'][1];
}
$_key = 'hbpubIdist'.intval($_GET['st']);
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
    $distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    $distjsary = array_values($distjsary);
    savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
} else {
    $distjsary = $_G['cache'][$_key]['variable'][0];
}

$total_view = $rsobj->total_views();
$total_resume = $rsobj->total_resumes();
$total_yy = C::t('#xigua_job#xigua_job_xiazai')->total_yy();
$total_view = job_trans($total_view, 4,1,1);
$total_resume = job_trans($total_resume, 4,1,2);
$total_yy = job_trans($total_yy, 4,1,3);
break;
case 'search':
if($_GET['from'] == 'resumes'){
    $_ac = 'resumes';
    $_type = $_GET['type'];
    $_high = $_GET['high'];
    $job_config['schtxt'] = $job_config['schtxt1'];
}else{
    $_ac = 'index';
    $_type = $_GET['type'];
    $_high = $_GET['high'];
}
$navtitle = $job_config['schtxt'];
break;
case 'view':
$jobid = $_GET['jobid'];
if(!$jobid){
    dheader('Location:'.$SCRITPTNAME.'?id=xigua_job'.$urlext);
}
$v = $jobobj->fetch_by_id($jobid);
$navtitle = $v['name'] . '-'. $v['type_u'].lang_job('zhaopin',0);
$member = getuserbyuid($v['uid']);
$isself = (IS_ADMINID && $_GET['admin']) || $_G['uid']==$v['uid'];
if($_G['uid']){
    $myresume = $rsobj->fetch_by_uid($_G['uid']);
    $has_toudi = C::t('#xigua_job#xigua_job_xiazai')->fetch_by_uid_jobid($_G['uid'], $jobid);
}
$custom_side = array("$SCRITPTNAME?id=xigua_job&ac=index&high=0",'<i class="iconfont icon-index"></i>');
$jobobj->incr($jobid, 'views', 1);
if($_G['uid']){
    if($viewid = C::t('#xigua_job#xigua_job_views')->fetch_by_jobid($_G['uid'], $jobid)){
        C::t('#xigua_job#xigua_job_views')->update($viewid['id'], array(
            'upts' => TIMESTAMP,
        ));
    }else{
        C::t('#xigua_job#xigua_job_views')->insert(array(
            'uid' => $_G['uid'],
            'jobid'=> $jobid,
            'crts' => TIMESTAMP,
            'upts' => TIMESTAMP,
        ));
    }
}
include_once DISCUZ_ROOT.'source/plugin/xigua_job/include/c_view.php';
break;
case 'taocan':
$navtitle = lang_job('zptc',0);
$zptc = array();
foreach (explode("\n", trim($job_config['zptc'])) as $index => $item) {
    list($tcname, $tcinfo) = explode('=', trim($item));
    list($xiazai, $fabu, $days, $delprice, $price,$zhiding) = explode(',', $tcinfo);
    $zptc[$index] = array(
        'name' => $tcname,
        'xiazai' => $xiazai,
        'fabu' => $fabu,
        'days' => $days,
        'delprice' => $delprice,
        'price' => $price,
        'days_str' => job_format_days($days),
        'zhiding' => $zhiding,
    );
}
if(submitcheck('formhash')){
    $taocan = array();
    foreach ($zptc as $index => $item) {
        if($item['days'] == $_GET['form']['viptype']){
            $taocan = $item;
        }
    }
    if(!$taocan){
        hb_message(lang_job('error', 0), 'error');
    }
    $_GET['rl'] = $_G['siteurl']."$SCRITPTNAME?id=xigua_job&ac=my$urlext";
    $_data = array(
        'uid' => $_G['uid'],
        'name' => $taocan['name'],
        'xiazai' => $taocan['xiazai'],
        'fabu' => $taocan['fabu'],
        'days' => $taocan['days'],
        'delprice' => $taocan['delprice'],
        'price' => $taocan['price'],
        'zhiding' => $taocan['zhiding'],
        'yixiazai' => 0,
        'yifabu' => 0,
    );
    if($taocan['price']>0){
        $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $taocan['price'], lang_job('gmzptc', 0).$taocan['name'], 'common_jobtaocan', array(
            'data' => $_data,
            'callback' => array(
                'file' => 'source/plugin/xigua_job/function_job.php',
                'method' => 'job_taocan_callback'
            ),
            'location' => $_GET['rl'],
        ));

        $rl = urlencode($_GET['rl']);
        $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
        hb_message(lang_hb('tiaozhuan',0), 'success', $jumpurl);
    }else{
        C::t('#xigua_job#xigua_job_taocan')->insert_G($_data);
        hb_message(lang_job('succeed',0), 'success', $_GET['rl']);
    }
}else{
    $taocan = $tcobj->fetch_by_uid($_G['uid']);
    if(!$taocan){
        $taocan = array(
            'name' => lang_job('wtc',0),
            'xiazai' => 0,
            'fabu' => 0,
            'days' => 0,
            'delprice' => 0,
            'price' => 0,
            'yixiazai' => 0,
            'yifabu' => 0,
            'endts_u' => lang_job('y',0),
        );
    }
    $custom_side = array(
        "$SCRITPTNAME?id=xigua_job&ac=my",
        lang_job('zpzx',0)
    );
}
break;
case 'resume_view':
if($_GET['mine'] && $_G['uid']){
    $v = $rsobj->fetch_by_uid($_G['uid']);
}else{
    $rsid = intval($_GET['rsid']);
    $v = $rsobj->fetch_by_rsid($rsid);
}
if(!$v || $v['qiustatus'] == lang('plugin/xigua_job', 'qzzt5')){
    dheader("Location: $SCRITPTNAME?id=xigua_job&ac=resume$urlext");
}
$navtitle = $v['realname'].lang_job('sresume',0);
$nextid = $rsobj->get_next($rsid);
if(!$_G['cookie']['is_company'] && $v['uid']!=$_G['uid']){
    dheader("Location: $SCRITPTNAME?id=xigua_job&ac=index$urlext");
}
$is_mine = $v['uid']==$_G['uid'];
if($is_mine){
    $custom_side = array("$SCRITPTNAME?id=xigua_job&ac=my",lang_hb('wode', 0));
}
$rsobj->incr($rsid, 'views', 1);
if($_G['uid']){
    if($viewid = C::t('#xigua_job#xigua_job_views')->fetch_by_uid_rsid($_G['uid'], $rsid)){
        C::t('#xigua_job#xigua_job_views')->update($viewid['id'], array(
            'upts' => TIMESTAMP,
        ));
    }else{
        C::t('#xigua_job#xigua_job_views')->insert(array(
            'uid' => $_G['uid'],
            'rsid'=> $rsid,
            'crts' => TIMESTAMP,
            'upts' => TIMESTAMP,
        ));
    }
}
$desc = $v['description'] ? strip_tags($v['description']) : $navtitle;
include_once DISCUZ_ROOT.'source/plugin/xigua_job/include/c_resume_view.php';
break;
case 'resume_manage':
$navtitle = lang_job('jlgl',0);
if($_GET['do']=='resume_manage_li'){
    if($jobid = intval($_GET['jobid'])){
        $jobids = $jobobj->fetch_by_id($jobid);
        $job_ary = array($jobid=>$jobids);
    }else{
        $job_ary = $jobobj->get_my_jobids($_G['uid']);
    }
    if($job_ary){
        $where = array();
        if($_GET['status']){
            $where[] = 'status='.intval($_GET['status']);
        }
        if(!$_GET['type'] || $_GET['type']=='xiazai'){
            $where[] = 'is_xiazai=1 AND uid='.$_G['uid'];
        }elseif($_GET['type']=='toudi' && $job_ary){
            $where[] = 'is_xiazai!=1 AND jobid IN('. implode(',', array_keys($job_ary)) .')';
        }
        $list = C::t('#xigua_job#xigua_job_xiazai')->fetch_all_by_page($start_limit, $lpp, $where, 'id DESC', 'id');
        if($list){
            $rsids = array();
            foreach ($list as $index => $item) {
                $rsids[] = $item['rsid'];
            }
            $rslist = $rsobj->fetch_all_by_page($start_limit, $lpp, array('rsid in ('.implode(',', $rsids).')'), '*', '', 'rsid');
        }
    }
    include template('xigua_hb:header_ajax');
    include template("xigua_job:resume_manage_li");
    include template('xigua_hb:footer_ajax');
}else{
    $myjobs = array();
    $myjobs = $jobobj->fetch_all_by_page(0, 20, array('uid='.$_G['uid'].' AND status=2'), 0, 'name,jobid,shname,type,crts,upts,status', 'jobid desc');
    if($jobid = intval($_GET['jobid'])){
        $jobinfo = $jobobj->fetch_by_id($jobid);
        $navtitle = $jobinfo['name'].'-'.$navtitle;
    }
    $custom_side = array("$SCRITPTNAME?id=xigua_job&ac=my",lang_job('zpzx',0));
}
break;
case 'resume':
$navtitle = lang_job('wdjl',0);
$_key = 'job_hangye1';
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    $listjson = $hyobj->list_json();
    $hyobj->init($listjson);
    $jsary = $hyobj->get_tree_array(0);
    savecache($_key, array('variable' => array($listjson, $jsary), 'expiration' => TIMESTAMP));
} else {
    $listjson = $_G['cache'][$_key]['variable'][0];
    $jsary = $_G['cache'][$_key]['variable'][1];
}
$jsary = array_values($jsary);
$_key = 'hbpubIdist'.intval($_GET['st']);
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
    $distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    $distjsary = array_values($distjsary);
    savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
} else {
    $distjsary = $_G['cache'][$_key]['variable'][0];
}
$digtys[0] ='0';
job_check_bind(1);
if(submitcheck('formhash')){
    $form = $_GET['form'];
    $form['avatar'] = $form['avatar'][0];
    if(!$form['avatar']){
        hb_message(lang_job('qsctx',0), 'error');
    }
    $jobwant_string = $jobwant_string_tmp = array();
    if($form['jobwant']){
        foreach ($listjson as $index => $item) {
            if(in_array($item['code'], $form['jobwant'])){
                $jobwant_string_tmp[$item['code']] = $item['oname'];
            }
        }
        foreach ($form['jobwant'] as $index => $item) {
            $jobwant_string[$item] = $jobwant_string_tmp[$item];
        }
        $form['jobwant_str'] = implode(',', $jobwant_string);
        $form['jobwant'] = implode(',', $form['jobwant']);
    }else{
        hb_message(lang_job('minqwgw',0), 'error');
    }
    if($form['areawant']){
        $eqdq = $form['areawant'];
        $areawant_str = $areawant_str_tmp = array();
        $distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
        foreach ($distlist as $index => $item) {
            if(in_array($item['code'], $eqdq)){
                $areawant_str_tmp[$item['code']] = diconv($item['name'], 'UTF-8', CHARSET);
            }
        }
        foreach ($form['areawant'] as $index => $item) {
            $areawant_str[$item] = $areawant_str_tmp[$item];
        }
        $form['areawant'] = implode(',', $form['areawant']);
        $form['areawant_str'] = implode(',', $areawant_str);
    }else{
        hb_message(lang_job('minqwdq',0), 'error');
    }
    if(!$form['xueli']){
        hb_message(lang_job('qxzxueli',0), 'error');
    }
    if(!$form['jingyan']){
        hb_message(lang_job('qxzjingyan',0), 'error');
    }
    $tagary = array();
    foreach ($form['goodat'] as $index => $item) {
        if($item == 1){$tagary[] = $index;}
    }
    $form['goodat']  = implode(",", $tagary);
    $data = array ('stid' =>  $form['stid'],'avatar' => $form['avatar'],'birth' => $form['birth'],'jingyan' => $form['jingyan'],'xueli' => $form['xueli'],'realname' => $form['realname'],'gender' => $form['gender'],'mobile' => $form['mobile'],'qiustatus' => $form['qiustatus'],'jobwant' => $form['jobwant'],'paywant' => $form['paywant'],'areawant' => $form['areawant'],'goodat' => $form['goodat'],'description' => $form['description'],'workexp' => serialize($form['workexp']),'eduexp' => serialize($form['eduexp']),'jobwant_str' => $form['jobwant_str'],'areawant_str' => $form['areawant_str'],'upts' => TIMESTAMP,'fullstatus' => $form['fullstatus'],);
    $data['album'] = serialize($form['album']);
    if($rsid = $form['rsid']){
        $rsult = $rsobj->update_G($rsid, $data);
        if($rsult){
            hb_message(lang_job('update_success',0), 'success', "$SCRITPTNAME?id=xigua_job&ac=resume_view&mine=1$urlext");
        }
    }else{
        $data['uid'] = $_G['uid'];
        $data['status'] = 2;
        $data['crts'] = TIMESTAMP;
        $data['digtype'] =  intval($form['digtype']);
        $rsid = $rsobj->insert($data, 1);
        if($digtys[$data['digtype']]>0){
            $title = $_G['username'].lang_job('zdjl',0).$data['digtype'].lang_job('day',0);
            $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_job&ac=my{$urlext}";
            $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $digtys[$data['digtype']], $title , 'common_resumedig', array(
                'data' => array('rsid' => $rsid,'last' => $data['digtype'],),
                'callback' => array('file' => 'source/plugin/xigua_job/function_job.php','method' => 'job_resume_callback'),
                'location' => $rtl,
                'referer' => $rtl,
            ));
            $rl = urlencode($rtl);
            $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
            hb_message(lang_job('create_success_pay',0), 'loading', $jumpurl);
        }
        hb_message(lang_job('create_success',0), 'success', "$SCRITPTNAME?id=xigua_job&ac=resume_view&mine=1$urlext");
    }
}else{
    $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
    $old_data = $rsobj->fetch_by_uid($_G['uid']);
    if($old_data['realname']){
        $user['realname'] = $old_data['realname'];
    }
    $custom_side = array("$SCRITPTNAME?id=xigua_job&ac=resume_view&mine=1",lang_job('resume_preview',0));
    $fullstatus = $old_data['fullstatus'] ?$old_data['fullstatus']:-1;
}
break;
case 'myview':
$custom_side = array("$SCRITPTNAME?id=xigua_job&ac=my",lang_hb('wode', 0));
if($_GET['do']=='li'){
    $where = array();
    $where[] = 'jobid>0 AND uid='.$_G['uid'];
    $viewlist = C::t('#xigua_job#xigua_job_views')->fetch_all_by_page($start_limit, $lpp, $where, 'upts DESC', 'jobid');
    if($viewlist){
        $list = $jobobj->fetch_all_by_page($start_limit, $lpp, array('jobid in ('.implode(',', array_keys($viewlist)).')'), 0, '*');
    }
    include template('xigua_hb:header_ajax');
    include template("xigua_job:job_li");
    include template('xigua_hb:footer_ajax');
}elseif($_GET['do']=='viewme_li'){
    $v = $rsobj->fetch_by_uid($_G['uid']);
    if($v){
        $where = array();
        $where[] = 'rsid='.$v['rsid'];
        $list = C::t('#xigua_job#xigua_job_views')->fetch_all_by_page($start_limit, $lpp, $where, 'upts DESC', 'uid');
        $uids = array();
        foreach ($list as $index => $item) {
            $uids[] = $item['uid'];
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            $xiazai= DB::fetch_all('SELECT uid,rsid FROM %t WHERE rsid=%d ', array('xigua_job_xiazai', $v['rsid']), 'uid');
        }
    }
    include template('xigua_hb:header_ajax');
    include template("xigua_job:viewme_li");
    include template('xigua_hb:footer_ajax');
}elseif($_GET['do']=='viewme'){
    $navtitle = lang_job('skgw',0);
    include template("xigua_job:viewme");
    exit;
}elseif($_GET['do'] == 'company'){
    $navtitle = lang_job('lljl',0);
}elseif($_GET['do'] == 'resumeli'){
    $where = array();
    $where[] = 'rsid>0 AND uid='.$_G['uid'];
    $viewlist = C::t('#xigua_job#xigua_job_views')->fetch_all_by_page($start_limit, $lpp, $where, 'upts DESC', 'rsid');
    if($viewlist){
        $list = $rsobj->fetch_all_by_page($start_limit, $lpp, array('rsid in ('.implode(',', array_keys($viewlist)).')'));
    }
    include template('xigua_hb:header_ajax');
    include template("xigua_job:resume_li");
    include template('xigua_hb:footer_ajax');
}else{
    $navtitle = lang_job('lljl',0);
}
break;
case 'pubjob':
$jobid = intval($_GET['jobid']);
if($jobid>0){
    $old_data = $jobobj->fetch_G($jobid);
}
$where = array();
$where[] = 'uid='.$_G['uid'];
$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
$_key = 'job_hangye2';
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    $listjson = $hyobj->list_json();
    foreach ($listjson as $index => $item) {
        unset($listjson[$index]['oname']);
    }
    $hyobj->init($listjson);
    $jsary = $hyobj->get_tree_array(0);
    $jsary = array_values($jsary);

    savecache($_key, array('variable' => array($listjson, $jsary), 'expiration' => TIMESTAMP));
} else {
    $listjson = $_G['cache'][$_key]['variable'][0];
    $jsary = $_G['cache'][$_key]['variable'][1];
}
$default_hy = diconv($jsary[0]['name'].' '. $jsary[0]['sub'][0]['name'], 'utf-8', CHARSET);
$cityjson = json_encode($jsary);
if($old_data['hy']) {
    $default_hy = $old_data['hy'];
}
$fuliary = array();
$tmp = array();
$_j = 0;
foreach (explode("\n", trim($job_config['fuli'])) as $index => $item) {
    $_tmpkey = ++$_j;
    list($tmpname, $tmpary) = explode('=', trim($item));
    $tmpary = array_filter(explode(',', trim($tmpary)));
    $fuliary[$_tmpkey] = array(
        'id' => $tmpname,
        'oname' => $tmpname,
        'sub' => array()
    );
    foreach ($tmpary as $_index => $_item) {
        $_j++;
        $fuliary[$_tmpkey]['sub'][] = array(
            'id' => $_item,
            'oname' => $_item,
        );
    }
}
$fuliary = array_values($fuliary);
if(submitcheck('formhash')){
    $_GET['type'] = $_GET['type'] ? $_GET['type']:$_GET['form']['type'];
    if(!$_GET['type']){
        $_GET['type'] = 'full';
    }
    $type = $_GET['type'];
    $form= $_GET['form'];
    $data = array(
        'lat' => $form['lat'],
        'lng' => $form['lng'],
        'province' => $form['province'],
        'city' => $form['city'],
        'district' => $form['district'],
        'street' => $form['street'],
        'street_number' => $form['street_number'],
        'addr' => $form['addr'],
    );
    $aress = array_keys($data);
    $data['type'] = $form['type'];
    if($form['jobid']){
        $old_data = $jobobj->fetch_G($form['jobid']);
        $data['type'] = $old_data['type'];
    }
    if($form['shname']){
        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']);
        if($sh){
            $data['shname']     = $sh['name'];
            $data['shid']       = $sh['shid'];
            foreach ($aress as $index => $ares) {
                if(!$data[$ares]){
                    $data[$ares] = $sh[$ares];
                }
            }
        }else{
            $data['shname'] = $form['shname'];
        }
    }else{
        hb_message(lang_job('qtx',0).lang_job('yrdw',0), 'error');
    }
    if(!$data['addr']){
        hb_message(lang_job('qtx',0).lang_job('addr',0), 'error');
    }
    $hy_ret = $hyobj->fetch_by_name(array_filter(explode(' ', trim($form['hy']))));
    $hangye_ids = array_keys($hy_ret);
    $data['hangye_id1'] = $hangye_ids[0];
    $data['hangye_id2'] = $hangye_ids[1];
    $data['hy'] = $form['hy'];
    $data['stid'] = $form['stid'];
    $data['name'] = $form['name'];
    if(!$data['name']){
        hb_message(lang_job('qtxzwmc',0), 'error');
    }
    $data['xinzi'] = $form['xinzi'];
    if(!$data['xinzi']){
        hb_message(lang_job('qtxzwxz2',0), 'error');
    }
    if($data['type'] == 'part'){
        $data['jiesuan'] = $form['jiesuan'];
        if(!$data['jiesuan']){
            hb_message(lang_job('qxzjsfs',0), 'error');
        }
    }
    $data['neednum'] = $form['neednum'];
    if(!$data['neednum']){
        hb_message(lang_job('qtxneednum',0), 'error');
    }
    $data['minage'] = $form['minage'];
    $data['maxage'] = $form['maxage'];
    if(!$data['minage'] || !$data['maxage']){
        hb_message( lang_job('qxznlyq',0), 'error');
    }
    $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
    $data['gender'] = $form['gender'];
    $data['xueli'] = $form['xueli'];
    $data['jingyan'] = $form['jingyan'];
    $data['fuli'] = $form['fuli'];
    $data['openmobile'] = $form['openmobile'];
    $data['mobile'] = $form['mobile'];
    $data['xinziunit'] = $form['xinziunit'];
    $data['shiduan'] = $form['shiduan'];
    $data['opentime'] = $form['opentime'];
    $data['realname'] = $user['realname'];
    if(!$data['mobile']){
        hb_message(lang_job('qtxlxdh',0), 'error');
    }
    $data['miaoshu'] = $form['miaoshu'];
    if(!$data['miaoshu']){
        hb_message(lang_job('qtxzwms',0), 'error');
    }
    $data['upts'] = TIMESTAMP;
    $data['album'] = serialize($form['album']);
    if($jobid = $form['jobid']){
        $rsult = $jobobj->update_G($jobid, $data);
        if($rsult){
            hb_message(lang_job('xgcg',0), 'success', "$SCRITPTNAME?id=xigua_job&ac=my_company$urlext");
        }
    }else{
        $data['endts'] = TIMESTAMP+$job_config['youxiaoqi']*86400;
        $data['uid'] = $_G['uid'];
        $data['status'] = $job_config['needshen'] ? 1 : 2;
        $data['crts'] = TIMESTAMP;
        $data['upts'] = TIMESTAMP;
        $wffb1 = lang_job('wffb1',0);
        $gmzptc = lang_job('gmzptc',0);
        $wflx6 = lang_job('wflx6',0);
        $wflx4 = lang_job('wflx4',0);
        $wffb2 = lang_job('wffb2',0);
        $wffb3 = lang_job('wffb3',0);
        $wflx7 = lang_job('wflx7',0);
        $taocan = $tcobj->fetch_by_uid($_G['uid']);
        if(!$taocan){
            hb_message($wffb1, 'error', "javascript:error_promt(\"$wffb1\", \"$wffb2\",\"$gmzptc\",\"$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2\");");
        }
        if($taocan['is_end']){
            hb_message($wflx4, 'error', "javascript:error_promt(\"$wffb1\", \"$wflx4\",\"$gmzptc\",\"$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2\");");
        }
        if($taocan['yifabu']>=$taocan['fabu']){
            hb_message($wflx7, 'error', "javascript:error_promt(\"$wffb1\", \"$wffb3\",\"$wflx6\",\"$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2\");");
        }
        $tcobj->incr($taocan['id'], 'yifabu', 1);
        $rsid = $jobobj->insert($data, 1);
        hb_message(lang_job('fbcg',0), 'success', "$SCRITPTNAME?id=xigua_job&ac=my_company$urlext");
    }
}else{
    if($old_data['type']){
        $_GET['type'] = $old_data['type'];
    }
    $_GET['type'] = $_GET['type'] ? $_GET['type']:$_GET['form']['type'];
    if(!$_GET['type']){
        $_GET['type'] = 'full';
    }
    $type = $_GET['type'];
    if($type=='full'){
        $navtitle = lang_job('pubfull',0);
    }elseif($type=='part'){
        $navtitle = lang_job('pubpart',0);
    }
    $navtitle .= lang_job('title_short',0);
    $opentime = array();
    for($i=0;$i<24;$i++):
        $opentime[] = $i.':00';
        $opentime[] = $i.':30';
    endfor;
    $opentimeend = $opentime;
    $opentime[] = '00:00';
    $opentime = json_encode($opentime);
    $opentimeend[] = '24:00';
    $opentimeend = json_encode($opentimeend);
}
break;
case 'haibao':
$jobid = intval($_GET['jobid']);
$upar = parse_url(hb_currenturl());
$hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_job&ac=view&jobid=$jobid&x=1{$urlext}");
$shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&url='.$hb_currenturl;
break;
case 'com':
switch ($_GET['do']){
case 'checkifview':
if(submitcheck('rsid')){
$rsid = intval($_GET['rsid']);
$taocan = $tcobj->fetch_by_uid($_G['uid']);
$wflx1 = lang_job('wflx1',0);
$wflx2 = lang_job('wflx2',0);
$wflx3 = lang_job('wflx3',0);
$wflx4 = lang_job('wflx4',0);
$wflx5 = lang_job('wflx5',0);
$wflx6 = lang_job('wflx6',0);
if(!$taocan){
    hb_message($wflx1, 'error', "javascript:error_promt(\"$wflx1\", \"$wflx2\",\"$wflx3\",\"$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2\");");
}
if($taocan['is_end']){
    hb_message($wflx4, 'error', "javascript:error_promt(\"$wflx1\", \"$wflx4\",\"$wflx3\",\"$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2\");");
}
if($taocan['yixiazai']>=$taocan['xiazai']){
    hb_message($wflx5, 'error', "javascript:error_promt(\"$wflx1\", \"$wflx5\",\"$wflx6\",\"$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2\");");
}

if(C::t('#xigua_job#xigua_job_xiazai')->fetch_by_uid_rsid($_G['uid'], $rsid)){
    $v = $rsobj->fetch_by_rsid($rsid);
    hb_message('success', 'success', "tel:{$v['mobile']}");
}else{
    if($taocan['yixiazai']<$taocan['xiazai']){
        C::t('#xigua_job#xigua_job_xiazai')->insert(array(
            'uid' => $_G['uid'],
            'rsid'=> $rsid,
            'crts' => TIMESTAMP,
            'upts' => TIMESTAMP,
            'status' => 1,
            'is_xiazai' => 1,
        ));
        $tcobj->incr($taocan['id'], 'yixiazai', 1);
        $rsobj->incr($rsid, 'xiazainum', 1);
        $v = $rsobj->fetch_by_rsid($rsid);
        hb_message('success', 'success', "tel:{$v['mobile']}");
    }
}
}
break;
case 'toudi':
if(submitcheck('formhash')) {
if (!$jobid = $_GET['jobid']) {
    hb_message('jobid error', 'error');
}
$resumelink = "$SCRITPTNAME?id=xigua_job&ac=resume&mobile=2";
$myresume = $rsobj->fetch_by_uid($_G['uid']);
if (!$myresume) {
    hb_message(lang_job('tdsb',0), 'error', $resumelink);
}
if (C::t('#xigua_job#xigua_job_xiazai')->fetch_by_uid_jobid($_G['uid'], $jobid)) {
    hb_message(lang_job('tdsb2',0), 'error');
} else {
    $job = $jobobj->fetch($jobid);
    $myresume = $rsobj->fetch_by_uid($_G['uid']);
    C::t('#xigua_job#xigua_job_xiazai')->insert(array(
        'uid' => $_G['uid'],
        'rsid' => $myresume['rsid'],
        'jobid' => $jobid,
        'crts' => TIMESTAMP,
        'status' => 1,
        'type' => $job['type'],
        'is_xiazai' => 0,
    ));
    $jobobj->incr($jobid, 'tdnum', 1);

    notification_add($job['uid'],'system',lang_job('tdnotice', 0),array(
        'username' => $myresume['realname'],
        'name' => $job['name'],
        'url' => "{$_G['siteurl']}{$SCRITPTNAME}?id=xigua_job&ac=resume_manage&type=toudi".$urlext
    ),1);

    hb_message(lang_job('tdcg',0), 'success');
}
}
break;
case 'offline':
if(submitcheck('formhash')){
$jobid = intval($_GET['jobid']);
if($_GET['xiajia']){
    $sta = 9;
}else{
    $sta = $job_config['needshen'] ? 1 : 2;
}
$jobobj->update_G($jobid, array(
    'status' => $sta
));
hb_message(lang_job('succeed',0),'success', 'reload');
}
break;
case 'refresh':
if(submitcheck('formhash')){
$jobid = intval($_GET['jobid']);
$job = $jobobj->fetch($jobid);
if($job['upts']>=TIMESTAMP-86400){
    hb_message(lang_job('jty',0), 'error');
}
$jobobj->update_G($jobid, array(
    'upts' => TIMESTAMP,
    'endts' => TIMESTAMP+$job_config['youxiaoqi']*86400,
));
hb_message(lang_job('refresh_succeed',0),'success', 'reload');
}
break;
case 'dig':
if(submitcheck('formhash')){
$jobid = intval($_GET['jobid']);
$job = $jobobj->fetch($jobid);
$zhiding_rate = 1;
if($_G['uid']){
    $taocan = $tcobj->fetch_by_uid($_G['uid']);
    $zhiding_rate = $taocan['zhiding']>0?$taocan['zhiding']/10:1;
}

$dig_prices = array();
if($job_config['digtys']){
foreach (explode("\n", trim($job_config['digtys'])) as $item) {
    list($tmp_type, $tmp_price) = explode('=', trim($item));
    $tmp_lang = lang_hb('days_'.$tmp_type, 0);
    $realprice = round($zhiding_rate*$tmp_price, 2);
    $yuan = lang_hb('yuan', 0);
    $s = "<s class='c9'>$tmp_price$yuan</s>";
    $dig_prices[$tmp_type] = array(
        'type'  => $tmp_type,
        'title' => lang_hb('zhiding', 0). ($tmp_lang == "days_$tmp_type" ? $tmp_type. lang_hb('day', 0) : $tmp_lang) ."(<b class='main_color'>$realprice$yuan</b> $s)",
        'price' => $realprice,
    );
}
}
$dig_price = $dig_prices[$_GET['digtype']];
if($dig_price['price']>0){
    $title = lang_job('zdzw',0).$job['name'].$dig_price['type'].lang_hb('day', 0);
    $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_job&ac=my_company{$urlext}";
    $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $dig_price['price'], $title , 'common_jobdig', array(
        'data' => array('jobid' => $jobid, 'last' => $dig_price['type'],),
        'callback' => array(
            'file' => 'source/plugin/xigua_job/function_job.php',
            'method' => 'job_dig_callback'
        ),
        'location' => $rtl,
        'referer' => $rtl,
    ));
    $rl = urlencode($rtl);
    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
    hb_message(lang_job('tzz',0), 'loading', $jumpurl);
}
}
break;
case 'resume_dig':
$form = $_GET['form'];
$data = array();
$data['digtype'] =  intval($form['digtype']);
$resume_v = $rsobj->fetch_by_uid($_G['uid']);
if($digtys[$data['digtype']]>0){
$title = $_G['username'].lang_job('zdjl',0).$data['digtype'].lang_job('day',0);
$rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_job&ac=resume_view&mine=1{$urlext}";
$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $digtys[$data['digtype']], $title , 'common_resumedig', array(
    'data' => array(
        'rsid' => $resume_v['rsid'],
        'last' => $data['digtype'],
    ),
    'callback' => array(
        'file' => 'source/plugin/xigua_job/function_job.php',
        'method' => 'job_resume_callback'
    ),
    'location' => $rtl,
    'referer' => $rtl,
));
$rl = urlencode($rtl);
$jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
hb_message(lang_job('tzz',0), 'loading', $jumpurl);
}
break;
case 'resume_refresh':
if(submitcheck('formhash')){
$resume_v = $rsobj->fetch_by_uid($_G['uid']);
if($resume_v['upts']>=TIMESTAMP-86400){
    hb_message(lang_job('jty',0), 'error');
}
$rsobj->update_G($resume_v['rsid'], array(
    'upts' => TIMESTAMP,
));
hb_message(lang_job('refresh_succeed',0),'success', 'reload');
}
break;
case 'resume_yy':
if(submitcheck('formhash')) {
$jobid = intval($_GET['jobid']);
if (!$jobid) {
    hb_message(lang_job('xzgw',0), 'error');
}
$uid = intval($_GET['uid']);
$yyts = strtotime($_GET['yy_time']);
$user_resume = $rsobj->fetch_by_uid($uid);
$yaoyue = C::t('#xigua_job#xigua_job_xiazai')->update_yy_uid($uid, $user_resume['rsid'], $jobid, $yyts, $_GET['note']);
$job = $jobobj->fetch($jobid);
notification_add($uid,'system',lang_job('yynotice', 0),array('shname' => $job['shname'],'name' => $job['name'],'time' => $_GET['yy_time'],'note' => $_GET['note'],'url' => "{$_G['siteurl']}{$SCRITPTNAME}?id=xigua_job&ac=mytd&type=yy&high=3".$urlext),1);
hb_message(lang_job('yymscg',0), 'success', 'reload');
}
break;
case 'resume_ignore_yy':
if(submitcheck('formhash')) {
$uid = intval($_GET['uid']);
$rsid = intval($_GET['rsid']);
$yaoyue = C::t('#xigua_job#xigua_job_xiazai')->resume_ignore_yy($uid, $rsid);
hb_message(lang_job('hlcg',0), 'success', 'reload');
}
break;
case 'incr':
if(submitcheck('formhash')) {
$jobid = intval($_GET['jobid']);
if($_GET['incr_type']=='shares'){
    $jobobj->incr($jobid, 'shares', 1);
    hb_message('success', 'success');
}
}
break;
case 'driving':
include_once DISCUZ_ROOT.'source/plugin/xigua_job/include/c_com.php';
break;
}
break;
case 'company':
    $shid = intval($_GET['shid']);
    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
    $hdcount = $jobobj->fetch_count_by_page(array('status=2 AND shid='.$shid.' AND endts>'.TIMESTAMP));
    $navtitle = $sh['name'];
    $sh['jieshao'] = cutstr(strip_tags($sh['jieshao']), 500);
    if($_G['cache']['plugin']['xigua_hr']){
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris_bysh(array($shid));
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($sh['uid']));
    }
    if($_G['uid']){
        $followed = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid_uid($shid, $_G['uid']);
    }
    $custom_side = array(
        "$SCRITPTNAME?id=xigua_job".$urlext,
        lang_hb('shouye', 0)
    );
    break;
case 'company_list':
    break;
case 'company_li':
    break;
}
if($_GET['mini']=='11'){$navtitle = strip_tags($navtitle);$navtitle = $navtitle?$navtitle:$config['tname'];
if($config['tnameshow']) {if($navtitle!=$config['tname']){$navtitle=$config['tname'].$navtitle;}}
ob_end_clean();
function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
header("Content-type: application/json; charset=utf-8");
echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));exit;}
if(!checkmobile()){include template('xigua_hb:index');exit;}
$ac_file = DISCUZ_ROOT . "source/plugin/xigua_job/include/c_$ac.php";
if (is_file($ac_file)) {include_once $ac_file;}
include template('xigua_job:' . $ac);