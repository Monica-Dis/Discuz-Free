<?php
/**
 * Created by https://dism.taobao.com?/?@xigua
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_job_hangye;
DROP TABLE pre_xigua_job_job;
DROP TABLE pre_xigua_job_nav;
DROP TABLE pre_xigua_job_resume;
DROP TABLE pre_xigua_job_taocan;
DROP TABLE pre_xigua_job_views;
DROP TABLE pre_xigua_job_xiazai;
DROP TABLE pre_xigua_job_index;
EOT;
runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/install.php');

xwbdelall(DISCUZ_ROOT . "./source/plugin/xigua_job");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_job");

$finish = TRUE;

function xwbdelall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);
        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwbdelall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}