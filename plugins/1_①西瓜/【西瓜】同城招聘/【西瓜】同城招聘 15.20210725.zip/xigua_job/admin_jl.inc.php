<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
$job_config = $_G['cache']['plugin']['xigua_job'];
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common_status.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/function.php';
$hyobj = C::t('#xigua_job#xigua_job_hangye');
$rsobj = C::t('#xigua_job#xigua_job_resume');
$jobobj = C::t('#xigua_job#xigua_job_job');
$tcobj = C::t('#xigua_job#xigua_job_taocan');


$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$pzfield = array();

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" />";
if($secid = intval($_GET['secid'])){
    $res = $rsobj->fetch_by_rsid($secid);
    $unsetary =array('jobwant_str' ,'rsid', 'stid','goodat_ary', 'hangye_id1', 'jobwant_ary', 'digtype', 'areawant', 'jobwant_str_ary', 'areawant_ary','areawant_str_ary', 'workexp_ary', 'eduexp_ary', 'gender_str', 'is_dig', 'dig_endts_u', 'upts_u', 'crts_u', 'age');
    $ts_ary = array('crts', 'upts', 'dig_crts','dig_endts');

    if(!submitcheck('dosubmit')) {
        if(!$res){
            $neww = 1;
            $res = array ('uid' => '0', 'stid' => '0', 'avatar' => '', 'birth' => '', 'jingyan' => '', 'xueli' => '', 'realname' => '', 'mobile' => '', 'gender' => '-1', 'qiustatus' => '', 'jobwant' => '', 'jobwant_str' => '', 'paywant' => '', 'areawant' => '', 'areawant_str' => '', 'goodat' => '', 'description' => '', 'digtype' => '0', 'dig_crts' => '0', 'dig_endts' => '0', 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'workexp' => '', 'eduexp' => '', 'status' => '2', 'album' => array (), 'fullstatus' => '-1', 'views' => '0', 'xiazainum' => '0');
        }

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl&secid=$secid", 'enctype');
        showtableheader(); /*dism��taobao��com*/
        showtitle(lang_job('gljl',0) . ($secid>0?'-'. $res['realname']." (ID: $secid)" :''). "&nbsp;&nbsp;<a class='abtn' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl'> ".lang_job('back',0)."</a>");

        $listinfo = $hyobj->list_all(1);
        $hyobj->init($listinfo);
        $cat_list = $hyobj->get_tree_array(0);

        foreach ($res as $index => $re) {
            if(in_array($index, $unsetary)){
                continue;
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, $ts_ary)){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('jingyan', 'xueli','qiustatus','paywant'))){
                if($index=='jingyan'){
                    $__tmp = $jingyan;
                    $cs = '<select name="editform[jingyan]">';
                }elseif($index=='xueli'){
                    $__tmp = $xueli;
                    $cs = '<select name="editform[xueli]">';
                }elseif($index=='qiustatus'){
                    $__tmp = $qzzt;
                    $cs = '<select name="editform[qiustatus]">';
                }elseif($index=='paywant'){
                    $__tmp = $xinzi;
                    $cs = '<select name="editform[paywant]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('type', 'gender','xinziunit', 'shiduan', 'jiesuan','goodat','fullstatus'))){
                if($index=='type'){
                    $__tmp = $job_types;
                    $cs = '<select name="editform[type]">';
                }elseif($index=='gender'){
                    $__tmp = $gender_ary;
                    $cs = '<select name="editform[gender]">';
                }elseif($index=='xinziunit'){
                    $__tmp = $yuanshi;
                    $cs = '<select name="editform[xinziunit]">';
                }elseif($index=='shiduan'){
                    $__tmp = $shiduan;
                    $cs = '<select name="editform[shiduan]">';
                }elseif($index=='jiesuan'){
                    $__tmp = $jiesuan;
                    $cs = '<select name="editform[jiesuan]">';
                }elseif($index=='fullstatus'){
                    $__tmp = $fullstatuss;
                    $cs = '<select name="editform[fullstatus]">';
                }elseif($index=='goodat'){
                    $__tmp = $goodat;
                    $cs = '<select name="editform[goodat][]" multiple>';
                    $re = explode(',', $re);
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c_t==$re||(is_array($re) && in_array($c_t, $re))){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($job_status as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb', 'avatar'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('showbm' ,'tuijian','showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk','openmobile'))){
                $tp = 'radio';
            }elseif(in_array($index, array('jobwant'))){
                $hangye = "<select name=\"editform[jobwant][]\" multiple>";
                foreach ($cat_list as $k => $v) {
                    $hangye .= "<optgroup label='$v[name]'>";
                    foreach ($v['sub'] as $kk => $vv) {
                        $s = '';
                        if(in_array($vv['id'], $res['jobwant_ary'])){
                            $s = 'selected';
                        }
                        $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;--$vv[name]</option>";
                    }
                    $hangye .= '</optgroup>';
                }
                $hangye .= '</select>';
                $tp = $hangye;
            }elseif(in_array($index, array('workexp', 'eduexp'))) {
                $tp  = 'textarea';
                $newre = '';
                $re_ary=unserialize($re);
                if($index == 'eduexp'){
                    foreach ($re_ary['comname'] as $_k => $item) {
                        $newre .=  lang_job('xuexiao',0).':'. $re_ary['comname'][$_k] ."\n";
                        $newre .=  lang_job('ruxue',0).':'. $re_ary['start'][$_k] ."\n";
                        $newre .=  lang_job('biye',0).':'. $re_ary['end'][$_k] ."\n";
                        $newre .=  lang_job('zy',0).':'. $re_ary['zhiwei'][$_k] ."\n\n";
                    }
                }else{
                    foreach ($re_ary['comname'] as $_k => $item) {
                        $newre .=  lang_job('hsname',0).':'. $re_ary['comname'][$_k] ."\n";
                        $newre .=  lang_job('start_js',0).':'. $re_ary['start'][$_k] ."\n";
                        $newre .=  lang_job('end_js',0).':'. $re_ary['end'][$_k] ."\n";
                        $newre .=  lang_job('title',0).':'. $re_ary['zhiwei'][$_k] ."\n\n";
                    }
                }
                $re = $newre;
            }

            if (in_array($index, array('album'))) {
//                $re = unserialize($re);
                $tp = 'filetext';
                $job_config = $_G['cache']['plugin']['xigua_job'];
                $loopnum = $job_config['maximg'];
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_job('rs'.$index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'description'){
                $_tmp1 = lang_job($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[description]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_job($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dism-Taobao-com*/
        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach ($ts_ary as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        foreach (array('album') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }


        $_key = 'job_hangye1';
        loadcache($_key);
        if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
            $listjson = $hyobj->list_json();
            $hyobj->init($listjson);
            $jsary = $hyobj->get_tree_array(0);
            savecache($_key, array('variable' => array($listjson, $jsary), 'expiration' => TIMESTAMP));
        } else {
            $listjson = $_G['cache'][$_key]['variable'][0];
            $jsary = $_G['cache'][$_key]['variable'][1];
        }
        $jsary = array_values($jsary);
        foreach ($listjson as $index => $item) {
            if(in_array($item['code'], $editform['jobwant'])){
                $jobwant_string_tmp[$item['code']] = $item['oname'];
            }
        }
        foreach ($editform['jobwant'] as $index => $item) {
            $jobwant_string[$item] = $jobwant_string_tmp[$item];
        }
        $editform['jobwant_str'] = implode(',', $jobwant_string);
        $editform['jobwant'] = implode(',', $editform['jobwant']);
        if($workexp = trim($editform['workexp'])){
            $workexp = explode("\n", $workexp);
            $newexp = array();
            foreach ($workexp as $index => $item) {
                list($_name, $_val) = explode(':', trim($item));
                if(in_array(trim($_name), array(lang_job('hsname',0), lang_job('xuexiao',0)))){
                    $newexp['comname'][] = $_val;
                }
                if(in_array(trim($_name), array(lang_job('ruxue',0), lang_job('start_js',0)))){
                    $newexp['start'][] = $_val;
                }
                if(in_array(trim($_name), array(lang_job('biye',0), lang_job('end_js',0)))){
                    $newexp['end'][] = $_val;
                }
                if(in_array(trim($_name), array(lang_job('title',0), lang_job('zy',0)))){
                    $newexp['zhiwei'][] = $_val;
                }
            }
            $editform['workexp'] = serialize($newexp);
        }
        if($eduexp = trim($editform['eduexp'])){
            $eduexp = explode("\n", $eduexp);
            $newexp = array();
            foreach ($eduexp as $index => $item) {
                list($_name, $_val) = explode(':', trim($item));
                if(in_array(trim($_name), array(lang_job('hsname',0), lang_job('xuexiao',0)))){
                    $newexp['comname'][] = $_val;
                }
                if(in_array(trim($_name), array(lang_job('ruxue',0), lang_job('start_js',0)))){
                    $newexp['start'][] = $_val;
                }
                if(in_array(trim($_name), array(lang_job('biye',0), lang_job('end_js',0)))){
                    $newexp['end'][] = $_val;
                }
                if(in_array(trim($_name), array(lang_job('title',0), lang_job('zy',0)))){
                    $newexp['zhiwei'][] = $_val;
                }
            }
            $editform['eduexp'] = serialize($newexp);
        }

        $eqdq = explode(',', $editform['areawant_str']);
        $__areawant = $areawant_str_tmp = array();
        $distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
        foreach ($distlist as $index => $item) {
            $itemname = diconv($item['name'], 'UTF-8', CHARSET);
            $areawant_str_tmp[$itemname] = $item['code'];
        }
        foreach ($eqdq as $index => $item) {
            $__areawant[$item] = $areawant_str_tmp[$item];
        }
        $editform['areawant'] = implode(',', $__areawant);

        $editform['description'] = htmlspecialchars_decode(trim($editform['description']));
        $editform['goodat']  = implode(",", $editform['goodat'] );
//        print_r($editform);
//        exit;

        if($secid>0){
            $rs = $rsobj->update($secid, $editform);
            $hid = $secid;
        }else{
            $hid = $rsobj->insert($editform, 1);
        }

        cpmsg(lang_job('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl&secid=$hid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            $rsobj->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            $rsobj->update($id, array( 'status' => $item['status']));
        }

        cpmsg(lang_job('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey(addslashes($keyword))) {
        $wherearr[] = " (realname LIKE '%$keyword%' OR jobwant_str LIKE '%$keyword%' OR mobile LIKE '%$keyword%' OR description LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }

    $ob = 'rsid desc';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_job('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($job_status as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl".' class="btn" >'.cplang('reset').'</a> ';
    echo "<style>.zlist{width:460px}.zlist ul.ul1{width:200px;float:left}.zlist ul.ul2{width:260px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}
.jobtit{font-size:13px;color:#369}
.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;border-radius:2px}
.jthumb{width:70px;height:40px}
.red{color:#ff6565}.avatar{width:20px;height:20px;border-radius:40px;display:inline-block;vertical-align:middle}
.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.escd{width:180px;max-height:100px;overflow-y:auto}
.imgp{width:40px;height:40px;}img{object-fit:cover}
</style>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl&secid=-1\" class=\"btn bg_green\">".lang_job('tjjl',0)."</a></div>";

    showtableheader(lang_job('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_job('del', 0),
        lang_job('xmtx',0).'<br>'.lang_job('sjh',0),
        lang_job('zl',0),
        lang_job('description',0).'<br>'.lang_job('rsalbum',0),
        lang_job('status',0),
        lang_job('sj',0),
        lang_job('caozuo', 0),
    ));
    $res = $rsobj->fetch_all_by_page($start_limit, $lpp, $wherearr, '*', $ob);
    $icount = $rsobj->fetch_count_by_page($wherearr);

    $uids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }

    $_csnf = lang_job('birth', 0);
    $_gzjy = lang_job('gzjy', 0);
    $_zgxl = lang_job('zgxl', 0);
    $_qzzt = lang_job('qzzt', 0);
    $_jobwant = lang_job('jobwant', 0);
    $_paywant = lang_job('paywant', 0);
    $_areawant = lang_job('areawant', 0);
    $_goodat = lang_job('goodat', 0);
    $_views = lang_job('views', 0);
    $_xiazainum = lang_job('xiazainum', 0);

    foreach ($res as $v) {
        $id = $v['rsid'];
        $thumb = $v['album'][0];

        $goodat_str = '';
        foreach ($v['goodat_ary'] as $i => $item) {
            $goodat_str .= ' '. $goodat[$item];
        }

        $zl = <<<HTML
<div class="zlist"><ul class="ul1">
    <li><em>$_csnf:</em> {$v['birth']} </li>
    <li><em>$_gzjy:</em> {$v['jingyan']}</li>
    <li><em>$_zgxl:</em> {$v['xueli']}</li>
    <li><em>$_qzzt:</em> {$v['qiustatus']} </li></ul><ul class="ul2">
    <li><em>$_jobwant:</em> {$v['jobwant_str']} </li>
    <li><em>$_paywant:</em> {$v['paywant']} </li>
    <li><em>$_areawant:</em> {$v['areawant_str']} </li>
    <li><em>$_goodat:</em> {$goodat_str} </li>
</ul></div>
HTML;

        $img = '';
        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' class='imgp' /> </a>";
        }

        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($job_status as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<p>"."<img class='avatar' src=\"$v[avatar]\" /> ".$v['realname']."(uid:".$v['uid'].")</p>{$v['mobile']}",
            $zl,
            "<div class='escd'>{$v['description']}  <div>$img</div></div>",
            "<p>$status_u</p>".
            "<p style='margin-top:5px'>$_views: <em class='c_green'>$v[views]</em></p>".
            "<p>$_xiazainum: <em class='c_green'>$v[xiazainum]</em></p>".
            '',
            lang_job('crts',0).': '.$v['crts_u'].'<br>'.
            lang_job('upts',0).': '.$v['upts_u'].'<br>'.
            ($v['dig_endts_u'] ? '<p class=\'red\'>'.lang_job('dig_endts',0).': '.$v['dig_endts_u'].'</p>':''),

            '<a class=\'btn bg_green\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl&secid=$id" . '">' . lang_job('edit', 0) . '</a> ',
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_jl&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism-Taobao-com*/
    showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
}
