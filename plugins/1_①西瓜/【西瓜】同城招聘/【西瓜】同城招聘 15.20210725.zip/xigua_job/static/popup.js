$(document).on('click','.check1', function () {
    var that = $(this);
    that.siblings().removeClass('main_color');
    that.addClass('main_color');
    that.parent().parent().find('.pupc-btm-in_list').hide();
    $('#'+that.data('titfix')+that.data('title')).show();
});
$(document).on('click','.check2', function(){
    var that = $(this);
    var dt = that.data('title'),dv = that.data('value'), tame = that.html();
    if(that.data('name')){
        tame = that.data('name');
    }
    if(that.data('max') && $('#'+that.data('ld')).find('a').length> that.data('max')){
        $.toast( that.data('maxtip'), 'error');
        return false;
    }
    $('#id_'+dt).remove();
    $('#'+that.data('ld')).append('<a id="id_'+dt+'" data-ld="'+that.data('ld')+'" data-form="'+that.data('form')+'" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">'+tame+'<input name="form['+that.data('form')+'][]" type="hidden" value="'+dv+'" /></a>');
    sync_formid(that.data('ld'), that.data('form'));
});
$(document).on('click','.post_com_tag .weui-btn_default', function () {
    var that = $(this);
    that.remove();
    sync_formid(that.data('ld'), that.data('form'));
});
function sync_formid(apend, dform){
    var val = '';
    $('#'+apend).find('a').each(function () {  val+=',' + $(this).text(); });
    $('#'+dform).val(val.substr(1));
}
$(document).on('click','.check3', function(){
    var that = $(this);
    $.ajax({type: 'GET',url: _APPNAME + '?id=xigua_job&ac=com&do=distli&name='+that.data('name')+'&ctid='+that.data('value')+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('#distbox').html(s).removeClass('none');
        }
    });
});