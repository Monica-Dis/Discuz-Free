$(document).on('click','#pubj', function () {
    $('#pub_ctrl').popup();
});
$(document).on('click', '.jump_job', function () {
    var that = $(this);
    var jmpurl = _APPNAME +'?id=xigua_job&ac=view&jobid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
    if(typeof mag !== 'undefined'){
        mag.newWin(GSITE+jmpurl);
        return false;
    }
    if(typeof wx !=='undefined'){
        if (window.__wxjs_environment === 'miniprogram') {
            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
            return false;
        }
    }
    window.location.href = jmpurl;
    return false;
});
$(document).on('click', '.resume_jump', function () {
    var that = $(this);
    var jmpurl = _APPNAME +'?id=xigua_job&ac=resume_view&rsid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
    if(typeof mag !== 'undefined'){
        mag.newWin(GSITE+jmpurl);
        return false;
    }
    if(typeof wx !=='undefined'){
        if (window.__wxjs_environment === 'miniprogram') {
            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
            return false;
        }
    }
    window.location.href = jmpurl;
    return false;
});

function job_getlocation(callback){
    if(0&&typeof mag != 'undefined'){
        mag.getLocation(function(res){
            callback(res);
        });
    }else if(typeof sq != 'undefined'){
        sq.getLocation(function(res){
            callback(res);
        });
    }else if(typeof QFH5 != 'undefined') {
        QFH5.getLocation(function (state, data) {
            if (state == 1) {
                callback(data);
            } else {
                alert(data.error);
            }
        });
    }else if((HB_INWECHAT&&HS_MULTIUPLOAD)==1) {
        wx.getLocation({
            type: 'gcj02',
            success: function (res) {
                callback(res);
            },
            cancel: function (res) {
            }
        });
    }else{
        console.log('myapp');
        var geolocation = new qq.maps.Geolocation(mkey, "myapp");
        geolocation.getLocation(callback, function () {
        }, {timeout:4000, failTipFlag:true});
    }
}

function job_getparget(){
    var rst = '';
    var $_GET = (function(){
        var url = window.location.href.toString();
        var u = url.split("?");
        if(typeof(u[1]) === "string"){
            u = u[1].split("&");
            var get = {};
            for(var i in u){
                var j = u[i].split("=");
                if(typeof j[0] !=='undefined' && typeof j[1] !=='undefined'){
                    get[j[0]] = j[1];
                }
            }
            return get;
        } else {
            return {};
        }
    })();
    for(var i in $_GET){
        rst += i+"="+$_GET[i]+"&";
    }
    return '?'+rst;
}

function job_setlist(that, ext){
    var lin = job_getparget();
    page = 1;lm = false;
    loadingurl = _APPNAME+lin+'&keyword=&ac=resume_li'+ext+'&page=';
    console.log(loadingurl);
    // history.replaceState(null,'', loadingurl.replace(/ac\=resume_li/g, '').replace(/ac\=job_li/g, '').replace(/inajax\=1/g, ''));
    if(that!==null){
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
    }
    DOAPPEND = 0;
    $.ajax({
        type: 'get',
        url: loadingurl+''+page,
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('#loading-show').addClass('hidden');
            if(!s){
                $('#loading-show').addClass('hidden');
                $('#loading-none').removeClass('hidden');
                setTimeout(function () {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                }, 300);
                $("#list").html(s);
                page = -1;lm = false;
                return ;
            }
            $("#list").html(s);
            page ++;lm = false;
        },
        error: function() {}
    });
}
function url_Encode(param, key, encode) {
    if(param==null) return '';
    var paramStr = '';
    var t = typeof (param);
    if (t === 'string' || t === 'number' || t === 'boolean') {
        paramStr += '&' + key + '=' + ((encode==null||encode) ? (param) : param);
    } else {
        for (var i in param) {
            var k = key == null ? i : key + (param instanceof Array ? '[' + i + ']' : '.' + i);
            paramStr += url_Encode(param[i], k, encode);
        }
    }
    return paramStr;
}
$(document).on('click','.ftb', function () {
    var that = $(this);
    that.parent().parent().find('.checked').removeClass('checked main_color');
    that.parent().addClass('checked main_color');
    $('.mask').trigger('click');

    var oem = $('#ftb'+that.data('idid')).find('em');
    var showhtm = that.html();
    if(that.data('orihtml')){
        showhtm = that.data('orihtml');
    }
    oem.data('html', oem.html()).html(showhtm);

    var lnk = that.data('sort');
    if(lnk.indexOf('&orderby=nearby')!==-1){
        if(lockIng) return;
        lockIng = 1;
        setTimeout(function () {
            lockIng = 0;
        }, 200);
        job_getlocation(function (position) {
            var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
            job_setlist(that, lnk+'&lat='+lat+'&lng='+lng+'&keyword=');
        });
    }else{
        job_setlist(that, lnk+'&keyword='+(typeof that.data('keyword')==='undefined' ? '': that.data('keyword')));
    }
});
$(document).on('click','.sxuan', function () {var popcm =$('#popup_sx');popcm.popup();popcm.show();setTimeout(function(){popcm.show();}, 500);return false;});

$(document).on('click','.check_box li', function () {
    var that = $(this);
    var cbox =that.parent().parent();
    if(that.data('backto')) {
        cbox.find('.filterjobwant').show();
        cbox.find('.zkbtn').show();
        that.parent().hide();
    }else if(that.data('sub')){
        that.addClass('oncheck');
        that.siblings().removeClass('oncheck');

        cbox.find('.check_box_sub').hide();
        $('#subid_'+that.data('sub')).show();

        cbox.find('.filterjobwant').hide();
        cbox.find('.zkbtn').hide();
    }else{
        if(that.index()===0){
            that.addClass('oncheck');
            that.siblings().removeClass('oncheck');
        }else{
            that.addClass('oncheck');
            if(that.data('only')){
                that.siblings().removeClass('oncheck');
            }else{
                that.parent().find('li:first-child').removeClass('oncheck');
            }
        }
        if(that.data('name')==='none'){
            var tmpcheck = cbox.find('.oncheck'), tmpi = 0;
            var newht = '', newht_val = [], newht_key = [];
            tmpcheck.each(function () {
                var _that = $(this);
                var _thval = _that.data('value'), _thkey = _that.data('id');
                if(_thval){
                    newht+='<div class="post_tags_flex_item"><a class="weui-btn weui-btn_mini weui-btn_default wauto" data-id="'+_thkey+'" href="javascript:;">'+_thval+'</a></div>';
                    newht_val.push(_thval);
                    newht_key.push(_thkey);
                    tmpi++;
                }
            });
            console.log(tmpi);
            if(tmpi>MAXINDEXHY){
                that.removeClass('oncheck');
                $.toast(MAXINDEXHYTIP, 'error');
                return false;
            }
            $('#popup_hyc_p2').html(newht);
            localStorage.setItem("newht_val", newht_val);
            localStorage.setItem("newht_key", newht_key);
        }
    }
});
function setindex_hy(){
    $('.whbtnlocal').remove();
    if(!localStorage.getItem('newht_key')){
        return;
    }
    var newht_key = localStorage.getItem('newht_key').split(','), newht_val = localStorage.getItem('newht_val').split(',');
    for(var i =0; i<newht_key.length;i++){
        $('<a class="weui-btn whbtn whbtnlocal" data-id="'+newht_key[i]+'" href="javascript:;">'+newht_val[i]+'</a>').insertBefore('.whbtnadd');
    }
}
$(document).on('click','.post_tags_flex_item a', function () {
    var that = $(this);
    $('#_thkey_'+that.data('id')).removeClass('oncheck');
    that.parent().remove();
});
$(document).on('click','.confirm-hyc', function () {
    setindex_hy();
    $.closePopup();
});
$(document).on('click','.zkbtn', function () {
    var that = $(this);
    var ct = that.parent().find('.filterjobwant');
    if(ct.hasClass('open')){
        ct.removeClass('open');
        that.removeClass('arrowopen');
    }else{
        ct.addClass('open');
        that.addClass('arrowopen');
    }
});
$(document).on('click','.close-reset', function () {
    $('.check_box li').removeClass('oncheck');
    $('.check_box').each(function () {
        var that = $(this);
        if(!that.hasClass('check_box_sub')) {
            that.find('li:first-child').addClass('oncheck');
        }
    });
});

$(document).on('click','.confirm-filter', function () {
    var args = {};
    $('.oncheck').each(function () {
        var that = $(this);
        if(args[that.data('name')]){
            args[that.data('name')] += ','+that.data('id');
        }else{
            args[that.data('name')] = that.data('id');
        }
    });
    var get_args = url_Encode(args);
    if(get_args.indexOf('&order=near')!==-1){
        if(lockIng) {return;}lockIng = 1;
        setTimeout(function(){lockIng = 0;}, 200);
        job_getlocation(function (position) {
            var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
            job_setlist(null, get_args+'&lat='+lat+'&lng='+lng);
        });
    }else{
        job_setlist(null, get_args);
    }
    $.closePopup();
});

$(document).on('click', '#v_openlocation_job', function () {
    var that = $(this);
    if((HB_INWECHAT&&HS_MULTIUPLOAD)==1){
        wx.openLocation({
            latitude: that.data('lat'),
            longitude: that.data('lng'),
            name: that.data('name'),
            address: that.data('addr'),
            scale: 14,
            infoUrl:window.location.href
        });
    }else if(GOOGLE){
        window.location.href = _APPNAME+'?id=xigua_hs&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng');
    }else{
        window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
    }
    return false;
});
$(document).on('click','.toudi', function () {
    var that = $(this);
    $.ajax({
        type: 'post',
        url: _APPNAME +'?id=xigua_job&ac=com&do=toudi&inajax=1',
        data: {'formhash':FORMHASH, 'jobid':that.data('jobid')},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {}
    });
});
$(document).on('click','.jv_viewbtn_lianxi', function () {
    var that = $(this);
    $.ajax({
        type: 'POST',
        url: _APPNAME + '?id=xigua_job&ac=com&do=checkifview&inajax=1',
        data:{formhash:FORMHASH,rsid:that.data('id')},
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s){
                var msgar = s.split('|');
                if(msgar[2]){
                    window.location.href =msgar[2];
                }else{
                    tip_common(s);
                }
            }
        }
    });
});
function error_promt(tit, msg, btn, btnlink) {
    $.modal({
        title:tit,
        text: msg,
        buttons: [
            { text:quxiao,className: "default",  onClick: function(){} },
            { text:btn, onClick: function(){hb_jump(btnlink);} }
        ]
    });
}
$(document).on('click','.resume_dig_btn', function () {
    var popcm =$('#popup_resume_dig');
    popcm.popup();popcm.show();setTimeout(function(){popcm.show();}, 500);
    return false;
});
$(document).on('click','.resume_refresh_btn', function () {
    var that = $(this);
    $.showLoading();
    $.ajax({
        type: "POST",
        url: _APPNAME+"?id=xigua_job&ac=com&do=resume_refresh&inajax=1",
        data:{formhash:FORMHASH, rsid:that.data('id')},
        dataType: "xml",
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        }
    });
});