<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function job_process(){
    global $navobj,$config,$job_config, $_G,$ac,$do,$aclist,$aclist_login,$page,$lpp,$start_limit,$shid,$hyobj,$rsobj,$jobobj,$gender_ary,$tcobj;

    $navobj = C::t('#xigua_job#xigua_job_nav');
    $shid = intval($_GET['shid']);
    $ac = $_GET['ac'];
    $do = $_GET['do'];
    $aclist = array('index','add', 'my','misc', 'del', 'resume','my_company', 'resumes','resume_li', 'choose','pubjob', 'job_li', 'view', 'resume_view', 'taocan', 'com', 'mytd','myview','resume_manage', 'search','company');
    $aclist_login = array('add', 'misc', 'my','del', 'resume','my_company', 'choose','pubjob', 'resume_view', 'taocan', 'com', 'mytd', 'myview','resume_manage');
    if (!in_array($ac, $aclist)) {
        $ac = 'index';
    }
    if (in_array($ac, $aclist_login) && !$_G['uid']) {
        hb_jump_login();
    }
    $_GET = dhtmlspecialchars($_GET);
    $page = max(1, intval($_GET['page']));
    $lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
    $start_limit = ($page - 1) * $lpp;
    $hyobj = C::t('#xigua_job#xigua_job_hangye');
    $rsobj = C::t('#xigua_job#xigua_job_resume');
    $jobobj = C::t('#xigua_job#xigua_job_job');
    $tcobj = C::t('#xigua_job#xigua_job_taocan');
    $config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $job_config['dftcolor'];
}

function lang_job($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_job', $lang);
    }else{
        return lang('plugin/xigua_job', $lang);
    }
}
function job_dump($t){
    echo '<pre>';
    print_r($t);
    echo '</pre>';
}
function job_set_parse($str){
    global $_G,$SCRITPTNAME;
    $rs = array();
    if($pic_string = $str){
        $top_pics = array_filter(explode("\n", $pic_string));
        if(!empty($top_pics) && is_array($top_pics)){
            foreach ($top_pics as $top_pic) {
                $top_pic = str_replace(array('|',','), ' ', trim($top_pic));
                list( $word, $src, $href) = explode(' ', $top_pic);
                $word = trim($word);
                $src = trim($src);
                $href = trim($href);
                if(empty($href) || $href == '#'){
                    $href = 'javascript:void(0);';
                }
                if($src && $href){
                    if(strpos($src, 'http://') === false && strpos($src, 'https://') === false){
                        $src = $_G['siteurl'] . $src;
                    }
                    $rs[] = array('href' => str_replace('plugin.php', $SCRITPTNAME ,$href), 'src' =>$src, 'name' => $word);
                }
            }
        }
    }
    return $rs;
}

function job_check_bind($type){
    global $_G,$job_config,$SCRITPTNAME;
    $m = unserialize($job_config['mustbind']);
    $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
    if($user['mobile']){
        return true;
    }
    if(count($m)==1&&in_array('1', $m)){
        return true;
    }
    if(in_array($type, $m)){
        if ($_GET['inajax']) {
            hb_message(lang_hb('plzbind', 0), 'error', $SCRITPTNAME.'?id=xigua_hb&ac=myzl'.$GLOBALS['urlext']);
        } else {
            dheader('location: ' . $SCRITPTNAME.'?id=xigua_hb&ac=myzl&referer='.urlencode(hb_currenturl()).$GLOBALS['urlext']);
        }
        return false;
    }
}


function job_format_days($days){
    if($days >= 365) {
        $return= intval($days/365).lang('plugin/xigua_job', 'nian');
    } elseif($days >= 30) {
        $return= intval($days/30).lang('plugin/xigua_job', 'yue');
    } elseif($days >= 1) {
        $return= intval($days).lang('plugin/xigua_job', 'ri');
    }else{
        $return= '';
    }
    return $return;
}


function job_trans($count, $power = 4, $fixed = 1, $id=1) {
    $id1 = '<i id="njum'.$id.'">';
    $id2 = '</i>';
    $count = intval($count);
    if ($count < 10000 || !$power || $power <= 0) {
        return  $id1.$count .$id2;
    } else if ($power < 1) {
        $power = 1;
    } else if ($power > 5) {
        $power = 4;
    }
    $unit = array('', '', '', 'K', lang_hb('wan',0));
    $v = $count / pow(10, $power);
    return $id1.round($v, $fixed).$id2 . $unit[$power];
}

function job_qrcode($mpid, $url, $avatar = ''){
    global $SCRITPTNAME, $job_config, $_G,$urlext;

    if($job_config['typewx'] ==2){
        $upar = parse_url($url);
        $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_job&ac=view&jobid=$mpid&x=1");

        $_qrfile = './source/plugin/xigua_job/cache/sh' . $mpid . '.jpg';
        if (!is_file(DISCUZ_ROOT . $_qrfile)){
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($hb_currenturl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
            }
        }
        $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo='.urlencode($avatar).'&url='.$hb_currenturl;
        return $shqr;
    }else{
        $config = $_G['cache']['plugin']['xigua_hb'];
        if($config['qraut']){
            return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=job_{$mpid}{$urlext}";
        }
        $repath = './source/plugin/xigua_job/cache/';
        $qrfile = $repath . $mpid . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;
        if(!is_file($abs_qrfile)) {
            if (!is_file($abs_qrfile)) {
                @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                if(class_exists('QRcode')){
                    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                }
            }
        }
        return $qrfile;
    }
}