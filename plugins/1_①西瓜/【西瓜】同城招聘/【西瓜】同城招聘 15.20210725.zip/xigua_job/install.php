<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/23
 * Time: 17:20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_job_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `share_title` varchar(200) NOT NULL,
 `share_desc` varchar(200) NOT NULL,
 `share_pic` varchar(200) NOT NULL,
 `showindex` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `showindex` (`showindex`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_job_job` (
 `jobid` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `name` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 `jingyan` varchar(50) NOT NULL,
 `xueli` varchar(50) NOT NULL,
 `realname` varchar(20) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `gender` int(11) NOT NULL,
 `openmobile` tinyint(1) NOT NULL,
 `hy` varchar(200) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `xinzi` varchar(80) NOT NULL,
 `xinziunit` varchar(20) NOT NULL,
 `shiduan` tinyint(3) NOT NULL,
 `opentime` varchar(20) NOT NULL,
 `jiesuan` varchar(80) NOT NULL,
 `neednum` int(11) NOT NULL,
 `minage` int(11) NOT NULL,
 `maxage` int(11) NOT NULL,
 `fuli` varchar(200) NOT NULL,
 `miaoshu` text NOT NULL,
 `album` varchar(2000) NOT NULL,
 `shid` int(11) NOT NULL,
 `shname` varchar(80) NOT NULL,
 `addr` varchar(80) NOT NULL,
 `province` varchar(40) NOT NULL,
 `city` varchar(40) NOT NULL,
 `district` varchar(40) NOT NULL,
 `street` varchar(80) NOT NULL,
 `street_number` varchar(80) NOT NULL,
 `lat` varchar(32) NOT NULL,
 `lng` varchar(32) NOT NULL,
 `endts` int(11) NOT NULL,
 `dig_crts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `status` tinyint(3) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `favs` int(11) NOT NULL,
 `tdnum` int(11) NOT NULL,
 PRIMARY KEY (`jobid`),
 KEY `uid` (`uid`),
 KEY `stid` (`stid`),
 KEY `status` (`status`),
 KEY `crts` (`crts`),
 KEY `upts` (`upts`),
 KEY `dig_endts` (`dig_endts`),
 KEY `dig_crts` (`dig_crts`),
 KEY `gender` (`gender`),
 KEY `endts` (`endts`),
 KEY `type` (`type`),
 KEY `views` (`views`),
 KEY `district` (`district`),
 KEY `city` (`city`),
 KEY `province` (`province`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_job_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_job_resume` (
 `rsid` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `avatar` varchar(200) NOT NULL,
 `birth` varchar(50) NOT NULL,
 `jingyan` varchar(50) NOT NULL,
 `xueli` varchar(50) NOT NULL,
 `realname` varchar(20) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `gender` int(11) NOT NULL,
 `qiustatus` varchar(50) NOT NULL,
 `jobwant` varchar(300) NOT NULL,
 `jobwant_str` varchar(1000) NOT NULL,
 `paywant` varchar(300) NOT NULL,
 `areawant` varchar(300) NOT NULL,
 `areawant_str` varchar(500) NOT NULL,
 `goodat` varchar(300) NOT NULL,
 `description` text NOT NULL,
 `digtype` varchar(11) NOT NULL,
 `dig_crts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `workexp` text NOT NULL,
 `eduexp` text NOT NULL,
 `status` tinyint(3) NOT NULL,
 `album` varchar(2000) NOT NULL,
 `fullstatus` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `xiazainum` int(11) NOT NULL,
 PRIMARY KEY (`rsid`),
 KEY `uid` (`uid`),
 KEY `stid` (`stid`),
 KEY `status` (`status`),
 KEY `crts` (`crts`),
 KEY `upts` (`upts`),
 KEY `dig_endts` (`dig_endts`),
 KEY `dig_crts` (`dig_crts`),
 KEY `gender` (`gender`),
 KEY `fullstatus` (`fullstatus`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_job_taocan` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `delprice` decimal(10,2) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `days` int(11) NOT NULL,
 `xiazai` int(11) NOT NULL,
 `yixiazai` int(11) NOT NULL,
 `fabu` int(11) NOT NULL,
 `yifabu` int(11) NOT NULL,
 `zhiding` decimal(10,1) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `payts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `uid` (`uid`),
 KEY `endts` (`endts`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_job_views` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) unsigned NOT NULL,
 `jobid` int(11) NOT NULL,
 `rsid` int(11) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `crts` (`crts`),
 KEY `upts` (`upts`),
 KEY `uid` (`uid`),
 KEY `jobid` (`jobid`),
 KEY `rsid` (`rsid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_job_xiazai` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) unsigned NOT NULL,
 `jobid` int(11) NOT NULL,
 `rsid` int(11) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '1normal 2yiyaoyue 3hulue',
 `type` varchar(10) NOT NULL,
 `yyts` int(11) NOT NULL,
 `is_xiazai` int(11) NOT NULL,
 `note` varchar(200) NOT NULL,
 `addr` varchar(200) NOT NULL,
 `hrname` varchar(80) NOT NULL,
 `hrmobile` varchar(80) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `crts` (`crts`),
 KEY `upts` (`upts`),
 KEY `uid` (`uid`),
 KEY `type` (`type`),
 KEY `yyts` (`yyts`),
 KEY `is_xiazai` (`is_xiazai`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_job_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `types` varchar(20) NOT NULL,
 `style` varchar(20) NOT NULL,
 `catids` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `types` (`types`),
 KEY `catids` (`catids`)
) ENGINE=InnoDB;

ALTER TABLE `pre_xigua_job_resume` ADD INDEX(`qiustatus`);
SQL;
if($sql){
    runquery($sql);
}
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/discuz_plugin_xigua_job_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_job/install.php');
