<?php exit('Author: https://dism.taobao.com?/?@xigua 西瓜先生 客服QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<div class="page__bd bgf">
<style>.new_search, #searchInput{background:#f5f5f5}</style>
<!--{eval $showsearch = ($ac=='search');}-->
<div class="site_header">
    <!--{if $showsearch}-->
    <form method="get" action="$SCRITPTNAME" id="dosearchform">
        <input name="id" value="xigua_job" type="hidden">
        <input name="ac" value="$_ac" type="hidden">
        <input name="type" value="$_type" type="hidden">
        <input name="high" value="$_high" type="hidden">
        <input type="hidden" name="st" value="$_GET[st]">
        <input type="hidden" name="idu" value="$_GET[idu]">
        <!--{/if}-->
        <header class="x_header cl f15" <!--{if $showsearch}-->style="margin-right:40px"<!--{/if}-->>
        <!--{if !IN_PROG}-->
        <a class="z f14" href="javascript:window.history.go(-1);" style="color:#5e606b;"><i class="iconfont icon-fanhuijiantou w15"></i></a>
        <!--{/if}-->
        <!--{if $showsearch}-->
        <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_job:search}</a>
        <!--{else}-->
        <a class="y sidectrl view_ctrl" style="color:#5e606b;"><i class="iconfont icon-gengduo1 f22"></i></a>
        <!--{/if}-->
        <div class="navtitle pr">
            <a class="new_search" href="$SCRITPTNAME?{echo http_build_query($_GET)}&id=xigua_job&ac=search&from=$_GET['from']">{echo $keyword ? $keyword : $job_config[schtxt]}</a>
            <!--{if $showsearch}-->
            <input type="search" class="serchinput" id="searchInput" placeholder="{$job_config[schtxt]}" required="required" name="keyword" value="$keyword">
            <!--{/if}-->
        </div>
        </header>
        <!--{if $showsearch}-->
    </form>
    <!--{/if}-->
</div>
<!--{if $reckys}-->
    <div id="reckys">
    <div class="weui-cells__title">{lang xigua_job:zjss}
    <a href="javascript:;" class="delrecent y"><i class="iconfont icon-shanchu vm"></i>{lang xigua_job:qk}</a>
    </div>
    <div class="weui-cells before_none after_none">
        <div class="recenttags cl">
            <!--{loop $reckys $_k $_v}-->
            <span><a href="{$SCRITPTNAME}?id=xigua_job&ac=$_ac&high=$_high&type=$_type&keyword={$_k}">{$_k}</a></span>
            <!--{/loop}-->
        </div>
    </div>
    </div>
<!--{/if}-->

    <div class="weui-cells__title">{lang xigua_job:rmss}</div>
    <div class="weui-cells before_none after_none">
        <div class="recenttags cl">
            <!--{eval $job_config[hotsearch] = explode("\n", trim($job_config[hotsearch]))}-->
            <!--{loop $job_config[hotsearch] $_k $_v}-->
            <span><a href="{$SCRITPTNAME}?id=xigua_job&ac=$_ac&high=$_high&type=$_type&keyword={echo trim($_v)}">{echo trim($_v)}</a></span>
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{eval $job_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_job:footer}-->
<script>
$(document).on('click','.delrecent', function () {
    hb_setcookie('reckys', '');
    $('#reckys').remove();
});
$(document).on('click','#dosearch', function () {
    if($('#searchInput').val()){
        $('#dosearchform').submit();
    }else{
        $.alert($('#searchInput').attr('placeholder'));
    }
});
</script>