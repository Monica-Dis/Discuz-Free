<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<div class="page__bd">
    <!--{if $_G['cache']['plugin']['xigua_job']['logo']}--><div class="hide none"><img src="{$_G['cache']['plugin']['xigua_job']['logo']}" /></div><!--{/if}-->
    <!--{if getcookie('miniprogram') && $ac=='resumes'}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
    <!--{if $ac=='index' && $config[showheader]}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if !$hide_nav}-->
    <!--{if $_G['cache']['plugin']['xigua_job']['showfz']}-->
    <header class="x_header bgcolor_11 cl  weui-flex f15" style="background:transparent!important;position:absolute">
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_job&ac=resumes&high=0&mobile=2");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
    </header><!--{/if}-->
<!--{/if}-->
    <!--{if $resumenavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $resumenavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $resumenavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->

    <div style="height:30px;" class="bgf">
        <div class="flnav">
            <div class="z">
                <a class="index_search f14" href="{$SCRITPTNAME}?id=xigua_job&ac=search&from=resumes&high=$_GET['high']&type=$_GET['type']">
                    <img class="hsindexs" src="source/plugin/xigua_job/static/img/sc_on.png">
                    <span style="margin-left:18px">{lang xigua_hs:search}</span></a>
            </div>
            <div class="weui-cell__bd f14 tr">
                <span>{lang xigua_job:ll}: <em class="main_color">$total_view</em></span>
                <span class="ml3">{lang xigua_job:jl}: <em class="main_color">$total_resume</em></span>
                <span class="ml3">{lang xigua_job:ms}: <em class="main_color">$total_yy</em></span>
            </div>
        </div>
    </div>

    <div class="job_nav">
        <div class="weui-cells fixbanner before_none mt0" style="width:calc(100% - 3.5rem)">
            <div class="weui-navbar weui-banner nobg fixbanner_in">
<!--{if $_GET['keyword']}-->
<a href="javascript:;" class="weui-navbar__item weui_bar__item_on ftb" data-keyword="$_GET['keyword']" data-idid="0" data-sort="&id=xigua_job&ac=resume_li&&hyid=0" data-orihtml="$_GET['keyword']">
<span>{lang xigua_job:search}:$_GET['keyword']</span>
</a>
<!--{/if}-->
<a href="javascript:;" class="weui-navbar__item <!--{if !$_GET['keyword']}-->weui_bar__item_on<!--{/if}--> ftb" data-idid="0" data-sort="&id=xigua_job&ac=resume_li&&hyid=0" data-orihtml="{lang xigua_job:tj}">
    <span>{lang xigua_job:tj}</span>
</a>
<!--{loop $hys $_k $_v}-->
<a href="javascript:;" class="weui-navbar__item ftb" data-idid="$_k" data-sort="&id=xigua_job&ac=resume_li&hyid={$_k}" data-orihtml="{$_v}">
<span>$_v</span>
</a>
<!--{/loop}-->
            </div>
        </div>
        <div class="sx_outer"><span class="sx sxuan sxbtn">{lang xigua_job:sx}</span></div>
    </div>
    <div id="list" class="mod-post x-postlist pt0"></div>
    <div class="sxuan main_color top_tip" style="display:none;background:#fff">{lang xigua_job:cxsx}</div>
    <!--{template xigua_hb:loading}-->
</div>

<div id="popup_sx" class="weui-popup__container z501">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:quxiao}</a>
                <h1 class="title">{lang xigua_job:sxrc}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none" style="margin-bottom:75px">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:qwyx}</p>
                        <ul class="check_box cl">
                            <li data-id="0" data-name="paywant" data-only="1">{lang xigua_job:buxian}</li>
                            <!--{loop $xinzi $_k $quan}-->
                            <li data-id="$_k" data-name="paywant" data-only="1">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:gzjy}</p>
                        <ul class="check_box cl">
                            <!--{loop $jingyan $_k $quan}-->
                            <li data-id="$_k" data-name="jingyan" data-only="1">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:xueli}</p>
                        <ul class="check_box cl">
                            <!--{loop $xueli $_k $quan}-->
                            <li data-id="$_k" data-name="xueli" data-only="1">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:jobwant}</p>
                        <ul class="check_box cl filterjobwant">
                            <li data-id="-1" data-name="jobwant">{lang xigua_job:buxian}</li>
                            <!--{loop $jsary $_k $quan}-->
                            <li data-sub="$_k" data-id="$_k" data-name="jobwant">$quan[oname]</li>
                            <!--{/loop}-->
                        </ul>
                        <i class="iconfont icon-xiangxia f13 zkbtn"></i>
                        <!--{loop $jsary $_k $quan}-->
                        <ul class="check_box cl check_box_sub" id="subid_$_k" style="display:none">
                            <li data-backto="$_k">{lang xigua_job:back}</li>
                            <!--{loop $quan[sub] $_v}-->
                            <li data-id="{$_v[id]}" data-name="jobwant">{$_v[oname]}</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{/loop}-->
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:qwdd}</p>
                        <ul class="check_box cl filterjobwant">
                            <li data-id="-1" data-name="areawant">{lang xigua_job:buxian}</li>
                            <!--{loop $distjsary $quan}-->
                            <li data-sub="_$quan[id]" data-id="$quan[id]" data-name="areawant">{eval echo diconv($quan[name],'UTF-8',CHARSET)}</li>
                            <!--{/loop}-->
                        </ul>
                        <i class="iconfont icon-xiangxia f13 zkbtn"></i>
                        <!--{loop $distjsary $quan}-->
                        <ul class="check_box cl check_box_sub" id="subid__{$quan[id]}" style="display:none">
                            <li data-backto="$quan[id]">{lang xigua_job:back}</li>
                            <!--{loop $quan[sub] $_v}-->
                            <li data-id="{$_v[id]}" data-name="areawant">{eval echo diconv($_v[name],'UTF-8',CHARSET)}</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{/loop}-->
                    </div>
                </div>

                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:gender}</p>
                        <ul class="check_box cl">
                            <!--{loop $gender_ary $_k $quan}-->
                            <li data-id="$_k" data-name="gender" data-only="1">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
            </div>
            <div class="fix-bottom sxbtns cl">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_default close-popup" value="{lang xigua_job:quxiao}">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_default close-reset" value="{lang xigua_job:cz}">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_primary confirm-filter" value="{lang xigua_job:queding}">
            </div>
        </div>
    </div>
</div>
<script src="source/plugin/xigua_hb/static/countUp.js"></script><script>
var loadingurl = window.location.href+'&ac=resume_li&type=$_GET[type]&inajax=1&page=';scrollto = 1;
setTimeout(function () {$('.close-reset').trigger('click');}, 800);
var options={useEasing:true,useGrouping:true,separator:'',decimal:'.',prefix:'',suffix:''};
new countUp("njum1", 0, $('#njum1').text(), 0, 2.5, options).start();
new countUp("njum2", 0, $('#njum2').text(), 0, 2.5, options).start();
new countUp("njum3", 0, $('#njum3').text(), 0, 2.5, options).start();
</script>
<!--{eval $tabbar=0;$job_tabbar=1;}-->
<!--{template xigua_job:pubcheck}-->
<!--{template xigua_job:footer}-->
<!--{if $_G['cache']['plugin']['xigua_job']['showfz'] && $_G['cache']['plugin']['xigua_hs'] && $_G['cache']['plugin']['xigua_st']['dingwei'] && !getcookie('setcitygeo')}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script><script>function autolbshs(){
        hs_getlocation(function (position) {
            var citylat = (position.latitude||position.lat);
            var citylng = (position.longitude||position.lng);
            $.ajax({
                type: 'GET',
                url: _APPNAME + '?id=xigua_hs&ac=getloc&checkst=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
                dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    console.log(s);
                    var m = s.split('|');
                    if('success' == m[0]){
                        var _t = m[1].split(',');
                        console.log(_t);
                        if(_t[0]>0 && _t[0]!='{$_GET[st]}'){
                            $.confirm("{lang xigua_hb:dqdws}"+_t[1]+'{lang xigua_hb:setcitygeo2}', function() {
                                window.location.href = _APPNAME+"?id=xigua_job&ac=resumes&high=0&st="+_t[0];
                                hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                            }, function() {
                                hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                            });
                        }else{
                            hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                        }
                    }
                }
            });
        });}
    if(typeof wx!='undefined'){wx.ready(function () { autolbshs(); });}else{setTimeout(function(){ autolbshs(); }, 300);}
</script><!--{/if}-->