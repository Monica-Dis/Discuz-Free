<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_job&ac=mytd&high=3" class="weui-navbar__item <!--{if !$_GET[type]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:qbzw}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_job&ac=mytd&type=full&high=3" class="weui-navbar__item <!--{if $_GET[type]=='full'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:full}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_job&ac=mytd&type=part&high=3" class="weui-navbar__item <!--{if $_GET[type]=='part'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:part}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_job&ac=mytd&type=yy&high=3" class="weui-navbar__item <!--{if $_GET[type]=='yy'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:ms}</span>
        </a>
    </div>
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
var loadingurl = window.location.href+'&ac=mytd&do=li&inajax=1&page=';scrollto = 0;
</script>
<!--{eval $tabbar=0;$job_tabbar=1;}-->
<!--{template xigua_job:footer}-->