<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $k $v}-->
<div class="cl border_bfull viewme_li">
    <div class="resume_left">
        <div class="resume_logo"><img src="{echo avatar($v[uid], 'middle', 1)}"></div>
    </div>
    <div class="resume_right">
        <div class="resume_realname cl">
            <span>{$users[$v[uid]][username]}</span>
            <span class="resume_span">{$v[upts_u]}{lang xigua_job:ckljl}</span>
        </div>
        <div class="resume_p">
            <span class="resume_spani main_red ml0">{echo $xiazai[$v[uid]][realname]? lang_job('yxz',0) : lang_job('wxz',0);}</span>
        </div>
    </div>
</div>
<!--{/loop}-->