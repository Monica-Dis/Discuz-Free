<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
<!--{if !$jobinfo}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_job&ac=resume_manage&type=xiazai" class="weui-navbar__item <!--{if !$_GET[type]||$_GET[type]=='xiazai'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:xzjl}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_job&ac=resume_manage&type=toudi" class="weui-navbar__item <!--{if $_GET[type]=='toudi'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:sdjl}</span>
        </a>
    </div>
<!--{/if}-->
    <div class="banner" style="position:relative">
        <nav class="weui-flex tag_list">
            <a href="$SCRITPTNAME?id=xigua_job&ac=resume_manage&jobid=$jobid&type=$_GET[type]" class="<!--{if !$_GET['status']}-->main_color<!--{/if}-->">
                <span>{lang xigua_job:qb}</span>
            </a>
            <!--{loop $toudi_status $_k $_v}-->
            <a href="$SCRITPTNAME?id=xigua_job&ac=resume_manage&jobid=$jobid&type=$_GET[type]&status=$_k" class="<!--{if $_k==$_GET['status']}-->main_color<!--{/if}-->">
                <span>$_v</span>
            </a>
            <!--{/loop}-->
        </nav>
    </div>
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
</div>

<div id="yy_pop" class="weui-popup__container popup-bottom" style="z-index:501">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:quxiao}</a>
                <h1 class="title">{lang xigua_job:yaoyue}<em id="yy_username"></em>{lang xigua_job:ms}</h1>
            </div>
        </div>
        <div class="modal-content">
<form  action="$SCRITPTNAME?id=xigua_job&ac=com&do=resume_yy&st={$_GET['st']}" method="post" id="form">
<input type="hidden" name="formhash" value="{FORMHASH}">
<input type="hidden" name="uid" id="uid">
<input type="hidden" name="jobid" id="jobid">

            <div class="weui-cells weui-cells_form">
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_job:msgw}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" id="job" type="text" placeholder="{lang xigua_job:djxzgw}" value="">
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label for="time-inline" class="weui-label">{lang xigua_job:yysj}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" id="time-inline" type="text" name="yy_time" value="{echo date('Y-m-d 10:00', TIMESTAMP+86400)}">
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <textarea class="weui-textarea" name="note" placeholder="{lang xigua_job:qtxnote}" rows="2"></textarea>
                    </div>
                </div>
            </div>

            <div class="fix-bottom cl" style="position:relative">
                <input type="submit" href="javascript:;" class="weui-btn weui-btn_primary confirm_yy" value="{lang xigua_job:queding}">
            </div>
</form>
        </div>
    </div>
</div>

<script>
var loadingurl = window.location.href+'&do=resume_manage_li&inajax=1&page=';scrollto = 0;

$("#time-inline").datetimePicker();

var jo_ary = [];<!--{loop $myjobs $k $v}-->jo_ary[{$v[jobid]}] = "{$v[shname]} - {$v[type_u]} {$v[name]}";<!--{/loop}-->

$("#job").select({
    title: "{lang xigua_job:djxzgw}",
    items: [<!--{loop $myjobs $k $v}-->{title: "{$v[shname]} - {$v[type_u]} {$v[name]}", value:$v[jobid]},<!--{/loop}-->],
    onChange: function(d) {$('#jobid').val(d.values);}
});
$(document).on('click','.yybtn1', function () {
    var that = $(this);
    var jbid = that.data('jobid');
    var popcm =$('#yy_pop');
    popcm.popup();popcm.show();setTimeout(function(){popcm.show();}, 500);
    $('#yy_username').html(that.data('realname'));
    $('#uid').val(that.data('uid'));
    $('#jobid').val(jbid);
    $("#job").select("update", { input: jo_ary[jbid]});
    return false;
});
$(document).on('click','.ignore_yy', function () {
    var that = $(this);
    $.confirm("{lang xigua_job:sfhl}"+that.data('realname'), function() {
        $.showLoading();
        $.ajax({
            type: "POST",
            url: _APPNAME+"?id=xigua_job&ac=com&do=resume_ignore_yy&inajax=1",
            data:{formhash:FORMHASH, rsid:that.data('rsid'), uid:that.data('uid')},
            dataType: "xml",
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            }
        });
    }, function() {
    });
});
</script>
<!--{eval $tabbar=0;$job_tabbar=1;}-->
<!--{template xigua_job:footer}-->