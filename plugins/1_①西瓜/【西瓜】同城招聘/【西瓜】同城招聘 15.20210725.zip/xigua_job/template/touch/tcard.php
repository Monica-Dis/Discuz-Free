<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style><!--{if 0}-->.tc_col{width:50%}<!--{/if}--></style>
<div class="tcnav">
    <div class="tcnav_top cl f14">
        <p class="z"><i class="iconfont icon-huiyuan1 main_color f14"></i> {$taocan[name]}</p>
        <p class="y c9">{$taocan[endts_u]}{lang xigua_job:gq}</p>
    </div>
    <div class="cl">
        <div class="tc_col"><p><em>{$taocan[yifabu]}/</em>{$taocan[fabu]}{lang xigua_job:t}</p> <span>{lang xigua_job:fbzw}</span></div>
        <div class="tc_col"><p><em>{$taocan[yixiazai]}/</em>{$taocan[xiazai]}{lang xigua_job:f}</p> <span>{lang xigua_job:xzjl}</span></div>
        <!--{if $taocan[zhiding]>0}-->
        <div class="tc_col"><p><em>{$taocan[zhiding]}</em>{lang xigua_job:zhe}</p> <span> {lang xigua_job:zdzw}</span></div>
        <!--{else}-->
        <div class="tc_col"><p class="c9">{lang xigua_job:wzk}</p> <span> {lang xigua_job:zdzw}</span></div>
        <!--{/if}-->
    </div>
</div>