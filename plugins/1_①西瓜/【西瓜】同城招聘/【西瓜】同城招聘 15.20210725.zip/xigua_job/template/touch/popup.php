<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="popup_jobwant" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:wc}</a>
                <h1 class="title">{lang xigua_job:plzjobwant}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cell list4 bgf f14">
                <div class="cl weui-cells_radio">
                    <!--{loop $fullstatuss $_k $_v}-->
                    <label class="z weui-check__label mr10" for="xx$_k">
                        <input type="radio" class="weui-check" name="form[fullstatus]" value="$_k" id="xx$_k" <!--{if $fullstatus==$_k}-->checked<!--{/if}-->>
                        <span class="weui-icon-checked"></span> $_v
                    </label>
                    <!--{/loop}-->
                </div>
            </div>
            <div class="border_bottom post_com_tag post-tags cl" id="p1"><!--{loop $old_data['jobwant_ary'] $_k $_v}--><a id="id_p1{$_v}" data-form="jobwant" data-ld="p1" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">{$old_data['jobwant_str_ary'][$_k]}<input name="form[jobwant][]" type="hidden" value="$_v"></a><!--{/loop}--></div>
            <div class="pupc-btm">
                <div class="pupc-btm-in">
                    <!--{loop $jsary $_k $_v}-->
                    <a class="border_bottom check1 <!--{if $_k==0}-->main_color<!--{/if}-->" data-title="{$_v[id]}" data-titfix="p1_" >{$_v[oname]}</a>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left">
                    <!--{loop $jsary $_k $_v}-->
                    <div class="pupc-btm-in_list <!--{if $_k>0}-->none<!--{/if}-->" id="p1_{$_v[id]}">
                        <!--{loop $_v[sub] $__v}-->
                        <a class="check2 pupc_check_a border_bottom" data-max="{echo $job_config[maxjobwant]-1}" data-maxtip="{lang xigua_job:zd}{$job_config[maxjobwant]}{lang xigua_job:g}" data-form="jobwant" data-ld="p1" data-title="p1{$__v[id]}" data-value="{$__v[id]}">{$__v[oname]}</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
    </div>
</div>
<div id="popup_areawant" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:wc}</a>
                <h1 class="title">{lang xigua_job:plzareawant}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="border_bottom post_com_tag post-tags cl" id="p2"><!--{loop $old_data['areawant_ary'] $_k $_v}--><a id="id_p2{$_v}" data-form="areawant" data-ld="p2" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">{$old_data['areawant_str_ary'][$_k]}<input name="form[areawant][]" type="hidden" value="$_v"></a><!--{/loop}--></div>
            <div class="pupc-btm">
                <div class="pupc-btm-in">
                    <!--{loop $distjsary $_k $_v}-->
                    <a class="border_bottom check1 <!--{if $_k==0}-->main_color<!--{/if}-->" data-title="{$_v[id]}" data-titfix="p2_" >{echo diconv($_v[name], 'UTF-8', CHARSET)}</a>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left">
                    <!--{loop $distjsary $_k $_v}-->
                    <div class="pupc-btm-in_list <!--{if $_k>0}-->none<!--{/if}-->" id="p2_{$_v[id]}">
                        <!--{loop $_v[sub] $__v}-->
                        <!--{eval $__name = diconv($__v[name], 'UTF-8', CHARSET);}-->
                        <a class="check3 pupc_check_a border_bottom" data-name="$__name" data-max="{echo $job_config[maxareawant]-1}" data-maxtip="{lang xigua_job:zd}{$job_config[maxareawant]}{lang xigua_job:g}" data-form="areawant" data-ld="p2" data-title="p2{$__v[id]}" data-value="{$__v[id]}">$__name</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left none" id="distbox"></div>
            </div>
        </div>
    </div>
</div>
<script src="source/plugin/xigua_job/static/popup.js?3{VERHASH}"></script>