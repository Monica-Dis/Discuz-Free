<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_job:header}-->
<link href="source/plugin/xigua_job/static/company.css?{VERHASH}" rel="stylesheet" />
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="shviewposition-top-bar">
        <div class="shviewline">
            <div class="shviewtopbar">
                <div class="shop-head">
                    <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]"><img src="{$sh[logo]}"></a>
                </div>
                <div class="shviewright-box">
                    <a class="shviewname" href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]">
                        <div class="shop-name-span">{$sh[name]}
                            <!--{if ($veris2[$shid] || $bao[$sh[uid]])}-->
                            <span class="sp_desc sp_tag">
                                <!--{if $veris2[$shid]}--><!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-dropbox vm"></i><!--{/if}--><!--{/if}-->
                                <!--{if $bao[$sh[uid]]}--><!--{if !$bao[$sh[uid]][icon]}--><!--{eval $bao[$sh[uid]][icon] = $_G[cache][plugin][xigua_hr][bzjtb];}--><!--{/if}--><!--{if $bao[$sh[uid]][icon]}--><img class="rzimg vm" src="$bao[$sh[uid]][icon]" /> <!--{else}--><i class="iconfont icon-baozhengjinmoshi color-good vm pr_1" style="font-size:19px"></i><!--{/if}--><!--{if $_G[cache][plugin][xigua_hr][bzjed]}--><span class="f13 main_color">{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$sh[uid]][price]}{lang xigua_hb:yuan}</span><!--{/if}--><!--{/if}-->
                            </span>
                            <!--{/if}-->
                        </div>
                    </a>
                    <div class="rzSignedBox" style="margin-left:0">
                        <p class="sp_desc main_color sp_tag" style="margin-left:.5rem">
                            <span class="mod-feed-tag b-color12" style="line-height:.9rem;margin-bottom:0">$sh[hangye]</span>
                            <!--{if $sh[guimo]}-->
                            <span class="mod-feed-tag b-color12" style="line-height:.9rem;margin-bottom:0">$sh[guimo]</span>
                            <!--{/if}-->
                        </p>
                    </div>
                    <div class="shviewmess" style="margin-top:.5rem">
                        <div class="focus">
                            <!--{if $followed}-->
                            <a href="javascript:;" class="do_follow main_bg" data-id="$shid"><em>{lang xigua_hs:yiguanzhu}</em></a>
                            <!--{else}-->
                            <a href="javascript:;" class="do_follow main_bg" data-wei="1" data-id="$shid"><em>{lang xigua_hs:jiaguanzhu}</em></a>
                            <!--{/if}-->
                        </div>
                        <span class="fans-num"><text>{$sh[follow]}</text>{lang xigua_hs:fans}</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="shviewintroduction border_top">
            <p class="intr-mess">
                $sh[jieshao]
            </p>
        </div>
    </div>

    <ul class="helist mt0" id="list" style="padding-top:0">
        <div class="weui-cell bgf mt10">
            <div class="weui-cell__bd">
                <p style="color:#000;font-weight:bold">{lang xigua_job:zzzw} ( <em class="main_color">$hdcount</em> )</p>
            </div>
        </div>
    </ul>
    <script>
        var loadingurl = window.location.href+'&ac=job_li&shid=$shid&inajax=1&pagesize=20&page=';
    </script>
    <!--{template xigua_hb:loading}-->
</div>

<!--{eval $tabbar=0;$job_tabbar=1;}-->
<!--{template xigua_job:footer}-->
<script>
    $(document).on('click','.do_follow', function () {
        var that = $(this);
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_hs&ac=follow&do=do_follow&shid='+that.data('id')+'&inajax=1',
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.split('|')[1]=='1'){
                    that.html('{lang xigua_hs:yiguanzhu}').addClass('weui-btn_disabled');
                }else{
                    tip_common(s);
                    that.html('{lang xigua_hs:jiaguanzhu}').removeClass('weui-btn_disabled');
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    });
</script>