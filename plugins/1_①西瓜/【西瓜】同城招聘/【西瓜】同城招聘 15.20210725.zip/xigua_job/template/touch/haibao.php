<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
$shot_img = $v[album][0]?$v[album][0]:'';
$ccc = $job_config[redcolor] ? $job_config[redcolor] : $config[maincolor];
$shot_file = 'source/plugin/xigua_job/cache/'.md5($shot_img).'.png';
if($shot_img && strpos($shot_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$shot_file)):
        file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
    endif;
    $shot_img = $shot_file;
endif;
$hb_currenturl = hb_currenturl();

$shlogo = $v[sh][logo];
$shlogo_file = 'source/plugin/xigua_job/cache/'.md5($shlogo).'.png';
if($shlogo && strpos($shot_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$shlogo_file)):
        file_put_contents(DISCUZ_ROOT.$shlogo_file, file_get_contents($shlogo));
    endif;
    $shlogo = $shlogo_file;
endif;
$hbavatar = $v[avatar];
}-->
<style>
.hbtn{background-color:$config[maincolor];box-shadow: 1px 1px 10px $config[maincolor]}
.mpc {margin: 15px;box-shadow: 1px 1px 10px rgba(0, 0, 0, .1);border-radius: 10px;overflow: hidden;}
.mpc_body .dh_viewheader{margin-bottom:0;}
.mpc_body {position: relative;background:#fff;background-size: cover;width: calc(100vw - 30px);min-height: calc(((100vw) / 1.95) - 15px);text-align: center;}.mpc_body .mpc_guide {color: #ADAFB2;margin-bottom: 10px;padding-top: calc(((100vw / 1.95) - 15px) / 2 - 40px);font-size: 16px;}.mpc_body .mpc_link {color: #7C8087;border: 1px solid;padding: 0 20px;border-radius: 100px;text-align: center;transform: scale(0.5);-webkit-transform: scale(0.5);transform-origin: 50% 0;-webkit-transform-origin: 50% 0;height: 76px;line-height: 76px;font-size: 30px;display: block;}.mpc_area {text-align: center;background: #F6F7FA;padding: 15px 0;}.mpc_area p {font-size: 14px;color: #999;}.mpb a {text-align: center;}.mpb {margin: 45px 15px 30px}.mpc_main {text-align: left;padding: 15px;position: relative}.mpc_main_top {}.mpc_main_top h2 {font-size: 26px;color: #333;float: left;width: 100%;text-align: left;position: relative;top: -2px;}.mpc_main_top p {color: #666;float: left;font-size: 14px;}.mpc_main_top .ava {width: 60px;height: 60px;position: absolute;right: 15px;top: 15px;border-radius: 60px;overflow: hidden;}.mpc_main_top .ava img {width: 100%;height: 100%;display: block;}.mpc_main_list li, .mpc_main_list > div {position: relative;padding-left: 10px;font-size: 13px;line-height: 20px;color: #999;}.mpc_main_list li:first-child, .mpc_main_list > div:first-child {padding-left: 0}.mpc_main_list li:not(:first-child):before, .mpc_main_list > div:not(:first-child):before {content: '';position: absolute;top: 7px;left: 0;right: 0;background-color: #ccc;height: 4px;width: 4px;border-radius: 10px;}.mpc_main_ft {font-size: 14px}.light-bottom {position: relative;background: transparent;box-shadow: none}.mpc_main_list, .mpc_main_ft {margin-top: 8px}#myshop {margin-left: 8px;opacity: 0}.filter_nav {white-space: nowrap;}.blur{display:none}.qrblock{width:90px;height:90px;display:block;float:right}.qreidl{padding:0 15px 15px;color: #fff;background:$ccc;}.bnphao{color: #fff;border-radius:3px;padding: 0 8px;font-size: 14px;height: 22px;line-height:22px;background:#ff6565;display:inline-block;}.dh_viewheader .shot_img img{width:100%;display:block;max-height:400px}.shot_img{overflow:hidden}
.shot_info{position: relative;border-radius: 50px;padding:15px;text-align: left;background-color:#fff}
.tl{text-align: left;}.jv_addr2 #driving{display:none}.jv_addr2{font-size: 14px;color: #333;margin-bottom: 5px;margin-top: -4px;}
.mpc .dphs_inner{background:#f5f5f5}
.mpc .dpavatar{position:absolute;top:-25px;background:#fff;width:50px;height:50px}
.mpc .userc{padding-top:5px;line-height:20px;height:20px;margin-left:65px;font-size:15px}
.mpc .dpdesc{color:#333;font-size:16px;margin-top:10px}
.qreidl .ttile{font-size:22px}.shot_in{padding-top: 1px;padding-bottom: 1px;border-radius: 10px;overflow: hidden;}.shot_in .dp_yz{ background-origin: content-box;}
</style>
<div class="right_float hbtn hbtn_share"></div>
<script src="source/plugin/xigua_hb/static/js/html2canvas.min.js?{VERHASH}"></script>
<div id="shot" style="position:fixed;bottom:-100000px">
    <div class="shot_in main_bg">
        <div class="mpc">
            <div class="mpc_body">
                <div class="dh_viewheader bgf">
                    <!--{if $shot_img}--><div class="shot_img"><img src="{$shot_img}"></div><!--{/if}-->
                    <div class="shot_info cl" style="overflow:hidden;min-height: 50vw;"></div>
                </div>
            </div>
        </div>
        <div class="weui-flex qreidl">
            <div class="weui-flex__item" style="height:90px!important;">
                <p class="ttile">$job_config[hbtitle]</p>
                <p class="f16 mt8">$job_config[hbdesc]</p>
            </div>
        <div>
<!--{eval include_once 'source/plugin/xigua_job/include/c_haibao.php';}-->
<!--{if $_G['cache']['plugin']['xigua_hx'] && IN_PROG}-->
    <img src="$shqr" class="qrblock">
<!--{else}-->
    <img src="{eval echo job_qrcode($v['jobid'], $hb_currenturl, $shot_img);}"  class="qrblock" />
<!--{/if}-->
            </div>
        </div>
    </div>
</div>
<script>
$(document).on('click','.hbtn_share', function () {
    $.ajax({type: 'post',url: _APPNAME +'?id=xigua_job&ac=com&do=incr&incr_type=shares&jobid=$v[jobid]&inajax=1',data: {'formhash':FORMHASH},dataType: 'xml'});
    $.showLoading();
    var cmpany = $('.jv_shname').length>0? '<div class="jv_addr2">'+$('.jv_shname').html()+'</div>':'';
    $('.shot_info').html($('.jv_top').html().replace('</h2>','</h2>'+cmpany));
    html2canvas(document.querySelector(".shot_in")).then(canvas => {
        var dataURL = canvas.toDataURL();
        COMCLAS = 'shot_outer';
        $.hideLoading();
        $.modal({
            title: "{lang xigua_job:ca}",
            text: "<img style='display:block' src='"+dataURL+"' />",
            buttons: [{ text: "{lang xigua_hb:close}", onClick: function(){} }]
        });
        $('.weui-dialog__title').css('font-size', '14px');
        COMCLAS = '';
    });
    return false;
});
</script>