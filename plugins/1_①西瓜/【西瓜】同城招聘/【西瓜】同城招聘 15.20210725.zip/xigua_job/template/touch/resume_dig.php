<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="resume_digbox">
<div id="dftvip" class="cl car-type pt0">
    <div class="type-item-box">
        <!--{loop $digtys $___k $___v}-->
        <label for="s{$___k}" class="type-item J_ping type-item-gray">
            <input type="radio" class="none" name="form[digtype]" value="{$___k}" id="s{$___k}" <!--{if $___k==0}-->checked="checked"<!--{/if}-->>
            <!--{if $___k==0}-->
            <div class="type-title">{lang xigua_job:bzd}</div>
            <!--{else}-->
            <div class="type-title">{lang xigua_job:zdjl}{$___k}{lang xigua_hb:day}</div>
            <!--{/if}-->
            <div class="car-sku-year cl">
                <div class="type-discount">
                    <!--{if $___v>0}-->
                    <span class="car-price">{echo floatval($___v)}</span><span class="car-unit">{lang xigua_hb:yuan}</span>
                    <!--{else}-->
                    <span class="car-unit">{lang xigua_job:mf}</span>
                    <!--{/if}-->
                </div>
            </div>
            <div class="car-active-b">
            <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
            </div>
        </label>
        <!--{/loop}-->
    </div>
</div>
</div>