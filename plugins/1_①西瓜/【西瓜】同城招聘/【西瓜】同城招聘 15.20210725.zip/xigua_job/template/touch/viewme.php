<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->

</div>
<script>
    var loadingurl = window.location.href+'&ac=myview&do=viewme_li&inajax=1&page=';scrollto = 0;
</script>
<!--{eval $tabbar=0;$job_tabbar=1;}-->
<!--{template xigua_job:footer}-->