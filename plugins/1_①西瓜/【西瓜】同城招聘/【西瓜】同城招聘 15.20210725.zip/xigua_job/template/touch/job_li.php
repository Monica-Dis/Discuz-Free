<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $k $v}-->
<!--{if $_GET['is_my']}-->
<div class="job_li cl border_bottom">
    <div class="job_top jump_job" data-id="$v[jobid]">
        <h4>{$v[name]}
            <span class="jbtn">{$v[type_u]}</span>
            <!--{if $v[is_dig]}-->
            <span class="jbtn is_dig">{lang xigua_job:dig}</span>
            <!--{/if}-->
            <span class="jbtn jbtn_gray y">{$job_status[$v[status]]}</span>
        </h4>
    </div>
    <div class="job_li_mid cl jump_job" data-id="$v[jobid]">
        <div class="z">
            <span class="resume_spani"> {lang xigua_job:views} <em class="c3">{$v[views]}</em></span> <span class="resume_spani">{lang xigua_job:sdjl} <em class="c3">{$v[tdnum]}</em></span>
        </div>
        <div class="y">
            <span class="resume_spani">{$v[upts_u]}{lang xigua_job:shuaxin}</span>
        </div>
    </div>
    <div class="job_li_mid cl">
        <div class="z f12 c9">{lang xigua_job:endts}: {$v[endts_u]}</div>
        <!--{if $v[dig_endts_u]}-->
        <div class="y f12 c9">{lang xigua_job:digts}: {$v[dig_endts_u]}</div>
        <!--{/if}-->
    </div>
    <div class="job_mid cl">
        <div class="z">
            <!--{if $v[status]==9}-->
            <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn offline_btn" data-jobid="$v[jobid]" data-xiajia="0">{lang xigua_job:sjia}</a>
            <!--{else}-->
            <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn offline_btn" data-jobid="$v[jobid]" data-xiajia="1">{lang xigua_job:xjia}</a>
            <!--{/if}-->
            <a href="$SCRITPTNAME?id=xigua_job&ac=pubjob&jobid=$v[jobid]" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_job:edit}</a>
            <a href="$SCRITPTNAME?id=xigua_job&ac=resume_manage&type=toudi&jobid=$v[jobid]" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_job:sdjl}</a>
        </div>
        <div class="y">
            <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn1 refresh_btn" data-jobid="$v[jobid]">{lang xigua_job:shuaxin}</a>
            <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn1 dig_btn" data-jobid="$v[jobid]">{lang xigua_job:dig}</a>
        </div>
    </div>
</div>
<!--{else}-->
<div class="job_li2 cl border_bfull">
    <div class="job_top2 jump_job" data-id="$v[jobid]">
        <h4>{$v[name]}
            <!--{if $v[is_dig]}-->
            <span class="jbtn is_dig pr-1">{lang xigua_job:dig}</span>
            <!--{/if}-->
            <!--{if $mytd_list[$v[jobid]] && !$_GET[type]}-->
            <span class="jbtn">{$v[type_u]}</span>
            <!--{/if}-->
            <!--{if $v[distance]}-->
            <span class="job_top_side y">$v[distance]</span>
            <!--{else}-->
            <span class="job_top_side y">$v[crts_u]</span>
            <!--{/if}-->
        </h4>
    </div>
    <div class="job_main2 cl jump_job" data-id="$v[jobid]">
        <div class="job_main_lef cl">
            <p>
                <span class="jv_xz f16">{echo str_replace(lang_hb('yuan',0), '', $v[xinzi])}<!--{if $yuanshi[$v['xinziunit']]}-->$yuanshi[$v['xinziunit']]<!--{else}--><!--{/if}--></span>
                <!--{if $v[hy_ary][0]}-->
                <span class="resume_span_small">{$v[hy_ary][0]}</span>
                <!--{/if}-->
                <!--{if $v[district]}-->
                <span class="resume_span_small">{$v[city]}{$v[district]}</span>
                <!--{/if}-->
            </p>
            <p>
                <!--{if $v[shname]}-->
                <span class="c9 f14">$v[shname]</span>
                <!--{/if}-->
                <!--{if !($_G[cache][plugin][xigua_hr][qytb]||$_G[cache][plugin][xigua_hr][bzjtb]) && ($veris2[$v[shid]] || $bao[$v[uid]])}-->
                <!--{if $veris2[$v[shid]] && $v[shid]>0}--><!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-dropbox vm"></i><!--{/if}--><!--{/if}-->
                <!--{if $bao[$v[uid]]}--><!--{if !$bao[$v[uid]][icon]}--><!--{eval $bao[$v[uid]][icon] = $_G[cache][plugin][xigua_hr][bzjtb];}--><!--{/if}--><!--{if $bao[$v[uid]][icon]}--><img class="rzimg vm" src="$bao[$v[uid]][icon]" /> <!--{else}--><i class="iconfont icon-baozhengjinmoshi color-good vm f18"></i><!--{/if}--><!--{if $_G[cache][plugin][xigua_hr][bzjed]}--><span class="f13 main_color">{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</span><!--{/if}--><!--{/if}-->
                <!--{/if}-->
            </p>
            <p class="cl item_tags">
                <!--{loop $v[fuli_ary] $_k $_v}-->
                <span class="mod-feed-tag b-color0 main_color">{$_v}</span>
                <!--{/loop}-->
            </p>
        </div>
        <!--{if $v[album]}--><div class="job_imglist"><!--{loop array_reverse(array_slice($v[album],0,2)) $img}--><img src="$img"><!--{/loop}--></div><!--{/if}-->
    </div>
    <!--{if $mytd_list[$v[jobid]][status]}-->
    <div class="job_btm2 cl jump_job" data-id="$v[jobid]">
        <p class="z f12 color-forest">{$toudi_status[$mytd_list[$v[jobid]][status]]}</p>
        <!--{if $mytd_list[$v[jobid]][status]==2}-->
        <p class="y f12 c9">{lang xigua_job:yysj}: $mytd_list[$v[jobid]][yyts_u]</p>
        <!--{elseif $mytd_list[$v[jobid]][upts_u]}-->
        <p class="y f12 c9">{lang xigua_job:zzgx}: $mytd_list[$v[jobid]][upts_u]</p>
        <!--{elseif $mytd_list[$v[jobid]][crts_u]}-->
        <p class="y f12 c9">{lang xigua_job:tdsj}: $mytd_list[$v[jobid]][crts_u]</p>
        <!--{/if}-->
    </div>
    <!--{elseif $v[username]}-->
    <div class="job_btm2 cl jump_job" data-id="$v[jobid]">
        <div class="z">
            <img class="jv_avatar" src="{avatar($v[uid], 'middle', 1)}" />
        </div>
        <a class="z ml8 f14">{$v['username']}</a>
        <a class="y job_li_link">{lang xigua_job:lgz}</a>
    </div>
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{/loop}-->
