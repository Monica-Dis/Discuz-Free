<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/mynew.css?{VERHASH}" />
<style>.x_header{position:relative}.centtop1 a i{color:{$config[maincolor]}}.centtop2 a i{color:#999}.my_new_bd .my__head_wap{height:7.5rem}
.my_new_bd .my__head_wap .weui-grids-mini{position: relative;bottom:0}
.my_new_bd .my__head_new{margin-bottom:0;height:7.5rem}.my_new_bd .my__head_user{margin:.5rem .75rem}.my_new_bd .jnav .weui-grid__label{margin-top:.5rem}.my_new_bd .qblink{padding-right:.5rem!important}.navtitle{display:none}</style>
<!--{eval
if(!$taocan):
    $taocan = array(
        'name' => lang_job('wtc',0),
        'xiazai' => 0,
        'fabu' => 0,
        'days' => 0,
        'delprice' => 0,
        'price' => 0,
        'yixiazai' => 0,
        'yifabu' => 0,
        'endts_u' => lang_job('y',0),
    );
endif;
}-->
<div class="page__bd my_new_bd">
    <div class="do_bd">
        <!--{template xigua_hb:common_nav}-->
        <div class="my__head_new main_bg" <!--{if $taocan||1}-->style="height:auto;padding-bottom:2.5rem;"<!--{/if}-->>
        <i class="header-annimate-element1"></i><i class="header-annimate-element4"></i>
        <i class="header-annimate-element5"></i><i class="header-annimate-element6"></i>
        <i class="header-annimate-element7"></i><i class="header-annimate-element8"></i>
        <i class="header-annimate-element9"></i>
        <div class="my__head_wap block">
            <div class="my__head_user z">
                <!--{if $_G['cache']['plugin']['xigua_member']}-->
                <a href="$SCRITPTNAME?id=xigua_member:profile" class="my__head_avatar z"><img src="$avatar" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'" ></a>
                <!--{else}-->
                <span class="my__head_avatar z"><img src="$avatar" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'"></span>
                <!--{/if}-->
<div>
    <div class="my__head_nickname f16">{$_G[username]} <em class="f12 op6">UID:{$_G[uid]}</em></div>
    <!--{if $_G['cookie']['is_company']}-->
        <a href="$resumelink" class="qblink"><i class="iconfont icon-bianji f10"></i> {lang xigua_job:ckyrdw}</a>
    <!--{else}-->
        <!--{if $myresume[qiustatus]}-->
        <a href="$resumelink" class="qblink">{$myresume[qiustatus]}<i class="iconfont icon-jinrujiantou f10"></i></a>
        <!--{else}-->
        <a href="$resumelink" class="qblink">{lang xigua_job:cjjl}<i class="iconfont icon-jinrujiantou f10"></i></a>
        <!--{/if}-->
    <!--{/if}-->
</div>
            </div>

            <!--{if $_G['cookie']['is_company']}-->
            <!--{eval $viewsstyle = 'style="width:33.333%;"';}-->
            <div class="weui-grids weui-grids-mini">
                <a href="$SCRITPTNAME?id=xigua_job&ac=resume_manage&type=xiazai" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum3" class="countup f16">$total_xz</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_job:xzjl}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_job&ac=resume_manage&type=toudi" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum2" class="countup f16">$total_rec</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_job:sdjl}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_job&ac=myview&do=company&mobile=2" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum1" class="countup f16 ">$total_view</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_job:lljl}</p>
                </a>
            </div>
            <!--{else}-->
            <!--{eval $viewsstyle = 'style="width:33.333%;"';}-->
            <div class="weui-grids weui-grids-mini">
                <a href="$SCRITPTNAME?id=xigua_job&ac=myview&mobile=2" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum3" class="countup f16">$total_view</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_job:lljl}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_job&ac=mytd&mobile=2&high=4" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum2" class="countup f16">$totaltoudi</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_job:tdjl}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_job&ac=myview&do=viewme" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum1" class="countup f16 ">$views</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_job:skgw}</p>
                </a>
            </div>
            <!--{/if}-->
        </div>
    </div>

<!--{if $_G['cookie']['is_company']}-->
    <!--{if $taocan||1}-->
    <div class="tcouter"><!--{template xigua_job:tcard}--></div>
    <!--{/if}-->
    <div class="jnav weui-grids weui-grids-mini hcard">
        <a style="width:25%;padding:.5rem 0" href="$shlink" class="weui-grid" >
            <div class="weui-grid__icon">
                <i class="iconfont icon-shoplight main_color f22 pr2"></i>
            </div>
            <p class="weui-grid__label">{lang xigua_job:dpgl}</p>
        </a>
        <a style="width:25%;padding:.5rem 0" href="$SCRITPTNAME?id=xigua_job&ac=my_company&mobile=2" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-huiyuanqia main_color f24"></i></div>
            <p class="weui-grid__label">{lang xigua_job:fabuguanli}</p>
        </a>
        <a style="width:25%;padding:.5rem 0" href="$SCRITPTNAME?id=xigua_job&ac=resume_manage&mobile=2" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-toutiao main_color f22 pr2"></i></div>
            <p class="weui-grid__label">{lang xigua_job:jlgl}</p>
        </a>
        <a style="width:25%;padding:.5rem 0" class="weui-grid" href="$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2">
            <div class="weui-grid__icon">
                <i class="iconfont icon-huiyuan1 main_color f24"></i>
            </div>
            <p class="weui-grid__label">{lang xigua_job:tcgm}</p>
        </a>
    </div>
    <div class="weui-cells border_none hcard">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_job&ac=pubjob&type=full&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-mingpian2 color-blue"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_job:pubfull}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_job&ac=pubjob&type=part&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-shijian color-red"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_job:pubpart}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
    </div>

<!--{else}-->
    <div class="jnav weui-grids weui-grids-mini hcard" style="position:relative;top:-2.5rem">
        <a href="$resumelink" class="weui-grid" style="width:25%;padding:.5rem 0">
            <div class="weui-grid__icon">
                <i class="iconfont icon-daohangguize main_color f24 " style="top:.1rem;position: relative"></i>
            </div>
            <p class="weui-grid__label">{lang xigua_job:wdjl}</p>
        </a>
        <a style="width:25%;padding:.5rem 0" href="javascript:;" class="weui-grid resume_dig_btn">
            <div class="weui-grid__icon">
                <i class="iconfont icon-huidaodingbu main_color f24"></i></div>
            <p class="weui-grid__label">{lang xigua_job:zdjl}</p>
        </a>
        <a style="width:25%;padding:.5rem 0" href="javascript:;" class="weui-grid resume_refresh_btn" data-id="$rsid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-shuaxin main_color f24"></i>
            </div>
            <p class="weui-grid__label">{lang xigua_job:sxjl}</p>
        </a>
        <a style="width:25%;padding:.5rem 0" class="weui-grid" href="$SCRITPTNAME?id=xigua_job&ac=mytd&mobile=2&high=4">
            <div class="weui-grid__icon">
                <i class="iconfont icon-ico_fenxiang main_color f24"></i></div>
            <p class="weui-grid__label">{lang xigua_job:wdtd}</p>
        </a>
    </div>
<!--{/if}-->

    <div class="weui-cells border_none hcard" <!--{if !$_G['cookie']['is_company']}-->style="position:relative;top:-2.5rem"<!--{/if}-->>
        <!--{if $_G['cookie']['is_company']}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_job&ac=my&set=user&high=4&mobile=2&java=1&st=-1">
            <div class="weui-cell__hd"><i class="iconfont icon-erified color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_job:qhw1}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <!--{else}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_job&ac=my&set=company&high=4&mobile=2&java=1&st=-1">
            <div class="weui-cell__hd"><i class="iconfont icon-mingpian1 color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_job:qhw2}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <!--{/if}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-guize color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_hb:bangzhu}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
            <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_hb:kefu}</p>
            </div>
            <div class="weui-cell__ft f15">{lang xigua_hb:zhwo}</div>
        </a>
    </div>

    </div>
</div>
<!--{if !$_G['cookie']['is_company']}-->
<div id="popup_resume_dig" class="weui-popup__container popup-bottom" style="z-index:999">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:quxiao}</a>
                <h1 class="title">{lang xigua_job:zdjl}</h1>
            </div>
        </div>
        <div class="modal-content dig_bottom_box">
            <!--{if $myresume[dig_endts_u]}-->
            <div class="resume_digbox_title">{lang xigua_job:yzdddjs}: $myresume[dig_endts_u]</div>
            <!--{/if}-->
            <form  action="$SCRITPTNAME?id=xigua_job&ac=com&do=resume_dig&st={$_GET['st']}" method="post" id="form">
                <input type="hidden" name="formhash" value="{FORMHASH}">
                <input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
                <!--{template xigua_job:resume_dig}-->
                <div class="fix-bottom" style="position:relative">
                    <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_job:queding}">
                </div>
            </form>
        </div>
    </div>
</div>
<!--{/if}-->
<!--{eval $job_tabbar=1;$tabbar=0;}-->
<!--{template xigua_job:footer}--><script src="source/plugin/xigua_hb/static/countUp.js"></script><script>
$(document).on('click','.J_ping', function(){
    $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
    $(this).addClass('type-item-active').removeClass('type-item-gray');
});
$('.J_ping:first-child').trigger('click');
$('.J_ping:first-child').find('.typevip').trigger('click');
$(document).on('click','.tcouter', function () {
    hb_jump('$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2');
});
var options={useEasing:true,useGrouping:true,separator:'',decimal:'.',prefix:'',suffix:''};
new countUp("njum1", 0, $('#njum1').text(), 0, 2.5, options).start();
new countUp("njum2", 0, $('#njum2').text(), 0, 2.5, options).start();
new countUp("njum3", 0, $('#njum3').text(), 0, 2.5, options).start();
</script>