<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
$hy = $hyobj->fetch_light(array($v[hangye_id1]), 'icon');
$desc = cutstr(strip_tags($v[miaoshu]), 80, '');
}--><!--{template xigua_job:header}--><div class="page__bd bgf"><!--{if $hy['icon']}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$hy['icon']"/></div><!--{/if}-->
<!--{if $v[album][0]}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$v[album][0]"/></div><!--{/if}-->
    <!--{template xigua_hb:common_nav}-->
    <div class="jv_top jv_status <!--{if $isself}-->jv_status_{$v[status]}<!--{/if}-->">
        <em class="jv_upts">{$v[upts_u]}{lang xigua_job:gx}</em>
        <h2 class="h2top mb5">{$v[name]}
            <!--{if $v[is_dig]}-->
            <span class="jbtn is_dig pr-1">{lang xigua_job:dig}</span>
            <!--{/if}--></h2>
        <p>
            <em class="jbtn">{$v[type_u]}</em>
            <span class="resume_span_small">{lang xigua_job:z}{$v[neednum]}{lang xigua_job:r}</span>
            <!--{if $v[jiesuan]}-->
            <span class="resume_span_small">$v[jiesuan]</span>
            <!--{/if}-->
        </p>
        <p class="jv_xz mtauto">{echo str_replace(lang_hb('yuan',0), '', $v[xinzi])}<!--{if $yuanshi[$v['xinziunit']]}-->$yuanshi[$v['xinziunit']]<!--{else}--><!--{/if}--></p>
<!--{if $v[fuli_ary]}-->
        <div class="cl item_tags mtauto">
            <!--{loop $v[fuli_ary] $_k $_v}-->
            <span class="mod-feed-tag b-color0 main_color">{$_v}</span>
            <!--{/loop}-->
        </div>
<!--{/if}-->

        <!--{if $v[opentime] || $v[shiduan]}-->
        <div class="f14 f14 c3">
            {lang xigua_job:jzsj}: $shiduan[$v[shiduan]] $v[opentime]
        </div>
        <!--{/if}-->
        <ul class="jv_ul mtauto cl">
            <li>{lang xigua_job:nlyq}: {$v[minage]}-{$v[maxage]}{lang xigua_job:s}</li>
            <li>{lang xigua_job:jingyan}: {$v[jingyan]}</li>
            <li>{lang xigua_job:_gender}: {$v[gender_u]}</li>
            <li>{lang xigua_job:xueli}: {$v[xueli]}</li>
        </ul>
    </div>

    <!--{if $_G['cache']['plugin']['xigua_hj']}-->
    <div class="weui-cells mt0">
        <a class="weui-cell weui-cell_access" href="$_G['cache']['plugin']['xigua_hj'][jblink]">
            <div class="weui-cell__bd">
                <div class="jv_safe">
                    <p>{lang xigua_job:aqxts}</p>
                    <p>{lang xigua_job:qwjn}</p>
                </div>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
    </div>
    <!--{/if}-->
    <div class="jv_addr">
        <h2 class="h2top">{lang xigua_job:addr}</h2>
        <!--{if $v[shname]}-->
        <div class="jv_shname" <!--{if $v[shid]}-->onclick="javascript:hb_jump('$SCRITPTNAME?id=xigua_hs&ac=view&shid={$v[shid]}&mobile=2');"<!--{/if}-->>
            $v[shname]
        <!--{if $v[lat]}-->
            <p class="c8 y" id="driving" data-id="$v[shid]"></p>
        <!--{/if}-->
        </div>
        <!--{/if}-->
    <!--{if $v[lat]}-->
        <div class="jv_map" id="v_openlocation_job" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[shname]" data-addr="$v[addr]">
            <div>{$v[city]}{$v[addr]}</div>
            <img src="https://apis.map.qq.com/ws/staticmap/v2/?center={$v[lat]},{$v[lng]}&zoom=13&size=640*120&maptype=roadmap&markers=size:large|color:0xFFCCFF|{$v[lat]},{$v[lng]}
&key={$_G['cache']['plugin']['xigua_hs'][mkey]}" />
            <p></p>
        </div>
    <!--{elseif $v[addr]}-->
    <div class="jv_map">
        <div>{$v[city]}{$v[addr]}</div>
        <p></p>
    </div>
    <!--{/if}-->
    </div>
    <!--{if $v[album]}-->
    <div class="jv_desc">
        <h2 class="h2top">{lang xigua_job:album}</h2>
        <div class="cl feed-preview-pic"><!--{loop $v[album] $img}--><span class="imgloading"><img src="$img"></span><!--{/loop}--></div>
    </div>
    <!--{/if}-->
    <div class="jv_jsbtn hbtn_share">
        {lang xigua_job:jsgpy}
    </div>
    <div class="jv_desc">
        <h2 class="h2top">{lang xigua_job:miaoshu}</h2>
        <div>
            {echo hb_nl2br(strpos($v['miaoshu'], '&lt;')!==false?htmlspecialchars_decode($v['miaoshu']):$v['miaoshu']);}
        </div>
    </div>
    <!--{if !$_G['cookie']['is_company']}-->
    <div class="weui-cells border_none mt0">
        <h2 class="h2top ml15">{lang xigua_job:zwfbz}</h2>
        <div class="weui-cell weui-cell_access border_bottom15">
            <div class="weui-cell__hd">
                <img class="jv_avatar" src="{avatar($v[uid], 'middle', 1)}" />
            </div>
            <div class="weui-cell__bd jv_username">
                {$member[username]}
            </div>
            <div class="weui-cell__ft"></div>
        </div>
    </div>
<!--    <h2 class="h2top ml15">{lang xigua_job:qtzw}</h2>-->
    <div class="jv_box" style="padding-bottom:0">
        <h2 class="h2top">{lang xigua_job:xszw}</h2>
    </div>
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
    <!--{/if}-->

    <!--{if $isself}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z" style="width:50%">
            <a href="$SCRITPTNAME?id=xigua_job&ac=pubjob&mobile=2&jobid={$v[jobid]}" class="jv_viewbtn">{lang xigua_job:bjzw}</a>
        </div>
        <!--{if $v[status]==1}-->
        <div class="weui-flex__item in_bottom_y">
            <a href="javascript:;" class="jv_viewbtn">
                {lang xigua_job:zwshz}
            </a>
        </div>
        <!--{elseif $v[status]==2}-->
        <div class="weui-flex__item in_bottom_y">
            <a href="javascript:;" class="jv_viewbtn offline_btn" data-jobid="$v[jobid]" data-xiajia="1">
                 {lang xigua_job:xxzw}
            </a>
        </div>
        <!--{elseif $v[status]==9}-->
        <div class="weui-flex__item in_bottom_y">
            <a href="javascript:;" class="jv_viewbtn offline_btn" data-jobid="$v[jobid]" data-xiajia="0">
                {lang xigua_job:sxzw}
            </a>
        </div>
        <!--{/if}-->
    </div>
    <!--{else}-->
    <div class="in_bottom weui-flex border_top">
        <!--{if $v[openmobile]}-->
        <div class="in_bottom_z border_right">
            <a <!--{if $myresume||!$job_config[mustresume]}-->href="tel:$v[mobile]" class="jv_viewbtn border_right"<!--{else}-->href="javascript:;" class="ifrs jv_viewbtn border_right"<!--{/if}-->>{lang xigua_job:ddhua}</a>
        </div>
        <!--{/if}-->
        <div class="in_bottom_z">
            <!--{if $has_toudi}-->
            <a href="javascript:;" class="jv_viewbtn op6">{lang xigua_job:ytd}</a>
            <!--{else}-->
            <a href="javascript:;" class="jv_viewbtn toudi" data-jobid="$jobid">{lang xigua_job:tjl}</a>
            <!--{/if}-->
        </div>
        <div class="weui-flex__item in_bottom_y">
            <a  <!--{if $myresume||!$job_config[mustresume]}-->href="$kflnk" class="jv_viewbtn"<!--{else}-->href="javascript:;" class="ifrs jv_viewbtn"<!--{/if}-->>
                {lang xigua_job:lgz}
                <i class="iconfont icon-sixin"></i>
            </a>
        </div>
    </div>
    <!--{/if}-->
</div>
<!--{template xigua_job:haibao}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$_G['cache']['plugin']['xigua_hs'][mkey]}"></script>
<script>
var loadingurl = window.location.href+'&ac=job_li&hyid=$v[hangye_id2]&not=$jobid&inajax=1&page=';scrollto = 1;
if($('#driving').length>0){
var driv = $('#driving'), dnt = 0;
var drivInterval=setInterval(function () {
    job_getlocation(function(position){
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_job&ac=com&do=driving&shid='+driv.data('id')+'&inajax=1&from='+(position.latitude||position.lat) + ','+ (position.longitude||position.lng)+'&to=$v[lat],$v[lng]',
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                if(null==data){return false;}
                var s = data.lastChild.firstChild.nodeValue;
                var sary = s.split('|');
                if(sary[0]=='success'){
                    $('#driving').show().html(sary[1]);
                }
                clearInterval(drivInterval);
            },
            error: function () { clearInterval(drivInterval); $('#driving').hide(); }
        });
    });
    dnt++;
    if(dnt>= 1){
        clearInterval(drivInterval);
        $('#driving').show().html('');
    }
}, 3000);
}
$(document).on('click','.jv_viewbtn_lianxi', function () {
    var that = $(this);
    $.ajax({
        type: 'POST',
        url: _APPNAME + '?id=xigua_job&ac=com&do=checkifview&inajax=1',
        data:{formhash:FORMHASH,rsid:that.data('id')},
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s){
                var msgar = s.split('|');
                if(msgar[2]){
                    window.location.href =msgar[2];
                }else{
                    tip_common(s);
                }
            }
        }
    });
});
$(document).on('click','.ifrs', function () {
    $.confirm('{lang xigua_job:nors}', function () {
        hb_jump("$SCRITPTNAME?id=xigua_job&ac=resume&mobile=2{$urlext}");
    }, function () {
    });
});
$(document).on('click','.offline_btn', function () {
    var that = $(this);
    $.showLoading();
    $.ajax({
        type: "POST",
        url: _APPNAME+"?id=xigua_job&ac=com&do=offline&inajax=1",
        data:{formhash:FORMHASH, jobid:that.data('jobid'), xiajia:that.data('xiajia')},
        dataType: "xml",
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        }
    });
});
</script>
<!--{eval $tabbar=0;$job_tabbar=0;}-->
<!--{template xigua_job:footer}-->