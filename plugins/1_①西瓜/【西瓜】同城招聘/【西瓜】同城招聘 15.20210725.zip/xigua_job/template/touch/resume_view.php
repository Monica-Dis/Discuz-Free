<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<div class="page__bd bgf">
    <!--{if $is_mine}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <div class="rsv_top">
        <div class="rsv_top_left">
            <div class="username">{$v[realname]}
                <!--{if $v[is_dig]}-->
                <span class="jbtn is_dig">{lang xigua_job:dig}</span>
                <!--{/if}-->
            </div>
            <div class="f14 mt10">{$v[qiustatus]}</div>
        </div>
        <div class="rsv_top_right"><img src="$v[avatar]"></div>
    </div>

    <ul class="jv_ul p15 cl">
        <li>{lang xigua_job:gender}: $v[gender_str]</li>
        <li>{lang xigua_job:xl}: $v[xueli]</li>
        <li>{lang xigua_job:age}: $v[age]</li>
        <li>{lang xigua_job:jy}: $v[jingyan]</li>
    </ul>

    <div class="jv_desc">
        <h2 class="h2top">{lang xigua_job:qzyx}</h2>
        <ul class="rsv_ul">
            <li>{lang xigua_job:paywant}: <em class="main_red">$v[paywant]</em></li>
            <li>{lang xigua_job:qwgz}: <em>$v[jobwant_str]</em></li>
            <li>{lang xigua_job:qwdd}: <em>$v[areawant_str]</em></li>
        </ul>
    </div>
    <div class="jv_desc">
        <h2 class="h2top">{lang xigua_job:grtc}</h2>
        <div class="cl item_tags ">
        <!--{loop $v['goodat_ary'] $_k $_v}-->
            <span class="mod-feed-tag b-color0">{$goodat[$_v]}</span>
        <!--{/loop}-->
        </div>
    </div>

<!--{if $v['workexp_ary']}-->
<!--{eval $workexpary = $v[workexp_ary];}-->
    <div class="jv_desc">
        <h2 class="h2top">{lang xigua_job:gzjl}</h2>
        <div class="cl ">
            <!--{loop $workexpary['comname'] $_k $_v}-->
            <div class="f14 jl_list">
                <p>{$workexpary[start][$_k]} {lang xigua_job:zhi} {echo $workexpary[end][$_k]?$workexpary[end][$_k]: lang_job('jin',0)}</p>
                <p class="c6">{lang xigua_job:hsname} : {$workexpary[comname][$_k]}</p>
                <p class="c6">{lang xigua_job:title} : {$workexpary[zhiwei][$_k]}</p>
            </div>
            <!--{/loop}-->
        </div>
    </div>
<!--{/if}-->

    <div class="jv_desc">
        <h2 class="h2top">{lang xigua_job:description}</h2>
        <div class="mr20">
            $v[description]
        </div>
    </div>

    <!--{if $v[album]}-->
    <div class="jv_desc">
        <h2 class="h2top">{lang xigua_job:rsalbum}</h2>
        <div class="cl feed-preview-pic"><!--{loop $v[album] $img}--><span class="imgloading"><img src="$img"></span><!--{/loop}--></div>
    </div>
    <!--{/if}-->

    <!--{if $v['eduexp_ary']}-->
    <!--{eval $eduexpary = $v[eduexp_ary];}-->
    <div class="jv_desc">
        <h2 class="h2top">{lang xigua_job:eduexp}</h2>
        <div class="cl ">
            <!--{loop $eduexpary['comname'] $_k $_v}-->
            <div class="f14 jl_list">
                <p>{$eduexpary[start][$_k]} {lang xigua_job:zhi} {echo $eduexpary[end][$_k]? $eduexpary[end][$_k]: lang_job('jin',0)}</p>
                <p class="c6">{lang xigua_job:xuexiao} : {$eduexpary[comname][$_k]}</p>
                <!--{if $eduexpary[zhiwei][$_k]}-->
                <p class="c6">{lang xigua_job:zy} : {$eduexpary[zhiwei][$_k]}</p>
                <!--{/if}-->
            </div>
            <!--{/loop}-->
        </div>
    </div>
    <!--{/if}-->

    <!--{if $is_mine}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right resume_refresh_btn" data-id="$rsid">{lang xigua_job:shuaxin}</a>
        </div>
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right resume_dig_btn">{lang xigua_job:dig}</a>
        </div>
        <div class="weui-flex__item in_bottom_y">
            <a href="$SCRITPTNAME?id=xigua_job&ac=resume&rsid={$rsid}" class="jv_viewbtn">{lang xigua_job:bjjl}</a>
        </div>
    </div>
    <!--{else}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_job&ac=resumes" class="jv_viewbtn border_right">{lang xigua_job:sy}</a>
        </div>
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_job&ac=resume_view&rsid=$nextid" class="jv_viewbtn border_right">{lang xigua_job:next}</a>
        </div>
        <div class="weui-flex__item in_bottom_y">
            <a href="javascript:;" class="jv_viewbtn jv_viewbtn_lianxi" data-id="$rsid">
                {lang xigua_job:ljlx}
            </a>
        </div>
    </div>
    <!--{/if}-->
</div>

<!--{if $is_mine}-->
<div id="popup_resume_dig" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:quxiao}</a>
                <h1 class="title">{lang xigua_job:zdjl}</h1>
            </div>
        </div>
        <div class="modal-content dig_bottom_box">
        <!--{if $v[dig_endts_u]}-->
        <div class="resume_digbox_title">{lang xigua_job:yzdzdjs}: $v[dig_endts_u]</div>
        <!--{/if}-->
        <form  action="$SCRITPTNAME?id=xigua_job&ac=com&do=resume_dig&st={$_GET['st']}" method="post" id="form">
            <input type="hidden" name="formhash" value="{FORMHASH}">
            <input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
            <!--{template xigua_job:resume_dig}-->
            <div class="fix-bottom" style="position:relative">
                <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_job:queding}">
            </div>
        </form>
        </div>
    </div>
</div>
<!--{/if}-->
<!--{eval $tabbar=0;$job_tabbar=0;}-->
<!--{template xigua_job:footer}-->
<!--{if $is_mine}-->
<script>
$(document).on('click','.J_ping', function () {
    $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
    $(this).addClass('type-item-active').removeClass('type-item-gray');
});
$('.J_ping:first-child').trigger('click');
$('.J_ping:first-child').find('.typevip').trigger('click');
</script>
<!--{/if}-->