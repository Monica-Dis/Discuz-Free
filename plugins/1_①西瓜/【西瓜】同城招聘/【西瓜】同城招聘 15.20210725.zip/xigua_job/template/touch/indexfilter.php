<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="popup_sx" class="weui-popup__container z501">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:quxiao}</a>
                <h1 class="title">{lang xigua_job:zwsx}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none" style="margin-bottom:75px">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:pxfs}</p>
                        <ul class="check_box cl">
                            <li data-id="new" data-name="order" data-only="1">{lang xigua_job:znpx}</li>
                            <li data-id="upts" data-name="order" data-only="1">{lang xigua_job:upts1}</li>
                            <li data-id="near" data-name="order" data-only="1">{lang xigua_job:jlzj}</li>
                        </ul>
                    </div>
                </div>
                <!--{if $_GET['type']=='full'}-->
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:paywant2}</p>
                        <ul class="check_box cl">
                            <li data-id="0" data-name="paywant" data-only="1">{lang xigua_job:buxian}</li>
                            <!--{loop $xinzi $_k $quan}-->
                            <li data-id="$_k" data-name="paywant" data-only="1">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                <!--{/if}-->
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:gzjy}</p>
                        <ul class="check_box cl">
                            <!--{loop $jingyan $_k $quan}-->
                            <li data-id="$_k" data-name="jingyan" data-only="1">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:xueli}</p>
                        <ul class="check_box cl">
                            <!--{loop $xueli $_k $quan}-->
                            <li data-id="$_k" data-name="xueli" data-only="1">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:qwdd}</p>
                        <ul class="check_box cl filterjobwant">
                            <li data-id="-1" data-name="areawant">{lang xigua_job:buxian}</li>
                            <!--{loop $distjsary $quan}-->
                            <!--{eval $quanname = diconv($quan[name],'UTF-8',CHARSET);}-->
                            <li data-sub="_$quan[id]" data-id="$quanname" data-name="areawant">{$quanname}</li>
                            <!--{/loop}-->
                        </ul>
                        <i class="iconfont icon-xiangxia f13 zkbtn"></i>
                        <!--{loop $distjsary $quan}-->
                        <ul class="check_box cl check_box_sub" id="subid__{$quan[id]}" style="display:none">
                            <li data-backto="$quan[id]">{lang xigua_job:back}</li>
                            <!--{loop $quan[sub] $_v}-->
                            <!--{eval $quanname = diconv($_v[name],'UTF-8',CHARSET);}-->
                            <li data-id="{$quanname}" data-name="areawant">{$quanname}</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{/loop}-->
                    </div>
                </div>

                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:gender}</p>
                        <ul class="check_box cl">
                            <!--{loop $gender_ary $_k $quan}-->
                            <li data-id="$_k" data-name="gender" data-only="1">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
            </div>
            <div class="fix-bottom sxbtns cl">
                <div class="oncheck none" data-name="ac" data-id="job_li"></div>
                <input type="button" href="javascript:;" class="weui-btn weui-btn_default close-popup" value="{lang xigua_job:quxiao}">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_default close-reset" value="{lang xigua_job:cz}">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_primary confirm-filter" value="{lang xigua_job:queding}">
            </div>
        </div>
    </div>
</div>


<div id="popup_hyc" class="weui-popup__container z501">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:quxiao}</a>
                <h1 class="title">{lang xigua_job:qxzzwlx}</h1>
            </div>
        </div>
        <div class="modal-content bgf">
            <div class="weui-cells before_none after_none" style="margin-bottom:120px">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_job:qxzzwlx}</p>
                        <ul class="check_box cl filterjobwant open">
                            <!--{loop $jsary $_k $quan}-->
                            <li data-sub="__$_k" data-id="$_k" data-name="none">$quan[oname]</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{loop $jsary $_k $quan}-->
                        <ul class="check_box cl check_box_sub" id="subid___$_k" style="display:none">
                            <li data-backto="$_k">{lang xigua_job:back}</li>
                            <!--{loop $quan[sub] $_v}-->
                            <li id="_thkey_{$_v[id]}" data-id="{$_v[id]}" data-name="none" data-value="{$_v[oname]}">{$_v[oname]}</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
            <div class="fix-bottom sxbtns sxbtns2 cl">
                <div class="post_tags_flex">
                    <div class="post_com_tag post-tags cl" id="popup_hyc_p2"></div>
                </div>
                <input type="button" href="javascript:;" class="weui-btn weui-btn_default close-popup" value="{lang xigua_job:quxiao}">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_primary confirm-hyc" value="{lang xigua_job:queding}">
            </div>
        </div>
    </div>
</div>