<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $job_config[index_hot]!=1}-->
<!--{eval
$shids = DB::fetch_all("select shid, count(shid) AS cshid FROM %t where status=2 AND shid!=0 AND endts>%d GROUP BY shid ORDER BY cshid DESC LIMIT 0,10", array('xigua_job_job', TIMESTAMP),'shid');
if($shids):
    $shs = DB::fetch_all("select shid,name,logo FROM %t where shid in(%n)", array('xigua_hs_shanghu', array_keys($shids) ), 'shid');
endif;
}-->
<div class="weui-cells__title weui_title border_none f15" style="padding-bottom:0">
    <span class="c3 f17">{lang xigua_job:rmqy}</span>
</div>
<div class="weui-cells before_none after_none">
    <div class="swiper-container jobqy_swiper swiper-container-horizontal">
        <div class="swiper-wrapper" style="padding:.5rem .5rem .5rem 0">
            <!--{loop $shids $__k $__v}-->
            <!--{eval $_v = $shs[$__k];}-->
            <div class="swiper-slide jobqy_box swiper-slide-active">
                <a href="$SCRITPTNAME?id=xigua_job&ac=company&shid={$_v[shid]}">
                    <div class="pr">
                        <img class="jobqy_img" src="{$_v[logo]}">
                    </div>
                    <div class="p1">{$_v['name']}</div>
                </a>
            </div>
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{/if}-->