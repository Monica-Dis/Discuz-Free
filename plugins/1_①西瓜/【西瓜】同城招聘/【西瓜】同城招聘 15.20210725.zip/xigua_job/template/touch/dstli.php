<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="pupc-btm-in_list" id="p2_{$_GET['ctid']}">
    <a class="check2 pupc_check_a border_bottom" data-name="{$_GET[name]}" data-max="{echo $job_config[maxareawant]-1}" data-maxtip="{lang xigua_job:zd}{$job_config[maxareawant]}{lang xigua_job:g}" data-form="areawant" data-ld="p2" data-title="p2{$_GET['ctid']}" data-value="{$_GET['ctid']}">{lang xigua_hb:quan}{$_GET[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a>
    <!--{loop $rlist $_k $__v}-->
    <!--{eval $__name = $__v[name];}-->
    <a class="check2 pupc_check_a border_bottom" data-name="$__name" data-max="{echo $job_config[maxareawant]-1}" data-maxtip="{lang xigua_job:zd}{$job_config[maxareawant]}{lang xigua_job:g}" data-form="areawant" data-ld="p2" data-title="p2{$__v[id]}" data-value="{$__v[id]}">$__name</a>
    <!--{/loop}-->
</div>