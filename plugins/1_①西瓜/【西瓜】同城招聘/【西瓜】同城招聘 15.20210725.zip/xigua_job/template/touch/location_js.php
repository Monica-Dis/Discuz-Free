<?php exit('xxxx');?>
<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$_G['cache']['plugin']['xigua_hs']['mkey']}"></script>
<!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}--><script type="text/javascript" src="//api.map.baidu.com/api?v=2.0&ak={$_G['cache']['plugin']['xigua_hs']['baidusdk']}"></script><!--{/if}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script>
var chooseMapRes = [], OBJ = {};
function setForm(lat, lng, deft){
    $.showLoading();
    $.ajax({
        type: 'GET',
        url: location + '&id=xigua_hs&ac=getloc&lat='+lat+'&lng='+lng+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s.indexOf('error')!=-1){
                tip_common(s);
            }else{
                var _actions = [];
                OBJ = jQuery.parseJSON(s.split('|')[1]);
                if(deft){
                    setFormField(OBJ[0]);
                    return true;
                }
                for(var j in OBJ){
                    _actions.push({
                        text: OBJ[j].address,
                        className:'obj_ obj_'+j,
                        onClick: function() {  $.closePopup(); }
                    });
                }
                $.actions({ actions:_actions });
            }
        },
        error: function () {
            $.hideLoading();
        }
    });
}
function setFormField(subj){
    $("input[name='form[addr]']").val(subj.address);
    $("input[name='form[lat]']").val(subj.location.lat);
    $("input[name='form[lng]']").val(subj.location.lng);
    $("input[name='form[province]']").val(subj.address_component.province);
    $("input[name='form[city]']").val(subj.address_component.city);
    $("input[name='form[district]']").val(subj.address_component.district);
    $("input[name='form[street]']").val(subj.address_component.street);
    $("input[name='form[street_number]']").val(subj.address_component.street_number);
}

function setPoint(position){
    if(typeof position.type != 'undefined'){
        if(position.type == 'ip'){
            if(IGNORETIP){}else {
                chooseMap(position);
            }
            return false;
        }
    }
    setForm((position.latitude||position.lat), (position.longitude||position.lng), 1);
}
function chooseMap(position) {
    if(typeof mag != 'undefined') {
        mag.mapPick(function (res) {
            setForm(res.lat, res.lng, 0);
        });
        return false;
    }
    var center = new qq.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
    var mapinit = function () {
        geocoder = new qq.maps.Geocoder({
            complete: function (result) {
                console.log(result);
                chooseMapRes = result;
            }
        });
        geocoder.getAddress(center);
        map = new qq.maps.Map(document.getElementById("mapcontainer"), {center: center, zoom: 13});
        marker = new qq.maps.Marker({
            position: center, map: map
        });
        qq.maps.event.addListener(map, 'click', function (event) {
            var tmpcenter = new qq.maps.LatLng(event.latLng.getLat(), event.latLng.getLng());
            marker.setPosition(tmpcenter);
            geocoder.getAddress(tmpcenter);
        });
        $("#mapouter").popup();
    };
    mapinit();
}
$(document).on('click', '.obj_', function(){
    var k = parseInt($(this)[0].classList[2].replace('obj_', ''));
    setFormField(OBJ[k]);
    $("#new_popup").popup();
});

$('#openlocation').on('click', function(){
    var pot = [];
    IGNORETIP = 0;
    pot.push({ text: "{lang xigua_hb:locacurrt}", onClick: function() { hs_getlocation(setPoint); } });
    if(!(GOOGLE && HB_INWECHAT)){
        pot.push({text: "{lang xigua_hb:xuandian}", onClick: function() { hs_getlocation(chooseMap); } });
    }
    $.actions({ actions: pot});
});

$('.confirm-popup').on('click', function(){
    setForm(chooseMapRes.detail.location.lat, chooseMapRes.detail.location.lng, 0);
});
</script>
