<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $k $v}-->
<!--{eval $rs = $rslist[$v[rsid]]}-->
<!--{if $rs[realname]}-->
<div class="viewme_li cl border_bfull">
    <div class="resume_left resume_jump" data-id="$v[rsid]">
        <div class="resume_logo"><img src="$rs[avatar]"></div>
        <i class="resume_gender g{$rs[gender]}"></i>
    </div>
    <div class="resume_right">
        <div class="resume_realname cl resume_jump" data-id="$v[rsid]">
            <span>{$rs[realname]}</span>
            <span class="resume_span">{$rs[age]}{lang xigua_job:s}</span>
            <div class="resume_span resume_span_pos">
                <!--{loop $rs[areawant_str_ary] $_k $_v}-->
                <span class="resume_spani">{$_v}</span>
                <!--{/loop}-->
            </div>
        </div>
        <div class="resume_p resume_jump" data-id="$v[rsid]">
            <span class="resume_spani main_red ml0">{$rs[paywant]}</span>
            <span class="resume_spani">{$rs[jingyan]}</span>
            <span class="resume_spani">{$rs[xueli]}</span>
        </div>
        <div class="resume_tag cl">
            <a class="bgf">{lang xigua_job:qw}</a>
            <!--{loop $rs[jobwant_str_ary] $_k $_v}-->
            <a href="javascript:;">$_v</a>
            <!--{/loop}-->
        </div>
<div class="resume_tag cl">
    <!--{if $v[is_xiazai]}-->
        <!--{if $v[status]==2}-->
            <p class=" xzts">{lang xigua_job:yysj}: $v[yyts_u]</p>
        <!--{elseif $v[crts_u]}-->
            <p class=" xzts">{lang xigua_job:xzsj}: $v[crts_u]</p>
        <!--{/if}-->
    <!--{else}-->
        <!--{if $v[status]==2}-->
            <p class=" xzts">{lang xigua_job:yysj}: $v[yyts_u]</p>
        <!--{elseif $v[crts_u]}-->
            <p class=" xzts">{lang xigua_job:tdsj}:$v[crts_u]</p>
        <!--{/if}-->
    <!--{/if}-->
    <p class="y f12 color-forest clstat">{$toudi_status[$v[status]]}</p>
    <!--{if $v[status]==1}-->
    <p class="y">
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn yybtn1" data-realname="$rs[realname]" data-jobid="$v[jobid]" data-uid="$rs[uid]">{lang xigua_job:yaoyue}</a>
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn ignore_yy" data-realname="$rs[realname]" data-rsid="$rs[rsid]" data-uid="$rs[uid]">{lang xigua_job:hulue}</a>
    </p>
    <!--{/if}-->
</div>
        <!--{if $job_ary[$v[jobid]]}-->
        <div class="resume_tag cl">
            <p class="xzts">{lang xigua_job:msgw}: $job_ary[$v[jobid]][shname] - $job_ary[$v[jobid]][name]</p>
        </div>
        <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<!--{/loop}-->
