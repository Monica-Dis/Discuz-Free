<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<link rel="stylesheet" href="source/plugin/xigua_job/static/job.css?{VERHASH}" /><style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}.gzbtn{background-color:$config[maincolor]}
.jv_jsbtn,.job2_tagbtn,.job_li_link{color:$config[maincolor]!important}.main_red,.jv_xz,.jbtn{color:$job_config[color2]}
.car-type .car-year-season{background-color:$config[maincolor]!important;}.job2_tagbtn,.job_li_link{background:{echo hb_hex2rgb($config[maincolor], 0.06)}!important}
.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]!important;}
.car-type .type-item-active:after,.jv_jsbtn,.job2_tagbtn,.job_li_link{border-color:$config[maincolor]!important}
.car-type .type-item-active {background:{echo hb_hex2rgb($config[maincolor], 0.06)}!important;}.car-type .type-item {height: 3.7333rem!important}
.check_box li.oncheck,.btnon{background:{echo hb_hex2rgb($config[maincolor], 0.06)};color:$config[maincolor]}
.check_box li.oncheck:after,.btnon:after{border-color:$config[maincolor]}
</style><script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}"; var lockIng = 0;
var GOOGLE = "{$_G['cache']['plugin']['xigua_hs']['google']}", PUB_VARID = 0, IGNORETIP = 0;var  PLZALLOW = '{lang xigua_hs:plzallow}', gengduodongtai = '{lang xigua_hs:gengduodongtai}', guanzhu_sj = '{lang xigua_hs:guanzhu_sj}', yiguanzhu = '{lang xigua_hs:yiguanzhu}', jiaguanzhu='{lang xigua_hs:jiaguanzhu}', quxiao = '{lang xigua_hb:quxiao}', MAXINDEXHY=$job_config[maxindexhy], MAXINDEXHYTIP = '{lang xigua_job:zdxz}{$job_config[maxindexhy]}{lang xigua_job:g}';</script>