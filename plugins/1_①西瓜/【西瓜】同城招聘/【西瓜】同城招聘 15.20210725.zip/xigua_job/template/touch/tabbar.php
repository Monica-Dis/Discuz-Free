<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $job_tabbar}--><!--{eval
$custom_nav = C::t('#xigua_job#xigua_job_nav')->fetch_index();
$navcount = count($custom_nav);$is_off = 1;
$curturl = hb_currenturl();
}--><div class="weui-tabbar<!--{if $showfloatapp}--> none<!--{/if}-->">
<!--{loop $custom_nav $loop_k $loopin}--><!--{eval
    $highlight = '&high='.$loop_k;
    if($loopin['adlink']=='pub'):
        $extstyle = "style='padding-top:2px;'";
        $inlink = 'javascript:;" id="pubj';
    else:
        $extstyle = '';
        $inlink = $loopin['adlink'].$highlight;
    endif;
    $is_on = !$is_on && strpos($curturl,$inlink)!==false || (strpos($curturl,$highlight)!==false)||$_GET['high']==$loop_k;
    if($is_off==$navcount):
    endif;
    if($is_on):
        $loopin[icon] = $loopin[icon2]?$loopin[icon2]:$loopin[icon];
    else:
        $is_off++;
    endif;
}--><a href="{$inlink}" class="weui-tabbar__item <!--{if $is_on}-->weui-bar__item_on<!--{/if}-->" $extstyle>
    <!--{if $loopin[icon]}-->
        <img src="$loopin[icon]" class="tabcon3 <!--{if $loopin[up]}-->up_icon<!--{/if}-->" />
    <!--{/if}-->
    <!--{if !$loopin[up]}-->
        <p class="weui-tabbar__label">{$loopin[name]}</p>
    <!--{/if}-->
</a><!--{/loop}-->
</div><!--{/if}-->