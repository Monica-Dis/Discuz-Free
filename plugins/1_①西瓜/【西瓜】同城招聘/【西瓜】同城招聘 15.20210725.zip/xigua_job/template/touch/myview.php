<?php exit('xxxxx');?>
<!--{template xigua_job:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->

</div>
<!--{if $_GET['do']=='company'}-->
<script>var loadingurl = window.location.href+'&ac=myview&do=resumeli&inajax=1&page=';scrollto = 0;</script>
<!--{else}-->
<script>var loadingurl = window.location.href+'&ac=myview&do=li&inajax=1&page=';scrollto = 0;</script>
<!--{/if}-->
<!--{eval $tabbar=0;$job_tabbar=1;}-->
<!--{template xigua_job:footer}-->