<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="pub_ctrl" class='weui-popup__container popup-bottom z501'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <h1 class="title">{lang xigua_job:qxzfblx}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <a href="$SCRITPTNAME?id=xigua_job&ac=pubjob&type=full{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__hd" >
                        <label><img src="source/plugin/xigua_job/static/img/r1.png?12"></label>
                    </div>
                    <div class="weui-cell__bd">
                        <p>{lang xigua_job:full}</p>
                        <p class="f12">{lang xigua_job:full_tip}</p>
                    </div>
                </a>
                <a href="$SCRITPTNAME?id=xigua_job&ac=pubjob&type=part{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__hd" >
                        <label><img src="source/plugin/xigua_job/static/img/r2.png?12"></label>
                    </div>
                    <div class="weui-cell__bd">
                        <p>{lang xigua_job:part}</p>
                        <p class="f12">{lang xigua_job:part_tip}</p>
                    </div>
                </a>
                <a class="weui-cell before_none" href="$SCRITPTNAME?id=xigua_job&ac=resume{$urlext}">
                    <div class="weui-cell__hd" >
                        <label><img src="source/plugin/xigua_job/static/img/r3.png?123"></label>
                    </div>
                    <div class="weui-cell__bd">
                        <p>{lang xigua_job:cjjl}</p>
                        <p class="f12">{lang xigua_job:cjjl_tip}</p>
                    </div>
                </a>
                <a href="javascript:;" class="picker-button close-popup iclose"><i class="iconfont icon-guanbijiantou c9 f24"></i></a>
            </div>
        </div>
    </div>
</div>
<!--{if 0 &&  $_G['cache']['plugin']['xigua_hs'] && C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid='.$_G['uid']), 0, 1)}-->
<style>.zbf{position:fixed;left:0;bottom:7rem;z-index:501;color:#fff;width:1rem;font-size:.6rem;line-height:.7rem;text-align:center;padding:.4rem .1rem;border-radius:0 .15rem .15rem 0;box-shadow:0 .1rem .25rem rgba(0,0,0,.25);opacity:.8}</style>
<!--{if $_G['cookie']['is_company']}-->
<a class="zbf main_bg" href="plugin.php?id=xigua_job&ac=my&set=user&mobile=2{$urlext}" id="shguide">{lang xigua_job:qhw1}</a>
<!--{else}-->
<a class="zbf main_bg" href="plugin.php?id=xigua_job&ac=my&set=company&mobile=2{$urlext}" id="shguide">{lang xigua_job:qhw2}</a>
<!--{/if}-->
<!--{/if}-->

<!--{template xigua_job:tabbar}-->
<script src="source/plugin/xigua_job/static/job.js?{VERHASH}"></script>
<!--{template xigua_hb:common_footer}-->