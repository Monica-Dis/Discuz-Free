<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<link rel="stylesheet" href="source/plugin/xigua_job/static/jobonly.css?{VERHASH}">
<form  action="$SCRITPTNAME?id=xigua_job&ac=resume&st={$_GET['st']}" method="post" id="form">
<input type="hidden" name="formhash" value="{FORMHASH}">
<input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
<input name="form[rsid]" value="{echo $old_data[rsid]?$old_data[rsid]:$_GET['rsid']}" type="hidden">
<div class="page__bd">
    <!--{if $old_data}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <div class="bgf cl">
        <div class="main_color top_tip" style="background:$config[maincolor]0d">
           {lang xigua_job:cjjltip}
        </div>
        <div class="change_mpava">
            <div class="change_avatar">
                <div id="box_avatar">
                    <ul class="weui-uploader__files" data-only="1" data-max="1" data-maxtip="{lang xigua_job:zdyz}"><!--{if $old_data[avatar]}-->
                        <div class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[avatar])"><input type="hidden" name="form[avatar][]" value="$old_data[avatar]"/></div>
                        <!--{/if}-->
                    </ul>
                    <div class="box_border">
                        <!--{if HB_INWECHAT && $config[multiupload]}-->
                        <a class="weui-uploader__input" data-name="form[avatar]" data-boxer="box_avatar" data-only="1" data-multi="0" type="file"></a>
                        <!--{else}-->
                        <input class="weui-uploader__input" data-name="form[avatar]" data-boxer="box_avatar" data-only="1" data-multi="0" type="file">
                        <!--{/if}-->
                    </div>
                </div>
                <p class="f14 mt10">{lang xigua_job:djsc}</p>
            </div>
        </div>
    </div>
    <div class="weui-cells weui-cells_form mt0 before_none after_none">
        <div class="weui-cell list3">
            <div class="weui-cell__bd">
                <p class="list3T">{lang xigua_job:birth}</p>
                <p>
                    <input class="weui-input" name="form[birth]" id="birth" type="text" value="{$old_data[birth]}" placeholder="{lang xigua_job:qxz}">
                </p>
            </div>
            <div class="weui-cell__bd">
                <p class="list3T">{lang xigua_job:gzjy}</p>
                <p>
                    <input class="weui-input" name="form[jingyan]" id="experience" type="text" value="{$old_data[jingyan]}" placeholder="{lang xigua_job:qxz}">
                </p>
            </div>
            <div class="weui-cell__bd">
                <p class="list3T">{lang xigua_job:zgxl}</p>
                <p>
                    <input class="weui-input" name="form[xueli]" id="xueli" type="text" value="{$old_data[xueli]}" placeholder="{lang xigua_job:qxz}">
                </p>
            </div>
        </div>
        <div class="weui-cell list4">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:realname1}<em class="color-red">*</em></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[realname]" type="text" value="{$user[realname]}" placeholder="{lang xigua_job:realnametip}">
            </div>
            <div class="cl weui-cells_radio">
                <label class="z weui-check__label mr10" for="x11">
                    <input type="radio" class="weui-check" name="form[gender]" value="1" id="x11" <!--{if $old_data[gender]==1}-->checked<!--{/if}-->>
                    <span class="weui-icon-checked"></span> {lang xigua_job:gender1}
                </label>
                <label class="z weui-check__label" for="x12">
                    <input type="radio" class="weui-check" name="form[gender]" value="2" id="x12" <!--{if $old_data[gender]==2}-->checked<!--{/if}-->>
                    <span class="weui-icon-checked"></span> {lang xigua_job:gender2}
                </label>
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:mobile}<em class="color-red">*</em></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[mobile]" type="tel" value="{$user[mobile]}" placeholder="{lang xigua_job:qtxmobile}">
            </div>
        </div>
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:qzzt}<em class="color-red">*</em></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[qiustatus]" id="qiustatus" type="tel" value="{$old_data[qiustatus]}" placeholder="{lang xigua_job:qxzqzzt}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:jobwant}<em class="color-red">*</em></label></div>
            <div class="weui-cell__bd">
                <input id="jobwant" class="weui-input" name="form[jobwant]" type="text" readonly value="{$old_data[jobwant_str]}" placeholder="{lang xigua_job:qxzjobwant}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:qwyx}<em class="color-red">*</em></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[paywant]" type="text" id="xinzi" value="{$old_data[paywant]}" placeholder="{lang xigua_job:qxzqwyx}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:areawant}<em class="color-red">*</em></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[areawant]" type="text" id="areawant" readonly value="{$old_data[areawant_str]}" placeholder="{lang xigua_job:plzareawant}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
    </div>

    <div class="weui-cells weui-cells_form before_none after_none">
        <div class="weui-cell" style="align-items: normal;">
            <div class="weui-cell__bd">
                <p class="list3T cl">{lang xigua_job:goodat}<em class="color-red">*</em></p>
                <div class="post-tags cl mt10" id="grtc">
                    <!--{loop $goodat $_k $_v}-->
                    <!--{eval $tag_on = in_array($_k, $old_data['goodat_ary']) ? 'tag-on' : '';}-->
                    <a class="weui-btn weui-btn_mini weui-btn_default $tag_on" href="javascript:;" onclick="return set_typeid($_k, this);">$_v</a>
                    <input name="form[goodat][$_k]" type="hidden" value="<!--{if $tag_on}-->1<!--{else}-->0<!--{/if}-->" />
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <div class="weui-cell" style="align-items: normal;">
            <div class="weui-cell__bd">
                <p class="list3T cl">
                    {lang xigua_job:description}<em class="color-red">*</em>
                    <a class="y main_color none">{lang xigua_job:cksl}<i class="f13 iconfont icon-jinrujiantou"></i></a>
                </p>
                <textarea name="form[description]" class="weui-textarea texta" placeholder="{lang xigua_job:qxzcksl}" rows="4">$old_data[description]</textarea>
            </div>
        </div>

        <div class="weui-cell">
            <div class="weui-cell__bd">
                <p class="list3T cl">{lang xigua_job:rsalbum}
                    <span class="y c9">{echo str_replace('n', $job_config['maximg'], lang_job('zuiduozhao',0))}</span>
                </p>
                <div class="weui-uploader mt10">
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-max="{$job_config['maximg']}" data-maxtip="{echo str_replace('n', $job_config['maximg'], lang_job('zuiduozhao',0))}">
                            <!--{loop $old_data[album] $img}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                <input type="hidden" name="form[album][]" value="$img"/>
                                <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                            </li>
                            <!--{/loop}--></ul>
                        <div class="weui-uploader__input-box">
                            <!--{if HB_INWECHAT && $config[multiupload]}-->
                            <a class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="weui-cell weui-cell_access ">
            <div class="weui-cell__hd"><label class="weui-label" style="width:70px">{lang xigua_job:gzjl}</label></div>
            <div class="weui-cell__bd workexplist">
            <!--{if $old_data[workexp_ary]}-->
            <!--{eval $workexpary = $old_data[workexp_ary];}-->
                <!--{loop $workexpary['comname'] $_k $_v}-->
                <div class="f12 jl_list">
                    <p>{$workexpary[start][$_k]} {lang xigua_job:zhi} {echo $workexpary[end][$_k]?$workexpary[end][$_k]: lang_job('jin',0)}</p>
                    <p class="f12 c9">{lang xigua_job:hsname} : {$workexpary[comname][$_k]}</p>
                    <p class="f12 c9">{lang xigua_job:title} : {$workexpary[zhiwei][$_k]}</p>
                    <a>x</a>
                    <input class="comname" name="form[workexp][comname][]" type="hidden" value="{$workexpary[comname][$_k]}" />
                    <input class="start" name="form[workexp][start][]" type="hidden" value="{$workexpary[start][$_k]}" />
                    <input class="end" name="form[workexp][end][]" type="hidden" value="{$workexpary[end][$_k]}" />
                    <input class="zhiwei" name="form[workexp][zhiwei][]" type="hidden" value="{$workexpary[zhiwei][$_k]}" />
                </div>
                <!--{/loop}-->
            <!--{else}-->
                <input class="weui-input workexpdft" type="tel" readonly placeholder="{lang xigua_job:qtjgzjl}">
            <!--{/if}-->
            </div>
            <div class="weui-cell__ft">
                <a class="main_color f15" id="workexp">{lang xigua_job:add}</a>
            </div>
        </div>
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label class="weui-label" style="width:70px">{lang xigua_job:eduexp}</label></div>
            <div class="weui-cell__bd eduexplist">
                <!--{if $old_data[eduexp_ary]}-->
                <!--{eval $eduexpary = $old_data[eduexp_ary];}-->
                <!--{loop $eduexpary['comname'] $_k $_v}-->
                <div class="f12 jl_list">
                    <p>{$eduexpary[start][$_k]} {lang xigua_job:zhi} {echo $eduexpary[end][$_k]? $eduexpary[end][$_k]: lang_job('jin',0)}</p>
                    <p class="f12 c9">{lang xigua_job:xuexiao} : {$eduexpary[comname][$_k]}</p>
                    <!--{if $eduexpary[zhiwei][$_k]}-->
                    <p class="f12 c9">{lang xigua_job:zy} : {$eduexpary[zhiwei][$_k]}</p>
                    <!--{/if}-->
                    <a>x</a>
                    <input class="comname" name="form[eduexp][comname][]" type="hidden" value="{$eduexpary[comname][$_k]}" />
                    <input class="start" name="form[eduexp][start][]" type="hidden" value="{$eduexpary[start][$_k]}" />
                    <input class="end" name="form[eduexp][end][]" type="hidden" value="{$eduexpary[end][$_k]}" />
                    <input class="zhiwei" name="form[eduexp][zhiwei][]" type="hidden" value="{$eduexpary[zhiwei][$_k]}" />
                </div>
                <!--{/loop}-->
                <!--{else}-->
                <input class="weui-input eduexpdft" type="tel" readonly placeholder="{lang xigua_job:qtjeduexp}">
                <!--{/if}-->
            </div>
            <div class="weui-cell__ft">
                <a class="main_color f15" id="eduexp">{lang xigua_job:add}</a>
            </div>
        </div>
    <!--{if !$old_data}-->
        <div class="weui-cell">
            <div class="weui-cell__bd">{lang xigua_job:qxzzdsj}</div>
        </div>
        <!--{template xigua_job:resume_dig}-->
    <!--{/if}-->
    </div>
    <div class="fix-bottom mt10" style="position:relative">
        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_job:save}">
    </div>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<!--{template xigua_job:popup}-->
</form>

<div id="popup_addfield" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:quxiao}</a>
                <h1 class="title">{lang xigua_job:tzgzjl}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:gsmc}<em class="color-red">*</em></label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="j_comname" type="text" placeholder="{lang xigua_job:qtxgsmc}">
                    </div>
                </div>
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:drzw}<em class="color-red">*</em></label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="j_zhiwei" type="text" placeholder="{lang xigua_job:qtxdrzw}">
                    </div>
                </div>
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:rzsj}<em class="color-red">*</em></label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input datectrl" name="j_start" type="text" placeholder="{lang xigua_job:qtxrzsj}">
                    </div>
                </div>
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:lzsj}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input datectrl" name="j_end" type="text" placeholder="{lang xigua_job:qxzlzsj}">
                    </div>
                </div>
            </div>
            <div class="fix-bottom" style="position: relative">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_primary expadd" value="{lang xigua_job:queding}">
            </div>
        </div>
    </div>
</div>
<div id="popup_edufield" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:quxiao}</a>
                <h1 class="title">{lang xigua_job:tjjyjl}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:xuexiao}<em class="color-red">*</em></label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="e_comname" type="text" placeholder="{lang xigua_job:qtxxuexiao}">
                    </div>
                </div>
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:zy}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="e_zhiwei" type="text" placeholder="{lang xigua_job:qtxzy}">
                    </div>
                </div>
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:ruxue}<em class="color-red">*</em></label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input datectrl" name="e_start" type="text" placeholder="{lang xigua_job:qxz}{lang xigua_job:ruxue}">
                    </div>
                </div>
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_job:biye}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input datectrl" name="e_end" type="text" placeholder="{lang xigua_job:qxz}{lang xigua_job:biye1}">
                    </div>
                </div>
            </div>
            <div class="fix-bottom" style="position: relative">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_primary eduexpadd" value="{lang xigua_job:queding}">
            </div>
        </div>
    </div>
</div>
<!--{template xigua_hb:enter_up}-->
<!--{eval $job_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_job:footer}-->
<script>
var sqs = [];
<!--{loop $birthinfo $quan}-->
sqs.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#birth").select({
    title: "{lang xigua_job:qxzbirth}",
    items: sqs,
    onOpen:function () {
        $('.masker').remove();
        $('body').append('<div class="masker" onclick="$(\'#birth\').select(\'close\')"></div>');
        $('.masker').fadeIn();
    },
    beforeClose:function () {
        $('.masker').fadeOut(150);
        return true;
    }
});
var jingyan = [];<!--{eval array_shift($jingyan);}-->
<!--{loop $jingyan $quan}-->
jingyan.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#experience").select({
    title: "{lang xigua_job:qxzjingyan}",
    items: jingyan,
    onOpen:function () {
        $('.masker').remove();
        $('body').append('<div class="masker" onclick="$(\'#experience\').select(\'close\')"></div>');
        $('.masker').fadeIn();
    },
    beforeClose:function () {
        $('.masker').fadeOut(150);
        return true;
    }
});
var xueli = [];<!--{eval array_shift($xueli);}-->
<!--{loop $xueli $quan}-->
xueli.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#xueli").select({
    title: "{lang xigua_job:qxzxueli}",
    items: xueli,
    onOpen:function () {
        $('.masker').remove();
        $('body').append('<div class="masker" onclick="$(\'#xueli\').select(\'close\')"></div>');
        $('.masker').fadeIn();
    },
    beforeClose:function () {
        $('.masker').fadeOut(150);
        return true;
    }
});
var xinzi = [];
<!--{loop $xinzi $quan}-->
xinzi.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#xinzi").select({
    title: "{lang xigua_job:qxzqwyx}",
    items: xinzi,
    onOpen:function () {
        $('.masker').remove();
        $('body').append('<div class="masker" onclick="$(\'#xinzi\').select(\'close\')"></div>');
        $('.masker').fadeIn();
    },
    beforeClose:function () {
        $('.masker').fadeOut(150);
        return true;
    }
});
var qiustatus = [];
<!--{loop $qzzt $quan}-->
qiustatus.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#qiustatus").select({
    title: "{lang xigua_job:qxzqzzt}",
    items: qiustatus,
    onOpen:function () {
        $('.masker').remove();
        $('body').append('<div class="masker" onclick="$(\'#qiustatus\').select(\'close\')"></div>');
        $('.masker').fadeIn();
    },
    beforeClose:function () {
        $('.masker').fadeOut(150);
        return true;
    }
});
$(document).on('click','#jobwant', function () {
    var popcm =$('#popup_jobwant');
    popcm.popup();
    popcm.show();
    setTimeout(function(){
        popcm.show();
    }, 500);
    return false;
});
$(document).on('click','#areawant', function () {
    var popcm =$('#popup_areawant');
    popcm.popup();
    popcm.show();
    setTimeout(function(){
        popcm.show();
    }, 500);
    return false;
});
$(document).on('click','#workexp', function () {
    var popcm =$('#popup_addfield');
    popcm.popup();
    popcm.show();
    setTimeout(function(){
        popcm.show();
    }, 500);
    return false;
});
$(document).on('click','#eduexp', function () {
    var popcm =$('#popup_edufield');
    popcm.popup();popcm.show();
    setTimeout(function(){popcm.show();}, 500);
    return false;
});

$(".datectrl").calendar();
$(document).on('click','.J_ping', function () {
    $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
    $(this).addClass('type-item-active').removeClass('type-item-gray');
});
$('.J_ping:first-child').trigger('click');
$('.J_ping:first-child').find('.typevip').trigger('click');

function set_typeid(id, obj) {
    if ($(obj).hasClass('tag-on')) {
        $(obj).removeClass('tag-on');
        $('input[name="form[goodat][' + id + ']"]').val('0');
    } else {
        var MaxTagNum = {$job_config['goodatnum']};
        if (MaxTagNum > 0 && $('.tag-on').length > MaxTagNum - 1) {
            $.toast('{lang xigua_job:zdxz}'+MaxTagNum+'{lang xigua_job:gtc}');
            return false;
        }
        $(obj).addClass('tag-on');
        $('input[name="form[goodat][' + id + ']"]').val('1');
    }
}

$('.sidectrl').attr('data-href', $('.sidectrl').attr('href')).attr('href', 'javascript:;');
$(document).on('click','.sidectrl', function () {
    $('#dosubmit').trigger('click');
});
$(document).on('click','.expadd', function () {
    var j_start = $('input[name="j_start"]').val();
    var j_end = $('input[name="j_end"]').val();
    var j_comname = $('input[name="j_comname"]').val();
    var j_zhiwei = $('input[name="j_zhiwei"]').val();
    if(!j_end){
        j_end = '{lang xigua_job:jin}';
    }
    if(!j_zhiwei || !j_comname || !j_start){
        return false;
    }
    var html = '<div class="f12 jl_list">\n' +
        '    <p>'+j_start+' {lang xigua_job:zhi} '+j_end+'</p>\n' +
        '    <p class="f12 c9">{lang xigua_job:hsname} : '+j_comname+'</p><p class="f12 c9">{lang xigua_job:title} : '+j_zhiwei+'</p>\n' +
        '    <a>x</a>\n' +
        '    <input class="comname" name="form[workexp][comname][]" type="hidden" value="'+j_comname+'" />\n' +
        '    <input class="start" name="form[workexp][start][]" type="hidden" value="'+j_start+'" />\n' +
        '    <input class="end" name="form[workexp][end][]" type="hidden" value="'+j_end+'" />\n' +
        '    <input class="zhiwei" name="form[workexp][zhiwei][]" type="hidden" value="'+j_zhiwei+'" />\n' +
        '</div>';
    $('.workexplist').append(html);
    $('.workexpdft').hide();
    $.closePopup();
});
$(document).on('click','.jl_list a', function () {
    $(this).parent().remove();
    if($('.jl_list').length<1){
        $('.workexpdft').show();
    }
});
$(document).on('click','.eduexpadd', function () {
    var e_start = $('input[name="e_start"]').val();
    var e_end = $('input[name="e_end"]').val();
    var e_comname = $('input[name="e_comname"]').val();
    var e_zhiwei = $('input[name="e_zhiwei"]').val();
    if(!e_comname || !e_start){
        return false;
    }
    if(!e_end){
        e_end = '{lang xigua_job:jin}';
    }
    if(!e_zhiwei){
        e_zhiwei = '-';
    }
    var html = '<div class="f12 jl_list">\n' +
        '    <p>'+e_start+' {lang xigua_job:zhi} '+e_end+'</p>\n' +
        '    <p class="f12 c9">{lang xigua_job:xuexiao} : '+e_comname+'</p><p class="f12 c9">{lang xigua_job:zy} : '+e_zhiwei+'</p>\n' +
        '    <a>x</a>\n' +
        '    <input class="comname" name="form[eduexp][comname][]" type="hidden" value="'+e_comname+'" />\n' +
        '    <input class="start" name="form[eduexp][start][]" type="hidden" value="'+e_start+'" />\n' +
        '    <input class="end" name="form[eduexp][end][]" type="hidden" value="'+e_end+'" />\n' +
        '    <input class="zhiwei" name="form[eduexp][zhiwei][]" type="hidden" value="'+e_zhiwei+'" />\n' +
        '</div>';
    $('.eduexplist').append(html);
    $('.eduexpdft').hide();
    $.closePopup();
});
</script>