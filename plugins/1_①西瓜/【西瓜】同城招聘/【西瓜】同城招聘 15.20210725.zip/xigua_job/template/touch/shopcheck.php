<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if !$sh && $job_config[musths]}-->
<!--{eval $backto = urlencode(hb_currenturl());}--><script>
$.confirm('{lang xigua_job:qxws}', function () {
    hb_jump("$SCRITPTNAME?id=xigua_hs&ac=enter&mobile=2{$urlext}&backto=$backto");
}, function () {
    hb_jump("$SCRITPTNAME?id=xigua_job&ac=my&mobile=2{$urlext}&backto=$backto");
});
</script>
<!--{else}-->
<!--{eval
$wffb1 = lang_job('wffb1',0);
$gmzptc = lang_job('gmzptc',0);
$wflx6 = lang_job('wflx6',0);
$wflx4 = lang_job('wflx4',0);
$wffb2 = lang_job('wffb2',0);
$wffb3 = lang_job('wffb3',0);
$wflx7 = lang_job('wflx7',0);
$taocan = $tcobj->fetch_by_uid($_G['uid']);
}-->
<!--{if !$taocan}-->
    <script>$.modal({title: "$gmzptc",text: '$wffb2',
        buttons: [
            { text: "{lang xigua_job:quxiao}", className: "default", onClick: function(){ window.history.go(-1)}},
            { text: "{lang xigua_job:queding}", onClick: function(){hb_jump('$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2');}},
        ]});
    </script>
<!--{else}-->
    <!--{if $taocan['is_end']}-->
    <script>$.modal({title: "$gmzptc",text: '$wflx4',
        buttons: [
            { text: "{lang xigua_job:quxiao}", className: "default", onClick: function(){ window.history.go(-1)}},
            { text: "{lang xigua_job:queding}", onClick: function(){hb_jump('$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2');}},
        ]});
    </script>
    <!--{/if}-->
    <!--{if $taocan['fabu'] && $taocan['yifabu']>=$taocan['fabu'] && !$_REQUEST['jobid'] && $_GET[ac]!='my_company'}-->
    <script>$.modal({title: "$wflx6",text: '$wffb3',
        buttons: [
            { text: "{lang xigua_job:quxiao}", className: "default", onClick: function(){ window.history.go(-1)}},
            { text: "{lang xigua_job:queding}", onClick: function(){hb_jump('$SCRITPTNAME?id=xigua_job&ac=taocan&mobile=2');}},
        ]});
    </script>
    <!--{/if}-->
<!--{/if}-->

<!--{/if}-->
