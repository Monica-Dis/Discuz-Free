<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/mynew.css?{VERHASH}" /><style>.x_header_fix{display:none}.x_header{position:relative}.centtop1 a i{color:{$config[maincolor]}}.centtop2 a i{color:#999}
.my_new_bd .my__head_wap .weui-grids-mini{position: relative;bottom:0}
.my_new_bd .my__head_new{height:80px;margin-bottom:0;overflow:hidden}.my_new_bd .my__head_user{margin:10px 15px}.my_new_bd .jnav .weui-grid__label{margin-top:10px}.my_new_bd .qblink{padding-right:10px!important}
.weui-cells__title{color:#333;margin-top:75px;}
.car-type .type-item-box{box-sizing:content-box;transform:translateZ(0);-webkit-transform:translateZ(0)}.car-type .type-item-box,.car-type .type-item-box-last{position:relative;width:100%;height:100%;z-index:1;display:-webkit-box;display:-ms-flexbox;display:flex;overflow-x:auto;overflow-y:hidden}.car-type .type-item{width:6.4rem;height:5.7333rem;padding-left:.5333rem;position:relative;box-sizing:border-box;-webkit-box-sizing:border-box;-webkit-flex-shrink:0;-ms-flex:0 0 auto;flex-shrink:0;margin-right:.5333rem;overflow:hidden;border-radius:4px}.car-type .type-item-active{background:#fff9e0}.car-type .type-title{height:.96rem;line-height:.96rem;font-size:.5333rem;font-weight:700;color:#172047;padding-top:.6133rem;overflow:hidden}.car-type .type-discount{height:1.4933rem;line-height:1.4933rem;font-size:0;color:#172047;overflow:hidden}.car-type .car-logo{font-size:.8rem}.car-type .car-price{font-size:1.5467rem;font-weight:700}.car-type .car-unit{font-size:.64rem}.car-type .type-origin{height:.8rem;line-height:.8rem;font-size:.5867rem;color:#666}.car-type .car-year-season{text-align:center;padding:0 .5333rem;line-height:.8rem;font-size:.5333rem;color:#fff;border-top-left-radius:.3733rem;border-bottom-right-radius:.3733rem;width:5rem}.typevip1+.type-item,.car-type .type-item-gray:after{content:"";position:absolute;top:0;left:0;height:calc(200% - 1px);width:calc(200% - 1px);border:1px solid #d9d9d9;border-radius:8px;transform:scale(.5);-webkit-transform:scale(.5);transform-origin:left top;-webkit-transform-origin:left top;z-index:200;box-sizing:border-box;-webkit-box-sizing:border-box;-webkit-backface-visibility:hidden;-webkit-transform-style:preserve-3d}.typevip1+.type-item .car-active-c,.car-type .type-item-gray .car-active-c{display:none}.typevip1+.type-item,.car-type .type-item-gray{background:#fff}.typevip1:checked+.type-item .car-active-c,.car-type .type-item-active .car-active-c{background-position:-3.04rem -1.3333rem;position:absolute;background-repeat:no-repeat;background-size:14.4533rem 6.7467rem;-webkit-background-size:14.4533rem 6.7467rem;display:block;border-bottom:1.2rem solid #00c2c4;border-left:1.2rem solid transparent;width:0;height:0;bottom:0;right:0}.typevip1:checked+.type-item .car-active-c .iconfont,.car-type .type-item-active .car-active-c .iconfont{position:absolute;color:#fff;top:.3rem;font-size:14px;right:-2px;z-index:99;transform:scale(.5)}.typevip1:checked+.type-item:after,.car-type .type-item-active:after{content:"";position:absolute;top:0;left:0;height:calc(200% - 1px);width:calc(200% - 1px);border:1px solid #ffbe3a;border-radius:8px;transform:scale(.5);-webkit-transform:scale(.5);transform-origin:left top;-webkit-transform-origin:left top;z-index:200;box-sizing:border-box;-webkit-box-sizing:border-box;-webkit-backface-visibility:hidden;-webkit-transform-style:preserve-3d}.car-type .car-tip{height:1.0667rem;line-height:1.0667rem;font-size:.5333rem;color:#666;margin-top:.3467rem}.car-type{padding:15px;background:#fff;-webkit-overflow-scrolling:touch}.type-discount + .car-year-season {margin-top: 1.4134rem;}
.car-type .type-item{float: left;height:8rem!important;width: calc(50vw - 24px);margin-right: 15px;margin-bottom: 15px;}
.car-type .type-item:nth-child(2n){margin-right:0;}
.car-type .type-origin{margin-bottom:5px;}
.car-type .type-item-box, .car-type .type-item-box-last{display:block}
.car-type .car-year-season {border-top-right-radius: 2px;border-bottom-left-radius: 2px;}.navtitle{display:none}
</style>
<div class="page__bd bgf my_new_bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="my__head_new main_bg">
        <i class="header-annimate-element1"></i><i class="header-annimate-element4"></i>
        <i class="header-annimate-element5"></i><i class="header-annimate-element6"></i>
        <i class="header-annimate-element7"></i><i class="header-annimate-element8"></i>
        <i class="header-annimate-element9"></i>
    </div>
    <!--{template xigua_job:tcard}-->
    <div class="weui-cells__title">{lang xigua_job:xzzptc}</div>
    <form  action="$SCRITPTNAME?id=xigua_job&ac=taocan" method="post" id="form">
        <input name="formhash" value="{FORMHASH}" type="hidden">
        <input name="inajax" value="1" type="hidden">
        <input name="st" value="{$_GET['st']}" type="hidden">
        <div class="cl car-type">
            <div class="type-item-box">
                <!--{loop $zptc $_k $_v}-->
                <label for="s$_k" class="type-item J_ping type-item-active">
                    <input type="radio" data-acs="0" class="none typevip" name="form[viptype]" value="$_v[days]" id="s$_k" checked="checked">
                    <div class="type-title">$_v[name]</div>
                    <div class="car-sku-year cl">
                        <div class="type-discount">
                            <span class="car-logo">{$_v[price]}{lang xigua_job:yuan} <s class="c9 f14">$_v[delprice]{lang xigua_job:yuan}</s></span>
                        </div>
                        <div class="car-tip">{lang xigua_job:yxq} $_v[days_str]</div>
                        <div class="type-origin">{lang xigua_job:fbzw} <span class="main_color ">{$_v[fabu]}{lang xigua_job:t}</span></div>
                        <div class="type-origin">{lang xigua_job:xzjl} <span class="main_color ">{$_v[xiazai]}{lang xigua_job:f}</span></div>
                        <!--{if $_v[zhiding]}-->
                        <div class="car-year-season ">{lang xigua_job:zdzw} {$_v[zhiding]}{lang xigua_job:zhe}</div>
                        <!--{/if}-->
                    </div>
                    <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
                </label>
                <!--{/loop}-->
            </div>
        </div>
        <div class="fix-bottom">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_job:queding}">
        </div>
    </form>
</div>
<div class="main_color f12" style="padding:10px 15px">{lang xigua_job:tcms}</div>
<div class="footer_fix"></div>
<div class="bottom_fix"></div>
<!--{eval $tabbar=0;$job_tabbar=0;}-->
<!--{template xigua_job:footer}-->
<script>
$(document).on('click','.J_ping', function () {
    $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
    $(this).addClass('type-item-active').removeClass('type-item-gray');
});
$('.J_ping:first-child').trigger('click');
$('.J_ping:first-child').find('.typevip').trigger('click');
</script>