<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if 0 && !$hasjob && $_GET['type']=='full'}-->
<script>
$.modal({
    title: "{lang xigua_job:nhmyfull}",
    text: '{lang xigua_job:nhmyfull2}',
    buttons: [
        { text: "{lang xigua_job:quxiao}", className: "default", onClick: function(){
                hb_jump('$SCRITPTNAME?id=xigua_job&ac=my');} },
        { text: "{lang xigua_job:ljfb}", onClick: function(){
                hb_jump('$SCRITPTNAME?id=xigua_job&ac=my_company&type=full');
            } },
    ]
});
</script>
<!--{elseif  0 && !$hasjob && $_GET['type']=='part'}-->
<script>
    $.modal({
        title: "{lang xigua_job:nhmypart}",
        text: '{lang xigua_job:nhmypart2}',
        buttons: [
            { text: "{lang xigua_job:quxiao}", className: "default", onClick: function(){
                    hb_jump('$SCRITPTNAME?id=xigua_job&ac=my');} },
            { text: "{lang xigua_job:ljfp}", onClick: function(){
                hb_jump('$SCRITPTNAME?id=xigua_job&ac=my_company&type=part');
                } },
        ]
    });
</script>
<!--{/if}-->