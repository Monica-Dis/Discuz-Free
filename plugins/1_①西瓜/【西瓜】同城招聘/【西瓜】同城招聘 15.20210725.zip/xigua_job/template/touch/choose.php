<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_job:header}-->
<style>.footer_fix{display:none}</style>
<div class="page__bd choose_pg bgf">
    <div class="ztop main_bg">
        <div class="zintop main_bg">
            <!--{if strpos($job_config['logo'],'/')!==false}--><img src="$job_config[logo]" /> <!--{else}--><span style="margin:0 .75rem">$job_config[logo]</span><!--{/if}-->
        </div>
    </div>

    <div class="choose_fiv">
        <a class="weui-btn weui-btn_primary" href="plugin.php?id=xigua_job&ac=resume&mobile=2"><i class="iconfont icon-shoplight"></i> {lang xigua_job:wygz}</a>
        <a class="weui-btn weui-btn_primary" href="plugin.php?id=xigua_job&ac=my_company&mobile=2"><i class="iconfont icon-icon_wode"></i> {lang xigua_job:wyzr}</a>
    </div>

    <div class="main_color choose_ft">
        {lang xigua_job:qhts}
    </div>
</div>
<!--{eval $tabbar=0;$job_tabbar=0;}-->
<!--{template xigua_job:footer}-->