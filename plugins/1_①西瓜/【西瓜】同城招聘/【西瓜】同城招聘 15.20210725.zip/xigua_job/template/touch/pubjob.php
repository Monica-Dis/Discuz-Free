<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<link rel="stylesheet" href="source/plugin/xigua_job/static/jobonly.css?{VERHASH}"><style>.weui-cell_access .weui-cell__ft:after{margin-top:10px}.select_abs{position: absolute;right: 10px;bottom: 10px;width:100px;height: 25px;line-height: 25px;}</style>
<form action="$SCRITPTNAME?id=xigua_job&ac=pubjob&st={$_GET['st']}" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
    <input name="form[jobid]" value="{echo $old_data[jobid]?$old_data[jobid]:$_GET['jobid']}" type="hidden">
    <input type="hidden" id="lat" name="form[lat]" value="{$old_data['lat']}">
    <input type="hidden" id="lng" name="form[lng]" value="{$old_data['lng']}">
    <input type="hidden" id="province" name="form[province]" value="{$old_data['province']}">
    <input type="hidden" id="city" name="form[city]" value="{$old_data['city']}">
    <input type="hidden" id="district" name="form[district]" value="{$old_data['district']}">
    <input type="hidden" id="street" name="form[street]" value="{$old_data['street']}">
    <input type="hidden" id="street_number" name="form[street_number]" value="{$old_data['street_number']}">
    <input type="hidden"name="form[type]" value="{$old_data['type']}">

    <div class="page__bd bgf">
        <div class="weui-cells weui-cells_form mt0">
            <div class="weui-cell ">
                <div class="weui-cell__bd">
                    <h2 class="c3 f16">{lang xigua_job:xzsmy}</h2>
                    <div class="main_color f12 mt10">
                        {lang xigua_job:xzsmytip}
                    </div>
                </div>
            </div>
            <!--{if !$old_data[jobid]}-->
            <div class="weui-cell list4">
                <div class="cl weui-cells_radio c3">
                    <label class="z weui-check__label mr10" for="x11">
                        <input type="radio" class="weui-check formtype" name="form[type]" value="full" id="x11" <!--{if $_GET['type']=='full'}-->checked<!--{/if}-->><span class="weui-icon-checked"></span> {lang xigua_job:full}
                    </label> <label class="z weui-check__label" for="x12">
                        <input type="radio" class="weui-check formtype" name="form[type]" value="part" id="x12" <!--{if $_GET['type']=='part'}-->checked<!--{/if}-->><span class="weui-icon-checked"></span> {lang xigua_job:part}
                    </label>
                </div>
            </div>
            <!--{/if}-->
            <!--{if $sh && $job_config[musths]}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:yrdw}</p>
                    <p class="mt10">
                        <input class="weui-input choose_ctrl" name="form[shname]" type="text" value="{echo $old_data?$old_data['shname']:$sh[0]['name']}" placeholder="{lang xigua_job:qxzyrdw}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{else}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:yrdw}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[shname]" type="text" value="{echo $old_data?$old_data['shname']:$sh[0]['name']}" placeholder="{lang xigua_job:qtx}{lang xigua_job:yrdw}">
                    </p>
                </div>
            </div>
            <!--{/if}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:hangye_id2}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[hy]" id="hangye" type="text" value="$default_hy" placeholder="{lang xigua_job:plzhangye_id2}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:title}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[name]" id="name" type="text" value="{$old_data[name]}" placeholder="{lang xigua_job:qtx}{lang xigua_job:title}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
<!--{if $_GET['type']=='full'}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:xinzi}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[xinzi]" id="xinzi" type="text" value="{$old_data[xinzi]}" placeholder="{lang xigua_job:qtxzwxz}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
<!--{else}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:xinzi}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[xinzi]" type="tel" value="{$old_data[xinzi]}" placeholder="{lang xigua_job:qtxxinzi}">

                        <select class="weui-select select_abs" name="form[xinziunit]">
                            <!--{loop $yuanshi $_k $_v}-->
                            <option value="$_k"  <!--{if $old_data[xinziunit]==$_k}-->selected<!--{/if}-->>$_v</option>
                            <!--{/loop}-->
                        </select>
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:jiesuan}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[jiesuan]" id="jiesuan" type="text" value="{$old_data[jiesuan]}" placeholder="{lang xigua_job:djxjiesuan}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:jzsj}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[opentime]" id="opentime" type="text" value="{echo $old_data ? $old_data[opentime] : '9:00-18:00'}" placeholder="{lang xigua_job:djxjzsj}">

                        <select class="weui-select select_abs" name="form[shiduan]">
                            <!--{loop $shiduan $_k $_v}-->
                            <option value="$_k"  <!--{if $old_data[shiduan]==$_k}-->selected<!--{/if}-->>$_v</option>
                            <!--{/loop}-->
                        </select>
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
<!--{/if}-->

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:neednum}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[neednum]" id="neednum" type="tel" value="{$old_data[neednum]}" placeholder="{lang xigua_job:qtxneednum}">
                    </p>
                </div>
                <div class="weui-cell__ft">{lang xigua_job:r}</div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:nlxb}</p>
                    <p class="mt10">
                        <input style="width:50px;border-bottom:1px solid #666;text-align:center;" class="weui-input" name="form[minage]"  type="tel" value="{echo $old_data ? $old_data[minage] : 18}" placeholder="{lang xigua_job:qtx}">
                        <span>-</span>
                        <input style="width:50px;border-bottom:1px solid #666;text-align:center;" class="weui-input" name="form[maxage]"  type="tel" value="{echo $old_data ? $old_data[maxage] : 55}" placeholder="{lang xigua_job:qtx}">
                        <select class="weui-select select_abs" name="form[gender]">
                            <!--{loop $gender_ary $_k $_v}-->
                            <!--{eval $_v = $_k==-1?$_v.lang_job('gender',0):$_v;}-->
                            <option value="$_k"  <!--{if $old_data[gender]==$_k}-->selected<!--{/if}-->>$_v</option>
                            <!--{/loop}-->
                        </select>
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:xueli}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[xueli]" id="xueli" type="text" value="{$old_data[xueli]}" placeholder="{lang xigua_job:djxxueli}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:jingyan}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[jingyan]" id="jingyan" type="text" value="{$old_data[jingyan]}" placeholder="{lang xigua_job:djxjingyan}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:fuli}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[fuli]" id="fuli" type="text" readonly value="{$old_data[fuli]}" placeholder="{lang xigua_job:djxfuli}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <!--{if $_GET['type']=='part' || !$sh || 1}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:addr}</p>
                    <p class="mt10">
                        <input readonly class="weui-input" id="openlocation" name="form[addr]" type="text" value="{$old_data[addr]}" placeholder="{lang xigua_job:djxaddr}">
                    </p>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->

            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__bd">
                    <p class="list3T">{lang xigua_job:ty}</p>
                    <p class="mt10">
                        <input class="weui-input" name="form[mobile]" id="tel" type="text" value="$old_data[mobile]" placeholder="{lang xigua_job:qtxlxdh}">
                    </p>
                </div>
                <div class="weui-cell__ft">
                    <input class="weui-switch" type="checkbox" checked="" name="form[openmobile]" value="1">
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <p class="list3T cl">
                        {lang xigua_job:miaoshu}
                        <a class="y main_color none">{lang xigua_job:cksl}<i class="f13 iconfont icon-jinrujiantou"></i></a>
                    </p>
                    <div>
                        <textarea class="weui-textarea texta" name="form[miaoshu]" rows="3">$old_data[miaoshu]</textarea>
                    </div>
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <p class="list3T cl">
                        {lang xigua_job:thumb}
                        <span class="y">{echo str_replace('n', $job_config['maximg'], lang_job('zuiduozhao',0))}</span>
                    </p>
                    <div class="weui-uploader">
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$job_config['maximg']}" data-maxtip="{echo str_replace('n', $job_config['maximg'], lang_job('zuiduozhao',0))}">
<!--{loop $old_data[album] $img}-->
<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
    <input type="hidden" name="form[album][]" value="$img"/>
    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
</li>
<!--{/loop}--></ul>
                            <div class="weui-uploader__input-box">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="form[album]" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="weui-cells__title">
        {lang xigua_job:guize}
    </div>
    <div class="footer_fix"></div>
    <div class="fix-bottom">
        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_job:queding}">
    </div>
</form>
<div class="masker masker1" onclick='$(".choose_ctrl").select("close")'></div>

<div id="popup_fuli" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_job:wc}</a>
                <h1 class="title">{lang xigua_job:djxfuli}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="border_bottom post_com_tag post-tags cl" id="p1"><!--{loop $old_data['fuli_ary'] $_k $_v}-->
                <a id="id_p1{$_v}" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">{$old_data['fuli_str_ary'][$_k]}<input name="form[fuli][]" type="hidden" value="$_v"></a>
                <!--{/loop}--></div>
            <div class="pupc-btm">
                <div class="pupc-btm-in">
                    <!--{loop $fuliary $_k $_v}-->
                    <a class="border_bottom check1 <!--{if $_k==0}-->main_color<!--{/if}-->" data-title="{$_v[id]}" data-titfix="p1_" >{$_v[oname]}</a>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left">
                    <!--{loop $fuliary $_k $_v}-->
                    <div class="pupc-btm-in_list <!--{if $_k>0}-->none<!--{/if}-->" id="p1_{$_v[id]}">
                        <!--{loop $_v[sub] $__v}-->
                        <a class="check2 pupc_check_a border_bottom" data-form="fuli" data-ld="p1" data-title="p1{$__v[id]}" data-value="{$__v[id]}">{$__v[oname]}</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
    </div>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div id="agree__text" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_job:gztitle}</h1>
                <section>
                    <section>
                        $job_config[xieyi]
                    </section>
                </section>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
        </div>
    </div>
</div>
<script> +function($){  $.rawCitiesData = $cityjson; }($);</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script>
$(document).on('click','.formtype', function () {
    if($(this).val()=='full'){
        <!--{if $_GET['type']!='full'}-->
        hb_jump('plugin.php?id=xigua_job&ac=pubjob&type=full');
        <!--{/if}-->
    }else{
        <!--{if $_GET['type']!='part'}-->
        hb_jump('plugin.php?id=xigua_job&ac=pubjob&type=part');
        <!--{/if}-->
    }
});
var itar = [];
<!--{loop $sh $_sh}--><!--{if $_sh[name]}-->
itar.push({title:'{$_sh[name]}'});
<!--{/if}--><!--{/loop}-->
$(".choose_ctrl").select({
    title: "{lang xigua_job:qxzyrdw}",
    items: itar,
    onOpen:function () {
        $('.masker1').fadeIn();
    },
    beforeClose:function () {
        $('.masker1').fadeOut(300);
        return true;
    }
});
$("#hangye").cityPicker({
    title: "{lang xigua_job:plzhangye_id2}",
    showDistrict: false,
    onChange: function (picker, values, displayValues) {
        $('#name').val(displayValues[1]);
    }
});
var xinzi = [];
<!--{loop $xinzi $quan}-->
xinzi.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#xinzi").select({
    title: "{lang xigua_job:qtxzwxz}",
    items: xinzi,
    onOpen:function () {
        $('.masker3').remove();
        $('body').append('<div class="masker masker3" onclick="$(\'#xinzi\').select(\'close\')"></div>');
        $('.masker3').fadeIn();
    },
    beforeClose:function () {
        $('.masker3').fadeOut(150);
        return true;
    }
});
var xueli = [];
<!--{loop $xueli $quan}-->
xueli.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#xueli").select({
    title: "{lang xigua_job:djxxueli}",
    items: xueli,
    onOpen:function () {
        $('.masker5').remove();
        $('body').append('<div class="masker masker5" onclick="$(\'#xueli\').select(\'close\')"></div>');
        $('.masker5').fadeIn();
    },
    beforeClose:function () {
        $('.masker5').fadeOut(150);
        return true;
    }
});
$(document).on('click','#fuli', function () {
    var popcm =$('#popup_fuli');
    popcm.popup();
    popcm.show();
    setTimeout(function(){
        popcm.show();
    }, 500);
    return false;
});
var jingyan = [];
<!--{loop $jingyan $quan}-->
jingyan.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#jingyan").select({
    title: "{lang xigua_job:djxjingyan}",
    items: jingyan,
    onOpen:function () {
        $('.masker6').remove();
        $('body').append('<div class="masker masker6" onclick="$(\'#experience\').select(\'close\')"></div>');
        $('.masker6').fadeIn();
    },
    beforeClose:function () {
        $('.masker6').fadeOut(150);
        return true;
    }
});
var jiesuan = [];
<!--{loop $jiesuan $quan}-->
    jiesuan.push({title:'{$quan}', value:'{$quan}'});
<!--{/loop}-->
$("#jiesuan").select({
    title: "{lang xigua_job:djxjiesuan}",
    items: jiesuan,
    onOpen:function () {
        $('.masker7').remove();
        $('body').append('<div class="masker masker7" onclick="$(\'#experience\').select(\'close\')"></div>');
        $('.masker7').fadeIn();
    },
    beforeClose:function () {
        $('.masker7').fadeOut(150);
        return true;
    }
});
$("#opentime").picker({
    title: "{lang xigua_job:djxjzsj}",
    value:['9:00', '18:00'],
    formatValue: function (p, values, displayValues) {
        return values[0]+'-'+values[1];
    },
    cols: [
        {textAlign: 'center',values: $opentime},
        {divider: true, content: '-'},
        {textAlign: 'center',values: $opentimeend}
    ]
});
$(document).on('click','.guize', function () {
    $("#agree__text").popup();
});
</script>
<script src="source/plugin/xigua_job/static/popup.js?{VERHASH}"></script>
<!--{eval $tabbar=0;$job_tabbar=0;}-->
<!--{template xigua_job:shopcheck}-->
<!--{template xigua_hb:enter_up}-->
<!--{template xigua_job:footer}-->
<!--{template xigua_job:location_js}-->