<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_job:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{if $topad1}-->
    <a href="$topad1[1]">
        <img class="blockimg" src="{$topad1[0]}" />
    </a>
    <!--{/if}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_job&ac=my_company" class="weui-navbar__item <!--{if !$_GET[type]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:qbzw}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_job&ac=my_company&type=full" class="weui-navbar__item <!--{if $_GET[type]=='full'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:full}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_job&ac=my_company&type=part" class="weui-navbar__item <!--{if $_GET[type]=='part'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_job:part}</span>
        </a>
    </div>
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
    <a href="$SCRITPTNAME?id=xigua_job&ac=pubjob&type=$_GET[type]" class="float_btn main_bg"><i class="iconfont icon-zengjia f14"></i>{lang xigua_job:fbzw}</a>
</div>
<script>
var loadingurl = window.location.href+'&ac=job_li&is_my=1&inajax=1&page=';scrollto = 0;
$(document).on('click','.offline_btn', function () {
    var that = $(this);
    $.showLoading();
    $.ajax({
        type: "POST",
        url: _APPNAME+"?id=xigua_job&ac=com&do=offline&inajax=1",
        data:{formhash:FORMHASH, jobid:that.data('jobid'), xiajia:that.data('xiajia')},
        dataType: "xml",
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        }
    });
});
$(document).on('click','.refresh_btn', function () {
    var that = $(this);
    $.showLoading();
    $.ajax({
        type: "POST",
        url: _APPNAME+"?id=xigua_job&ac=com&do=refresh&inajax=1",
        data:{formhash:FORMHASH, jobid:that.data('jobid')},
        dataType: "xml",
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        }
    });
});

$(document).on('click','.dig_btn', function () {
    var that = $(this);
    var act = [];
    $.actions({
        title: '{lang xigua_hb:qingxuanzezhiding}',
        actions: [<!--{loop $dig_prices $_d_i}-->{
            text: "{$_d_i[title]}", onClick: function () {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_job&ac=com&do=dig&digtype={$_d_i[type]}',
                    data:{jobid:that.data('jobid'), formhash:FORMHASH},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function() {
                        $.hideLoading();
                    }
                });
            }
        },<!--{/loop}-->]
    });
});
</script>
<!--{eval $tabbar=0;$job_tabbar=0;}-->
<!--{template xigua_job:shopcheck}-->
<!--{template xigua_job:footer}-->