<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_job:header}-->
<!--{if $_G['cache']['plugin']['xigua_job']['logo']}--><div class="hide none"><img src="{$_G['cache']['plugin']['xigua_job']['logo']}" /></div><!--{/if}-->

<div class="page__bd ">
<!--{if getcookie('miniprogram') && $ac=='index'}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if $ac=='index' && $config[showheader]}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if !$hide_nav}--><!--{if $_G['cache']['plugin']['xigua_job']['showfz']}-->
<header class="x_header bgcolor_11 cl  weui-flex f15" style="background:transparent!important;position:absolute">
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_job&ac=index&high=0&mobile=2");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
</header><!--{/if}-->
<!--{/if}-->
    <!--{if $topnavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->
    <div style="height:30px;" class="bgf">
        <div class="flnav">
            <div class="weui-cell__bd scbg">{$job_config[schtxt]}</div>
        </div>
    </div>
    <div class="weui-cells mt0 after_none before_none">
        <div class="weui-cell tl" style="padding: 0px 25px 10px;">
            <div class="weui-cell__bd">
                <i class="iconfont icon-hot1 main_color f14"></i>
                <span class="f14">{lang xigua_job:ll}: <em class="main_color">{$totalviews}</em></span>
                <span class="ml3 f14">{lang xigua_job:title_short}: <em class="main_color">$totaljobs</em></span>
                <span class="ml3 f14">{lang xigua_job:jl}: <em class="main_color">$total_resume</em></span>
            </div>
        </div>
    </div>
    <!--{if $indexstype}-->
    <nav class=" nav-list cl swipe transparent hm_nav mt3">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $indexstype $k $n}-->
                    <!--{if $k && $k%$subkp==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li {$sty_li}>
                        <a href="{$n[href]}">
                            <span><img src="{$n[src]}"/></span>
                            <em class="m-piclist-title <!--{if strpos($n['href'], $_GET['stype'])!==FALSE||($_GET['stype']=='seckill'&&strpos($n['href'],'good')===false&&strpos($n['href'],'stype')===false)}-->main_color<!--{/if}-->" >{$n[name]}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
    </nav>
    <!--{/if}-->

    <!--{template xigua_job:index_pic}-->
    <!--{template xigua_job:index_qy}-->

    <div class="sxtj">
        <div class="weui-cells__title weui_title border_none f15">
            <span class="c3 f17">{lang xigua_job:wntj}</span>
            <a class="y c3 sxbtn sxuan" href="javascript:;">{lang xigua_job:sx}</a>
        </div>
        <div class="chose_cats cl">
            <!--{if $keyword}-->
            <a class="weui-btn whbtn btnon" data-id="0" data-keyword="$keyword" href="javascript:;">{lang xigua_job:search}:$keyword</a>
            <!--{/if}-->
            <!--{if !$keyword}-->
            <a class="weui-btn whbtn btnon" data-id="0" href="javascript:;">{lang xigua_job:zxzw}</a>
            <!--{/if}-->
            <!--{loop $myresume[jobwant_str_ary] $_k $_v}-->
            <a class="weui-btn whbtn" data-id="{$myresume[jobwant_ary][$_k]}" href="javascript:;">$_v</a>
            <!--{/loop}-->
            <!--{loop $exthy $_k $_v}-->
            <a class="weui-btn whbtn" data-id="$_k" href="javascript:;">$_v</a>
            <!--{/loop}-->
            <a class="weui-btn whbtn whbtnadd" href="javascript:;">+</a>
        </div>
    </div>
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
    <!--{template xigua_job:indexfilter}-->
</div>
<!--{eval $job_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_job:footer}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$_G['cache']['plugin']['xigua_hs'][mkey]}"></script>
<script src="source/plugin/xigua_hb/static/countUp.js"></script><script>
if ($('.jobqy_swiper').length > 0) {
    var coupon_swiper = new Swiper('.jobqy_swiper', {
        slidesPerView: 'auto',
        paginationClickable: true,
        spaceBetween: 0
    });
}
var loadingurl = window.location.href+'&ac=job_li&inajax=1&page=';scrollto = 1;
$(document).on('click','.whbtn', function () {
    var that = $(this);
    if(that.index()===$('.whbtn').length-1){
        var popcm =$('#popup_hyc');popcm.popup();popcm.show();setTimeout(function(){popcm.show();}, 500);
        return false;
    }
    that.addClass('btnon');
    that.siblings().removeClass('btnon');
    var kyd = that.data('keyword');
    job_setlist(null, '&ac=job_li&type={$_GET[type]}&hyid='+that.data('id')+'&keyword='+(typeof kyd==='undefined' ? '': kyd));
});
$('.close-reset').trigger('click');
setindex_hy();
$(document).on('click','.scbg', function () { hb_jump('{$SCRITPTNAME}?id=xigua_job&ac=search&high=$_GET[high]&type=$_GET[type]');});
var options={useEasing:true,useGrouping:true,separator:'',decimal:'.',prefix:'',suffix:''};
new countUp("njum1", 0, $('#njum1').text(), 0, 2.5, options).start();
new countUp("njum2", 0, $('#njum2').text(), 0, 2.5, options).start();
new countUp("njum3", 0, $('#njum3').text(), 0, 2.5, options).start();
</script>
<!--{if $_G['cache']['plugin']['xigua_job']['showfz'] && $_G['cache']['plugin']['xigua_hs'] && $_G['cache']['plugin']['xigua_st']['dingwei'] && !getcookie('setcityjob')}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script><script>function autolbshs(){
hs_getlocation(function (position) {
    var citylat = (position.latitude||position.lat);
    var citylng = (position.longitude||position.lng);
    $.ajax({
        type: 'GET',
        url: _APPNAME + '?id=xigua_hs&ac=getloc&checkst=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            console.log(s);
            var m = s.split('|');
            if('success' == m[0]){
                var _t = m[1].split(',');
                console.log(_t);
                if(_t[0]>0 && _t[0]!='{$_GET[st]}'){
                    $.confirm("{lang xigua_hb:dqdws}"+_t[1]+'{lang xigua_hb:setcitygeo2}', function() {
                        window.location.href = _APPNAME+"?id=xigua_job&ac=index&high=0&st="+_t[0];
                        hb_setcookie('setcityjob', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                    }, function() {
                        hb_setcookie('setcityjob', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                    });
                }else{
                    hb_setcookie('setcityjob', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                }
            }
        }
    });
});}
if(typeof wx!='undefined'){wx.ready(function () { autolbshs(); });}else{setTimeout(function(){ autolbshs(); }, 300);}
</script><!--{/if}-->