<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
$job_config = $_G['cache']['plugin']['xigua_job'];
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common_status.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/function.php';
$hyobj = C::t('#xigua_job#xigua_job_hangye');
$rsobj = C::t('#xigua_job#xigua_job_resume');
$jobobj = C::t('#xigua_job#xigua_job_job');
$tcobj = C::t('#xigua_job#xigua_job_taocan');

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" />";
if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        $tcobj->deletes($delete);
    }

    if($_GET['n']){
        $rows = array();
        foreach ($_GET['n']['uid'] as $index => $item) {
            $rows[$index] = array(
                'uid' => $item,
                'name' => $_GET['n']['name'][$index],
                'yixiazai' => $_GET['n'][$index]['yixiazai'],
                'xiazai' => $_GET['n'][$index]['xiazai'],
                'yifabu' => $_GET['n'][$index]['yifabu'],
                'fabu' => $_GET['n'][$index]['fabu'],
                'zhiding' => $_GET['n'][$index]['zhiding'],
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
            );
        }
        foreach ($rows as $index => $row) {
            if($row['uid']>0){
                if($tcobj->fetch_by_uid($row['uid'])){
                    cpmsg(lang_job('yytc', 0).'[UID '.$row['uid'].']', "action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_taocan&shid={$_GET['shid']}&page=$page", 'error');
                }
                $tcobj->insert($row);
            }
        }
    }
    foreach ($_GET['r'] as $id => $item) {
        $item['upts'] = TIMESTAMP;
        $item['endts'] = strtotime($item['endts']);
        $tcobj->update($id, $item);
    }

    cpmsg(lang_job('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_taocan&shid={$_GET['shid']}&page=$page", 'succeed');
}

$wherearr = array();
$keyword = $_GET['keyword'];
if (is_numeric($keyword) && $keyword<9999999) {
    $wherearr[] = 'uid=' . intval($keyword);
}else if ($keyword = stripsearchkey(addslashes($keyword))) {
    $wherearr[] = " (name LIKE '%$keyword%') ";
}
$ob = 'id desc';

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_taocan&shid={$_GET['shid']}");

echo '<div><input type="text" id="keyword" placeholder="'.lang_job('tcss',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
echo '&nbsp;';
echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_taocan".' class="btn" >'.cplang('reset').'</a> ';
echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}
.jobtit{font-size:13px;color:#369}
.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;font-size:12px;border-radius:2px}
.jthumb{width:70px;height:40px}
.red{color:#ff6565}.short{width:30px!important;margin: 0 5px!important;}
.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.mt5{margin-top:5px}
</style>";
echo "</div>";
showtableheader(lang_job('tcgl', 0));
showtablerow('class="header"', array(), array(
    lang_job('del', 0),
    lang_job('tcname', 0),
    lang_job('tcuser', 0),
    lang_job('tcyl', 0),
    lang_job('sj', 0),
));
$res = $tcobj->fetch_all_by_page($start_limit, $lpp, $wherearr, 0, '*', $ob);
$icount = $tcobj->fetch_count_by_page($wherearr);

$shids = array();
$order_ids = array();
foreach ($res as $v) {
    if ($v['uid']) {
        $uids[$v['uid']] = $v['uid'];
    }
    $shids[$v['shid']] = $v['shid'];
    $order_ids[$v['order_id']] =$v['order_id'];
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}
$orders = DB::fetch_all('SELECT * FROM %t WHERE order_id IN(%n)', array(
    'xigua_hb_order',$order_ids
), 'order_id');

$id = '{n}';
$tcyl1 = "<p>".lang_job('xiazai',0)." : <input class=\"txt short\" name=\"n[$id][yixiazai]\" value=\"0\">/<input class=\"txt short\" name=\"n[$id][xiazai]\" value=\"0\"></p>";
$tcyl1.= "<p class=\"mt5\">".lang_job('fabu',0)." : <input class=\"txt short\" name=\"n[$id][yifabu]\" value=\"0\">/<input class=\"txt short\" name=\"n[$id][fabu]\" value=\"0\"></p>";
$tcyl1.= "<p class=\"mt5\">".lang_job('dig',0)." : <input class=\"txt short\" name=\"n[$id][zhiding]\" value=\"\">".lang_job('zhe', 0)."</p>";
foreach ($res as $v) {
    $id = $v['id'];
    $tcyl = "<p>".lang_job('xiazai',0)." : <input class='txt short' name='r[$id][yixiazai]' value='{$v[yixiazai]}'>/<input class='txt short' name='r[$id][xiazai]' value='{$v[xiazai]}'></p>";
    $tcyl.= "<p class='mt5'>".lang_job('fabu',0)." : <input class='txt short' name='r[$id][yifabu]' value='{$v[yifabu]}'>/<input class='txt short' name='r[$id][fabu]' value='{$v[fabu]}'></p>";
    $tcyl.= "<p class='mt5'>".lang_job('dig',0)." : <input class='txt short' name='r[$id][zhiding]' value='{$v[zhiding]}'>".lang_job('zhe', 0)."</p>";

    $shijian = '';
    $shijian.= "<p>".lang_job('crts1',0).": $v[crts_u]</p>";
    $shijian.= "<p>".lang_job('upts1',0).": $v[upts_u]</p>";
    $shijian.= "<p>".lang_job('payts',0).": $v[payts_u]</p>";

    $v['endts_u'] = date('Y-m-d H:i', $v['endts']);
    $shijian.= "<p>".lang_job('endts',0).": <input type=\"text\" class=\"txt\" name=\"r[$id][endts]\" value=\"{$v[endts_u]}\" onclick=\"showcalendar(event, this, 1)\"></p>";

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> ID:$id",
        $v['name'],
        $users[$v['uid']]['username'].'<em>(uid:'.$v['uid'].')</em>'.($v['order_id'] ? ('<br>'.lang_job('ddh',0).':'.$v['order_id'].'<br>'.($orders[$v['order_id']]['paystatus']?'<strong style="color:forestgreen;">'.(lang('plugin/xigua_hb','yi')) .'</strong>' : '<strong style="color:orangered;">'.(lang('plugin/xigua_hb','wei')) .'</strong>').'<br>') : '').
        lang_job('price',0).':'. $v['price'].'<br>',
        $tcyl,
        $shijian,
    ));
}
echo "<tr>
<td>&nbsp;</td>
<td colspan=\"99\"><div>
        <a href=\"javascript:;\" onclick=\"addrow(this, 0)\" class=\"addtr\">".lang_job('tjtc',0)."</a>
    </div></td>
</tr>";
$dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_taocan&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_taocan&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', 'del', "", $multipage);
showtablefooter(); /*dism-Taobao-com*/
showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
?>
<script>
    var rowtypedata = [
        [
            [1, ''],
            [1, '<input type="text" class="txt" name="n[name][]" value="" />'],
            [1,'UID: <input type="text" class="txt" name="n[uid][]" value="" />', 'td25'],
            [1,'<div><?php echo $tcyl1;?></div>'],
            [1,'<div><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_job('del')?></a></dvi>']
        ]
    ];
</script>
<script type="text/javascript" src="static/js/calendar.js"></script>