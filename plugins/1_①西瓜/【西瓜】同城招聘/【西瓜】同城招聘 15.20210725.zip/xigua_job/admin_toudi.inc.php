<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
$job_config = $_G['cache']['plugin']['xigua_job'];
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common_status.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/function.php';
$hyobj = C::t('#xigua_job#xigua_job_hangye');
$rsobj = C::t('#xigua_job#xigua_job_resume');
$jobobj = C::t('#xigua_job#xigua_job_job');
$tcobj = C::t('#xigua_job#xigua_job_taocan');
$xzobj = C::t('#xigua_job#xigua_job_xiazai');

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" />";
{

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            $xzobj->deletes($delete);
        }
        foreach ($_GET['r'] as $id => $item) {
            $item['upts'] = TIMESTAMP;
            $xzobj->update($id, $item);
        }

        cpmsg(lang_job('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_toudi&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey(addslashes($keyword))) {
        $wherearr[] = " (name LIKE '%$keyword%') ";
    }
    $ob = 'id desc';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_toudi&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_job('UID',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';


    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_toudi".' class="btn" >'.cplang('reset').'</a> ';
    echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}
.jobtit{font-size:13px;color:#369}
.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;border-radius:2px}
.jthumb{width:70px;height:40px}
.red{color:#ff6565}.short{width:30px!important;margin: 0 5px!important;}
.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.mt5{margin-top:5px}
</style>";
    echo "</div>";
    showtableheader(lang_job('tdgl', 0));
    showtablerow('class="header"', array(), array(
        lang_job('del', 0),
        lang_job('czr', 0),
        lang_job('title', 0).'<br>'.lang_job('dwmc',0),
        lang_job('jl', 0),
        lang_job('status', 0),
        lang_job('sj', 0),
    ));
    $res = $xzobj->fetch_all_by_page($start_limit, $lpp, $wherearr);
    $icount = $xzobj->fetch_count_by_page($wherearr);

    $jobids = array();
    $rsids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $jobids[$v['jobid']] = $v['jobid'];
        $rsids[$v['rsid']] =$v['rsid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if ($jobids) {
        $jobs = DB::fetch_all('SELECT jobid,`name`,shname,shid FROM %t WHERE jobid IN (%n)', array('xigua_job_job', $jobids), 'jobid');
    }
    if ($rsids) {
        $resumes = DB::fetch_all('SELECT rsid,uid,`realname` FROM %t WHERE rsid IN (%n)', array('xigua_job_resume', $rsids), 'rsid');
        $newuser = array();
        foreach ($resumes as $index => $resume) {
            $newuser[$resume['uid']] = $resume['uid'];
        }
        $newuser = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $newuser), 'uid');
    }
    $orders = DB::fetch_all('SELECT * FROM %t WHERE order_id IN(%n)', array(
        'xigua_hb_order',$order_ids
    ), 'order_id');

    foreach ($res as $v) {
        $id = $v['id'];
        $shijian = '';
        $shijian.= "<p>".lang_job('crts1',0).": $v[crts_u]</p>";
        if($v['upts_u']){
            $shijian.= "<p>".lang_job('upts1',0).": $v[upts_u]</p>";
        }
        $rsuid = $resumes[$v['rsid']]['uid'];

        $stat = $toudi_status[$v['status']];
        if($v['status']==2){
            $stat .= "<p>".lang_job('yysj',0).': '.$v['yyts_u']."</p>";
            $stat .= "<p>".lang_job('note',0).': '.$v['note']."</p>";
        }
        $vtag = $v['is_xiazai'] ? '<span class="jbtn">'.lang_job('xiazai',0).'</span>' : '<span class="jbtn red">'.lang_job('td',0).'</span>';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> ID:$id",
            $vtag.' '.$users[$v['uid']]['username'].'<br><em>UID: '.$v['uid'].'</em>',
            $jobs[$v['jobid']]['name']."[ID: {$v['jobid']}]".'<br>'.
            $jobs[$v['jobid']]['shname']."[ID: {$jobs[$v['jobid']]['shid']}]",
            $resumes[$v['rsid']]['realname']."[ID: {$v['rsid']}]".'<br>'.
            $newuser[$rsuid]['username'].'<br>'.
            "UID: {$rsuid}",
            $stat,
            $shijian,
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_toudi&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_toudi&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism-Taobao-com*/
    showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
}
