<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($v['areawant_ary']){
    $distlist = DB::fetch_all("SELECT `name`,upid,id FROM %t where id IN (%n)", array('xigua_hb_district', $v['areawant_ary']) ,'id');
    $areawant_str_tmp = array();
    foreach ($distlist as $index => $item) {
        $areawant_str_tmp[$item['upid']] = $item['upid'];
    }
    $upstlist = DB::fetch_all("SELECT `name`,upid,id FROM %t where id IN (%n)", array('xigua_hb_district',$areawant_str_tmp) ,'id');
    $str_aera_tmp = array();
    foreach ($v['areawant_ary'] as $index => $item) {
        $str_aera_tmp[] = $upstlist[$distlist[$item]['upid']]['name'] . ' ' .$distlist[$item]['name'];
    }
    $v['areawant_str'] = implode(', ', $str_aera_tmp);
}
if(!$is_mine){
    /*if($_G['cache']['plugin']['xigua_hs']){
        if(!DB::fetch_first('select * from %t where uid=%d and display=1', array('xigua_hs_shanghu', $_G['uid']))){
            dheader("Location: $SCRITPTNAME?id=xigua_hs&ac=enter$urlext");
        }
    }*/
    $taocan = $tcobj->fetch_by_uid($_G['uid']);
    if(!$taocan){
        dheader("Location: $SCRITPTNAME?id=xigua_job&ac=taocan$urlext");
    }
}