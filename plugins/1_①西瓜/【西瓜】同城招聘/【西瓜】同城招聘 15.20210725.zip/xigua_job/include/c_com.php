<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['do']=='driving'){
    include_once DISCUZ_ROOT.'source/plugin/xigua_hs/function.php';
    $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
    if($shid && $shdata){
        $to = $shdata['lat'].','.$shdata['lng'];
    }else{
        $to = $_GET['to'];
        list($tolat, $tolng) = explode(',', $to);
        $shdata['lat'] = $tolat;
        $shdata['lng'] = $tolng;
    }
    $ret = hb_curl_get('http://apis.map.qq.com/ws/direction/v1/driving/?mode=driving&key='.$hs_config['skey'].'&from='.$_GET['from'].'&to='.$to);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $_rs = $ret['result']['routes'][0];
        if($_rs['distance']>0){
            $rs = lang_hs('junin', 0).hs_trans2m($_rs['distance']).' '.lang_hs('yue', 0).hs_minute2str($_rs['duration']);
            hb_message($rs, 'success');
        }
    }else{
        list($lat, $lng) = explode(',', $_GET['from']);
        $m = C::t('#xigua_hs#xigua_hs_shanghu')->get_distance($shdata['lat'], $shdata['lng'], $lat, $lng);
        if($m>0){
            $rs = lang_hs('junin', 0).hs_trans2m($m);
            hb_message($rs, 'success');
        }
        hb_message(diconv($ret['message'], 'utf-8', CHARSET), 'success');
    }
}elseif($_GET['do']=='distli'){
    $rlist = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($_GET['ctid']);
    include template('xigua_hb:header_ajax');
    include template('xigua_job:dstli');
    include template('xigua_hb:footer_ajax');
    exit;
}