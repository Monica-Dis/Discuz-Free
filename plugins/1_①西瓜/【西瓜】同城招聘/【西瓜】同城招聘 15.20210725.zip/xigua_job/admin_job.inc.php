<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
$job_config = $_G['cache']['plugin']['xigua_job'];
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/common_status.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_job/function.php';
$hyobj = C::t('#xigua_job#xigua_job_hangye');
$rsobj = C::t('#xigua_job#xigua_job_resume');
$jobobj = C::t('#xigua_job#xigua_job_job');
$tcobj = C::t('#xigua_job#xigua_job_taocan');

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$pzfield = array();

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" />";
if($secid = intval($_GET['secid'])){
    $res = $jobobj->fetch_by_id($secid);
    $unsetary =array('allnum' ,'jobid', 'hy', 'hangye_id1', 'shname', 'street', 'street_number','type_u','is_dig','dig_endts_u',
        'upts_u','crts_u','gender_u','fuli_ary','hy_ary','endts_u');
    $ts_ary = array('crts', 'upts', 'dig_crts','dig_endts', 'endts');
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $neww = 1;
            $res = array (  'uid' => '0', 'stid' => '0', 'name' => '', 'type' => 'full', 'jingyan' => '', 'xueli' => '', 'realname' => '', 'mobile' => '', 'gender' => '-1', 'openmobile' => '1', 'hy' => '', 'hangye_id1' => '0', 'hangye_id2' => '0', 'xinzi' => '', 'xinziunit' => '', 'shiduan' => '', 'opentime' => '9:00-18:00', 'jiesuan' => '0', 'neednum' => '0', 'minage' => '18', 'maxage' => '55', 'fuli' => '', 'miaoshu' => '', 'album' => array ( ), 'shid' => '0', 'shname' => '', 'addr' => '', 'province' => '', 'city' => '', 'district' => '', 'street' => '', 'street_number' => '', 'lat' => '', 'lng' => '', 'endts' => TIMESTAMP+90*365, 'dig_crts' => '0', 'dig_endts' => '0', 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'status' => '2', 'views' => '0', 'shares' => '0', 'favs' => '0', 'tdnum' => '0');
        }

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&secid=$secid", 'enctype');
        showtableheader(); /*dism��taobao��com*/
        showtitle(lang_job('spgl',0) . ($secid>0?'-'. $res['name']." (ID: $secid)" :''). "&nbsp;&nbsp;<a class='abtn' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job'> ".lang_job('back',0)."</a>");

        $listinfo = $hyobj->list_all(1);
        $hyobj->init($listinfo);
        $cat_list = $hyobj->get_tree_array(0);
//        print_r($cat_list);
//        exit;

        if($res['type']=='full'){
            $unsetary = array_merge($unsetary, array('xinziunit', 'shiduan','opentime','jiesuan'));
        }

        foreach ($res as $index => $re) {
            if(in_array($index, $unsetary)){
                continue;
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, $ts_ary)){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('jingyan', 'xueli'))){
                if($index=='jingyan'){
                    $__tmp = $jingyan;
                    $cs = '<select name="editform[jingyan]">';
                }elseif($index=='xueli'){
                    $__tmp = $xueli;
                    $cs = '<select name="editform[xueli]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('type', 'gender','xinziunit', 'shiduan', 'jiesuan'))){
                if($index=='type'){
                    $__tmp = $job_types;
                    $cs = '<select name="editform[type]">';
                }elseif($index=='gender'){
                    $__tmp = $gender_ary;
                    $cs = '<select name="editform[gender]">';
                }elseif($index=='xinziunit'){
                    $__tmp = $yuanshi;
                    $cs = '<select name="editform[xinziunit]">';
                }elseif($index=='shiduan'){
                    $__tmp = $shiduan;
                    $cs = '<select name="editform[shiduan]">';
                }elseif($index=='jiesuan'){
                    $__tmp = $jiesuan;
                    $cs = '<select name="editform[jiesuan]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($job_status as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shid'))){
                $cs = '<select name="editform[shid]" onchange="showshname(this)">';
                $ck0 = '';
                $STY = 'style=\'display:none\'';
                if(!$re){
                    $ck0 = 'selected';
                    $STY = '';
                }
                $cs .= "<option $ck0 value='0'>0 ".lang_job('wsh',0)."</option>";
                foreach (DB::fetch_all('select shid,`name`,display,endts from %t WHERE display=1 ORDER BY shid asc', array(
                    'xigua_hs_shanghu',
                    TIMESTAMP
                ), 'shid') as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    if($c['endts']<TIMESTAMP){
                        $eet = '['.lang('plugin/xigua_hb', 'yiguoqi').']';
                    }else{
                        $eet = '';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['shid']} {$c['name']} $eet</option>";
                }
                $cs .= '</select>';

                $cs .= "<input $STY id='sh_name' name='editform[shname]' class='txt' value='".$res['shname']."' />";

                $tp = $cs;
            }elseif(in_array($index, array('thumb'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('showbm' ,'tuijian','showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk','openmobile'))){
                $tp = 'radio';
            }elseif(in_array($index, array('hangye_id2'))){
                $hangye = "<select name=\"editform[hangye_id2]\">";
                foreach ($cat_list as $k => $v) {
                    $hangye .= "<optgroup label='$v[name]'>";
                    foreach ($v['sub'] as $kk => $vv) {
                        $s = '';
                        if($res['hangye_id2']== $vv['id']){
                            $s = 'selected';
                        }
                        $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;--$vv[name]</option>";
                    }
                    $hangye .= '</optgroup>';
                }
                $hangye .= '</select>';
                $tp = $hangye;
            }

            if(in_array($index, array('fengmian'))){
                $tp = 'filetext';
            }
            if (in_array($index, array('album'))) {
                $re = !is_array($re) ? unserialize($re) : $re;
                $tp = 'filetext';
                $job_config = $_G['cache']['plugin']['xigua_job'];
                $loopnum = $job_config['maximg'];
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_job($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'customtxt'){
                $tp = 'textarea';
                $cmt = lang_job('customtxttip',0);
                showsetting(lang_job($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }elseif($index == 'miaoshu'){
                $_tmp1 = lang_job($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[miaoshu]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_job($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dism-Taobao-com*/
        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach ($ts_ary as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        $editform['miaoshu'] = ($editform['miaoshu']);

        foreach (array('album') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }

        if($editform['shid']){
            $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
            if(!$sh){
                cpmsg(lang_job('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&secid=$secid", 'error');
            }
            $editform['shname']     = $sh['name'];
            $editform['shid']       = $sh['shid'];
        }elseif($editform['shname']){
            $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($editform['shname']);
            if($sh){
                $editform['shname']     = $sh['name'];
                $editform['shid']       = $sh['shid'];
            }else{
                $editform['shname'] = $editform['shname'];
            }
        }

        $hy_ret = $hyobj->get_pid_by_childs(array($editform['hangye_id2']));
        $hy_str = $hyobj->fetch_light($hy_ret);
        $editform['hangye_id1'] = $hy_ret['pid'];
        $editform['hangye_id2'] = $hy_ret['id'];
        $editform['hy'] = $hy_str[$hy_ret['pid']]['name']. ' ' .$hy_str[$hy_ret['id']]['name'];


        if($secid>0){
            $rs = $jobobj->update($secid, $editform);
            $hid = $secid;
        }else{
            $hid = $jobobj->insert($editform, 1);
        }

        cpmsg(lang_job('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&secid=$hid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            $jobobj->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            $jobobj->update($id, array( 'status' => $item['status']));
        }

        cpmsg(lang_job('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey(addslashes($keyword))) {
        $wherearr[] = " (name LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR fuli LIKE '%$keyword%' OR miaoshu LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }

    $ob = 'jobid desc';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_job('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($job_status as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job".' class="btn" >'.cplang('reset').'</a> ';
echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}
.jobtit{font-size:13px;color:#369}
.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;font-size:12px;border-radius:2px}
.jthumb{width:70px;height:40px}
.red{color:#ff6565}
.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}
</style>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&secid=-1\" class=\"btn bg_green\">".lang_job('tjsp',0)."</a></div>";

    showtableheader(lang_job('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_job('del', 0),
        lang_job('thumb', 0),
        lang_job('title', 0),
        lang_job('zwxq', 0),
        lang_job('spzt', 0),
        lang_job('author', 0),
        lang_job('caozuo', 0),
    ));
    $res = $jobobj->fetch_all_by_page($start_limit, $lpp, $wherearr, 0, '*', $ob);
    $icount = $jobobj->fetch_count_by_page($wherearr);

    $shids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $shids[$v['shid']] = $v['shid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }

    $xinzi = lang_job('xinzi', 0);
    $jiesuan = lang_job('jiesuan', 0);
    $opentime = lang_job('opentime', 0);
    $neednum = lang_job('neednum', 0);
    $age = lang_job('age', 0).lang_job('gender', 0);
    $_xueli = lang_job('xueli', 0);
    $_jy = lang_job('jingyan', 0);
    $_fuli = lang_job('fuli', 0);
    $_addr = lang_job('addr', 0);
    $_views = lang_job('views', 0);
    $_tdnum = lang_job('tdnum', 0);

    foreach ($res as $v) {
        $id = $v['jobid'];
        $shid = $v['shid'];
        $thumb = $v['fengmian'] ? $v['fengmian'] : ($v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0]);


        $appeend = '';
        foreach ($v['append_img_ary'] as $__k => $__v) {
            $appeend .= "<p><img style='width:180px;display:block' src=\"{$__v}\" /></p>";
            $appeend .= "<p>" . nl2br($v['append_text_ary'][$__k]) . "</p>";
        }

        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($job_status as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        if($shinfos[$v['shid']]['name']){
            $shlink = "<a target='_blank' href='".ADMINSCRIPT."?action=plugins&operation=config&do=&identifier=xigua_hs&pmod=admin_shanghu&shid=".$v['shid']."'>".$shinfos[$v['shid']]['name'].'</a>';
        }else{
            $shlink = $v['shname'];
        }
        $zwxq = <<<HTML
<div class="zlist"><ul class="ul1">
    <li><em>$xinzi:</em> {$v['xinzi']} {$yuanshi[$v['xinziunit']]} </li>
    <li><em>$jiesuan:</em> {$v['jiesuan']}</li>
    <li><em>$opentime:</em> {$v['opentime']} {$shiduan[$v['shiduan']]}</li>
    <li><em>$neednum:</em> {$v['neednum']} </li></ul><ul class="ul2">
    <li><em>$age:</em> {$v['minage']}-{$v['maxage']} {$gender_ary[$v['gender']]}</li>
    <li><em>$_xueli:</em> {$v['xueli']} </li>
    <li><em>$_jy:</em> {$v['jingyan']} </li>
    <li><em>$_addr:</em> {$v['city']}{$v['district']}{$v['addr']} </li>
</ul></div>
HTML;

        $digstr = $v['is_dig'] ? '<span class="dig">'.lang_job('dig',0).'</span>' : '';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<img src='$thumb' class='jthumb' />",
"<p class='jobtit'>$digstr <span class='jbtn'>{$v['type_u']}</span> {$v['name']} </p>
<p class='red'>{$v['hy']}</p>
<p>$shlink</p>",
            $zwxq,
            "<p>$status_u</p>".
            "<p style='margin-top:5px'>$_views: <em class='c_green'>$v[views]</em></p>".
            "<p>$_tdnum: <em class='c_green'>$v[tdnum]</em></p>".
            '',

            $users[$v['uid']]['username'].'<em>(uid:'.$v['uid'].')</em><br> '.
            $v['realname'].' '.$v['mobile'].'<br>'.
        lang_job('crts',0).': '.$v['crts_u'].'<br>'.
        lang_job('upts',0).': '.$v['upts_u'].'<br>'.
        ($v['dig_endts_u'] ? '<p class=\'red\'>'.lang_job('dig_endts',0).': '.$v['dig_endts_u'].'</p>':'').
        '',

            '<a class=\'btn bg_green\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&secid=$id" . '">' . lang_job('edit', 0) . '</a> '.
            '',
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_job&pmod=admin_job&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism-Taobao-com*/
    showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
}
if($secid){
    echo <<<HTML
<script>
function showshname(obj) {
    if(obj.value==0){
        $('sh_name').style.display='block';
    }else{
        $('sh_name').style.display='none';
    }
}
</script>
HTML;
}