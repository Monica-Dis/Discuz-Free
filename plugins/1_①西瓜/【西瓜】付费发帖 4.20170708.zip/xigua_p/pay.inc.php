<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2016/4/25
 * Time: 17:57
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_p/common.php';

if(!$_G['uid']){
    $loginurl = $_G['siteurl'].'member.php?mod=logging&action=login&mobile=2';
    if(WECHAT_P){
        if($_G['cache']['plugin']['xigua_login']){
            $loginurl = $_G['siteurl'].'plugin.php?id=xigua_login:login&backreferer='.urlencode(p_current_url());
        }
    }
    dheader('Location: '.$loginurl);
}

$pid = intval($_GET['pid']);
$tid = intval($_GET['tid']);
$fid = intval($_GET['fid']);
loadcache(array('forums'));

if($_GET['action'] == 'newthread'){
    $price = $GLOBALS['prilist'][$fid];
}else{
    $price = $GLOBALS['edit_prilist'][$fid];
}

$yuan = lang_p('yuan', 0);

$thread = DB::fetch_first("SELECT fid,subject FROM " . DB::table('forum_thread') . " WHERE tid='$tid' and authorid=".intval($_G['uid']));
if(!$thread){
    showmessage('error!');
}

$subject = lang_p($_GET['action'], 0).'-'. $thread['subject'];
$subject = str_replace(array(' ', "\t", "\n", "\r"), '', $subject);

if(!submitcheck('formhash')){
    $wxpay = $config['appid'] && $config['appsecert'] && $config['key'];
    if(WECHAT_P && $wxpay){
        $openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
        if(! $openid){
            $tools = new JsApiPay_P();
            $opendata = $tools->GetFollowOpenid(p_current_url().'&oauth=yes');
            if($openid = $opendata['openid']){
                dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 7200);
            }else{
                var_dump($opendata);
                exit;
                $url = str_replace('oauth=yes', '', p_current_url());
                dheader('Location:'.$url);
            }
        }
    }

    $autolink = $_G['siteurl'].'plugin.php?id=xigua_p&ac=order';
    if($config['autolink']){
        $autolink = $config['autolink'];
    }

    if(stripos($_SERVER['HTTP_USER_AGENT'], 'magapp') !== false){
        $digdesc = strip_tags($digdesc);

        $call_back = $_G['siteurl'] . 'source/plugin/xigua_p/notify_ma.php';
        $ma_server = rtrim($config['magapp_url'], '/');
        $secret    = $config['magapp_secret'];

        $order_id = C::t('#xigua_p#xigua_p_order')->init_order($price, $_G['uid'], $tid, $pid, $fid, $subject, 'App', $_GET['qforder_id']);
        $ura = array(
            'trade_no' => $order_id,
            'callback' => $call_back,
            'amount'   => $price,
            'title'   => $subject,
            'user_id' => $_G['uid'],
            'to_user_id' => 0,
            'des' => $subject,
            'remark' => '',
            'secret' => $secret,
        );
        $mg = "$ma_server/core/pay/pay/unifiedOrder?".http_build_query($ura);
        if($oret = json_decode(dfsockopen($mg), true)){
            if($unionOrderNum = $oret['data']['unionOrderNum']){
                C::t('#xigua_p#xigua_p_order')->update($order_id, array( 'qforder_id' => $unionOrderNum));
            }
            include template('xigua_p:ma');
            exit;
        }
    }

    include template('xigua_p:pay');
}else {

    if( $_GET['qforder_id']){
        $order_id = C::t('#xigua_p#xigua_p_order')->init_order($price, $_G['uid'], $tid, $pid, $fid, $subject, 'APP', $_GET['qforder_id']);
    }else{
        $order_id = C::t('#xigua_p#xigua_p_order')->init_order($price, $_G['uid'], $tid, $pid, $fid, $subject);
    }

    if( $_GET['payqf']){
        echo $order_id;
        exit;
    }

    $subject = $body = diconv(cutstr(strip_tags($subject), 40), CHARSET, 'UTF-8');

    if ($_GET['checkbox1'] == 'wxpay') {
        $tools = new JsApiPay_P();

        $notify = new NativePay_P();
        $input = new WxPayUnifiedOrder_P();
        $input->SetBody($body);
        $input->SetAttach($body);
        $input->SetOut_trade_no($order_id);
        $input->SetTotal_fee($price*100);
        $input->SetTime_start(date("YmdHis"));
//    $input->SetTime_expire(date("YmdHis", time() + 3600));
        $input->SetGoods_tag($body);
        $input->SetNotify_url($_G['siteurl'] . 'source/plugin/xigua_p/notify_wx.php');
        $input->SetTrade_type(WECHAT_P ? "JSAPI" : "NATIVE");

        if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false) {

            $input->SetTrade_type("APP");
            $postObj = WxPayApi_P::unifiedOrder($input);
            $noncestr = WxPayApi_P::getNonceStr();

            $timestamp = $_G['timestamp'];
            $apppay = array();
            $apppay['appid'] = P_APPID;
            $apppay['partnerid'] = P_MCHID;
            $apppay['prepayid'] = $postObj['prepay_id'];
            $apppay['noncestr'] = $noncestr;
            $apppay['timestamp'] = $timestamp;
            $apppay['package'] = "Sign=WXPay";
            $apppay['sign'] = get_sign_p($apppay);
            echo json_encode($apppay);
            exit;
        }

        if (WECHAT_P) {

            $openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
            $input->SetOpenid($openid);
            $order = WxPayApi_P::unifiedOrder($input);
            try {
                $jsApiParameters = $tools->GetJsApiParameters($order);
            } catch (Exception $e) {
                $jsApiParameters = json_encode(array('error' => diconv($e->getMessage(), 'utf-8')));
            }
            echo $jsApiParameters;
            exit;
        } else {
            $input->SetProduct_id($order_id);
            $result = $notify->GetPayUrl($input);
            $url2 = $result["code_url"];

            if (!$url2) {
                $data['qrurl'] =  diconv($result['return_msg'], 'utf-8');
            } else {
                $src = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text=' . urlencode($url2);
                $data['qrurl'] = "<img src='$src' />";
            }
            if(checkmobile()){
                echo json_encode($data);
            }else{
                $qrcodeurl = $src;
                include_once template('xigua_p:payitem');
            }
            exit;
        }
    } else {

        require_once DISCUZ_ROOT . './api/trade/api_alipay.php';
        $notify_url = $_G['siteurl'] . 'source/plugin/xigua_p/notify_ali.php';        //�������첽֪ͨҳ��·��

        if (checkmobile()) {

            $alipay_config['partner'] = DISCUZ_PARTNER;
            $alipay_config['key'] = DISCUZ_SECURITYCODE;
            $alipay_config['sign_type'] = strtoupper('MD5');;
            $alipay_config['input_charset'] = strtolower('utf-8');
            $alipay_config['cacert'] = DISCUZ_ROOT . 'source/plugin/xigua_p/lib/alipay_m/cacert.pem';
            $alipay_config['transport'] = 'http';
            $seller_email = $_G['setting']['ec_account'];
            $format = "xml";  //���ظ�ʽ
            $v = "2.0";   //���ظ�ʽ
            $req_id = date('Ymdhis'); //�����
            $call_back_url = $notify_url; //ҳ����תͬ��֪ͨҳ��·��
            unset($_GET['formhash']);
            $merchant_url = $notify_url . '?back=' . urlencode(p_current_url());          //�����жϷ��ص�ַ

            //����ҵ�������ϸ
            $req_data = '<direct_trade_create_req><notify_url>' . $notify_url . '</notify_url><call_back_url>' . $call_back_url . '</call_back_url><seller_account_name>' . $seller_email . '</seller_account_name><out_trade_no>' . $order_id . '</out_trade_no><subject>' . $subject . '</subject><total_fee>' . ($price) . '</total_fee><merchant_url>' . $merchant_url . '</merchant_url></direct_trade_create_req>';

//����Ҫ����Ĳ������飬����Ķ�
            $para_token = array(
                "service" => "alipay.wap.trade.create.direct",
                "partner" => trim($alipay_config['partner']),
                "sec_id" => trim($alipay_config['sign_type']),
                "format" => $format,
                "v" => $v,
                "req_id" => $req_id,
                "req_data" => $req_data,
                "_input_charset" => trim(strtolower($alipay_config['input_charset']))
            );
            include_once DISCUZ_ROOT . 'source/plugin/xigua_p/lib/alipay_m/AlipaySubmit.php';
            //��������
            $alipaySubmit = new AlipaySubmit($alipay_config);
            $html_text = $alipaySubmit->buildRequestHttp($para_token);
            //URLDECODE���ص���Ϣ
            $html_text = urldecode($html_text);
            //����Զ��ģ���ύ�󷵻ص���Ϣ
            $para_html_text = $alipaySubmit->parseResponse($html_text);

            //��ȡrequest_token
            $request_token = $para_html_text['request_token'];

            //ҵ����ϸ
            $req_data = '<auth_and_execute_req><request_token>' . $request_token . '</request_token></auth_and_execute_req>';


            //����Ҫ����Ĳ������飬����Ķ�
            $parameter = array(
                "service" => "alipay.wap.auth.authAndExecute",
                "partner" => trim($alipay_config['partner']),
                "sec_id" => trim($alipay_config['sign_type']),
                "format" => $format,
                "v" => $v,
                "req_id" => $req_id,
                "req_data" => $req_data,
                "_input_charset" => trim(strtolower($alipay_config['input_charset']))
            );


            //��������
            $alipaySubmit = new AlipaySubmit($alipay_config);
            $html_text = $alipaySubmit->buildRequestForm($parameter, 'get', 'confirm');
            echo $html_text;

        } else {

            $args = array(
                'subject' => $body,
                'body' => $body,
                'service' => 'trade_create_by_buyer',
                'partner' => DISCUZ_PARTNER,
                'notify_url' => $notify_url,
                'return_url' => $notify_url,
                'show_url' => $_G['siteurl'],
                '_input_charset' => 'UTF-8',
                'out_trade_no' => $order_id,
                'price' => $price,
                'quantity' => 1,
                'seller_email' => $_G['setting']['ec_account'],
                'extend_param' => 'isv^dz11'
            );
            if (DISCUZ_DIRECTPAY) {
                $args['service'] = 'create_direct_pay_by_user';
                $args['payment_type'] = '1';
            } else {
                $args['logistics_type'] = 'EXPRESS';
                $args['logistics_fee'] = 0;
                $args['logistics_payment'] = 'SELLER_PAY';
                $args['payment_type'] = 1;
            }
            $link = trade_returnurl($args);
            dheader('location: ' . $link);
            exit;
        }
    }
}


function get_sign_p($Obj){
    $apikey = P_WXPAY_KEY;
    foreach ($Obj as $k => $v)
    {
        $Parameters[$k] = $v;
    }
    ksort($Parameters);
    $String = formatBizQueryParaMap_p($Parameters, false);
    $String = $String."&key=$apikey";
    $String = md5($String);
    $result_ = strtoupper($String);
    return $result_;
}
function formatBizQueryParaMap_p($paraMap, $urlencode)
{
    $buff = "";
    ksort($paraMap);
    foreach ($paraMap as $k => $v)
    {
        if($urlencode)
        {
            $v = urlencode($v);
        }
        $buff .= $k . "=" . $v . "&";
    }
    $reqPar = '';
    if (strlen($buff) > 0)
    {
        $reqPar = substr($buff, 0, strlen($buff)-1);
    }
    return $reqPar;
}