<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_p_order` (
 `order_id` char(24) NOT NULL,
 `uid` int(11) unsigned NOT NULL,
 `fromopenid` char(32) NOT NULL,
 `baseprice` decimal(10,2) unsigned NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `payupts` int(11) unsigned NOT NULL,
 `paystatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
 `tid` int(11) unsigned NOT NULL,
 `pid` int(11) unsigned NOT NULL,
 `subject` varchar(2000) NOT NULL,
 `paymethod` varchar(20) NOT NULL,
 `order_sn` varchar(80) NOT NULL,
 `fid` int(11) NOT NULL,
 `note` varchar(200) NOT NULL,
 `qforder_id` varchar(32) NOT NULL,
 PRIMARY KEY (`order_id`),
 KEY `paystatus` (`paystatus`,`payupts`),
 KEY `crts` (`crts`),
 KEY `qforder_id` (`qforder_id`)
) ENGINE=InnoDB;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_p/discuz_plugin_xigua_p.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_p/discuz_plugin_xigua_p_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_p/discuz_plugin_xigua_p_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_p/discuz_plugin_xigua_p_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_p/discuz_plugin_xigua_p_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_p/install.php');





if(is_file(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')){
    $pluginid = 'xigua_p';

    $Hooks = array(
        'newthread_extraInfo',
        'newthread_variables',
        'viewthread_variables'
    );

    $data = array();
    foreach($Hooks as $Hook) {
        $data[] = array(
            $Hook => array(
                'plugin' => $pluginid,
                'include' => 'api.class.php',
                'class' => $pluginid,
                'method' => $Hook,
                'order' => 999,
            )
        );
    }
    require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::updateAPIHook($data);
}