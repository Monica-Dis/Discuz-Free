<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * http://t.cn/Aiux14ti
 * Time: 15:09
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_p_order extends discuz_table
{
    CONST PAYWAIT = 0;
    CONST PAYSUCCESS = 1;
    CONST PAYFAUIL = 2;
    CONST WXPAY = 'WECAHT';
    CONST ALIPAY = 'ALIPAY';

    public function __construct()
    {
        $this->_table = 'xigua_p_order';
        $this->_pk = 'order_id';

        parent::__construct();
    }

    public function init_order($baseprice, $uid, $tid, $pid, $fid, $subject, $note = '', $qforder_id = 0)
    {
        $order = array(
            'order_id' => date('YmdHis') . mt_rand(1000000, 9999999),
            'uid' => $uid,
            'fromopenid' => '',
            'baseprice' => $baseprice,
            'payupts' => 0,
            'crts' => time(),
            'paystatus' => self::PAYWAIT,
            'tid' => $tid,
            'pid' => $pid,
            'subject' => $subject,
            'fid'  => $fid,
            'note' => $note,
            'qforder_id' => $qforder_id,
        );
        if ($this->insert($order)) {
            return $order['order_id'];
        }
        return 0;
    }

    public function fetch_by_order_id($order_id)
    {
        return $this->fetch($order_id);
    }

    public function fetch_by_qforder_id($order_id)
    {
        return DB::fetch_first("select * from %t WHERE qforder_id=%s limit 1", array($this->_table, $order_id));
    }

    public function finish_order_pay($order_id, $fromopenid, $order_sn, $paymethod = self::WXPAY)
    {
        return $this->update($order_id, array(
            'paystatus' => self::PAYSUCCESS,
            'fromopenid' => $fromopenid,
            'payupts' => time(),
            'paymethod' => $paymethod,
            'order_sn'  => $order_sn,
        ));
    }


    public function clear_order()
    {
        return DB::delete($this->_table, array('paystatus' => self::PAYWAIT));
    }

    public function delete_order($ids)
    {
        return DB::query('DELETE FROM %t WHERE order_id IN (%n)', array($this->_table, $ids));
    }


    public function fetch_all_bypage($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_count_bypage()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function check_paid($fromuid, $pid){
        return DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND pid=%d AND paystatus=%d LIMIT 1', array(
            $this->_table,
            $fromuid,
            $pid,
            self::PAYSUCCESS
        ));
    }



    public function fetch_all_paid_bypage($uid, $pid, $start_limit, $lpp)
    {
        if($pid){
            $p = " AND pid=$pid ";
        }else{
            $p = '';
        }
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE uid=$uid AND paystatus=".self::PAYSUCCESS." $p ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $v) {
            if($v['uid']){
                $uids[$v['uid']] = $v['uid'];
            }
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }

        foreach ($result as $index => $item) {
            $result[$index]['fromusername'] = $users[$item['uid']]['username'];
            $result[$index]['fromuseravatar'] = avatar($item['uid'], 'middle', true);
            $result[$index]['payupts'] = dgmdate($result[$index]['payupts'], 'Y-m-d H:i:s');
        }
        return $result;
    }

    public function fetch_count_paid_bypage($uid)
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table). " WHERE uid=$uid AND paystatus=".self::PAYSUCCESS);
        return $result;
    }

    public function fetch_by_tid($tid)
    {
        $result = DB::fetch_first('SELECT * FROM ' . DB::table($this->_table). " WHERE tid=$tid AND paystatus=".self::PAYSUCCESS.' ORDER BY crts DESC');
        return $result;
    }
    public function fetch_unpay_by_uid_inqf($uid)
    {
        $result = DB::fetch_all("SELECT qforder_id FROM %t  where uid=%d and qforder_id!='' and paystatus!=".self::PAYSUCCESS, array(
            $this->_table,
            $uid,
        ) );
        return $result;
    }


}