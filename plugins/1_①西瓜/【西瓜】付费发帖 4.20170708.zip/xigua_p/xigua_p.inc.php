<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2017/3/8
 * Time: 14:47
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT .'source/plugin/xigua_p/common.php';


function p_qf_nonce($length = 32){
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str ="";
    for ( $i = 0; $i < $length; $i++ )  {
        $str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);
    }
    return $str;
}
function p_qf_sign($params, $secret) {
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}


if(!$_G['uid']){
    $loginurl = $_G['siteurl'].'member.php?mod=logging&action=login&mobile=2';
    if(WECHAT_P){
        if($_G['cache']['plugin']['xigua_login']){
            $loginurl = $_G['siteurl'].'plugin.php?id=xigua_login:login&backreferer='.urlencode(p_current_url());
        }
    }
    dheader('Location: '.$loginurl);
}

$wxpay = $config['appid'] && $config['appsecert'] && $config['key'];

$showheader = 0;
if( WECHAT_P && strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'android') !== false  ){
    $showheader = 1;
}

$page = empty($_GET['page'])?1:intval($_GET['page']);
if($page<1) $page=1;
$perpage = 10;
$start = ($page-1)*$perpage;

if($_GET['ac'] == 'orderlist') {

    $listdata = C::t('#xigua_p#xigua_p_order')->fetch_all_paid_bypage($_G['uid'], 0, $start, $perpage);
    include template('xigua_p:my_order_item');

}else if($_GET['ac'] == 'check') {
    $order_id = $_GET['order_id'];
    $data = C::t('#xigua_p#xigua_p_order')->fetch($order_id);
    include_once template('common/header');
    if($data['paystatus']==table_xigua_p_order::PAYSUCCESS){
        echo 'done';
    }else{
        echo '1';
    }
    include_once template('common/footer');
}else if($_GET['ac'] == 'order'){
    $qfids = C::t('#xigua_p#xigua_p_order')->fetch_unpay_by_uid_inqf($_G['uid']);
    if($qfids){
        foreach ($qfids as $index => $qfid) {
            if($qforder_id = $qfid['qforder_id']){

                $nonce = p_qf_nonce();
                $secret = $config['secert'];

                $data = array(
                    'order_id' => $qforder_id,
                    'nonce' => $nonce,
                );

                $data['sign']  = p_qf_sign($data, $secret);
                $r = http_build_query($data);

                $url = str_replace('{hostname}', $config['hostname'], 'http://{hostname}.qianfanapi.com/api1_2/orders/query?').$r;
                $retfrom = dfsockopen($url);
                if(!$retfrom){
                    $retfrom = file_get_contents($url);
                }
                if($retqf = json_decode($retfrom, true)){
                    if($retqf['data'][$qforder_id]['result']==1 || $retqf['data'][$qforder_id]['result']==2){

                        $order     = C::t('#xigua_p#xigua_p_order')->fetch_by_qforder_id($qforder_id);
                        $order_id = $order['order_id'];

                        if( $order && $order['paystatus'] == table_xigua_p_order::PAYWAIT ) {

                            C::t('#xigua_p#xigua_p_order')->finish_order_pay($order_id, '', $qforder_id, '');

                            C::t('forum_thread')->update($order['tid'], array('displayorder'=>0));
                            C::t('forum_thread')->clear_cache($order['tid']);
                            C::t('forum_thread')->clear_cache($order['tid'], 'forumdisplay_');

                            notification_add($order['uid'],'system',lang('plugin/xigua_p', 'pay_succeed').$order['note'].$order['subject'],array(),1);
                        }

                    }
                }
            }
        }
    }

    if($qforder_id = $_GET['qforder_id']){

        $nonce = p_qf_nonce();
        $secret = $config['secert'];

        $data = array(
            'order_id' => $qforder_id,
            'nonce' => $nonce,
        );

        $data['sign']  = p_qf_sign($data, $secret);
        $r = http_build_query($data);

        $url = str_replace('{hostname}', $config['hostname'], 'http://{hostname}.qianfanapi.com/api1_2/orders/query?').$r;
        $retfrom = dfsockopen($url);
        if(!$retfrom){
            $retfrom = file_get_contents($url);
        }

        if($retqf = json_decode($retfrom, true)){
            if($retqf['data'][$qforder_id]['result']==1 || $retqf['data'][$qforder_id]['result']==2){

                $order     = C::t('#xigua_p#xigua_p_order')->fetch_by_qforder_id($qforder_id);
                $order_id = $order['order_id'];

                if( $order && $order['paystatus'] == table_xigua_p_order::PAYWAIT ) {

                    C::t('#xigua_p#xigua_p_order')->finish_order_pay($order_id, '', $qforder_id, 'APP');

                    C::t('forum_thread')->update($order['tid'], array('displayorder'=>0), true);

                    notification_add($order['uid'],'system',lang('plugin/xigua_p', 'pay_succeed').$order['note'].$order['subject'],array(),1);
                }

            }
        }
    }else if($unionOrderNum = $_GET['unionOrderNum']){
        $ma_server = rtrim($config['magapp_url'], '/');
        $secret    = $config['magapp_secret'];
        $retfrom = dfsockopen("$ma_server/core/pay/pay/orderStatusQuery?unionOrderNum=$unionOrderNum&secret=$secret");

        if($retma = json_decode($retfrom, true)){
            if($retma['paycode'] == 1){

                $qforder_id = $unionOrderNum;

                $order     = C::t('#xigua_p#xigua_p_order')->fetch_by_qforder_id($qforder_id);
                $order_id = $order['order_id'];

                if( $order && $order['paystatus'] == table_xigua_p_order::PAYWAIT ) {

                    C::t('#xigua_p#xigua_p_order')->finish_order_pay($order_id, '', $qforder_id, 'APP');

                    C::t('forum_thread')->update($order['tid'], array('displayorder'=>0), true);

                    notification_add($order['uid'],'system',lang('plugin/xigua_p', 'pay_succeed').$order['note'].$order['subject'],array(),1);
                }
            }
        }

    }

    if(!checkmobile()){
        dheader('Location: home.php?mod=spacecp&ac=plugin&id=xigua_p:myorder');
    }
    $ajax_url = "plugin.php?id=xigua_p&ac=orderlist&page=";
    $navtitle = lang('plugin/xigua_p', 'myorder_title');
    include template('xigua_p:my_order');
}else if($_GET['ac'] == 'threadlist'){

    $page = max(1, intval(getgpc('page')));
    $lpp   = 10;
    $start_limit = ($page - 1) * $lpp;

    if(!$_G['cache']['forums']){
        loadcache('forums');
    }
    require_once libfile('function/misc');
    require_once libfile('function/forum');


    $threads = $tids = array();
    $vfid = array_merge(array_keys($GLOBALS['edit_prilist']), array_keys($GLOBALS['prilist']));
    $listdata = DB::fetch_all("select * from %t where displayorder=-2 AND authorid=%d AND fid in(%n) ORDER  BY tid DESC ".DB::limit($start_limit, $lpp), array(
        'forum_thread',
        $_G['uid'],
        $vfid
    ));

    foreach ($listdata as $index => $thread) {
        $threads[$thread['tid']] = procthread($thread);
        $threads[$thread['tid']]['postlist'] = C::t('forum_post')->fetch_all_by_tid('tid:'.$thread['tid'], $thread['tid'], true, 'ASC', 0, 1, 1);
        $threads[$thread['tid']]['postlist'] = array_values($threads[$thread['tid']]['postlist'] );
        $threads[$thread['tid']]['pid']      = $thread['pid'] = $threads[$thread['tid']]['postlist'][0]['pid'];
        $threads[$thread['tid']]['image']    = read_by_tid_pid($thread['tid'], $threads[$thread['tid']]['postlist'][0]['message'], $thread['pid']);
        $has = C::t('#xigua_p#xigua_p_order')->fetch_by_tid($thread['tid']);
        $threads[$thread['tid']]['action']   = $has ? 'edit' : 'newthread';
    }


//    var_dump($threads);exit;
    include template('xigua_p:item');

}else{
    $navtitle = lang_p('daizhifuzhuti', 0);
    $navtitle1 = lang_p('fufei', 0);

    if(!checkmobile()){
        dheader('Location: home.php?mod=spacecp&ac=plugin&id=xigua_p:myorder');
    }
    $ajax_url = "plugin.php?id=xigua_p&ac=threadlist&fromajax=1&my=1&displayorder={$_GET['displayorder']}&page=";

    include template('xigua_p:index');
}