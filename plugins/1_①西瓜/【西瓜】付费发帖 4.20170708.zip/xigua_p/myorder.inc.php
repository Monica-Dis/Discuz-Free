<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/4/9
 * Time: 23:29
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(checkmobile()){
    dheader('Location: plugin.php?id=xigua_p&ac=order');
}

include_once DISCUZ_ROOT .'source/plugin/xigua_p/common.php';

function jsd_reajaxget($m)
{
    $link = $m[1];
    $ext = $m[2];
    if($_REQUEST['orderlog']==2){
        $link = str_replace('orderlog=1', 'orderlog=2', $link);
    }
    return '<a href="' . $link . '" onclick="ajaxget(\'' . $link . '\', \'gridtable\');return false;"' . $ext . '>';
}
if(submitcheck('orderlog', 1)){
    $page = max(1, intval(getgpc('page')));
    $lpp   = 10;
    $start_limit = ($page - 1) * $lpp;

    if($_GET['orderlog']==1){
        $listdata = C::t('#xigua_p#xigua_p_order')->fetch_all_paid_bypage($_G['uid'],0, $start_limit, $lpp);
        $icount = C::t('#xigua_p#xigua_p_order')->fetch_count_paid_bypage($_G['uid']);
    }else{

        if(!$_G['cache']['forums']){
            loadcache('forums');
        }
        require_once libfile('function/misc');
        require_once libfile('function/forum');
        $vfid = array_merge(array_keys($GLOBALS['edit_prilist']), array_keys($GLOBALS['prilist']));

        $listdata = DB::fetch_all("select * from %t where displayorder=-2 AND authorid=%d and fid in(%n) ORDER  BY tid DESC  ".DB::limit($start_limit, $lpp), array(
            'forum_thread',
            $_G['uid'],
            $vfid
        ));

        foreach ($listdata as $index => $thread) {
            $listdata[$index]['dateline'] = dgmdate($listdata[$index]['dateline'], 'u');
            $listdata[$index]['forumname'] = empty($_G['cache']['forums'][$thread['fid']]['name']) ? 'Forum' : $_G['cache']['forums'][$thread['fid']]['name'];
            $has = C::t('#xigua_p#xigua_p_order')->fetch_by_tid($thread['tid']);
            $listdata[$index]['action']   = $has ? 'edit' : 'newthread';
        }

        $icount = DB::result_first("select count(*) as num from %t where displayorder=-2 AND authorid=%d and fid in(%n) ", array(
            'forum_thread',
            $_G['uid'],
            $vfid
        ));
    }
    $realpages = @ceil($icount / $lpp);
    $_G['gp_ajaxtarget'] = '';
    $multi = multi($icount, $lpp, $page, 'home.php?mod=spacecp&ac=plugin&id=xigua_p:myorder&orderlog=1');
    $multi = preg_replace_callback("/<a\shref=\"([\s\S]*?)\"(.*?)>/is", "jsd_reajaxget", $multi);
    $multi = str_replace('\"', '"', $multi);

    include_once template('xigua_p:myorder_item');
}