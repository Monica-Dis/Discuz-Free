<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/1/27
 * Time: 21:56
 */


define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/xigua_p/', '',$_G['siteurl'] );

include_once DISCUZ_ROOT.'./source/plugin/xigua_p/notify_func.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_p/common.php';

$notifydata = xigua_pnotifycheck();
if($notifydata['validator']) {

    $order_id  = $notifydata['order_no'];
    $postprice = $notifydata['price'];
    $order     = C::t('#xigua_p#xigua_p_order')->fetch_by_order_id($order_id);

    if(
        $order &&
        $order['paystatus'] == table_xigua_p_order::PAYWAIT
    ) {

        C::t('#xigua_p#xigua_p_order')->finish_order_pay($order_id, $notifydata['fromopenid'], $notifydata['trade_no'], table_xigua_p_order::WXPAY);

        C::t('forum_thread')->update($order['tid'], array('displayorder'=>0));
        C::t('forum_thread')->clear_cache($order['tid']);
        C::t('forum_thread')->clear_cache($order['tid'], 'forumdisplay_');

        notification_add($order['uid'],'system',lang('plugin/xigua_p', 'pay_succeed').$order['note'].$order['subject'],array(),1);
    }

}
function xigua_pnotifycheck() {
    $_G = $GLOBALS['_G'];

    $msg = '';

    $notify = WxPayApi_P::notify($msg);

    if(empty($notify)){
        $return = array(
            'return_code'=>'FAIL',
            'return_msg'=>$msg,
        );
        WxPayApi_P::replyNotify(xigua_p_arr2xml($return));
        exit;
    }

    //checksign
    $sign = $notify['sign'];
    unset($notify['sign']);

    ksort($notify);
    $paramstring = ToUrlParams($notify);

    if(!$_G['cache']['plugin']){
        loadcache('plugin');
    }
    $config = $_G['cache']['plugin']['xigua_p'];

    if(strtoupper(md5($paramstring . "&key=".$config['appkey'])) != $sign){
        if(strtoupper(md5($paramstring . "&key=".$config['key'])) != $sign) {
            $return = array(
                'return_code' => 'FAIL',
                'return_msg' => 'sign error!',
            );
            WxPayApi_P::replyNotify(xigua_p_arr2xml($return));
            exit;
        }
    }
    if($notify['result_code'] == 'SUCCESS') {
        return array(
            'validator'  => isset($notify['result_code']) && $notify['result_code'] == 'SUCCESS' ? 1 : 0,
            'order_no'   => $notify['out_trade_no'],
            'trade_no'   => isset($notify['transaction_id']) ? $notify['transaction_id'] : '',
            'price'      => $notify['total_fee'],
            'appid'      => $notify['appid'],
            'notify'     => xigua_p_arr2xml(array('return_code'=>'SUCCESS')),
            'location'   => false,
            'fromopenid' => $notify['openid'],
        );
    }
}


function xigua_p_arr2xml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val)
    {
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}

function ToUrlParams($urlObj)
{
    $buff = "";
    foreach ($urlObj as $k => $v)
    {
        $buff .= $k . "=" . $v . "&";
    }

    $buff = trim($buff, "&");
    return $buff;
}