<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2016/4/27
 * Time: 11:25
 */
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/xigua_p/', '',$_G['siteurl'] );

if($_GET['back']){
    dheader('location: '.$_GET['back']);
}
require_once DISCUZ_ROOT.'./api/trade/api_alipay.php';

include_once DISCUZ_ROOT.'./source/plugin/xigua_p/notify_func.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_p/common.php';

$notifydata = xigua_pnotifycheck();

if($notifydata['validator']) {

    $order_id = $notifydata['order_no'];
    $postprice = intval($notifydata['price']*100);

    $order     = C::t('#xigua_p#xigua_p_order')->fetch_by_order_id($order_id);

    if(!$postprice){
        $postprice = $order['baseprice'];
    }
    if($order) {
        C::t('forum_thread')->update($order['tid'], array('displayorder'=>0));
        C::t('forum_thread')->clear_cache($order['tid']);
        C::t('forum_thread')->clear_cache($order['tid'], 'forumdisplay_');
        C::t('#xigua_p#xigua_p_order')->finish_order_pay($order_id, '', $notifydata['trade_no'], table_xigua_p_order::ALIPAY);

        notification_add($order['uid'],'system',lang('plugin/xigua_p', 'pay_succeed').$order['note'].$order['subject'],array(),1);

        $tid = $order['tid'];
        dheader('location: '.($config['autolink'] ?$config['autolink']: $_G['siteurl']."plugin.php?id=xigua_p&ac=order"));
    }

}

if($notifydata['location']) {
    $order_id = $notifydata['order_no'];
    $order     = C::t('#xigua_p#xigua_p_order')->fetch_by_order_id($order_id);
    $tid = $order['tid'];

    if($_GET['back']){
        dheader('location: '.$_GET['back']);
    }else{
        dheader('location: '.($config['autolink'] ?$config['autolink']: $_G['siteurl']."plugin.php?id=xigua_p&ac=order"));
    }
} else {
    exit($notifydata['notify']);
}


function xigua_pnotifycheck() {
    if(!empty($_POST)) {
        $notify = $_POST;
        $location = FALSE;
    } elseif(!empty($_GET)) {
        $notify = $_GET;
        $location = TRUE;
    } else {
        exit('fail');
    }
    unset($notify['diy']);

    if(!$_REQUEST['notify_id']&& $_REQUEST['notify_data']) {
        $notify = xigua_pFromXml($_REQUEST['notify_data']);
    }

    $url = "http://notify.alipay.com/trade/notify_query.do?partner=".DISCUZ_PARTNER."&notify_id=".$notify['notify_id'];
    $retcheck = file_get_contents($url);
    if(!$retcheck && function_exists('dfsockopen')){
        $retcheck = dfsockopen($url);
    }
    if($notify['notify_id'] && $retcheck !== 'true') {
        exit('fail');
    }

    if($notify['notify_id'] && $_REQUEST['notify_data']){
        return array(
            'validator'  => TRUE,
            'status'     => trade_getstatus(!empty($notify['refund_status']) ? $notify['refund_status'] : $notify['trade_status'], 1),
            'order_no'   => $notify['out_trade_no'],
            'price'      => $notify['price'] ? $notify['price'] : $notify['total_fee'],
            'trade_no'   => $notify['trade_no'],
            'notify'     => 'success',
            'location'   => $location
        );
    }

    if(!DISCUZ_SECURITYCODE) {
        exit('fail');
    }
    ksort($notify);
    $sign = '';
    foreach($notify as $key => $val) {
        if($key != 'sign' && $key != 'sign_type') $sign .= "&$key=$val";
    }
    if($notify['sign'] != md5(substr($sign,1).DISCUZ_SECURITYCODE)) {
        exit('fail');
    }

    return array(
        'validator'  => TRUE,
        'status'     => trade_getstatus(!empty($notify['refund_status']) ? $notify['refund_status'] : $notify['trade_status'], 1),
        'order_no'   => $notify['out_trade_no'],
        'price'      => $notify['price'] ? $notify['price'] : $notify['total_fee'],
        'trade_no'   => $notify['trade_no'],
        'notify'     => 'success',
        'location'   => $location
    );
}

function xigua_pFromXml($xml)
{
    return json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
}