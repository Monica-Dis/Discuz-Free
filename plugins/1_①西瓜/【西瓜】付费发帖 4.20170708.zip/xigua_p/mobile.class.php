<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 * Time: 13:58
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_xigua_p
{
    public function post_message($value)
    {
        global $_G;
        $param = $value['param'];
        $tid = $param[2]['tid'];
        $pid = $param[2]['pid'];
        $fid = $_G['fid'] = $param[2]['fid'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }

        $GLOBALS['not_include'] = 1;
        include_once DISCUZ_ROOT.'source/plugin/xigua_p/common.php';
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_p'];
        if(  in_array($_G['groupid'], (array)unserialize($config['groups']) ))  {
            return '';
        }



        if (strtolower($_SERVER['REQUEST_METHOD']) == 'post' && $tid && $pid ) {
            $newthread = ($param[0]=='post_newthread_succeed' || $param[0]=='post_newthread_mod_succeed');
            $edit      = ($param[0]=='post_edit_succeed'|| $param[0]=='edit_newthread_mod_succeed');
            $post = C::t('forum_post')->fetch_all_by_pid('pid:'.$pid, array($pid));
            $first = $post[$pid]['first'];

            if( ! ($first && ($newthread || $edit)) ){
                return '';
            }

            $get = array();
            $get['tid'] = $tid;
            $get['pid'] = $pid;
            $get['fid'] = $fid;

            $has = C::t('#xigua_p#xigua_p_order')->fetch_by_tid($tid);
            if($has){
                $price = $GLOBALS['edit_prilist'][$_G['fid']];
                $get['action'] = 'edit';
            }else{
                $price = $GLOBALS['prilist'][$_G['fid']];
                $get['action'] = 'newthread';
            }
            if( $price <=0){
                return '';
            }

            $jump = "plugin.php?id=xigua_p:pay&".http_build_query($get);

            C::t('forum_thread')->update($tid, array('displayorder'=>-2), true);
            if($first){
                updatemoderate('tid', $tid);
                manage_addnotify('verifythread');
            }

            if($_GET['inajax']){
                showmessage(lang('plugin/xigua_p', 'publish_succeed'), $jump);
            }else if($GLOBALS['inapi']){
                return $jump;
            }else{
                showmessage(lang('plugin/xigua_p', 'publish_succeed'), $jump);
//                dheader("Location: $jump");
//                exit;
            }
        }
    }
}

class plugin_xigua_p_forum extends plugin_xigua_p
{


    public static function post_bottom_mobile()
    {
        global $_G;
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }
        $GLOBALS['not_include'] = 1;
        include_once DISCUZ_ROOT.'source/plugin/xigua_p/common.php';
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_p'];
        if(  in_array($_G['groupid'], (array)unserialize($config['groups']) ))  {
            return '';
        }

        $has = 0;
        if($tid = intval($_GET['tid'])){
            $has = C::t('#xigua_p#xigua_p_order')->fetch_by_tid($tid);
        }

        if($has){
            $price = $GLOBALS['edit_prilist'][$_G['fid']];
            $_action = 'edit';
        }else{
            $price = $GLOBALS['prilist'][$_G['fid']];
            $first = 1;
            $_action = 'newthread';
        }

        if($pid = intval($_GET['pid'])){
            $post = C::t('forum_post')->fetch_all_by_pid('pid:'.$pid, array($pid));
            $first = $post[$pid]['first'];
        }

        if($price <=0 || !$first){
            return '';
        }
        $pc = '';
        if(!checkmobile()){
            $pc = 'border: #ccc solid 1px; background: #FFFFD7;';
        }
        $html = '<div style="margin:8px 0; padding: 10px; line-height: 28px; '.$pc.'">'.lang_p($_action.'_', 0).'<span style="color:#f60;font-size:22px;font-weight:500��">'.$price.lang_p('yuan', 0).'</span><br><span style="color:#888;font-size:12px;">'.lang_p('order_tip', 0).'</span>';
        return $html;
    }

    public function post_attribute_extra_body_output()
    {
        return $this->post_bottom_mobile();
    }
}

class mobileplugin_xigua_p extends plugin_xigua_p_forum
{

}
class mobileplugin_xigua_p_forum extends plugin_xigua_p_forum
{

}

