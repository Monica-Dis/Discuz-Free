<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2017/4/10
 * Time: 14:40
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class xigua_p
{
    public function viewthread_variables(& $params)
    {
        global $_G;

        foreach ($params['postlist'] as $index => $item) {
            if($item['first']){
                $tid = $item['tid'];
                if($jump = $_G['cookie']['d_jump_'.$tid]){
                    $params['postlist'][ $index ]['message'] = "<script>location.href='$jump';</script >".$params['postlist'][ $index ]['message'];
                }
                dsetcookie('d_jump_'.$tid, '', 0);
                break;
            }
        }
        return true;
    }

    public function newthread_variables(&$variables)
    {
        global $_G;

        if(strtolower($_SERVER['REQUEST_METHOD']) != 'post'){
            return;
        }
        $tid =$variables['tid'];
        $pid = $variables['pid'];
        $fid = $variables['fid'] ? $variables['fid'] : $_GET['fid'];
        $value = array();
        $value['param'] = array(
            0 => 'post_newthread_succeed',
            2 => array(
                'tid' => $tid,
                'pid' => $pid,
                'fid' => $fid,
            )
        );

        include_once DISCUZ_ROOT.'source/plugin/xigua_p/mobile.class.php';
        $GLOBALS['inapi'] = 1;
        $jump = plugin_xigua_p_forum::post_message($value);
        if($jump){
            dsetcookie('d_jump_'.$tid, $jump, 999);
        }
    }

    public function newthread_extraInfo()
    {
        include_once DISCUZ_ROOT.'source/plugin/xigua_p/mobile.class.php';

        $html = "";
        $html.= plugin_xigua_p_forum::post_bottom_mobile();
        return $html;
    }

}