<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT .'source/plugin/xigua_p/common.php';
if(submitcheck('clear')){
    $r = C::t('#xigua_p#xigua_p_order')->clear_order();
    if($r){
        cpmsg(lang('plugin/xigua_p', 'clear_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_p&pmod=admincp_order&page=".$_GET['page'], 'succeed');
    }
}
if(submitcheck('permsubmit')){
    $r = C::t('#xigua_p#xigua_p_order')->delete_order($_GET['delete']);
    if($r){
        cpmsg(lang('plugin/xigua_p', 'delete_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_p&pmod=admincp_order&page=".$_GET['page'], 'succeed');
    }
}
showtips(lang_p('tip', 0));
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_p&pmod=admincp_order&page=".$_GET['page']);
showtableheader(lang('plugin/xigua_p','orderinfo'));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_p','del'),
    lang('plugin/xigua_p','orderid'),
    lang('plugin/xigua_p','note'),
    lang('plugin/xigua_p','orderprice'),
    lang('plugin/xigua_p','fuk'),
    lang('plugin/xigua_p','status'),
    lang('plugin/xigua_p', 'method'),
//    lang('plugin/xigua_p', 'ordersn'),
    lang('plugin/xigua_p','crts').'/'.lang('plugin/xigua_p','upts'),
));
$page = max(1, intval(getgpc('page')));
$lpp   = 15;
$start_limit = ($page - 1) * $lpp;
$res = C::t('#xigua_p#xigua_p_order')->fetch_all_bypage($start_limit, $lpp);
$icount = C::t('#xigua_p#xigua_p_order')->fetch_count_bypage();

foreach ($res as $v) {
    if($v['uid']){
        $uids[$v['uid']] = $v['uid'];
    }
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}


foreach ($res as $re) {

    $paymethod = '';
    $paymethods = array(
        table_xigua_p_order::ALIPAY => '<span style="color:#51b7ec">'.lang_p('alipay', 0).'</span>',
        table_xigua_p_order::WXPAY => '<span style="color:#1AAD19">'.lang_p('wxpay', 0).'</span>',
    );
    $paymethod = $paymethods[$re['paymethod']];

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='{$re['order_id']}' />",
        $re['order_id'].'<br>'.lang('plugin/xigua_p', 'ordersn').': '. ($re['order_sn']? $re['order_sn'] : '-'),

        lang('plugin/xigua_p','wenzhangming')."<a href='forum.php?mod=viewthread&tid={$re['tid']}' target='_blank'>{$re['subject']}</a><br>".str_replace(',', '<br>', $re['note']),
        $re['baseprice'],
        '<a target="_blank" href="home.php?mod=space&uid='.$re['uid'].'&do=profile" >'.($users[$re['uid']] ?$users[$re['uid']]['username']: $re['fromopenid']).'</a>',
        $re['paystatus'] ? '<strong style="color:forestgreen;">'.(lang('plugin/xigua_p','yi')) .'</strong>' : '<strong style="color:orangered;">'.(lang('plugin/xigua_p','wei')) .'</strong>',
        $paymethod,
        date('m-d H:i:s', $re['crts']).'<br>'.
        ($re['payupts'] ? date('m-d H:i:s', $re['payupts']) : '-'),
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_p&pmod=admincp_order&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '<input type="hidden" name="clear" id="clear" value="0" /><input type="button" class="btn" onclick="$(\'clear\').value=1;$(\'cpform\').submit();" value="'.(lang('plugin/xigua_p','qingli')) .'">',$multipage);
showtablefooter();/*dis'.'m.tao'.'bao.com*/
showformfooter();/*Dism_taobao_com*/