<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/xigua_p/common.php';

$fid = intval($_GET['fid']);
$tid = intval($_GET['tid']);
$type = intval($_GET['type']);



$resultpc = $result = '';
$resultpc .= lang_p('shichang',0);
$resultpc .= " <select id='d_default_priceid' name='d_default_priceid'>";

for($i=1; $i<=6; $i++){
    $key = 'price'.$i;
    if($row[$key]>0){
        $lang = str_replace('.00', '', $row[$key]).' '.lang_p('p'.$i, 0);
        $result .= "<div onclick='return d_price_list(this);' class=\"d_cell\" data-priceid=\"{$row['id']}\" data-field='{$key}' data-unit=\"".lang_p($key, 0)."\" data-price=\"{$row[$key]}\"><div class=\"d_cell__bd\">$lang</div></div>";
        $resultpc .= "<option value=\"{$row['id']}\" data-field='{$key}' data-unit=\"".lang_p($key, 0)."\" data-price=\"{$row[$key]}\">$lang</option>";
    }
}
if(checkmobile()){
    echo $result;
}else{
    $resultpc .= "</select>";
    include_once template('common/header');
    echo $resultpc;
    include_once template('common/footer');
}
//echo json_encode($result);
//print_r($row);
//print_r($langprice);
//print_r($data);
