<?php exit('xxxx');?>
<style><!--{if $config['maincolor']}-->
.pay-submit, .d_btn_primary,.d_button_m_on, .d_button_s, .bgcolor_11{background-color:$config[maincolor]!important;}
.d_price, .dai-price, .forumname,#thread_types li.xw1 a,#thread_types li.a a,.thread_types li.xw1 a,.thread_types li.a a{color:$config[maincolor]!important;}
.pay-submit,.choose-list li.pay-current{border-color:$config[maincolor]!important;}
<!--{/if}-->
</style>
