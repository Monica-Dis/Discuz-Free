<?php exit('xxx'); ?>
<!--{template common/header}-->
<!--{template xigua_p:color}-->
<link href="source/plugin/xigua_p/static/pcpay.css" rel="stylesheet"/>
<div class="wp">
    <form id="formc" action="plugin.php?id=xigua_p:pay" method="post">
        <!--{loop $_GET $k $v}-->
        <input type="hidden" name="$k" value="$v">
        <!--{/loop}-->
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="checkbox1" id="checkbox1" value="<!--{if $config[allowalipay]}-->alipay<!--{elseif $allowwxpay}-->wxpay<!--{/if}-->">
        <div class="title-notice">
            <span class="order-icon">$digname</span>
        </div>
        <div class="d_order">
            <ul>
                <li>
                    <div class="d_order-title">
                        {lang xigua_p:zhuti1}
                    </div>
                    <div class="d_order-content">
                        $subject
                    </div>
                </li>
                <li>
                    <div class="d_order-title">
                        {lang xigua_p:yingfu1}
                    </div>
                    <div class="d_order-content">
                        <span class="damount">$price $yuan</span>
                    </div>
                </li>
            </ul>
        </div>
        <div class="title-notice">
            <span class="choose-icon">{lang xigua_p:paymethod}</span>
        </div>
        <ul class="choose-list">
            <!--{if $config[allowalipay]}-->
            <li id="d_alipay" class="pay-current" onclick="chooseme('alipay');">
                <img src="source/plugin/xigua_p/static/pay2.png">
            </li>
            <!--{/if}-->
            <!--{if $allowwxpay}-->
            <li id="d_wxpay" class="<!--{if !$config[allowalipay]}-->pay-current<!--{/if}-->" onclick="chooseme('wxpay');">
                <img src="source/plugin/xigua_p/static/pay1.png">
            </li>
            <!--{/if}-->
        </ul>
        <div class="pay-amount">
            <a href="javascript:void(0);" onclick="return pay_d_submit();" class="pay-submit">{lang xigua_p:pay}</a>
            <span class="amount-title">{lang xigua_p:pay1} </span> <span class="damount">$price $yuan</span>
        </div>

    </form>
</div>
<script>
    function chooseme(type) {
        if (type == 'alipay') {
            $('d_alipay').className = 'pay-current';
            if($('d_wxpay')){
                $('d_wxpay').className = '';
            }
        } else {
            if($('d_alipay')){
                $('d_alipay').className = '';
            }
            $('d_wxpay').className = 'pay-current';
        }
        $('checkbox1').value = type;
    }
    function pay_d_submit() {
        var paytype = $('checkbox1').value;
        if (paytype == 'alipay') {
            $('formc').submit();
        } else if(paytype=='wxpay') {
            showWindow('wxpaybox', 'formc', 'post', 0);
        }
        return false;
    }
</script>

<!--{template common/footer}-->
