<?php echo 'From: DisM.taobao.com';exit;?>
<style>
    table.gridtable {
        color:#333333;
        border-width: 1px;
        border-color: #d9d9d9;
        border-collapse: collapse;
        width:100%;
        text-align:center;
        font-size:14px;
    }
    table.gridtable th {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #d9d9d9;
        background-color:#f2f2f5;
        text-align:center;
    }
    table.gridtable td {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #d9d9d9;
        background-color: #ffffff;
        min-width: 50px;
        font-size:14px;
        text-align:left;
    }.WB_cardtitle_b {
         position: relative;
         height: 38px;
         padding: 4px 10px;
         line-height: 38px;
         overflow: hidden;
        font-size:14px;
        padding-left:0;
     }
</style>
<div class="cl pcset">
    <ul class="tb cl">
        <li <!--{if !$_GET[show]}-->class="a"<!--{/if}-->><a href="home.php?mod=spacecp&ac=plugin&id=xigua_p:myorder">{lang xigua_p:myorder_title}</a></li>
        <li <!--{if $_GET[show]}-->class="a"<!--{/if}-->><a href="home.php?mod=spacecp&ac=plugin&id=xigua_p:myorder&show=thread">{lang xigua_p:daizhifuzhuti}</a></li>
    </ul>
    <div class="cl avatar-badge-list">
        <div class="E_inner_frame cl p10">
            <div>
                <div class="WB_cardwrap S_bg2">
                    <div class="WB_cardtitle_b S_line2">
                        <h4 class="xi2">
                            {lang xigua_p:order_tip}
                        </h4>
                    </div>
                    <div class="E_PCD_chart6">
                        <div class="WB_innerwrap">
                            <div>
                                <table class="gridtable">
                                    <tbody>
                                    <!--{if !$_GET[show]}-->
                                    <th>{lang xigua_p:orders1n1}</th>
                                    <th>{lang xigua_p:note}</th>
                                    <th>{lang xigua_p:method}</th>
                                    <th>{lang xigua_p:zhifushijian1}</th>
                                    <th>{lang xigua_p:jine1}</th>
                                    <!--{else}-->
                                    <th>{lang xigua_p:zhuti}</th>
                                    <th>{lang xigua_p:dateline}</th>
                                    <th>{lang xigua_p:caozuo}</th>
                                    <!--{/if}-->
                                    </tbody>
                                    <tbody id="gridtable">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="WB_cardpage S_line1">
                        <div class="W_pages"></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<script>
    ajaxget('home.php?mod=spacecp&ac=plugin&id=xigua_p:myorder&orderlog=<!--{if $_REQUEST[show]}-->2<!--{else}-->1<!--{/if}-->', 'gridtable');
</script>