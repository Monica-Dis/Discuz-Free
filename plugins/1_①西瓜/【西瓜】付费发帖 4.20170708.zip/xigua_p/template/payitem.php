<?php exit('hrh'); ?>
<!--{template common/header}-->
<!--{eval $handlekey = 'wxpaybox';}-->
<h3 class="flb">
    <em id="return_$handlekey">{lang xigua_p:wxpay1}</em>
    <span><a href="javascript:;" class="flbc" onclick="clearTimeout(d_checkST);hideWindow('$handlekey')" title="{lang close}">{lang close}</a></span>
</h3>
<div class="c" align='center' style="width:240px;height:250px">
    <img width="220" height="220" src="$qrcodeurl"/>
    <div style="text-align:center;color:#666;font-size:14px">{lang xigua_p:tiptip}</div>
</div>
<script>
    var d_checkST = null, d_checkCount = 0;
    function d_checkstart() {
        d_checkST = setTimeout(function () {
            d_check()
        }, 2000);
    }
    function d_check() {
        var x = new Ajax();
        x.get('plugin.php?id=xigua_p&ac=check&order_id={$order_id}&inajax=1', function (s, x) {
            s = trim(s);
            if (s != 'done') {
                if (s == '1') {
                    d_checkstart();
                }
                d_checkCount++;
                if (d_checkCount >= 100) {
                    clearTimeout(d_checkST);
                    hideWindow('$handlekey');
                }
            } else {
                clearTimeout(d_checkST);
                window.location.href = 'plugin.php?id=xigua_p&ac=order';
            }
        });
    }
    d_checkstart();
</script>
<!--{template common/footer}-->