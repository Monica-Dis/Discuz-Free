<?php echo 'From: DisM.taobao.com';exit;?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <link href="source/plugin/xigua_p/static/common.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_p/static/weui.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_p/static/iconfont.css?{VERHASH}" rel="stylesheet"/>
    <script src="source/plugin/xigua_p/static/jquery.min.js?{VERHASH}"></script>
    <script src="source/plugin/xigua_p/static/custom.js?{VERHASH}"></script>
    <!--{template xigua_p:color}-->
</head>
<body>
<!--{if $_GET[id]!='xigua_p:pay'}-->
<!--{if $showheader}-->
<header class="x_header bgcolor_11 cl">
    <div class="thr">
        <a class="y" href="javascript:window.history.go(-1);"><i class="iconfont icon-xiangzuojiantou"></i> </a>
    </div>
    <a class="y" href="forum.php?mobile=2"><i class="icon iconfont icon-shouye"></i></a> $navtitle
</header>
<!--{/if}-->
<ul id="thread_types" class="ttp  cl">
    <li class="<!--{if $_GET[ac]!='order'}-->xw1 a<!--{/if}-->"><a style="width:50%" href="plugin.php?id=xigua_p">{lang xigua_p:waitpay}</a></li>
    <li class="<!--{if $_GET[ac]=='order'}-->xw1 a<!--{/if}-->"><a style="width:50%" href="plugin.php?id=xigua_p&ac=order">{lang xigua_p:order}</a></li>
</ul>
<!--{/if}-->