<?php exit('xxxx');?>
<style><!--{if $config['maincolor']}-->
.d_btn_primary,.d_button_m_on, .d_button_s, .bgcolor_11,.weui-btn_primary{background-color:$config[maincolor]!important;}
.d_price, .forumname,#thread_types li.xw1 a,#thread_types li.a a,.thread_types li.xw1 a,.thread_types li.a a,.weui-cells_checkbox .weui-check:checked + .weui-icon-checked:before{color:$config[maincolor]!important;}
<!--{/if}-->
</style>
