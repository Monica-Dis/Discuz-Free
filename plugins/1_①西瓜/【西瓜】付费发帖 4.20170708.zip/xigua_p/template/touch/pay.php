<?php exit('hehehe!') ?>
<!--{template xigua_p:header}-->

<style>
    .weui-panel{margin-top:0}
    .weui-panel:before{display:none}
</style>

<div class="mod-app-container">
<form id="formc" action="" method="post">
    <!--{loop $_GET $k $v}-->
    <input type="hidden" name="$k" value="$v">
    <!--{/loop}-->
    <input type="hidden" name="formhash" value="{FORMHASH}">

    <div class="weui-panel weui-panel_access">

        <div class="weui-panel__bd">
            <div class="weui-media-box weui-media-box_text">
                <h4 class="weui-media-box__title">{lang xigua_p:zhuti}</h4>
                <p class="weui-media-box__desc">$subject</p>
                <p class="weui-media-box__desc">{lang xigua_p:daizhifu} <span class="amount">$price $yuan</span></p>
            </div>

        </div>

    </div>
    <div class="weui-cells__title">{lang xigua_p:paymethod}</div>

    <div class="weui-cells weui-cells_checkbox">
        <!--{if $allowwxpay}-->
        <label class="weui-cell weui-check__label" for="s11">
            <div class="weui-cell__hd">
                <input type="radio" class="weui-check" name="checkbox1" value="wxpay" id="s11" checked="checked"> <i class="weui-icon-checked"></i>
            </div>
            <div class="weui-cell__bd">
                <p><img src="source/plugin/xigua_p/static/pay1.png" style="height:50px" /> </p>
            </div>
        </label>
        <!--{/if}-->
        <!--{if $config[allowalipay]}-->
        <label class="weui-cell weui-check__label" for="s12">
            <div class="weui-cell__hd">
                <input type="radio" name="checkbox1" class="weui-check" value="alipay" id="s12"> <i class="weui-icon-checked"></i>
            </div>
            <div class="weui-cell__bd">
                <p><img src="source/plugin/xigua_p/static/pay2.png" style="height:50px" /></p>
            </div>
        </label>
        <!--{/if}-->
    </div>

    <div id="qrbox" class="tc d_none">
        <div id="qr"></div>
        <p>{lang xigua_p:qr}</p>
    </div>
    <div class="weui-btn-area">
        <a class="weui-btn weui-btn_primary d_btn_primary" href="javascript:" id="submitc">{lang xigua_p:pay}</a>
    </div>
</form>

</div>

<script>
    $('#submitc').on('click', function () {
        <!--{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false}-->

        <!--{else}-->
        var paytype = $('input[name="checkbox1"]:checked').val();
        if (paytype == 'alipay') {
            $('#formc').submit();
        } else if(paytype=='wxpay') {
            $.ajax({
                url: 'plugin.php?id=xigua_p:pay',
                cache: false,
                dataType: "json",
                data: $('#formc').serialize(),
                type: "POST",
                success: function (data) {
                    if (data.error) {
                        alert(data.error);
                    } else if (data.qrurl) {
                        $('#qr').html(data.qrurl);
                        $('#qrbox').show();
                    } else {
                        callpay(data);
                    }
                }
            });
        }
        <!--{/if}-->
        return false;
    });
    function callpay(kapi) {
        <!--{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false}-->
        payWechat(kapi);
        connectAppbymeJavascriptBridge(function (bridge) {
            payWechat(kapi);
        });
        <!--{else}-->
        if (typeof WeixinJSBridge == "undefined") {
            if (document.addEventListener) {
                document.addEventListener('WeixinJSBridgeReady', function (kapi) {
                    jsApiCall(kapi);
                }, false);
            } else if (document.attachEvent) {
                document.attachEvent('WeixinJSBridgeReady', function (kapi) {
                    jsApiCall(kapi);
                });
                document.attachEvent('onWeixinJSBridgeReady', function (kapi) {
                    jsApiCall(kapi);
                });
            }
        } else {
            jsApiCall(kapi);
        }
        <!--{/if}-->
    }
    function jsApiCall(apiKey) {
        WeixinJSBridge.invoke(
            'getBrandWCPayRequest',
            apiKey,
            function (res) {
                if (res.err_msg == 'get_brand_wcpay_request:ok') {
                    window.location.href = '$autolink';
                } else {
                }
            }
        );
    }

    <!--{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false}-->
    var QFjson = {
        "item" : '[{"title":"$subject", "cover":"", "num":1, "gold_cost":0, "cash_cost":$price}]',
        "address" : '{"name":"pay_subject", "mobile":"18988888888", "address":"jiangsu"}'
    },QFdata = {
        'type' : 10000,
        'item' : QFjson.item,
        'send_type' : 0,
        'address' : QFjson.address,
        'allow_pay_type' : 14
    };

    setTimeout(function () {
        QFH5.createOrder(QFdata['type'], QFdata['item'], QFdata['send_type'], QFdata['address'], QFdata['allow_pay_type'],function(state,data){
            if(state == 1){
                var oid = data.order_id;
                $.ajax({
                    url: 'plugin.php?id=xigua_p:pay&payqf=1&qforder_id='+oid,
                    cache: false,
                    data: $('#formc').serialize(),
                    type: "POST",
                    success: function (s) {
                        QFH5.jumpPayOrder(oid,function(state_jump,data){
                            if(state_jump==1){
                                window.location.href = '$autolink&qforder_id='+oid;
                            }else{
                                alert(data.error);//data.error  string
                            }
                        });
                    }
                });
            }else{
                alert(data.error);
            }
        });
    }, 800);
    <!--{/if}-->

</script>

<script src="https://market-cdn.app.xiaoyun.com/release/sq-2.3.js"></script>
<script type="text/javascript">
    function payWechat(kapi) {
        var payParam = {
            appid: kapi.appid,
            partnerid: kapi.partnerid,
            prepayid: kapi.prepayid,
            attach: 'Sign=WXPay',
            noncestr: kapi.noncestr,
            timestamp: kapi.timestamp,
            sign: kapi.sign
        };
        AppbymeJavascriptBridge.payRequest(function (data) {
            if (data.errCode == '0') {
                //alert(data.errInfo);

                top.location.href = '$autolink';

            } else {

                alert(data.errInfo);

                top.location.href = '$autolink';

            }

        }, 1, JSON.stringify(payParam));
        wxpay();
    }
</script>
</body>
</html>