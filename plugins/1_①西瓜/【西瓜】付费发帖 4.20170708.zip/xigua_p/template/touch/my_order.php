<?php exit('hehehe!') ?>
<!--{template xigua_p:header}-->


<div class="mod-app-container">
    <div class="weui-cells__title">$navtitle</div>
    <div class="weui-panel list-content">
        
    </div>


    <a class="btn-gray loadmore" href="javascript:void(0);">{lang xigua_p:dianjijiazai}</a>
    <a class="btn-gray icon-loading-s loadings" href="javascript:void(0);" style="display:none;">{lang xigua_p:zhengzaijia}</a>
    <a class="btn-gray noData" href="javascript:void(0);" style="display:none">{lang xigua_p:zanwugengduo}</a>
</div>

<script>

    var page = 1;
    var ajaxpage = '{$ajax_url}';
    var running = 0;
    var nodata = 0;

    jQuery(window).scroll(function () {
        var top = (jQuery(document).height() - jQuery(this).scrollTop() - jQuery(this).height());
        if (top<20) {
            jQuery('.loadmore').trigger('click');
        }
    });

    jQuery('.loadmore').on('click',function () {
        if(nodata || running){
            return;
        }
        running = 1;

        jQuery.ajax({
            url: ajaxpage+page,
            dataType: 'html',
            beforeSend:function(){
                jQuery('.loadmore').hide();
                jQuery('.loadings').fadeIn();
            },
            success: function (data) {
                jQuery('.loadings').hide();
                page++;
                if(data){
                    jQuery('.list-content').append(data);
                    jQuery('.loadmore').fadeIn();
                }else{
                    nodata = 1;
                    jQuery('.loadmore').hide();
                    jQuery('.noData').fadeIn();
                }
                setTimeout(function () {
                    running = 0;
                }, 500);
            },
            error:function () {
                jQuery('.loadmore').fadeIn();
                jQuery('.loadings').hide();
                setTimeout(function () {
                    running = 0;
                }, 500);
            }
        });
    });
    jQuery('.loadmore').trigger('click');

</script>
</body>
</html>