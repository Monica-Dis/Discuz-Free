<?php exit('hehehe!') ?>
<!--{loop $listdata $v}-->
<div class="weui-panel__bd">
    <div class="weui-media-box weui-media-box_text">
        <h4 class="weui-media-box__title"><a href="forum.php?mod=viewthread&tid={$v[tid]}">$v[subject]</a></h4>
        <ul class="weui-media-box__info">
            <li class="weui-media-box__info__meta">{lang xigua_p:orders1n}<span class="">$v[order_id]</span></li>
            <li class="weui-media-box__info__meta">{lang xigua_p:jine}<span class="">$v[baseprice]{lang xigua_p:yuan}</span></li>
            <li class="weui-media-box__info__meta">{lang xigua_p:method1}<span class="">{echo lang_p($v[paymethod], 0)}</span></li>
            <li class="weui-media-box__info__meta">{lang xigua_p:pingtaidan}$v[order_sn]</li>
            <li class="weui-media-box__info__meta">{lang xigua_p:zhifushijian}$v[payupts]</li>
        </ul>
    </div>
</div>
<!--{/loop}-->