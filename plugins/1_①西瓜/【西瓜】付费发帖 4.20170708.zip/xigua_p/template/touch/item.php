<?php exit('xxxxx'); ?>
<!--{if $threads}--><!--{loop $threads $thread}-->
<div class="weui-cell ">
    <!--{if $thread[image]}-->
    <div class="weui-cell__hd" style="position: relative;margin-right:10px;">
        <a href="forum.php?mod=viewthread&tid={$thread[tid]}"> <img class="cover smlimg" src="{$thread[image]}"> </a>
    </div>
    <!--{/if}-->

    <div class="weui-cell__bd"><a href="forum.php?mod=viewthread&tid={$thread[tid]}">
            <p class="c-tx2">{$thread[subject]}</p>
            <p class="c-tx1">
                <span class="sv"> <i class="iconfont icon-liulanliang"></i> $thread[views]</span>
                <span class="sv sv1"><i class="iconfont icon-shijian"></i> $thread[dateline]</span>
            </p>
        </a>
    </div>

    <div class="weui-cell__ft">
        <a href="plugin.php?id=xigua_p:pay&action={$thread[action]}&fid=$thread[fid]&tid=$thread[tid]&pid=$thread[pid]" class="weui-btn weui-btn_mini weui-btn_primary" id="open{$row[id]}">{lang xigua_p:paynow}</a>
    </div>
</div><!--{/loop}--><!--{/if}-->