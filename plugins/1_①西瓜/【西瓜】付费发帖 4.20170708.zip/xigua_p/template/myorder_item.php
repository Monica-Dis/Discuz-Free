<?php exit('hehehe!') ?>
<!--{template common/header}-->
<!--{if $_GET[orderlog]==1}-->
<!--{loop $listdata $v}-->
<tr>
    <td>$v[order_id]</td>
    <td><a href="forum.php?mod=viewthread&tid={$v[tid]}">$v[subject]</a><br>{echo str_replace(',','<br>', $v[note])}</td>
    <td><span class="forumname">{echo lang_p($v[paymethod], 0)}</span></td>
    <td><span class="forumname">$v[payupts]</span></td>
    <td><span class="forumname">$v[baseprice]{lang xigua_p:yuan}</span></td>
</tr>
<!--{/loop}-->
<!--{else}-->
<!--{loop $listdata $v}-->
<tr>
    <td>[ $v[forumname] ] <a href="forum.php?mod=viewthread&tid={$v[tid]}">$v[subject]</a></td>
    <td>$v[dateline]</td>
    <td><a href="plugin.php?id=xigua_p:pay&action={$v[action]}&fid=$v[fid]&tid=$v[tid]&pid=$v[pid]" class="pn pnc" style="padding:2px 8px">{lang xigua_p:paynow}</a></td>
</tr>
<!--{/loop}-->
<!--{/if}-->
<!--{if $multi}-->
<tr>
    <td colspan="6">$multi</td>
</tr>
<!--{/if}-->
<!--{template common/footer}-->