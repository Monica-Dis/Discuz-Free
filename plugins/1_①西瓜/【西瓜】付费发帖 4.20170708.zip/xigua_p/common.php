<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!function_exists('curl_init')) {
	exit('Missing curl extension! DISM.TAOBAO.COM');
}
if (!function_exists('openssl_csr_export')) {
	exit('Missing openssl extension! DISM.TAOBAO.COM');
}
$pluginversion = '20160201';
global $_G;
if (!$_G['cache']['plugin']) {
	loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_p'];
$allowwxpay = 0;
$authkey = $_G['config']['security']['authkey'];
include_once libfile('function/cache');
if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false) {
	define('P_APPID', trim($config['appappid']));
	define('P_MCHID', trim($config['appshanghuid']));
	define('P_APPSECRET', trim($config['appappsecert']));
	define('P_WXPAY_KEY', trim($config['appkey']));
	if ($config['appappid'] && $config['appshanghuid'] && $config['appappsecert'] && $config['appkey']) {
		$allowwxpay = 1;
	}
} else {
	define('P_APPID', trim($config['appid']));
	define('P_MCHID', trim($config['shanghuid']));
	define('P_APPSECRET', trim($config['appsecert']));
	define('P_WXPAY_KEY', trim($config['key']));
	if ($config['appid'] && $config['shanghuid'] && $config['appsecert'] && $config['key']) {
		$allowwxpay = 1;
	}
}
define('P_NOTIFY_URL', $_G['siteurl'] . 'source/plugin/xigua_p/notify_wx.php');
define('WECHAT_P', !(stripos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false));
define('XIAOYUN_P', !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') === false));
$repath = './source/plugin/xigua_p/cache/';
if (!$GLOBALS['not_include']) {
	include_once DISCUZ_ROOT . 'source/plugin/xigua_p/lib/wxpay/lib/WxPay.Config.php';
	include_once DISCUZ_ROOT . 'source/plugin/xigua_p/lib/wxpay/lib/WxPay.Api.php';
	include_once DISCUZ_ROOT . 'source/plugin/xigua_p/lib/wxpay/example/WxPay.JsApiPay.php';
	include_once DISCUZ_ROOT . 'source/plugin/xigua_p/lib/wxpay/example/WxPay.NativePay.php';
	include_once DISCUZ_ROOT . 'source/plugin/xigua_p/lib/wxpay/example/log.php';
	include_once DISCUZ_ROOT . 'source/plugin/xigua_p/lib/wxpay/lib/WxPay.Data.php';
}
$ckey = 'pwechatopenid';
$GLOBALS['edit_prilist'] = $GLOBALS['prilist'] = array();
if ($config['price']) {
	foreach (explode("\n", trim($config['price'])) as $item) {
		list($fid, $price) = explode('=', trim($item));
		$GLOBALS['prilist'][$fid] = $price;
	}
}
if ($config['editprice']) {
	foreach (explode("\n", trim($config['editprice'])) as $item) {
		list($fid, $price) = explode('=', trim($item));
		$GLOBALS['edit_prilist'][$fid] = $price;
	}
}
init_xigua_p();
function p_current_url()
{
	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
	$php_self = $_SERVER['PHP_SELF'] ? p_safe_replace($_SERVER['PHP_SELF']) : p_safe_replace($_SERVER['SCRIPT_NAME']);
	$path_info = isset($_SERVER['PATH_INFO']) ? p_safe_replace($_SERVER['PATH_INFO']) : '';
	$relate_url = isset($_SERVER['REQUEST_URI']) ? p_safe_replace($_SERVER['REQUEST_URI']) : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . p_safe_replace($_SERVER['QUERY_STRING']) : $path_info);
	return $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
}
function p_safe_replace($string)
{
	$string = str_replace('%20', '', $string);
	$string = str_replace('%27', '', $string);
	$string = str_replace('%2527', '', $string);
	$string = str_replace('*', '', $string);
	$string = str_replace('"', '&quot;', $string);
	$string = str_replace('\'', '', $string);
	$string = str_replace('"', '', $string);
	$string = str_replace(';', '', $string);
	$string = str_replace('<', '&lt;', $string);
	$string = str_replace('>', '&gt;', $string);
	$string = str_replace('{', '', $string);
	$string = str_replace('}', '', $string);
	$string = str_replace('\\', '', $string);
	return $string;
}
function p_get_picurl($pic, $remote = 0)
{
	global $_G;
	if (!$pic) {
		return '';
	}
	if (p_is_picurl($pic)) {
		return $pic;
	}
	if (strpos($pic, 'forum.php') !== false) {
		return $_G['siteurl'] . $pic;
	}
	if ($remote) {
		$attach__ = $_G['setting']['ftp']['attachurl'] . 'forum/' . $pic;
	} else {
		$pic = $_G['setting']['attachurl'] . 'forum/' . $pic;
		if (p_is_picurl($pic)) {
			return $pic;
		}
		$attach__ = $_G['siteurl'] . $pic;
	}
	return $attach__;
}
function p_is_picurl($pic)
{
	return in_array(strtolower(substr($pic, 0, 6)), array('http:/', 'https:', 'ftp://'));
}
function p_check_by_tid_pid($tid, $pid, $message)
{
	$picitem = NULL;
	$tmp = DB::fetch_first('SELECT pid FROM %t WHERE tid=%d AND first=1 AND invisible=0 LIMIT 1', array(table_forum_post::get_tablename('tid:' . $tid), $tid));
	$pid = $tmp['pid'];
	$reys = C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'pid', $pid, 'aid ASC', true, false, false, 1);
	foreach ($reys as $index => $row) {
		$picitem = p_get_picurl($row['thumb'] ? getimgthumbname($row['attachment']) : $row['attachment'], $row['remote']);
	}
	if (!$picitem) {
		if (strpos($message, '[/hide]') !== false) {
			$message = preg_replace('/\\[hide\\].*?\\[\\/hide\\]/i', '', $message);
		}
		if (strpos($message, '[/img]') !== false) {
			$pattern = '/\\[img.*?\\](.*?)\\[\\/img\\]/i';
			preg_match_all($pattern, $message, $matchsimg);
			$picitem = $matchsimg[1][0];
		}
	}
	return $picitem;
}
function lang_p($lang = '', $echo = 1)
{
	$ret = lang('plugin/xigua_p', $lang);
	if ($echo) {
		echo $ret;
		return true;
	}
	return $ret;
}
function read_by_tid_pid($tid, $message, $pid)
{
	$picitem = NULL;
	$tmp = DB::fetch_first('SELECT pid FROM %t WHERE tid=%d AND first=1 AND invisible=0 LIMIT 1', array(table_forum_post::get_tablename('tid:' . $tid), $tid));
	$pid = $tmp['pid'];
	$reys = C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'pid', $pid, 'aid ASC', true, false, false, 1);
	foreach ($reys as $index => $row) {
		$picitem = p_get_picurl($row['thumb'] ? getimgthumbname($row['attachment']) : $row['attachment'], $row['remote']);
	}
	if (!$picitem) {
		if (strpos($message, '[/hide]') !== false) {
			$message = preg_replace('/\\[hide\\].*?\\[\\/hide\\]/i', '', $message);
		}
		if (strpos($message, '[/img]') !== false) {
			$pattern = '/\\[img.*?\\](.*?)\\[\\/img\\]/i';
			preg_match_all($pattern, $message, $matchsimg);
			$picitem = $matchsimg[1][0];
		}
	}
	return $picitem;
}
function init_xigua_p()
{
}