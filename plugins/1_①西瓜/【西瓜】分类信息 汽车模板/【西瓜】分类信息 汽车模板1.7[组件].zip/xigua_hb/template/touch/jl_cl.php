<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_GET['is_my'] || $_GET['is_admin']}-->
<!--{template xigua_hb:mypub_item}-->
<!--{else}-->
<!--{loop $list $k $v}-->
<!--{eval
$msg = (str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))));
$price1 = array_slice($v[vars], 0, 1);
$price1 = $price1[0][html]?$price1[0][html]:$price1[0][value];
$v[vars] = array_slice($v[vars], 1);
$line1 = array();
foreach($v[vars] as $__k=> $__v):
    if($__v[type]=='pics' || $__v[type]=='linkurl'):
        unset($v[vars][$__k]);
        continue;
    endif;
    if(count($line1)<3):
        $line_text = $__v[html] ?$__v[html] :$__v[value];
        if($line_text):
            unset($v[vars][$__k]);
            $line1[] = $line_text;
        endif;
    endif;
endforeach;
$line1 = implode('<em>/</em>', $line1);
$showideo = $v['video_cover'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php');
$v[vars] = array_values($v[vars]);
}-->
<div class="card_row view_jump" data-id="$v[id]" data-stid="$v[stid]">
    <div class="card_left">
        <div class="card_activity_tag orange"><i class="red">{$cats[$v[catid]][name]}</i></div>
        <img class="card_abs_img" src="<!--{if $v[img_preview][0]}-->$v[img_preview][0]<!--{elseif $showideo}-->$v[video_cover]<!--{/if}-->" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
        <!--{if $showideo}-->
        <div class="card_video_play"></div>
        <!--{/if}-->
    </div>
    <div class="card_right"><h3><!--{if $v[dig_on]}--><div class="mod-lv is-star">{lang xigua_hb:zhiding}</div><!--{/if}-->{$msg}</h3>
        <div class="car_info">{$line1}</div>
        <div class="bt_box"><strong class="priceC"><span class="price_title"></span><i class="ifoset">$price1</i></strong>
            <ul class="tagsS">
                <!--{loop $v[vars] $_k $_v}--><!--{eval $__varhtml = $_v[html] ? $_v[html] : $_v[value];}--><!--{if $__varhtml}--><li class="card_car_tag grayY"><i>$__varhtml</i></li><!--{/if}--><!--{/loop}-->
                <!--{loop $v[tags] $___k $tag}--><!--{if $tag}--><li class="card_car_tag blue"><i>$tag</i></li><!--{/if}--><!--{/loop}-->
            </ul>
        </div>
    </div>
</div>
<!--{/loop}-->
<!--{/if}-->