<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $c06 = hb_hex2rgb($config['maincolor'], .06);}--><style>.card_row{padding:.75rem;display:-webkit-box;-webkit-box-pack:start;-webkit-justify-content:flex-start;-ms-flex-pack:start;justify-content:flex-start;border-bottom:.05rem solid #f1f3f6;overflow:hidden;background:#fff}
.card_left{position:relative;width:5.5rem;min-width:5.5rem;border-radius:.2rem}
.card_right{padding-left:.6rem;position:relative;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-flex:1;-webkit-flex:1;-ms-flex:1;flex:1}
.card_left:before{content:'';display:block;height:0;padding-top:75%;overflow:hidden}
.card_activity_tag{position:absolute;top:0;left:0;display:inline-block;height:.8rem;line-height:.8rem;border-radius:.2rem 0 .2rem 0;z-index:1}
.card_activity_tag.orange{background:{$config[maincolor]};color:#fff}
.card_activity_tag i{display:inline-block;font-size:.6rem;vertical-align:.1rem;-webkit-transform:scale(.833);-ms-transform:scale(.833);transform:scale(.833);-webkit-transform-origin:center;-ms-transform-origin:center;transform-origin:center}
.card_abs_img{position:absolute;top:0;left:0;width:100%;height:100%;border-radius:.2rem;z-index:0}
.card_video_play{position:absolute;right:.2rem;bottom:.2rem;width:.9rem;height:.9rem;background:url(source/plugin/xigua_hb/static/img/vp.png) no-repeat;background-size:100%}
.card_right h3{display:-webkit-box;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;-webkit-box-orient:vertical;-webkit-box-align:start;-webkit-line-clamp:2;font-size:.8rem;color:#111e36;letter-spacing:0;height:1.9rem;line-height:.95rem;overflow:hidden;width:100%}
.card_right .car_info{margin:.4rem 0 .4rem 0;display:inline-block;position:relative;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;font-size:.6rem;font-weight:300;color:#666d7f;height:.6rem;line-height:.6rem;overflow:hidden}
.card_right .car_info span{padding:0}
.card_right .car_info span:first-child{padding-left:0}
.card_right .car_info em{display:inline-block;text-align:center;width:.55rem;color:#c5cad4}
.card_right .bt_box{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:end;-webkit-align-items:flex-end;-ms-flex-align:end;align-items:flex-end;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;height:.9rem;line-height:.9rem;overflow:hidden}
.card_right .bt_box .priceC{padding-right:.2rem;display:inline-block;color:#f60;letter-spacing:0;height:.9rem;line-height:.9rem}
.card_right .bt_box .priceC i{display:inline-block}
.card_right .bt_box ul.tagsS{margin-bottom:.05rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-flex:1;-webkit-flex:1;-ms-flex:1;flex:1;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-align:inherit;-webkit-align-items:inherit;-ms-flex-align:inherit;align-items:inherit;height:.8rem;overflow:hidden}
.card_car_tag{margin-bottom:.05rem;margin-left:.2rem;padding:.1rem .15rem;height:.8rem;line-height:.8rem;vertical-align:bottom;background:#fff;border-radius:.2rem 0 .2rem 0;box-sizing:border-box}
.card_car_tag.grayY{color:#666d7f;border:1px solid #e6ebf5}
.card_right .bt_box ul.tagsS li{margin-bottom:0;margin-left:.2rem}
.card_right .bt_box ul.tagsS li:first-child{margin-left:0}
.card_car_tag i{display:inline-block;font-size:.6rem;font-weight:300;color:#686d7f;line-height:.5rem;vertical-align:top;-webkit-transform:scale(.833);-ms-transform:scale(.833);transform:scale(.833);-webkit-transform-origin:center;-ms-transform-origin:center;transform-origin:center;white-space:nowrap}
.card_car_tag.blue {background:$c06;border:1px solid $c06}
.card_car_tag.blue i {color:$config['maincolor'];}.ifoset{font-family:DINAlternate-Bold;src:local("DINAlternate-Bold"),url(source/plugin/xigua_hb/static/css/DINAlternate-Bold.ttf) format("truetype")}</style>