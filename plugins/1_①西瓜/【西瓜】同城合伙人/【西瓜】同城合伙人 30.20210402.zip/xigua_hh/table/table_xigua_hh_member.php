<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hh_member extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hh_member';
        $this->_pk = 'uid';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false)
    {
        global $_G, $renew;
        if($renew && !$GLOBALS['hassaveback']){
            $old = $this->fetch($val);
            unset($old['oldback']);
            $data['oldback'] = serialize($old);
            $GLOBALS['hassaveback'] = 1;
        }
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }

    public function fetch_prepare($uid)
    {
        $rt = parent::fetch($uid);
        return self::_prepare($rt);
    }

    public function fetch_prepare_by_fansuid($fansuid)
    {
        $row = C::t('#xigua_hh#xigua_hh_invite')->fetch_by_fansuid($fansuid);
        if($row['uid']>0){
            $rt = parent::fetch($row['uid']);
            return self::_prepare($rt);
        }
        return array();
    }

    public function delete_unpay($uid)
    {
        $old = $this->fetch($uid);
        DB::query("DELETE FROM %t WHERE {$this->_pk}=%d AND haspay=0 AND status=-1", array($this->_table, $uid));
        if($oldback = unserialize($old['oldback'])){
            $this->insert($oldback);
        }
        return 1;
    }

    function _hh_parse_type(){
        global $_G;
        $hh_config = $_G['cache']['plugin']['xigua_hh'];
        $str = $hh_config['price_join'];
        $ar = array();
        foreach (explode("\n", trim($str)) as $index => $item) {
            list($name, $price, $percentage, $lazy, $subpct) = explode('#', trim($item));
            $name = trim($name);
            $ar[$name] = array(
                'name' => $name,
                'price' => trim($price),
                'price_display' => '&yen;'.trim(str_replace('.00','', $price)),

                'percent' => round(trim(str_replace('%', '', $percentage)), 2),
                'subpct' => round(trim(str_replace('%', '', $subpct)), 2),

                'percentage' => trim($percentage),
                'subpctage' => trim($subpct),
                'lazy' => intval($lazy)
            );
        }
        return $ar;
    }

    public function _prepare($v)
    {
        global $hh_config;
        $sta = array(
            1=>lang('plugin/xigua_hh', 'shen1'),
            -1=>lang('plugin/xigua_hh', 'shen-1'),
            0=>lang('plugin/xigua_hh', 'shen0'),
        );
        if($v){
            $v['joininfo'] = unserialize($v['joininfo']);
            if(!defined('IN_ADMINCP')){
                $hh_type = $this->_hh_parse_type();
                if($v['joininfo']['name'] && $hh_type[$v['joininfo']['name']]){
                    $v['joininfo'] = $hh_type[$v['joininfo']['name']];
                }elseif($v['joininfo']['name'] && !$hh_type[$v['joininfo']['name']]){
                    $hh_type_values = array_values($hh_type);
                    $v['joininfo'] = $hh_type_values[0];
                }
            }
            $v['endts_u']  = $v['endts']<2147483647 ? dgmdate($v['endts'], 'Y-m-d') : lang('plugin/xigua_hh', 'yongjiu');
            $v['end']        = ($v['endts']>TIMESTAMP?0:1);
            $v['status_u']   = $sta[$v['status']];
            $v['display']    = ($v['status']==1);
            $v['unpay']      = ($v['status']==-1);
            if($v['unpay']){
                $v['order'] = C::t('#xigua_hb#xigua_hb_order')->fetch($v['order_id']);
                $v['order']['info'] = unserialize($v['order']['info']);
            }
            if($hh_config['fanslock'] == 'lock2'){
                if($v['end']){
                    DB::delete('xigua_hh_invite', array('uid' => $v['uid']));
                }
            }elseif($hh_config['fanslock'] == 'lock3' && $hh_config['locktime']>0){
                $tsmp = $hh_config['locktime']*86400+$v['endts'];
                if($tsmp <TIMESTAMP){
                    DB::delete('xigua_hh_invite', array('uid' => $v['uid']));
                }
            }
/*
            if($v['endts'] && !$v['lastnoti'] && ($v['endts']-TIMESTAMP <= 86400) ){
                global $SCRITPTNAME, $_G;
                $ti = TIMESTAMP;
                $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_hh&ac=join&do=renew";
                $member = getuserbyuid($v['uid']);
                $vvr= array(
                    'shname' => $member['username'],
                    'endts_u' => $v['endts_u'],
                    'url' => $url
                );
                notification_add($v['uid'],'system', "<a href='{url}'>"."&#24744;&#30340;&#21512;&#20249;&#20154;&#36523;&#20221;{shname}&#23558;&#20110;{endts_u}&#36807;&#26399;&#65292;&#35831;&#23613;&#24555;&#32493;&#36153;&#65292;&#20197;&#20813;&#36896;&#25104;&#19981;&#24517;&#35201;&#30340;&#25439;&#22833;"."</a>", $vvr,1);
                DB::query("update %t set lastnoti=$ti WHERE {$this->_pk}=%d", array($this->_table,  $v['uid']));
            }*/
        }
        return $v;
    }


    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $order_by = '')
    {
        if(!$order_by){
            $order_by = 'crts DESC ';
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY $order_by" . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = self::_prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function increase($id, $field, $num = 1)
    {
        if(!$field){
            return null;
        }
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }
}