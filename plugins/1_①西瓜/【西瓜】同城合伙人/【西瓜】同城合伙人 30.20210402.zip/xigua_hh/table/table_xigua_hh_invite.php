<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hh_invite extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hh_invite';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }

    public function total_week_group($uid)
    {
        $ret = array();
        $stime = TIMESTAMP;
        $oldend = $etime = strtotime(date("Y-m-d 00:00:00", strtotime('-1 week +1 day')));

        while($stime>= $etime){
            $ret[date('m-d',$etime)] = 0;
            $etime=$etime + 3600*24;
        }

        $all = DB::fetch_all("SELECT fansuid,FROM_UNIXTIME(crts) as `days` FROM %t WHERE uid=%d AND crts>=%s", array($this->_table, $uid, $oldend));
        foreach ($all as $index => $item) {
            $ret[substr($item['days'], 5, 5)] += 1;
        }
        return $ret;
    }

    public function insert_invite($idfrom, $fansuid)
    {
        static $ret = null;
        if($ret !== null){
            return $ret;
        }
        $ret = true;

        global $SCRITPTNAME, $_G;
        if(!$SCRITPTNAME){
            $SCRITPTNAME = 'plugin.php';
        }
        $hh_config = $_G['cache']['plugin']['xigua_hh'];
        $idfrom = intval($idfrom);
        $fansuid = intval($fansuid);
        if($hh_config['fanswhere']=='fanswhere2' || $hh_config['fanswhere']=='fanswhere4'){
            if(DB::result_first("select uid from %t WHERE uid=%d AND status=1 AND endts>=".TIMESTAMP, array('xigua_hh_member', $fansuid))){
                dsetcookie('hhidu', '', 0);
                dsetcookie('widthauto', '', 0);
                return false;
            }
        }
        if( $_G['cache']['plugin']['xigua_hk']){
            if($hh_config['fanswhere']=='fanswhere3' || $hh_config['fanswhere']=='fanswhere4'){
                $card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($fansuid);
                if($card){
                    dsetcookie('hhidu', '', 0);
                    dsetcookie('widthauto', '', 0);
                    return false;
                }
            }
        }
        if(!DB::result_first("select uid from %t WHERE uid=%d AND status=1 AND endts>=".TIMESTAMP, array('xigua_hh_member', $idfrom))){
            dsetcookie('hhidu', '', 0);
            dsetcookie('widthauto', '', 0);
            return false;
        }
    if($old_row = $this->fetch_by_fansuid($fansuid)){
        if($hh_config['fanslock'] == 'lock4'){
            if( !$hh_config['baohu'] || ($hh_config['baohu']>0&&($old_row['crts']+$hh_config['baohu']*86400<TIMESTAMP)) ){
                DB::query("update %t set uid=%d where fansuid=%d AND uid!=%d limit 1", array(
                    'xigua_hh_invite',
                    $idfrom,
                    $fansuid,
                    $idfrom
                ));
                if(DB::affected_rows()>0){
                    C::t('#xigua_hh#xigua_hh_member')->increase($old_row['uid'], 'totalfans', -1);
                    if($hh_config['hhmode']==2) {
                        $tmp = $this->fetch_by_fansuid($old_row['uid']);
                        if($tmp['uid']>0){
                            C::t('#xigua_hh#xigua_hh_member')->increase($tmp['uid'], 'totalsecfans', -1);
                        }
                    }
                }else{
                    dsetcookie('hhidu', '', 0);
                    dsetcookie('widthauto', '', 0);
                    return false;
                }
            }
        }else{
            dsetcookie('hhidu', '', 0);
            dsetcookie('widthauto', '', 0);
            return false;
        }
    }
        $insert_id = parent::insert(array(
                'uid'     => $idfrom,
                'fansuid' => $fansuid,
                'crts' => TIMESTAMP
            ),true, false, 1);
        if($insert_id){
            C::t('#xigua_hh#xigua_hh_member')->increase($idfrom, 'totalfans');
            if($hh_config['allowtz']){
                notification_add($idfrom,'system', lang('plugin/xigua_hh', 'note_4'),array('url' => "$SCRITPTNAME?id=xigua_hh&ac=myfans", 'who' => $_G['username']),1);
            }
            $tmp = $this->fetch_by_fansuid($idfrom);
            if($tmp['uid']>0 && $hh_config['hhmode']==2){
                C::t('#xigua_hh#xigua_hh_member')->increase($tmp['uid'], 'totalsecfans');
                $yourfans = getuserbyuid($idfrom);
                if($hh_config['allowtz']) {
                    notification_add($tmp['uid'], 'system', lang('plugin/xigua_hh', 'note_5'), array(
                        'url' => "$SCRITPTNAME?id=xigua_hh&ac=myfans&do=sec",
                        'who' => $_G['username'],
                        'youfans' => $yourfans['username'],
                    ), 1);
                }
            }
        }
        dsetcookie('hhidu', '', 0);
        dsetcookie('widthauto', '', 0);
        return $insert_id;
    }

    public function fetch_by_fansuid($fansuid)
    {
        return DB::fetch_first("SELECT * FROM %t WHERE fansuid=%d", array($this->_table, $fansuid));
    }

    public function delete_fans($fansuid, $uid)
    {
        return DB::query("DELETE FROM %t WHERE fansuid=%d AND uid=%d", array($this->_table, $fansuid, $uid));
    }

    public function fetch_by_uid($uid,  $start_limit , $lpp){
        $uid = intval($uid);
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)." WHERE uid=$uid ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        $result = self::_prepares($result);
        return $result;
    }

    public function fetch_sec_by_uid($uid,  $start_limit , $lpp)
    {
        $uid = intval($uid);
        $tb = DB::table($this->_table);
        $result = DB::fetch_all("SELECT a.uid,b.uid as buid,b.fansuid as fansuid,b.crts FROM `$tb` as a inner join `$tb` as b on a.fansuid=b.uid WHERE a.uid=$uid ORDER BY b.crts DESC " . DB::limit($start_limit, $lpp));
        $result = self::_prepares($result);
        return $result;
    }

    public function fetch_myfans_shop($uid,  $start_limit , $lpp){
        $uid = intval($uid);
        $result = DB::fetch_all('SELECT h.*,s.* FROM '.DB::table($this->_table)." as h, ".DB::table('xigua_hs_shanghu')." AS s WHERE h.uid=$uid and h.fansuid=s.uid ORDER BY h.crts DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = C::t('#xigua_hs#xigua_hs_shanghu')->prepare($item);
        }
        return $result;
    }

    public function fetch_up_by_uid($uid,  $start_limit , $lpp)
    {
        $uid = intval($uid);
        $tb = DB::table($this->_table);
        $result = DB::fetch_all("SELECT *, uid as fansuid,fansuid as uid FROM `$tb` WHERE fansuid=$uid ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        $result = self::_prepares($result);
        return $result;
    }

    public static function _prepares($result)
    {
        $buids = $uids = array();
        foreach ($result as $index => $item) {
            $result[$index]['crts_u'] = dgmdate($item['crts'], 'u');
            $uids[] = $item['fansuid'];
            if($item['buid']){
                $buids[] = $item['buid'];
            }
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }

        if($buids){
            $busers = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $buids), 'uid');
        }
        foreach ($result as $index => $item) {
            $result[$index]['fans'] = $users[$item['fansuid']];
            if($busers){
                $result[$index]['buser'] = $busers[$item['buid']];
            }
        }
        return $result;
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $orderby = '')
    {
        if(!$orderby){
            $orderby = "crts DESC";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY $orderby" . DB::limit($start_limit, $lpp));
        $result = self::_prepares($result);
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }
}