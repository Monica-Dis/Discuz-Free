<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hh_income extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hh_income';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }

    public function sum_today_by_uid($uid)
    {
        return DB::result_first("SELECT sum(money) as m FROM %t WHERE uid=%d AND reach<>-2 AND crts BETWEEN %s AND %s", array($this->_table, $uid, strtotime(date('Y-m-d')), strtotime(date('Y-m-d 23:59:59'))));
    }

    public function sum_month_by_uid($uid)
    {
        return DB::result_first("SELECT sum(money) as m FROM %t WHERE uid=%d AND reach<>-2 AND crts BETWEEN %s AND %s", array($this->_table, $uid, strtotime('-1 month'), strtotime(date('Y-m-d 23:59:59'))));
    }

    public function sum_week_group($uid)
    {
        $ret = array();
        $stime = TIMESTAMP;
        $oldend = $etime = strtotime(date("Y-m-d 00:00:00", strtotime('-1 week +1 day')));

        while($stime>= $etime){
            $ret[date('m-d',$etime)] = 0;
            $etime=$etime + 3600*24;
        }

        $all = DB::fetch_all("SELECT money,FROM_UNIXTIME(crts) as `days` FROM %t WHERE uid=%d AND reach<>-2 AND crts>=%s", array($this->_table, $uid, $oldend));
        foreach ($all as $index => $item) {
            $ret[substr($item['days'], 5, 5)] += $item['money'];
        }
        return $ret;
    }

    public function sum_total_by_uid($uid)
    {
        return DB::result_first("SELECT sum(money) as m FROM %t WHERE uid=%d AND reach<>-2 ", array($this->_table, $uid));
    }

    public function fetch_u_order($wherearr,  $start_limit , $lpp){
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $uids = $ouids = array();
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)." $wheresql ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $uids[] = $item['fansuid'];
            $result[$index] = self::prepare($item);
            $ouids[] = $result[$index]['info']['fromuid'];
        }

        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }
        if($ouids){
            $ousers = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $ouids), 'uid');
        }
        foreach ($result as $index => $item) {
            $result[$index]['fans'] = $users[$item['fansuid']];
            $result[$index]['orderuser'] = $ousers[$item['info']['fromuid']];
        }
        return $result;
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
            $v['info'] = unserialize($v['info']);
        }
        return $v;
    }

    public function do_reach($uid){
        global $_G, $SCRITPTNAME;
        $hh_config = $_G['cache']['plugin']['xigua_hh'];
        if(!C::t('#xigua_hh#xigua_hh_member')->fetch($uid)){
            if($hh_config['autohhr']){
                $ar = array();
                foreach (explode("\n", trim($hh_config['price_join'])) as $index => $item) {
                    list($name, $price, $percentage, $lazy, $subpct) = explode('#', trim($item));
                    $ar[$index] = array(
                        'name' => trim($name),
                        'price' => trim($price),
                        'price_display' => '&yen;'.trim(str_replace('.00','', $price)),

                        'percent' => round(trim(str_replace('%', '', $percentage)), 2),
                        'subpct' => round(trim(str_replace('%', '', $subpct)), 2),

                        'percentage' => trim($percentage),
                        'subpctage' => trim($subpct),
                        'lazy' => intval($lazy)
                    );
                }

                $prj = $ar;
                $data = array(
                    'uid'      => $uid,
                    'crts'     => TIMESTAMP,
                    'upts'     => TIMESTAMP,
                    'endts'    => TIMESTAMP+($hh_config['autohhr']*2592000),
                    'status'   => 1,
                    'joininfo' => serialize($prj[0]),
                    'months'   => $hh_config['autohhr'],
                    'order_id' => '',
                    'haspay'   => 1,
                );
                C::t('#xigua_hh#xigua_hh_member')->insert($data);
            }
            return false;
        }
        $today = date('Y-m-d', TIMESTAMP);
        $tc = lang('plugin/xigua_hh', 'tc');
        $rz = lang('plugin/xigua_hh', 'rz');

        if(0){
            /*$reach = -1;
            DB::query("update %t set reach=%s WHERE indate<=%s AND reach=0 AND uid=%d", array(
                $this->_table,
                $reach,
                $today,
                $uid,
            ));
            $affect_rows = DB::affected_rows();
            return $affect_rows;*/
        }else{
            $reach = 1;
            $processname = 'hh_cache_lock';
            if(discuz_process::islocked($processname, 120)) {
                return false;
            }
            foreach (DB::fetch_all("select * from %t WHERE indate<=%s AND reach=0 LIMIT 10", array( $this->_table, $today, $uid)) as $k => $v) {
                /*if($extinfo = unserialize($v['info'])){
                    $log = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch($extinfo['info']['data'][1]['log_id']);
                    if(!$log['hxcrts']){
                        DB::query("update %t set indate=%s WHERE id=%d", array(
                            $this->_table,
                            date('Y-m-d', TIMESTAMP+86400),
                            $v['id'],
                        ));
                        continue;
                    }
                }*/
                if(parent::update($v['id'], array('reach'=>1, 'realints' => TIMESTAMP))){
                    $v = self::prepare($v);
                    $user = DB::fetch_first('SELECT uid,username FROM %t WHERE uid=%d', array('common_member', $v['info']['fromuid']));
                    $ratio = str_replace('.00', '', $v['ratio']).'%';

                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['uid'], 'money', $v['money']);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid'  => $v['uid'],
                        'crts' => TIMESTAMP,
                        'size' => $v['money'],
                        'note' => $user['username'].$v['info']['subject']."<br>{$tc}{$ratio},{$rz}&yen;{$v['money']}",
                        'link' => "$SCRITPTNAME?id=xigua_hb&ac=member&uid={$v['info']['fromuid']}",
                    ));
                    notification_add($v['uid'],'system', lang('plugin/xigua_hh', 'note_3'),array('url' => "$SCRITPTNAME?id=xigua_hh&ac=income&do=reach", 'money'=>$v['money']),1);
                }
            }
            return true;
        }
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = self::prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function init_income($postprice, $extinfo)
    {
        global $_G,$SCRITPTNAME,$urlext;
        $hh_config = $_G['cache']['plugin']['xigua_hh'];
        $buyeruid = $extinfo['fromuid'];
        if($hh_config['allowself']){
            $hher = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($buyeruid);
            if(!$hher['display']){
                $hher = array();
            }
        }
        if(!$hher){
            $hher = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare_by_fansuid($buyeruid);
        }
        if(!$hher){
            return $postprice;
        }
        if($extinfo['info']['callback']['method']=='hr_paybao_finish'){
            return $postprice;
        }

        /*if('common_rw_pub' == $extinfo['note']){

        }else*/
        if(!in_array($extinfo['note'], unserialize($hh_config['openmodule']))){
            return $postprice;
        }
        if($extinfo['note'] == 'red' || $extinfo['note'] == 'shred'){
            $postprice = $postprice - intval($extinfo['info']['price']*100);
        }
        $third_id = 0;
        if($extinfo['note'] == 'common_seckill'){
            $sxfee = $totalprice = $extinfo['info']['data'][1]['price'];
            if($_G['cache']['plugin']['xigua_hm']['hhrmethod']==2){
                include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($extinfo['info']['data'][0]['shid']);
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                $insxf   = $vipinfo['insxf']/100;

                if($shdata['shinsxf']){
                    $insxf   = $shdata['shinsxf']/100;
                }
                $secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($extinfo['info']['data'][0]['id']);
                if($secinfo['shrate']){
                    $insxf = $secinfo['shrate']/100;
                }
                $sxfee = round($insxf*$totalprice, 2);
                if($secinfo['jiesuan1']> 0){
                    $sxfee = $secinfo['jiesuan1'];
                }
            }

            $secinfo = $extinfo['info']['data'][0];

            $postprice = round($sxfee, 2)*100;
            $third_id = $extinfo['info']['data'][1]['log_id'];
            $hh_config['needshen_in'] = 1;
        }elseif($extinfo['note'] =='common_fk') {

        }elseif($extinfo['note'] =='common_pt') {
            $sxfee = $totalprice = $extinfo['info']['data']['pay_money'];
            if ($_G['cache']['plugin']['xigua_pt']['hhrmethod'] == 2) {
                include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
                $shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($extinfo['info']['data']['shid']);
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                $insxf = $vipinfo['insxf'] / 100;
                if ($shdata['shinsxf']> 0) {
                    $insxf = $shdata['shinsxf'] / 100;
                }
                $sxfee = round($insxf * $totalprice, 2);
            }
            $postprice = round($sxfee, 2)*100;
            $third_id = $extinfo['info']['data']['id'];
        }
        elseif($extinfo['note'] =='common_sp') {
            $infodata = $extinfo['info']['data'];
            if($infodata['crts']>0){
                $sxfee    = $totalprice = $infodata['pay_money'];
                $shid     = $infodata['shid'];
                $third_id = $infodata['id'];
            }else{
                $shid     = $extinfo['info']['callback']['shid'];
                $sxfee    = $totalprice = $extinfo['info']['callback']['price_l'];
                $third_id = $extinfo['info']['callback']['ptlog_ids'];
            }
            if ($_G['cache']['plugin']['xigua_sp']['hhrmethod'] == 2) {
                include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
                $shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                $insxf = $vipinfo['insxf'] / 100;
                if ($shdata['shinsxf']> 0) {
                    $insxf = $shdata['shinsxf'] / 100;
                }
                $sxfee = round($insxf * $totalprice, 2);
            }
            $postprice = round($sxfee, 2)*100;
            $hh_config['needshen_in'] = 1;
        }elseif($extinfo['note'] =='common_bm'){
            $third_id_ary = array();
            $tmpsize1 = 0;
            $tmpsize2 = 0;
            $datas = $extinfo['info']['data'];
            foreach ($datas as $index => $__item) {
                $bmid = intval($__item['id']);
                $third_id_ary[] = $bmid;

                $pzinfo = unserialize($__item['pzinfo']);
                $tmpsize1+=floatval($pzinfo['pzhhr1']);
                $tmpsize2+=floatval($pzinfo['pzhhr2']);
            }

            if($third_id_ary){
                $third_id = implode(',', $third_id_ary);
            }
            $postprice = $tmpsize1*100;
            $hh_config['needshen_in'] = 1;
        }

        if(!$hher['end'] && $hher['display']){
            $money = round($postprice*$hher['joininfo']['percent']/10000, 2);

            if($extinfo['note'] == 'common_seckill') {
                if ($secinfo['hhr_ticheng']> 0 || $hh_config['jicheng']==2) {
                    $money = $secinfo['hhr_ticheng'] * intval($extinfo['info']['data'][1]['num']);
                    if($secinfo['hhr_ticheng2']<=0){
                        $hh_config['hhmode'] = 1;
                    }
                }
                if($secinfo['hhr_ticheng2']> 0 || $hh_config['jicheng']==2){
                    $money2imp = $secinfo['hhr_ticheng2'] * intval($extinfo['info']['data'][1]['num']);
                    $hh_config['hhmode'] = 2;
                }
            }elseif($extinfo['note'] =='common_pt'){
                $ptlog = $extinfo['info']['data'];
                $goodinfo = unserialize($ptlog['goodinfo']);
                if($goodinfo['custom_ticheng']> 0 || $hh_config['jicheng']==2){
                    $money = $goodinfo['custom_ticheng'] * intval($ptlog['gnum']);
                    $hh_config['hhmode'] = 1;
                }
                if($goodinfo['custom_ticheng2']> 0 || $hh_config['jicheng']==2){
                    $money2imp = $goodinfo['custom_ticheng2'] * intval($ptlog['gnum']);
                    $hh_config['hhmode'] = 2;
                }
            }elseif($extinfo['note'] =='common_sp'){
                if($extinfo['info']['data']['crts']>0) {
                    $ptlog = $extinfo['info']['data'];
                }else{
                    $gnum = 0;
                    $tmp = array_values($extinfo['info']['data']);
                    foreach ($tmp as $index => $item) {
                        $gnum+=$item['gnum'];
                    }
                    $ptlog = $tmp[0];
                    $ptlog['gnum'] = $gnum;
                }
                $goodinfo = unserialize($ptlog['goodinfo']);
                if($goodinfo['custom_ticheng']> 0 || $hh_config['jicheng']==2){
                    $money = $goodinfo['custom_ticheng'] * intval($ptlog['gnum']);
                    $hh_config['hhmode'] = 1;
                }
                if($goodinfo['custom_ticheng2']> 0 || $hh_config['jicheng']==2){
                    $money2imp = $goodinfo['custom_ticheng2'] * intval($ptlog['gnum']);
                    $hh_config['hhmode'] = 2;
                }
            }elseif($extinfo['note'] =='common_bm'){
                $money = $tmpsize1;
                if($tmpsize2> 0){
                    $money2imp = $tmpsize2;
                    $hh_config['hhmode'] = 2;
                }
            }

            if($hh_config['hhmode']==2){
                $top = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare_by_fansuid($hher['uid']);
                if(!$top['end'] && $top['display']){
                    if($money2 = $money2imp) {
                    }else{
                        $money2 = round($postprice*$top['joininfo']['subpct']/10000, 2);
                    }
                }
            }

            if($hh_config['sjfrom']==2){
                if($money <=$money2){
                    $money2 = 0;
                }else{
                    $money = $money - $money2;
                }
            }
            if($money>0){
                $indate = date('Y-m-d', strtotime('+'.$hher['joininfo']['lazy'].' days'));
                C::t('#xigua_hh#xigua_hh_income')->insert(array(
                    'uid'     => $hher['uid'],
                    'fansuid' => $buyeruid,
                    'crts'    => TIMESTAMP,
                    'ratio'   => $hher['joininfo']['percent'],
                    'indate'  => $indate,
                    'money'   => $money,
                    'info'    => serialize($extinfo),
                    'reach'   => ($hh_config['needshen_in'] ? -1 : 0),
                    'level'   => 1,
                    'idtype'  => $extinfo['note'],
                    'thirdid' => $third_id
                ));
//                $this->send_yj($hher['uid'], 'LV2mdfAj19rT0a8e-erqCo69A60-9pofehDkAPBd20k',"$SCRITPTNAME?id=xigua_hh&ac=income$urlext", $extinfo['baseprice'],$extinfo['subject'], $money);
                notification_add($hher['uid'],'system', lang('plugin/xigua_hh', 'note_6'),array('url' => "$SCRITPTNAME?id=xigua_hh&ac=income$urlext", 'money'=>$money, 'date' => $indate),1);
            }
            if($money2>0){
                $indate2 = date('Y-m-d', strtotime('+'.$top['joininfo']['lazy'].' days'));
                C::t('#xigua_hh#xigua_hh_income')->insert(array(
                    'uid'     => $top['uid'],
                    'fansuid' => $hher['uid'],
                    'crts'    => TIMESTAMP,
                    'ratio'   => $top['joininfo']['subpct'],
                    'indate'  => $indate2,
                    'money'   => $money2,
                    'info'    => serialize($extinfo),
                    'reach'   => ($hh_config['needshen_in'] ? -1 : 0),
                    'level'   => 2,
                    'idtype'  => $extinfo['note'],
                    'thirdid' => $third_id
                ));
                notification_add($top['uid'],'system', lang('plugin/xigua_hh', 'note_6'),array('url' => "$SCRITPTNAME?id=xigua_hh&ac=income$urlext", 'money'=>$money2, 'date' => $indate2),1);
            }
        }
        return $postprice-($money*100)-($money2*100);
    }

    function send_yj($touid, $template_id, $url,$note, $price, $yongjin){
        global $_G;
        $xconfig = $_G['cache']['plugin']['xigua_x'];
        if(is_file(DISCUZ_ROOT. './source/plugin/xigua_x/xWechat.lib.class.php')){
            include_once DISCUZ_ROOT. './source/plugin/xigua_x/xWechat.lib.class.php';
        }
        $client = new xWeChat($xconfig['appid'], $xconfig['appsecret']);
        $tpl = DB::fetch_first("SELECT * FROM %t WHERE template_id=%s", array('xigua_x', $template_id));
        $data_sys = unserialize($tpl['split']);
        $openid = DB::result_first('select openid from %t where uid=%d', array('common_member_wechat', $touid));
        $user = getuserbyuid($touid);

        /*����һ������Ϣ
��Ʒ��Ϣ{xinxi}
��Ʒ����{jiage}
��ƷӶ��{yongjin}
����ʱ��{shijian}
��������鿴*/
        foreach ($data_sys as $index => $item) {
            $item['value'] = str_replace(array(
                '{username}',
                '{xinxi}',
                '{shijian}',
                '{jiage}',
                '{yongjin}',
            ), array(
                $user['username'],
                $note,
                dgmdate(TIMESTAMP, 'Y-m-d H:i:s'),
                $price,
                $yongjin,
            ), $item['value']);

            $data_sys[$index]['value'] = diconv($item['value'], CHARSET, 'UTF-8');
        }

        $param = array(
            'touser'      => $openid,
            'template_id' => $template_id,
            'url'         => $url,
            'topcolor'    => '#ff0000',
            'data'        => $data_sys,
        );
        $result = $client->dosendTemplate($param);
    }
}