<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function hh_join($param){
    global $_G;
    $hh_config = $_G['cache']['plugin']['xigua_hh'];

    $info = $param['info'];
    $uid = intval($info['data'][1]['uid']);
    if(C::t('#xigua_hh#xigua_hh_member')->fetch($uid, true)){
        C::t('#xigua_hh#xigua_hh_member')->update($uid, array(
            'status' => $hh_config['needshen'] ? '0' : '1',
            'haspay' => 1,
        ));
    }
    return true;
}

function lang_hh($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hh', $lang);
    }else{
        return lang('plugin/xigua_hh', $lang);
    }
}

function hh_price_join($str){
    $ar = array();
    foreach (explode("\n", trim($str)) as $index => $item) {
        list($name, $price, $percentage, $lazy, $subpct, $_hide, $opensh, $fastincome) = explode('#', trim($item));
        $ar[$index] = array(
            'name' => trim($name),
            'oldname' => trim($name),
            'price' => trim($price),
            'price_display' => '&yen;'.trim(str_replace('.00','', $price)),

            'percent' => round(trim(str_replace('%', '', $percentage)), 2),
            'subpct' => round(trim(str_replace('%', '', $subpct)), 2),

            'percentage' => trim($percentage),
            'subpctage' => trim($subpct),
            'lazy' => intval($lazy),
            'hide' => intval($_hide),
            'opensh' => intval($opensh),
            'fastincome' => intval($fastincome),
        );
    }
    return $ar;
}
function hh_yongjiu_join($str){
    $ar = array();
    foreach (explode("\n", trim($str)) as $index => $item) {
        list($name, $price, $percentage, $lazy, $subpct) = explode('#', trim($item));
        $name = trim($name);
        $ar[$name] = array(
            'name' => $name,
            'price' => trim($price),
        );
    }
    return $ar;
}

function hh_init(){
    return true;
}

function  hh_my_index(){
    return true;
}

function hb_join_index(){
    return true;
}