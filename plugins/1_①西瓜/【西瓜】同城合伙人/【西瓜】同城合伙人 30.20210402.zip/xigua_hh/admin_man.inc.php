<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
$hh_config = $_G['cache']['plugin']['xigua_hh'];
$hh_type = hh_parse_type($hh_config['price_join']);
/*$hher = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare_by_fansuid(1);
print_r($hher['joininfo']['percent']);*/
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$sta = array(
    1=>lang_hh('shen1',0),
    -1=>lang_hh('shen-1',0),
    0=>lang_hh('shen0',0),
);

$page = max(1, intval(getgpc('page')));
$lpp   = 100;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hh#xigua_hh_member')->deletes($delete);
    }

    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            $item['endts'] = strtotime($item['endts']);
            $item['upts'] = TIMESTAMP;
            $item['joininfo'] = serialize($hh_type[$item['type']]);
            unset($item['type']);

            if($item['status']==1){
                $old = C::t('#xigua_hh#xigua_hh_member')->fetch($index);
            }else{
                $old = array();
            }
            $rt = C::t('#xigua_hh#xigua_hh_member')->update($index, $item);
            if($old && $old['status']!=1 && $item['status']==1){
                notification_add($old['uid'],'system', lang_hh('note_1', 0),array('url' => "$SCRITPTNAME?id=xigua_hh&ac=my"),1);
            }
        }
    }
    if($n = $_GET['n']){
        foreach ($n['uid'] as $index => $uid) {
            $uid = intval($uid);
            if($uid<1){
                continue;
            }
            if(C::t('#xigua_hh#xigua_hh_member')->fetch($uid)){
               continue;
            }
            $endts = strtotime($n['endts'][$index]);
            $status = $n['status'][$index];
            $joininfo = serialize($hh_type[$n['type'][$index]]);
            $data = array(
                'uid'      => $uid,
                'crts'     => TIMESTAMP,
                'upts'     => TIMESTAMP,
                'endts'    => $endts,
                'status'   => $status,
                'joininfo' => $joininfo,
                'months'   => 0,
                'order_id' => '',
                'haspay'   => 0,
            );
            C::t('#xigua_hh#xigua_hh_member')->insert($data);
        }
    }
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_man&status={$_GET['status']}", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}else if($keyword){
    $wherearr[] = " ( joininfo LIKE '%$keyword%' ) ";
}
if(isset($_GET['status']) && $_GET['status']!==''){
    $wherearr[] = "status='".intval($_GET['status'])."'";
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_man&status={$_GET['status']}");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="UID" value="'.$_GET['keyword'].'" class="txt" /> ';

foreach ($sta as $index => $item) {
    $chk = isset($_GET['status']) && $_GET['status']==$index && $_GET['status']!=='' ? 'checked':'';
    echo " <label><input type=\"radio\" name=\"status\" value=\"$index\" $chk>$item</label>";
}

echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';

showtableheader(lang_hh('hhrmanage', 0));
showtablerow('class="header"',array(),array(
    lang_hb('del', 0),
    lang_hb('uid', 0),
    lang_hb('username', 0),
    lang_hb('mobile', 0),
    lang_hh('guoqi', 0),
    lang_hh('tongji', 0),
    lang_hh('level', 0),
    lang_hh('stat', 0),
    lang_hh('fans', 0),
    lang_hh('crts', 0) .'<br>'.lang_hh('upts', 0),
));

$res = C::t('#xigua_hh#xigua_hh_member')->fetch_all_by_page($start_limit, $lpp, $wherearr, 'totalfans DESC');
$icount = C::t('#xigua_hh#xigua_hh_member')->fetch_count_by_page($wherearr);

foreach ($res as $v) {
    $uids[] = $v['uid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $hbusers = DB::fetch_all('SELECT uid,mobile,money FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');

    $total_sum = DB::fetch_all("SELECT uid, sum(money) as m FROM %t WHERE uid IN (%n) AND reach<>-2 GROUP BY uid", array('xigua_hh_income', $uids) ,'uid');
}
foreach ($res as $v) {
    $uid = $v['uid'];

    $toj = lang_hh('qianbao1', 0).": <b style='color:forestgreen'>".floatval($hbusers[$uid]['money']).'</b> '."
<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_user&mid=$uid'>".lang_hb('qbjl',0)."</a>
<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_user&mtid=$uid'>".lang_hb('txjl',0)."</a>
".'<br>';
    $toj .= lang_hh('leijiti', 0).": <b style='color:orangered'>". floatval($total_sum[$uid]['m']).'</b>';
/*
 *     $total_sum = C::t('#xigua_hh#xigua_hh_income')->sum_total_by_uid($uid);
    $month_sum = C::t('#xigua_hh#xigua_hh_income')->sum_month_by_uid($uid);

    $toj .= '<br>'."����������: <b style='color:orangered'>".floatval($month_sum).'</b>'.'<br>';
    $toj .= "�ۼ�������: <b style='color:orangered'>".floatval($total_sum) .'</b>';*/

    $sel = $seltype = '';
    foreach ($sta as $index => $item) {
        if($v['status'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }
    foreach ($hh_type as $index => $item) {
        $ext = lang_hh('ticheng1',0).": {$item['percentage']}".lang_hh('ticheng2',0).": {$item['subpctage']} ".lang_hh('zhangqi',0).": {$item['lazy']}".lang_hb('day',0);
        if($v['joininfo']['name'] == $index){
            $seltype .= "<option value=\"$index\" selected>$index $ext</option>";
        }else{
            $seltype .= "<option value=\"$index\">$index $ext</option>";
        }
    }

    $endts = date('Y-m-d H:i:s', $v['endts']);
    $crts = date('Y-m-d H:i:s', $v['crts']);
    $upts = date('Y-m-d H:i:s', $v['upts']);

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$uid' />",
        $uid,
        "<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
        $hbusers[$v['uid']]['mobile'] ? $hbusers[$v['uid']]['mobile'] : '-',
        "<input type=\"text\" style='width:150px' class=\"txt\" name=\"r[$uid][endts]\" value=\"$endts\" onclick=\"showcalendar(event, this, 1)\">",

        $toj,
        "<select name='r[$uid][type]'>$seltype</select>",
        "<select name='r[$uid][status]'>$sel</select>",
        lang_hh('yiji',0).': '."<input style='width:30px' name=\"r[$uid][totalfans]\" value=\"{$v['totalfans']}\" /><br>".
        lang_hh('erji',0).': '."<input style='width:30px' name=\"r[$uid][totalsecfans]\" value=\"{$v['totalsecfans']}\" />",
        "$crts<br>"."$upts",

    ));
}
if(!$res){
    $sel = $seltype = '';
    foreach ($sta as $index => $item) {
        $sel .= "<option value=\"$index\">$item</option>";
    }
    foreach ($hh_type as $index => $item) {
        $ext = lang_hh('ticheng1',0).": {$item['percentage']}".lang_hh('ticheng2',0).": {$item['subpctage']} ".lang_hh('zhangqi',0).": {$item['lazy']}".lang_hb('day',0);
        $seltype .= "<option value=\"$index\">$index $ext</option>";
    }
}
?>
<tr>
    <td>&nbsp;</td>
    <td colspan="99"><div>
        <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hh('new')?></a>
    </div></td>
</tr>
<?php
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_man&lpp=$lpp&keyword=$keyword&status={$_GET['status']}", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism��taobao _com*/

function lang_hh($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hh', $lang);
    }else{
        return lang('plugin/xigua_hh', $lang);
    }
}
function hh_parse_type($str){
    $ar = array();
    foreach (explode("\n", trim($str)) as $index => $item) {
        list($name, $price, $percentage, $lazy, $subpct) = explode('#', trim($item));
        $name = trim($name);
        $ar[$name] = array(
            'name' => $name,
            'price' => trim($price),
            'price_display' => '&yen;'.trim(str_replace('.00','', $price)),

            'percent' => round(trim(str_replace('%', '', $percentage)), 2),
            'subpct' => round(trim(str_replace('%', '', $subpct)), 2),

            'percentage' => trim($percentage),
            'subpctage' => trim($subpct),
            'lazy' => intval($lazy)
        );
    }
    return $ar;
}
?>
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>

<script>
    var rowtypedata = [
        [
            [1, ''],
            [1,'<input type="text" class="txt" name="n[uid][]" value="0" />', 'td25'],
            [2, ''],
            [1, '<input type="text" style="width:150px" class="txt" name="n[endts][]" onclick="showcalendar(event, this, 1)">'],
            [1, '<select name="n[status][]"><?php echo $sel;?></select>'],
            [1, '<select name="n[type][]"><?php echo $seltype;?></select>'],
            [5,'<div><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
        ]
    ];
</script>