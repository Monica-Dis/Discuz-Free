<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$uids = $hkusers = array();
if($hh_config['showhk'] && $_G['cache']['plugin']['xigua_hk']){
    foreach ($list as $index => $li) {
        $uids[$li['fansuid']] = $li['fansuid'];
    }
    if($uids){
        $hkusers = DB::fetch_all("SELECT uid FROM %t WHERE uid IN (%n) AND status=1 AND endts>%s", array('xigua_hk_card', $uids, TIMESTAMP), 'uid');
    }
}