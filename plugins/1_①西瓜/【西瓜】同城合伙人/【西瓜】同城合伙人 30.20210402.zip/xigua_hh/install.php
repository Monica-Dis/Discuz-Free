<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_hh_income` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `reach` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `indate` date NOT NULL,
 `money` decimal(10,2) NOT NULL,
 `ratio` decimal(10,2) NOT NULL,
 `fansuid` int(11) NOT NULL,
 `level` int(11) NOT NULL,
 `info` text NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `crts` (`crts`),
 KEY `indate` (`indate`),
 KEY `fansuid` (`fansuid`),
 KEY `reach` (`reach`),
 KEY `level` (`level`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hh_invite` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `fansuid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `fansuid` (`fansuid`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hh_member` (
 `uid` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `status` int(11) NOT NULL DEFAULT '0',
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `joininfo` varchar(5120) NOT NULL,
 `months` int(11) NOT NULL,
 `order_id` varchar(32) NOT NULL,
 `haspay` int(11) NOT NULL DEFAULT '0',
 `totalfans` int(11) NOT NULL,
 `totalsecfans` int(11) NOT NULL,
 PRIMARY KEY (`uid`),
 KEY `endts` (`endts`),
 KEY `status` (`status`),
 KEY `order_id` (`order_id`),
 KEY `haspay` (`haspay`)
) ENGINE=InnoDB;

SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hh/discuz_plugin_xigua_hh.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hh/discuz_plugin_xigua_hh_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hh/discuz_plugin_xigua_hh_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hh/discuz_plugin_xigua_hh_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hh/discuz_plugin_xigua_hh_TC_UTF8.xml');

$finish = TRUE;



@unlink(DISCUZ_ROOT . './source/plugin/xigua_hh/install.php');


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'idtype\'', array('xigua_hh_income'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hh_income` ADD `idtype` VARCHAR(80) NOT NULL;

ALTER TABLE `pre_xigua_hh_income` ADD `thirdid` VARCHAR(200) NOT NULL;

ALTER TABLE `pre_xigua_hh_income` ADD INDEX( `idtype`);

ALTER TABLE `pre_xigua_hh_income` ADD INDEX( `thirdid`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'realints\'', array('xigua_hh_income'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hh_income` ADD `realints` INT(11) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'oldback\'', array('xigua_hh_member'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hh_member` ADD `oldback` TEXT NOT NULL;

SQL;
    runquery($sql);
}