<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval include_once DISCUZ_ROOT.'source/plugin/xigua_hh/include/c_fansli.php';}--><!--{loop $list $v}-->
<div data-uid="{$v[uid]}" data-fansuid="{$v[fansuid]}" data-username="{$v[fans][username]}" data-href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[fansuid]" class="weui-cell weui-cell_access <!--{if $_GET['do']!='up'}-->fans_li
<!--{else}-->fans_li2<!--{/if}-->" id="li_{$v[fansuid]}">
    <div class="weui-cell__hd" style="position: relative;margin-right: 10px;">
        <img src="{avatar($v[fansuid], 'big', true)}" style="width:30px;height:30px;margin-right:5px;display:block;border-radius:50%" />
    </div>
    <div class="weui-cell__bd">
        <p>{$v[fans][username]}
            <!--{if $hkusers[$v[fansuid]]}-->
            <img src="$hh_config[showhk]" style="height: 18px;vertical-align: middle;display: inline-block;">
            <!--{/if}--></p>
        <!--{if $v[buser]}--><p class="weui-desc">{lang xigua_hh:sj}: {$v[buser][username]}</p><!--{/if}-->
    </div>
    <div class="weui-cell__ft">
        $v[crts_u]
    </div>
</div>
<!--{/loop}-->
