<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hh:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{if $hh_mode2}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hh&ac=myfans" class="weui-navbar__item <!--{if !$do}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hh:yiji}{lang xigua_hh:fans}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hh&ac=myfans&do=sec" class="weui-navbar__item <!--{if $do=='sec'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hh:erji}{lang xigua_hh:fans}</span>
        </a>
        <!--{if $hh_config[allowsj]}-->
        <a href="$SCRITPTNAME?id=xigua_hh&ac=myfans&do=up" class="weui-navbar__item  <!--{if $do=='up'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:wode}{lang xigua_hh:sj}</span>
        </a>
        <!--{/if}-->
    </div>
    <!--{/if}-->
    <div  id="list" class="weui-cells p0 before_none"></div>
    <script>
        var loadingurl = window.location.href+'&ac=fans_li&do=$do&inajax=1&pagesize=20&page=';
    </script>
    <!--{template xigua_hb:loading}-->
</div>

<!--{eval $tabbar=1;}-->
<!--{template xigua_hh:footer}-->
<script>
$(document).on('click','.fans_li', function () {
    var that = $(this);
    $.modal({
        title: '{lang xigua_hh:fansname}',
        text: that.data('username'),
        buttons: [
            { text: "{lang xigua_hh:cancel}", className: "default", onClick: function(){ } },
            { text: "{lang xigua_hh:jiechu}", onClick: function(){
                var fansuid = that.data('fansuid');
                confirm_del('{lang xigua_hh:qjiechu}', window.location.href+'&ac=myfans&do=del&formhash={FORMHASH}&delid='+fansuid, fansuid);
            } },
            { text: "{lang xigua_hh:view}", onClick: function(){ window.location.href=that.data('href')} }
        ]
    });
});
$(document).on('click','.fans_li2', function () {
    var that = $(this);
    $.modal({
        title: '{lang xigua_hh:fansname}',
        text: that.data('username'),
        buttons: [
            { text: "{lang xigua_hh:cancel}", className: "default", onClick: function(){ } },
            { text: "{lang xigua_hb:sixin}", className: "default", onClick: function(){ window.location.href="$SCRITPTNAME?id=xigua_hb&ac=chat&touid="+that.data('fansuid');  } },
            { text: "{lang xigua_hh:view}", onClick: function(){ window.location.href=that.data('href')} }
        ]
    });
});

</script>