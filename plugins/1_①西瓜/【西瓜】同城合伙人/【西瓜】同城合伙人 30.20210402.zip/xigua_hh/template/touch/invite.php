<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hh:header}-->
<div class="page__bd">
    <!--{if stripos($_SERVER['HTTP_USER_AGENT'], 'Android') && HB_INWECHAT}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <div class="bgf">
        <!--{if $invitetpl}-->
        <div class="hh_sw swiper-container swiper-container-horizontal">
            <div class="swiper-wrapper mt0">
                <!--{loop $invitetpl $_lk $_lv}-->
                <div class="swiper-slide" ><img src="{$_lv}" class="main-img"></div>
                <!--{/loop}-->
            </div>
        </div>
        <!--{/if}-->

        <div class="fix-bottom" style="position:relative">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_primary" onclick="$.toptip('{lang xigua_hh:savetip}', 'success');return false;" href="javascript:;">{lang xigua_hh:picivt}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_default fzbtn1" href="javascript:;" data-clipboard-text="{echo hb_currenturl()}">{lang xigua_hh:linkvt}</a>
            </div>
        </div>

        <article class="weui-article">
            <section>
                <h2 class="title main_color"><b>{lang xigua_hh:ivttip}</b></h2>
                <section>{$haochu}</section>
            </section>
        </article>
    </div>

    <div class="bottom_fix"></div>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hh:footer}--><script src="source/plugin/xigua_hb/static/js/clipboard.min.js?{VERHASH}"></script>
<script>
var clipboard = new ClipboardJS('.fzbtn1');
clipboard.on('success', function(e) {
    $.alert(''+e.text+' <br> {lang xigua_hh:fzcg}!'+'');
});
</script>