<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hh:header}-->
<script src="source/plugin/xigua_hh/static/js/echarts.simple.min.js?{VERHASH}"></script>
<div class="page__bd">

    <!--{template xigua_hb:common_nav}-->
    <div class="weui-cells__title">{lang xigua_hh:qushiin7}</div>
    <div class="weui-cells">
        <div class="weui-cell">
            <div id="main1" class="chart_list"></div>
        </div>
    </div>
    <div class="weui-cells__title">{lang xigua_hh:fansin7}</div>
    <div class="weui-cells">
        <div class="weui-cell">
            <div id="main2" class="chart_list"></div>
        </div>
    </div>
</div>
<script>
    var myChart1 = echarts.init(document.getElementById('main1'));
    var option1 ={
        tooltip: {            trigger: "axis"        },
        toolbox: {
            feature: {
                dataView: {                    readOnly: true                },
                magicType: {
                    type: ["line", "bar", "stack", "tiled"],
                    show: false
                }
            }
        },
        xAxis: [{
                type: "category",
                boundaryGap: false,
                data: <!--{eval echo json_encode(array_keys($income_days));}-->,
                axisLine: {
                    show: true,
                    lineStyle: {                        type: "dashed",                        width: 1,                        color: "#999"                    }
                },
                axisTick: {                    show: false                },
                splitLine: {                    show: false                },
                splitArea: {                    show: false                }
            }],
        yAxis: [
            {
                type: "value",
                axisLine: {
                    show: true,
                    lineStyle: {                        type: "dashed",                        color: "#999",                        width: 1                    }
                },
                axisLabel: {                    show: true,                    margin: 3                },
                axisTick: {                    show: false                },
                splitArea: {                    show: false                },
                splitLine: {                    show: false                }
            }
        ],
        series: [
            {
                name: "qushi",
                type: "line",
                data: <!--{eval echo json_encode(array_values($income_days));}-->,
                smooth: true,
                itemStyle: {
                    normal: {
                        areaStyle: {                            color: "#edf2fc"                        },
                        color:'#65a8ff'
                    }
                },
                lineStyle:{
                    normal:{                        width:1,                        color: "#65a8ff"                    }
                }
            }
        ],
        grid: {            x: 35,            y: 15,            x2: 20,            y2: 30        }
    };
    myChart1.setOption(option1);

    var myChart2 = echarts.init(document.getElementById('main2'));
    var option2 ={
        tooltip: {            trigger: "axis"        },
        toolbox: {
            feature: {
                dataView: {                    readOnly: true                },
                magicType: {                    type: ["line", "bar", "stack", "tiled"],                    show: false                }
            }
        },
        xAxis: [
            {
                type: "category",
                boundaryGap: false,
                data: <!--{eval echo json_encode(array_keys($income_days));}-->,
                axisLine: {
                    show: true,
                    lineStyle: {                        type: "dashed",                        width: 1,                        color: "#999"                    }
                },
                axisTick: {                 show: false                },
                splitLine: {show: false},
                splitArea: {show: false}
            }
        ],
        yAxis: [
            {
                type: "value",
                axisLine: {
                    show: true,
                    lineStyle: {                        type: "dashed",                        color: "#999",                        width: 1                    }
                },
                axisLabel: { show: true, margin: 3 },
                axisTick: {                    show: false                },
                splitArea: {                    show: false                },
                splitLine: {                    show: false                }
            }
        ],
        series: [
            {
                name: "qushi",
                type: "line",
                data: <!--{eval echo json_encode(array_values($fans_days));}-->,
                smooth: true,
                itemStyle: {
                    normal: {
                        areaStyle: {                            color: "#fcefed"                        },
                        color:'#ff6565'
                    }
                },
                lineStyle:{
                    normal:{                        width:1,                        color: "#ff6565"                    }
                }
            }
        ],
        grid: {            x: 35,            y: 15,            x2: 20,            y2: 30        }
    };
    myChart2.setOption(option2);
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hh:footer}-->