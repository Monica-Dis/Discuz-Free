<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=member&uid={$v[orderuser][uid]}">
    <div class="weui-cell__hd weui-head_fix">
        <img class="weui-head_img" src="{avatar($v[orderuser][uid], 'big', true)}" />
        <span class="weui-desc f10">$v[crts_u]</span>
    </div>
    <div class="weui-cell__bd">
        <p class="main_color f16"><!--{if $v[orderuser][uid]==$v[fans][uid]}--><em class="mod-lv is-green">{lang xigua_hh:yijidd}</em><!--{else}--><em class="mod-lv is-star">{lang xigua_hh:erjidd}</em><!--{/if}-->{lang xigua_hh:tc} +{$v[money]} {lang xigua_hb:yuan}</p>
        <p class="weui-desc"><p class="color-tumblr">{lang xigua_hh:oinfo2}{$v[info][baseprice]}{lang xigua_hb:yuan}</p> {$v[orderuser][username]} {$v[info][subject]}</p>
        <!--{if $do == 'reach'}-->
        <!--{if $v[realints]>0}-->
        <p class="weui-desc">{lang xigua_hh:sjdzrq}: {echo date('Y-m-d H:i:s', $v[realints])}</p>
        <!--{/if}-->
        <!--{else}-->
        <p class="weui-desc color-red">{lang xigua_hh:ddrq}: {$v[indate]}</p>
        <!--{/if}-->
    </div>
    <div class="weui-cell__ft"></div>
</a>
<!--{/loop}-->
