<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hh:header}-->
<div class="page__bd">
    <!--{if HB_INWECHAT}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <div class=""><style>.weui-grid{padding-left:0;padding-right:0}</style>
        <!--{if $topnavslider}-->
        <div class="swipe cl" data-speed="5000">
            <div class="swipe-wrap">
                <!--{loop $topnavslider $_lk $_lv}-->
                <div><a href="{$_lv[href]}"><img src="{$_lv[src]}" ></a></div>
                <!--{/loop}-->
            </div>
            <nav class="cl bullets bullets1">
                <ul class="position">
                    <!--{loop $topnavslider $k $slider}-->
                    <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                    <!--{/loop}-->
                </ul>
            </nav>
        </div>
        <!--{/if}-->

        <div class="weui-cells__title">{lang xigua_hh:plzchoice}</div>
        <div class="weui-cells">
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd">
                    <input class="weui-input" id="hhr" type="text" name="jontype" value="{$first_prj[name]}" data-values="{$first_val}" placeholder="{lang xigua_hh:plzchoice_click}">
                </div><div class="weui-cell__ft">
                </div>
            </div>
        </div>
        <div class="weui-cells__title">{lang xigua_hh:leveltq}</div>
        <div class="weui-grids bgf weui-grids-nob">
            <a href="javascript:;" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-fensiguanli color-good f28"></i>
                </div>
                <p class="weui-grid__label c9 f15" style="margin-top:20px">
                    <span>{lang xigua_hh:joinprice}</span>
                    <span class="main_color f12" id="t1" style="display:block">{$first_prj['price_display']}/{lang xigua_hh:yue} <!--{if $yjprj[$first_prj[oldname]]}-->({$yjprj[$first_prj[oldname]]['price']}{lang xigua_hh:yuan}/{lang xigua_hh:yongjiu})<!--{/if}--></span>
                </p>
            </a>
            <a href="javascript:;" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-shouru color-twitter f28"></i>
                </div>
                <p class="weui-grid__label c9 f15" style="margin-top:20px">
                    <span>{lang xigua_hh:tichengbl}</span>
                    <span class="main_color f12" id="t2" style="display:block">{$first_prj['percentage']}<!--{if $hh_mode2}-->({lang xigua_hh:erji}{$first_prj[subpctage]})<!--{/if}--></span>
                </p>
            </a>
            <a href="javascript:;" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-zhangqiqiehuan color-flickr f28"></i>
                </div>
                <p class="weui-grid__label c9 f15" style="margin-top:20px">
                    <span>{lang xigua_hh:zhangqitian}</span>
                    <span class="main_color f12" id="t3" style="display:block">{$first_prj[lazy]}{lang xigua_hh:day}</span>
                </p>
            </a>
        </div>
        <article class="weui-agree weui-article">
            <section>
                <h3><b class="tv main_color">{$first_prj[name]}</b>{lang xigua_hh:joinprice}<b class="t1 main_color">{$first_prj['price_display']}/{lang xigua_hh:yue} <!--{if $yjprj[$first_prj[oldname]]}-->({$yjprj[$first_prj[oldname]]['price']}{lang xigua_hh:yuan}/{lang xigua_hh:yongjiu})<!--{/if}--></b></h3>
                <h3>{lang xigua_hh:jointip1}<b class="main_color t2">{$first_prj['percentage']}<!--{if $hh_mode2}-->({lang xigua_hh:erji}{$first_prj[subpctage]})<!--{/if}--></b>{lang xigua_hh:jointip2}</h3>
                <h3>{lang xigua_hh:jointip3}<b class="main_color">T+<em class="t3">{$first_prj[lazy]}</em></b>{lang xigua_hh:jointip4}<b class="main_color t3">{$first_prj[lazy]}{lang xigua_hh:day}</b>{lang xigua_hh:jointip5}</h3>
                <div id="pricehide none" style="display:none;">{$first_prj['price']}</div>
            </section>
        </article>

    </div>

    <div class="bottom_fix"></div>
    <div class="fix-bottom">
        <a class="weui-btn weui-btn_primary <!--{if $renew && $dis}-->weui-btn_disabled<!--{/if}-->" id="dojoinsubmit" onclick="return hh_reconfirm();"><!--{if $renew}-->
            <!--{if $xufei}-->{lang xigua_hh:yiguoqi}<!--{else}-->{lang xigua_hh:shengji}<!--{/if}--><!--{else}-->{lang xigua_hh:lijicheng}<!--{/if}--></a>
    </div>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hh:footer}-->
<script>
    var sqs = [], tits = [], tq=[], jsbumit = $('#dojoinsubmit'), t_price = [], yongjiu=[];
    <!--{loop $yjprj $vvv}-->
    yongjiu['{$vvv[name]}'] = '{$vvv[price]}';
    <!--{/loop}-->
    <!--{loop $prj $_k $_v}-->
    t_price[$_k] = '{$_v[price]}';
    tits[$_k] = '{$_v[name]}';
    tq[$_k] = {
        t1:'{$_v[price_display]}/{lang xigua_hh:yue} <!--{if $yjprj[$_v[oldname]]}-->({$yjprj[$_v[oldname]][price]}{lang xigua_hh:yuan}/{lang xigua_hh:yongjiu})<!--{/if}-->',
        t2:'{$_v[percentage]}<!--{if $hh_mode2}-->({lang xigua_hh:erji}{$_v[subpctage]})<!--{/if}-->',
        t3:'{$_v[lazy]}{lang xigua_hh:day}',
        t4:'{$_v[price]}',
    };
    sqs.push({title:tits[$_k], value:'$_k'});
    <!--{/loop}-->
    $("#hhr").select({
        title: "{lang xigua_hh:plzchoice_click}",
        items: sqs,
        onChange:function (d) {
            var dv = tq[d.values];
            $('#t1,.t1').html(dv.t1);
            $('#t2,.t2').html(dv.t2);
            $('#t3,.t3').html(dv.t3);
            $('.tv').html(tits[d.values]);
            <!--{if $renew && $dis}-->
            if('{$first_val}' == d.values){
                jsbumit.addClass('weui-btn_disabled');
                return;
            }
            <!--{/if}-->
            jsbumit.removeClass('weui-btn_disabled');
        }
    });

    function hh_reconfirm(){
        if(jsbumit.hasClass('weui-btn_disabled')){
            return false;
        }
        <!--{if $renew && $dis}-->
        $.confirm('{lang xigua_hh:shengjiconfirm}', function () {
            joinsubmit();
        }, function () {

        });
        <!--{else}-->
        joinsubmit();
        <!--{/if}-->
        return false;
    }
    function joinsubmit () {
        var acs = [], ations = [];
        var val = $('#hhr').data('values');
        var tit = tits[val];
        <!--{loop $months $_k $_v}-->
        var dfttxt = "{echo $_v.lang_hh('geyue', 0);}/"+ parseFloat(parseInt('$_v')*100 * t_price[val])/100 + '{lang xigua_hh:yuan}';
        if($_v==999){
            dfttxt = '{lang xigua_hh:yongjiu}';
            dfttxt += yongjiu[tit]>0 ? '/'+yongjiu[tit]+'{lang xigua_hh:yuan}' : '';
        }
        acs.push({text: dfttxt,
            className:'{$_v}',
            onClick: function() {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: '{$SCRITPTNAME}?id=xigua_hh&ac=join&inajax=1&st={$_GET[st]}&{echo $renew?"&do=renew":""}',
                    data:{formhash:'{FORMHASH}',months:'{$_v}',jointype:val},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });
        ations.push('{$_v}');
        <!--{/loop}-->
        $.actions({ title:tit, actions: acs });
    }
</script>