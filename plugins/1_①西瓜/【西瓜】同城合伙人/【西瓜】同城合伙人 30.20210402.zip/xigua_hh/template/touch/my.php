<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hh:header}--><!--{eval $no_header_fix=1;}--><style>.x_header{position:relative}</style>
<div class="page__bd">
<!--{if !$do}-->
    <div class="do_bd">
        <!--{template xigua_hb:common_nav}-->

        <div class="mt0 main_bg hh_my_head">
            <i class="header-annimate-element1"></i>
            <i class="header-annimate-element4"></i>
            <i class="header-annimate-element5"></i>
            <i class="header-annimate-element6"></i>
            <i class="header-annimate-element7"></i>
            <i class="header-annimate-element8"></i>
            <i class="header-annimate-element9"></i>

            <div class="hh_my_head_in">

                <div class="main_yen">
                    <span><em class="f18">&yen;&nbsp;</em><em id="njum1">{$today_sum}</em></span>
                    <em class="f12">{lang xigua_hh:today}</em>
                </div>

                <div class="weui-flex sec_yen">
                    <a class="weui-flex__item" <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jumpDownload();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}-->>
                        <span><em class="f18">&yen;&nbsp;</em><em id="njum2">{$hb_money}</em></span>
                        <em class="f12">{lang xigua_hh:keti}</em>
                    </a>
                    <div class="weui-flex__item">
                        <span><em class="f18">&yen;&nbsp;</em><em id="njum3">{$total_sum}</em></span>
                        <em class="f12">{lang xigua_hh:leijiti}</em>
                    </div>
                </div>

            </div>
        </div>
    <div class="weui-cells mt0 after_none">
        <div class="chip-row">
            <div class="toutiao" style="font-weight:normal;">$hh_config[toutitle]</div>
            <div class="toutiao-slider swiper-container" id="newsSlider">
                <ul class="swiper-wrapper" style="margin-top:0!important;">
                    <!--{loop $incomes $__v}-->
                    <li class="swiper-slide">{$users[$__v[uid]][username]} {$__v[crts_u]} {lang xigua_hb:datixian} <em class="color-red2">{$__v[money]}{lang xigua_hh:yuan}</em></li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
    </div>
    <!--{if $_G['cache']['plugin']['xigua_hh']}-->
    <!--{eval $hhme = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G[uid]);}-->
    <!--{if $hhme}-->
    <div class="weui-cells">
        <a class="weui-cell weui-cell_access" href="<!--{if $hhme[display]}--><!--{if $hhme[end]}-->$SCRITPTNAME?id=xigua_hh&ac=join&do=renew<!--{else}-->$SCRITPTNAME?id=xigua_hh&ac=join&do=renew<!--{/if}--><!--{elseif $hhme[unpay]}-->javascript:myhh_pay('{$hhme[order][subject]}','{$hhme[order][baseprice]}', '{$hhme[order][order_id]}');<!--{else}-->javascript:$.toast('{lang xigua_hh:shen0}');<!--{/if}-->">
            <div class="weui-cell__hd"><i class="iconfont icon-hehuoren color-red f18"></i></div>
            <div class="weui-cell__bd">
                <p>{$hhme[joininfo][name]}</p>
            </div>
            <div class="weui-cell__ft"><!--{if $hhme[display]}--><!--{if $hhme[end]}-->{lang xigua_hh:yiguoqi}<!--{else}-->{lang xigua_hh:youxiaoqidao}{$hhme[endts_u]}<!--{/if}--><!--{else}-->{$hhme[status_u]}<!--{/if}--></div>
        </a>
    </div>
    <!--{else}-->
    <div class="weui-cells">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hh&ac=join&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-hehuoren color-red f18"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:joinhh}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
    </div>
    <!--{/if}-->
    <!--{/if}-->

        <div class="weui-cells">
            <!--{if !$hhme[unpay]}-->
            <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hh&ac=invite&&idu={$_G[uid]}">
                <div class="weui-cell__hd"><i class="iconfont icon-huojian color-red"></i></div>
                <div class="weui-cell__bd">
                    <p>{lang xigua_hh:gaojiazhuan}</p>
                </div>
                <div class="weui-cell__ft">{lang xigua_hh:yaoqingzhuan}</div>
            </a>
            <!--{/if}-->
            <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hh&ac=myfans">
                <div class="weui-cell__hd"><i class="iconfont icon-fensiguanli color-red"></i></div>
                <div class="weui-cell__bd">
                    <p>{lang xigua_hh:myfans}</p>
                </div>
                <div class="weui-cell__ft main_color"><!--{echo $user[totalfans]+$user[totalsecfans]}--><!--<span class="weui-badge weui-badge_dot" style="margin-left: 5px;margin-right: 5px;"></span>--></div>
            </a>
        </div>

        <div class="weui-cells">
            <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hh&ac=income">
                <div class="weui-cell__hd"><i class="iconfont icon-shouru color-orange"></i></div>
                <div class="weui-cell__bd">
                    <p>{lang xigua_hh:mingxi}</p>
                </div>
                <div class="weui-cell__ft"></div>
            </a>
            <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hh&ac=trend">
                <div class="weui-cell__hd"><i class="iconfont icon-luxian color-dropbox"></i></div>
                <div class="weui-cell__bd">
                    <p>{lang xigua_hh:qushi}</p>
                </div>
                <div class="weui-cell__ft"></div>
            </a>
            <a class="weui-cell weui-cell_access" <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jumpDownload();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}-->>
                <div class="weui-cell__hd"><i class="iconfont icon-qianbao2 color-orange"></i></div>
                <div class="weui-cell__bd">
                    <p>{lang xigua_hb:myqb}</p>
                </div>
                <div class="weui-cell__ft"></div>
            </a>
        </div>
        <div class="weui-cells">
            <a class="weui-cell weui-cell_access"  onclick='$("#guize").popup();' href="javascript:;">
                <div class="weui-cell__hd"><i class="iconfont icon-guize color-blue"></i></div>
                <div class="weui-cell__bd">
                    <p>{lang xigua_hh:guize}</p>
                </div>
                <div class="weui-cell__ft"></div>
            </a>
            <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
                <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
                <div class="weui-cell__bd">
                    <p>{lang xigua_hb:kefu}</p>
                </div>
                <div class="weui-cell__ft">{lang xigua_hb:zhwo}</div>
            </a>
        </div>
    </div>
<!--{elseif $do =='in'}-->
    <!--{template xigua_hb:loading}-->
<!--{elseif $do =='user'}-->
    <!--{template xigua_hb:loading}-->
<!--{/if}-->
</div>
<div id="guize" class="weui-popup__container" style="z-index:501;">
    <div class="weui-popup__modal bgf8">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_hh:guize}</h1>
                <section>{$hh_config[guize]}</section>
            </article>
            <div class="footer_fix"></div>
            <div class="fix-bottom" style="position:relative">
                <a class="mt0 half weui-btn weui-btn_primary" onclick='$.closePopup();' href="javascript:;">{lang xigua_hh:zhidaole}</a>
            </div>
        </div>
    </div>
</div>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hh:footer}-->
<script src="source/plugin/xigua_hb/static/countUp.js"></script>
<script>
    var options = {useEasing : true,useGrouping : true,separator : '',decimal : '.',prefix : '',suffix : ''};
    new countUp("njum1", 0, $('#njum1').text(), 2, 2.5, options).start();
    new countUp("njum2", 0, $('#njum2').text(), 2, 2.5, options).start();
    new countUp("njum3", 0, $('#njum3').text(), 2, 2.5, options).start();
    $.ajax({
        type: 'GET',
        url: _APPNAME+'?id=xigua_hh&ac=jiaozhun&inajax=1',
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){return false;}
            var s = data.lastChild.firstChild.nodeValue;
            console.log(s);
        },
        error: function() {
        }
    });
    <!--{if $_G['cache']['plugin']['xigua_hh']}-->
    function myhh_pay(tit, pri, oid){
        $.modal({
            title: "{lang xigua_hb:pay}",
            text: "<span>"+tit+" <b class='color-red'> &yen;"+pri+"</b></span>",
            buttons: [
                { text: "{lang xigua_hb:close}", className: "default"},
                { text: "{lang xigua_hh:quxiaodingdan}", className: "default", onClick: function(){myhh_dopay(0);}},
                { text: "{lang xigua_hb:pay1}", onClick: function(){myhh_dopay(oid);}}
            ]
        });
    }
    function myhh_dopay(order_id){
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_hh&ac=unjoin&inajax=1&order_id='+order_id+(order_id?'':'&do=del'),
            data:{formhash:FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () { $.hideLoading(); }
        });
    }
    <!--{/if}-->
</script>
