<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
$hh_config = $_G['cache']['plugin']['xigua_hh'];
$hh_type = hh_parse_type($hh_config['price_join']);
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}

function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}
$sta = array(
    -2=>lang_hh('ostat-2',0),
    -1=>lang_hh('ostat-1',0),
    0 =>lang_hh('ostat0',0),
    1 =>lang_hh('ostat1',0),
);

$page = max(1, intval(getgpc('page')));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hh#xigua_hh_income')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            if(isset($item['reach']) && intval($item['reach'])==0){
                $old = C::t('#xigua_hh#xigua_hh_income')->fetch($index);
            }else{
                $old = array();
            }
            C::t('#xigua_hh#xigua_hh_income')->update($index, $item);
            if($old && $old['reach']!=0){
                notification_add($old['uid'],'system', lang_hh('note_2', 0),array('url' => "$SCRITPTNAME?id=xigua_hh&ac=income", 'money'=>$old['money']),1);
            }
        }
    }
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_order", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}else{
    $keyword = stripsearchkey($keyword);
    $wherearr[] = "info LIKE '%$keyword%'";
}
if($_GET['reach']){
    $wherearr[] = "reach='".intval($_GET['reach'])."'";
}
if($_GET['level']){
    $wherearr[] = "level='".intval($_GET['level'])."'";
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_order&page=$page");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_hh('uidorder',0).'" value="'.$_GET['keyword'].'" class="txt" /> ';
foreach ($sta as $index => $item) {
    $chk = isset($_GET['reach']) && $_GET['reach']==$index ? 'checked':'';
    echo " <label><input type=\"radio\" name=\"reach\" value=\"$index\" $chk>$item</label>";
}
$chk1 = $_GET['level']==1 ? 'checked':'';
$chk2 = $_GET['level']==2 ? 'checked':'';
echo " <label><input type=\"radio\" name=\"level\" value=\"1\" $chk1>".lang_hh('yiji',0).lang_hh('fans',0)."</label>";
echo " <label><input type=\"radio\" name=\"level\" value=\"2\" $chk2>".lang_hh('erji',0).lang_hh('fans',0)."</label>";



echo '&nbsp;&nbsp;&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(20, 50, 100, 200, 500, 1000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;


echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';


echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_order&doexport=1&keyword={$_GET['keyword']}&reach={$_GET['reach']}&lpp=$lpp&level={$_GET['level']}&formhash=".formhash()."&lpp=$lpp".' class="btn" >'.lang_hh('dc', 0).'</a> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_order".' class="btn" >'.cplang('reset').'</a> ';

echo '</div>';

showtableheader(lang_hh('tichengmanage', 0));
showtablerow('class="header"',array(),array(
    lang_hb('del', 0),
    lang_hb('ID', 0),
    lang_hh('hhr', 0),
    lang_hh('caozuo', 0),
    lang_hh('ruzhangqi', 0),
    lang_hh('tichengyuan', 0),
    lang_hh('tichengbl', 0),
    lang_hh('fans', 0),
    lang_hh('ddxinxi', 0),
    lang_hh('crts', 0),
));

$res = C::t('#xigua_hh#xigua_hh_income')->fetch_all_by_page($start_limit, $lpp, $wherearr);
$icount = C::t('#xigua_hh#xigua_hh_income')->fetch_count_by_page($wherearr);

$uids = array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['fansuid'];
    $uids[] = $v['info']['fromuid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $joinifos = DB::fetch_all('SELECT joininfo FROM %t WHERE uid IN (%n)', array('xigua_hh_member', $uids), 'uid');
}
$stasel= $sta;
unset($stasel[1]);
foreach ($res as $kk => $v) {
    $id = $v['id'];
    $uid = $v['uid'];
    $fansuid = $v['fansuid'];
    $info = $v['info'];
    $fromuid = $info['fromuid'];

    $hhrtype = '';
    $joinifo = unserialize($joinifos[$uid]['joininfo']);
    foreach ($hh_type as $index => $item) {
        $ext = lang_hh('ticheng1',0).": {$item['percentage']}".lang_hh('ticheng2',0).": {$item['subpctage']} ".lang_hh('zhangqi',0).": {$item['lazy']}".lang_hb('day',0);
        if($joinifo['name'] == $index){
            $hhrtype = "<p>$index $ext</p>";
        }
    }
    $sel = $seltype = '';
    foreach ($stasel as $index => $item) {
        if($v['reach'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }
    /*if($v['reach']==1){
        $dis = 'disabled';
    }*/
    $endts = date('Y-m-d H:i:s', $v['endts']);
    $crts = date('Y-m-d H:i:s', $v['crts']);
    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        "<p><a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a></p>".$hhrtype,
        ($v['reach']>=0) ? $sta[$v['reach']]: "<select name='r[$id][reach]' $dis>$sel</select>",
        "<input type=\"text\" style='width:100px' class=\"txt\" name=\"r[$id][indate]\" value=\"{$v['indate']}\" onclick=\"showcalendar(event, this, 0)\">",
        "<input type=\"text\" style='width:80px' class=\"txt\" name=\"r[$id][money]\" value=\"{$v['money']}\">",
        "{$v['ratio']}%",

        ($fansuid==$info['fromuid']? '<em style="color:red">'.lang_hh('yiji',0).lang_hh('fans',0).'</em>'." <a href='home.php?mod=space&uid=$fansuid&do=profile' target='_blank'>{$users[$fansuid]['username']}</a>":'<em style="color:forestgreen">'.lang_hh('erji',0).lang_hh('fans',0).'</em>'." <a href='home.php?mod=space&uid=$fansuid&do=profile' target='_blank'>{$users[$fansuid]['username']}</a>".lang_hh('dofans',0)),

        lang_hh('oinfo1',0).':'.$info['subject'].
        '<br>'.lang_hh('oinfo2',0).':'.$info['baseprice'].
        '<br>'.lang_hh('oinfo3',0).':'.$info['order_id'].
        '<br>'.lang_hh('oinfo4',0).':'."<a href='home.php?mod=space&uid=$fromuid&do=profile' target='_blank'>{$users[$fromuid]['username']}</a>",
        "$crts",

    ));


    unset($res[$kk]['info']);
    unset($res[$kk]['level']);
    unset($res[$kk]['crts_u']);

    $res[$kk]['uid'] = $users[$uid]['username'];
    $res[$kk]['reach'] = $sta[$v['reach']];
    $res[$kk]['oinfo1'] = $info['subject'];
    $res[$kk]['oinfo2'] = $info['baseprice'];
    $res[$kk]['oinfo3'] = '[ '.$info['order_id'] .' ]';
    $res[$kk]['oinfo4'] = $users[$fromuid]['username'];
    $res[$kk]['crts'] = date('Y-m-d H:i:s', $res[$kk]['crts']);

}
if(submitcheck('formhash', 1) && $_GET['doexport']==1 && $_GET['formhash'] == FORMHASH){
    $title_arr= array();
    foreach ($res[0] as $index => $item) {
        $title_arr[] = lang_hh($index, 0);
    }
    export_csv($res, $title_arr);
}
if(isset($_GET['reach'])){
    $tt = "&reach={$_GET['reach']}";
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_order&lpp=$lpp&keyword={$_GET['keyword']}&level={$_GET['level']}$tt", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism��taobao _com*/

function lang_hh($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hh', $lang);
    }else{
        return lang('plugin/xigua_hh', $lang);
    }
}
function hh_parse_type($str){
    $ar = array();
    foreach (explode("\n", trim($str)) as $index => $item) {
        list($name, $price, $percentage, $lazy, $subpct) = explode('#', trim($item));
        $name = trim($name);
        $ar[$name] = array(
            'name' => $name,
            'price' => trim($price),
            'price_display' => '&yen;'.trim(str_replace('.00','', $price)),

            'percent' => round(trim(str_replace('%', '', $percentage)), 2),
            'subpct' => round(trim(str_replace('%', '', $subpct)), 2),

            'percentage' => trim($percentage),
            'subpctage' => trim($subpct),
            'lazy' => intval($lazy)
        );
    }
    return $ar;
}
?>
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>