<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function qrcode_make($url, $invitetpl){
    global $urlext;
    @include_once DISCUZ_ROOT . './source/plugin/mobile/qrcode.class.php';
    global $_G, $config, $SCRITPTNAME;
    $rs = array();
    $repath = './source/plugin/xigua_hh/cache/';

    if($config['qraut'] && 0){
        $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hb:qrauto&needqrfile=1&ode=hh_{$_G['uid']}";
        $abs_qrfile = DISCUZ_ROOT . hb_curl($url);
        do_resizeImage($abs_qrfile, 246, 246, $abs_qrfile.'.jpg', 'image/jpeg');
        $abs_qrfile = $abs_qrfile.'.jpg';
        $houzhui = 'lt.jpg';
    }else{
        $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hh&ac=invite$urlext&idu={$_G['uid']}";
        $code = md5($url.$_G['uid'].'inv1');
        $qrfile = $repath . $code . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;

        if(!is_file($abs_qrfile)) {
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if (class_exists('QRcode')) {
                QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 6);
            }
        }
        $houzhui = '_inv.jpg';
    }

    $invitetpl = array_filter(explode("\n", $invitetpl));

    $stamp = imagecreatefrompng($abs_qrfile);
    if($stamp===false){
        $stamp = imagecreatefromjpeg($abs_qrfile);
    }

    foreach ($invitetpl as $index => $item) {
        $im = DISCUZ_ROOT.trim($item);
        if(!is_file($im.$_G['uid'].$houzhui)) {
            $basename = basename($im);
            if(strpos($item,'.png')!==false){
                $im = imagecreatefrompng($im);
            }else{
                $im = imagecreatefromjpeg($im);
            }
            $marge_right = 10;
            $marge_bottom = 10;
            $sx = imagesx($stamp);
            $sy = imagesy($stamp);
            imagecopy($im, $stamp, (imagesx($im) - $sx)/2+5, (imagesy($im) - $sy)/2+40, 0, 0, imagesx($stamp), imagesy($stamp));

            $base = $repath . $basename . $_G['uid'].$houzhui;
            imagejpeg($im, DISCUZ_ROOT . $base, 100);
            $rs[] = $base;
            imagedestroy($im);
        }else{
            $rs[] = $im.$houzhui;
        }
    }
    return $rs;
}

function do_resizeImage($fromfile ,$maxwidth,$maxheight, $name, $filetype)
{
    if(!function_exists('imagejpeg')){
        return false;
    }

    $imagefunc = 'imagejpeg';
    $imagecreatefromfunc = 'imagecreatefromjpeg';
    switch($filetype) {
        case 'image/jpeg':
            $imagecreatefromfunc = function_exists('imagecreatefromjpeg') ? 'imagecreatefromjpeg' : '';
            $imagefunc = function_exists('imagejpeg') ? 'imagejpeg' : '';
            break;
        case 'image/gif':
            $imagecreatefromfunc = function_exists('imagecreatefromgif') ? 'imagecreatefromgif' : '';
            $imagefunc = function_exists('imagegif') ? 'imagegif' : '';
            break;
        case 'image/png':
            $imagecreatefromfunc = function_exists('imagecreatefrompng') ? 'imagecreatefrompng' : '';
            $imagefunc = function_exists('imagepng') ? 'imagepng' : '';
            break;
    }

    $im = $imagecreatefromfunc($fromfile);
    $pic_width = imagesx($im);
    $pic_height = imagesy($im);

    if(($maxwidth && $pic_width > $maxwidth) || ($maxheight && $pic_height > $maxheight))
    {
        if($maxwidth && $pic_width>$maxwidth)
        {
            $widthratio = $maxwidth/$pic_width;
            $resizewidth_tag = true;
        }
        if($maxheight && $pic_height>$maxheight)
        {
            $heightratio = $maxheight/$pic_height;
            $resizeheight_tag = true;
        }
        if($resizewidth_tag && $resizeheight_tag)
        {
            if($widthratio<$heightratio)
                $ratio = $widthratio;
            else
                $ratio = $heightratio;
        }
        if($resizewidth_tag && !$resizeheight_tag)
            $ratio = $widthratio;
        if($resizeheight_tag && !$resizewidth_tag)
            $ratio = $heightratio;
        $newwidth = $pic_width * $ratio;
        $newheight = $pic_height * $ratio;
        if(function_exists("imagecopyresampled"))
        {
            $newim = imagecreatetruecolor($newwidth,$newheight);
            imagecopyresampled($newim,$im,0,0,0,0,$newwidth,$newheight,$pic_width,$pic_height);
        }
        else
        {
            $newim = imagecreate($newwidth,$newheight);
            imagecopyresized($newim,$im,0,0,0,0,$newwidth,$newheight,$pic_width,$pic_height);
        }

        $imagefunc($newim, $name);
        imagedestroy($newim);
    }
    else
    {
        $imagefunc($im,$name);
    }
    return $name;
}