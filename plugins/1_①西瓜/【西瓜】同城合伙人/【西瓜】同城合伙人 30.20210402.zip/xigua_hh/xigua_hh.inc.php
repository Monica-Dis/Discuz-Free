<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_hh/function.php';
global $SCRITPTNAME;
global $hh_config;
global $_G;
global $hbmy;
global $hhmy;
global $aclist;
global $lolist;
global $ac;
global $do;
global $needlgi;
global $hh_mode2;
global $hh_mode1;
global $page;
global $lpp;
global $start_limit;
$hh_config = $_G['cache']['plugin']['xigua_hh'];
$hbmy = $SCRITPTNAME . '?id=xigua_hb&ac=my';
$hhmy = $SCRITPTNAME . '?id=xigua_hh&ac=my';
$aclist = array('index', 'join', 'unjoin', 'my', 'invite', 'myfans', 'fans_li', 'income', 'income_li', 'trend', 'jiaozhun');
$lolist = array('join', 'unjoin', 'income', 'trend', 'jiaozhun');
$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
$needlgi = in_array($ac, $lolist) || !(strpos($ac, 'my') === false) && !$_G['uid'];
if ($needlgi && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$hh_mode2 = $hh_config['hhmode'] == 2;
$hh_mode1 = $hh_config['hhmode'] == 1;
$page = max(1, intval(getgpc('page')));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
hh_init();
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
switch ($ac) {
	case 'join':
		hb_join_index();
		global $SCRITPTNAME;
		global $config;
		global $hh_config;
		global $_G;
		global $user;
		global $urlext;
		global $navtitle;
		global $desc;
		global $description;
		global $head_fix;
		global $midnavslider;
		global $topnavslider;
		global $prj;
		global $yjprj;
		global $months;
		global $cover;
		global $incomes;
		global $uids;
		global $users;
		global $totalfans;
		$head_fix = 1;
		check_bind(5);
		$navtitle = lang_hh('zhaohutit', 0);
		$desc = $description = $hh_config['jjhhrms'];
		$midnavslider = $topnavslider = array();
		$topnavslider = hb_parse_set($hh_config['topslider'], 1);
		$prj = hh_price_join($hh_config['price_join']);
		$yjprj = hh_yongjiu_join($hh_config['yongjiu']);
		$months = explode(',', trim($hh_config['months']));
		$ar = array();
		foreach (explode("\n", trim($hh_config['price_join'])) as $index => $item) {
			list($name, $price, $percentage, $lazy, $subpct, $hide) = explode('#', trim($item));
			if (!$hide) {
				$ar[$index] = array('name' => trim($name), 'oldname' => trim($name), 'price' => trim($price), 'price_display' => '&yen;' . trim(str_replace('.00', '', $price)), 'percent' => round(trim(str_replace('%', '', $percentage)), 2), 'subpct' => round(trim(str_replace('%', '', $subpct)), 2), 'percentage' => trim($percentage), 'subpctage' => trim($subpct), 'lazy' => intval($lazy));
			}
		}
		$prj = array_values($ar);
		if (submitcheck('formhash')) {
			$jtype = $prj[$_GET['jointype']];
			$month = intval($_GET['months']);
			if (!in_array($month, $months)) {
				hb_message(lang_hh('yuefenerr', 0), 'error');
			}
			if (!$jtype) {
				hb_message(lang_hh('error', 0), 'error');
			}
			if ($do == 'renew') {
				$renew = 1;
				$user = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
				if (!$user || $_G['uid'] != $user['uid']) {
					hb_message(lang_hh('notexists', 0));
				}
			} else {
				if (C::t('#xigua_hh#xigua_hh_member')->fetch($_G['uid'], true)) {
					hb_message(lang_hh('exists', 0));
				}
			}
			$data = array('uid' => $_G['uid'], 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'endts' => TIMESTAMP + $month * 2592000, 'status' => 0, 'joininfo' => serialize($jtype), 'months' => $month, 'order_id' => '', 'haspay' => 0);
			$price = $month == 999 && $yjprj[$jtype['name']]['price'] > 0 ? $yjprj[$jtype['name']]['price'] : abs($jtype['price']) * $month;
			if ($price > 0) {
				$data['status'] = 0 - 1;
				if ($renew) {
					$rs = C::t('#xigua_hh#xigua_hh_member')->update($_G['uid'], $data);
				} else {
					$rs = C::t('#xigua_hh#xigua_hh_member')->insert($data);
				}
				if ($rs) {
					$tit = $month == 999 ? lang_hh('yongjiu', 0) : $month . lang_hh('geyue', 0);
					$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, lang_hh('jiameng', 0) . $jtype['name'] . $tit, 'com', array('data' => array($jtype, $data), 'callback' => array('file' => 'source/plugin/xigua_hh/function.php', 'method' => 'hh_join'), 'location' => $_G['siteurl'] . $hhmy));
					C::t('#xigua_hh#xigua_hh_member')->update($_G['uid'], array('order_id' => $order_id));
					$rl = urlencode($hhmy);
					$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
					hb_message(lang_hh('jumppay', 0), 'success', $jumpurl);
				} else {
					hb_message(lang_hh('submiterr', 0));
				}
			} else {
				$fast = 0;
				if (!$hh_config['needshen_free']) {
					$data['status'] = 1;
					$fast = 1;
				}
				if ($renew) {
					$rs = C::t('#xigua_hh#xigua_hh_member')->update($_G['uid'], $data);
				} else {
					$rs = C::t('#xigua_hh#xigua_hh_member')->insert($data);
				}
				if ($rs) {
					if ($fast) {
						hb_message(lang_hh('joinsucceed', 0), 'success', $SCRITPTNAME . '?id=xigua_hh&ac=my');
					} else {
						hb_message(lang_hh('joinwait', 0), 'success', $hhmy);
					}
				} else {
					hb_message(lang_hh('submiterr', 0));
				}
			}
		} else {
			$user = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
			if ($user && !$do) {
				dheader('Location: ' . $SCRITPTNAME . '?id=xigua_hh&ac=join&do=renew' . $urlext);
			}
			if ($do == 'renew') {
				$renew = 1;
				if (!$user) {
					dheader('Location: ' . $SCRITPTNAME . '?id=xigua_hh&ac=join' . $urlext);
				}
				$reprj = array();
				$prj_key = NULL;
				foreach ($prj as $index => $item) {
					if ($item['name'] == $user['joininfo']['name']) {
						$prj_key = $index;
					}
					$reprj[$index] = $item;
				}
				$prj = $reprj;
			}
			foreach ($prj as $index => $item) {
				$first_val = $index;
				$first_prj = $item;
				break;
			}
			if ($user['display']) {
				if ($user['endts'] < TIMESTAMP) {
					$dis = 0;
					$xufei = 1;
				} else {
					$dis = 1;
				}
				$reprj = array();
				$prj_key = NULL;
				foreach ($prj as $index => $item) {
					if ($item['name'] == $user['joininfo']['name']) {
						$first_val = $prj_key = $index;
						$item['name'] = $item['name'] . '(' . lang_hh('youxiaoqi', 0) . $user['endts_u'] . ')';
						$first_prj = $item;
					}
					$reprj[$index] = $item;
				}
				$prj = $reprj;
			}
		}
		break;
	case 'unjoin':
		if (submitcheck('formhash')) {
			if ($do == 'del') {
				C::t('#xigua_hh#xigua_hh_member')->delete_unpay($_G['uid']);
				hb_message(lang_hh('cancelsucceed', 0), 'success', $hbmy);
			} else {
				$order_id = $_GET['order_id'];
				$rl = urlencode($hbmy);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
				hb_message(lang_hh('jumppay', 0), 'success', $jumpurl);
			}
		}
		break;
	case 'my':
		hh_my_index();
		global $SCRITPTNAME;
		global $config;
		global $hh_config;
		global $_G;
		global $user;
		global $urlext;
		global $navtitle;
		global $desc;
		global $custom_side;
		global $today_sum;
		global $total_sum;
		global $hbuser;
		global $hb_money;
		global $qi;
		global $cover;
		global $incomes;
		global $uids;
		global $users;
		global $totalfans;
		$user = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
		if (!$user) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_hh&ac=join' . $urlext);
		}
		$navtitle = $user['joininfo']['name'] . '-' . $_G['username'];
		$desc = $hh_config['invitedesc'];
		$custom_side = array($SCRITPTNAME . '?id=xigua_hh&ac=join&do=renew', lang_hh('leveldesc', 0));
		$today_sum = C::t('#xigua_hh#xigua_hh_income')->sum_today_by_uid($_G['uid']);
		$total_sum = C::t('#xigua_hh#xigua_hh_income')->sum_total_by_uid($_G['uid']);
		$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
		$today_sum = round($today_sum, 2);
		$total_sum = round($total_sum, 2);
		$hb_money = round($hbuser['money'], 2);
		if ($secret = $config['magapp_secret'] && $config['autoinapp'] == 1) {
			$ma_server = rtrim($config['magapp_url'], '/');
			$url = $ma_server . '/core/pay/pay/getAccountBalance?secret=' . $secret;
			$retfrom = file_get_contents($url);
			if (!$retfrom && function_exists('hb_curl')) {
				$retfrom = hb_curl($url);
			}
			if ($retma = json_decode($retfrom, true)) {
				if ($retma['code'] == 101 && $retma['success'] && $retma['data']) {
					$hb_money = $retma['data'];
				}
			}
		}
		dsetcookie('URLEXT', '&idu=' . $_G['uid'], 31536000);
		$qi = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
		$cover = $qi['cover'];
		$incomes = C::t('#xigua_hb#xigua_hb_tixian')->fetch_all_bypage(0, 10, array('return_code=\'SUCCESS\''));
		$uids = array();
		foreach ($incomes as $k => $v) {
			$uids[] = $v['uid'];
			$incomes[$k]['money'] = $incomes[$k]['amount'] / 100;
			$incomes[$k]['crts_u'] = dgmdate($incomes[$k]['upts'], 'u');
		}
		if ($uids) {
			$users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
		}
		if ($user['totalfans'] + $user['totalsecfans'] == 0) {
			$_tmplist = C::t('#xigua_hh#xigua_hh_invite')->fetch_by_uid($_G['uid'], 0, 1);
			if ($_tmplist) {
				$totalfans = C::t('#xigua_hh#xigua_hh_invite')->fetch_count_by_page(array('uid=' . $_G['uid']));
				C::t('#xigua_hh#xigua_hh_member')->update($_G['uid'], array('totalfans' => $totalfans));
			}
		}
		break;
	case 'jiaozhun':
		$_tmplist = C::t('#xigua_hh#xigua_hh_invite')->fetch_by_uid($_G['uid'], 0, 1);
		if ($_tmplist) {
			$totalfans = C::t('#xigua_hh#xigua_hh_invite')->fetch_count_by_page(array('uid=' . $_G['uid']));
			C::t('#xigua_hh#xigua_hh_member')->update($_G['uid'], array('totalfans' => $totalfans));
		}
		include template('xigua_hb:header_ajax');
		echo $totalfans;
		include template('xigua_hb:footer_ajax');
		break;
	case 'invite':
		$urlext = $urlext . '&idu=' . $_G['uid'];
		$head_fix = 1;
		$user = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
		include_once DISCUZ_ROOT . 'source/plugin/xigua_hh/invite.php';
		include_once DISCUZ_ROOT . 'source/plugin/xigua_hh/qrcode.php';
		$location = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hh&ac=invite&idu=' . $_G['uid']);
		$invitetpl = qrcode_make($location, $hh_config['invitetpl']);
		$navtitle = $hh_config['invitetitle'];
		$desc = $hh_config['invitedesc'];
		$haochu = str_replace(array('{indate}', '{percentage}', '{subpctage}'), array($user['joininfo']['lazy'], $user['joininfo']['percentage'], $user['joininfo']['subpctage']), $hh_config['haochu']);
		break;
	case 'myfans':
		$navtitle = lang_hh('myfans', 0);
		$custom_side = array($hhmy, lang_hh('hhindex', 0));
		if (submitcheck('delid', 1) && $_GET['formhash'] == FORMHASH) {
			$fansuid = intval($_GET['delid']);
			if (C::t('#xigua_hh#xigua_hh_invite')->delete_fans($fansuid, $_G['uid'])) {
				C::t('#xigua_hh#xigua_hh_member')->increase($_G['uid'], 'totalfans', 0 - 1);
				hb_message(lang_hh('jiechuok', 0), 'success');
			} else {
				if (C::t('#xigua_hh#xigua_hh_invite')->delete_fans($_G['uid'], $fansuid)) {
					C::t('#xigua_hh#xigua_hh_member')->increase($fansuid, 'totalfans', 0 - 1);
					hb_message(lang_hh('jiechuok', 0), 'success');
				}
				hb_message(lang_hh('jiechuerr', 0));
			}
		}
		break;
	case 'fans_li':
		$uid = intval($_G['uid']);
		if ($do == 'sec') {
			$list = C::t('#xigua_hh#xigua_hh_invite')->fetch_sec_by_uid($uid, $start_limit, $lpp);
		} elseif ($do == 'shop') {
			$list = C::t('#xigua_hh#xigua_hh_invite')->fetch_myfans_shop($uid, $start_limit, $lpp);
			include template('xigua_hb:header_ajax');
			include template('xigua_hs:myshop_li');
			include template('xigua_hb:footer_ajax');
		} elseif ($do == 'up') {
			$list = C::t('#xigua_hh#xigua_hh_invite')->fetch_up_by_uid($uid, $start_limit, $lpp);
		} else {
			$list = C::t('#xigua_hh#xigua_hh_invite')->fetch_by_uid($uid, $start_limit, $lpp);
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_hh:fans_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'trend':
		$uid = intval($_G['uid']);
		$navtitle = lang_hh('qushi', 0);
		$custom_side = array($hhmy, lang_hh('hhindex', 0));
		$income_days = C::t('#xigua_hh#xigua_hh_income')->sum_week_group($_G['uid']);
		$fans_days = C::t('#xigua_hh#xigua_hh_invite')->total_week_group($_G['uid']);
		break;
	case 'income':
		$uid = intval($_G['uid']);
		$navtitle = lang_hh('mingxi', 0);
		$custom_side = array($hhmy, lang_hh('hhindex', 0));
		break;
	case 'income_li':
		$uid = intval($_G['uid']);
		$where[] = 'uid=' . $uid;
		if ($do == 'reach') {
			$where[] = 'indate<=\'' . date('Y-m-d', TIMESTAMP) . '\'';
			$where[] = 'reach=1';
		} else {
			$where[] = 'reach<>1';
		}
		$list = C::t('#xigua_hh#xigua_hh_income')->fetch_u_order($where, $start_limit, $lpp);
		include template('xigua_hb:header_ajax');
		include template('xigua_hh:income_li');
		include template('xigua_hb:footer_ajax');
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_hh/template/touch/' . $ac . '.php'))) {
	include template('xigua_hh:' . $ac);
}