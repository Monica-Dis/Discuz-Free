<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
$hh_config = $_G['cache']['plugin']['xigua_hh'];
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hh#xigua_hh_invite')->deletes($delete);
    }
    if($n = $_GET['n']){
        foreach ($n['uid'] as $index => $uid) {
            $uid = intval($uid);
            $fuid = intval($n['fansuid'][$index]);
            if($uid<1 || $fuid<1){
                continue;
            }
            $data = array(
                'uid'      => $uid,
                'crts'     => TIMESTAMP,
                'fansuid'    => $fuid,
            );
            C::t('#xigua_hh#xigua_hh_invite')->insert($data, 1, 1);
        }
    }
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_fans", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword' or fansuid='$keyword'";
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_fans");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="UID,'.lang_hh('fansuid', 0).'" value="'.$_GET['keyword'].'" class="txt" /> ';
echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';

showtableheader(lang_hh('fansmanage', 0));
showtablerow('class="header"',array(),array(
    lang_hb('del', 0),
    lang_hh('ID', 0),
    lang_hh('UID', 0).'/'.lang_hb('username', 0),
    lang_hh('fansuid', 0).'/'.lang_hh('fans', 0),
    lang_hh('crts', 0),
));

$res = C::t('#xigua_hh#xigua_hh_invite')->fetch_all_by_page($start_limit, $lpp, $wherearr);
$icount = C::t('#xigua_hh#xigua_hh_invite')->fetch_count_by_page($wherearr);

foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['fansuid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}

foreach ($res as $v) {
    $uid = $v['uid'];
    $id  = $v['id'];

    $crts = date('Y-m-d H:i:s', $v['crts']);

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        "UID: $uid <br> <a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
        "UID: {$v['fansuid']} <br> <a href='home.php?mod=space&uid={$v['fansuid']}&do=profile' target='_blank'>{$v['fans']['username']}</a>",
        "$crts",
    ));
}
?>

<tr>
    <td>&nbsp;</td>
    <td colspan="99"><div>
            <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hh('new')?></a>
        </div></td>
</tr>
<?php
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hh&pmod=admin_fans&keyword=$keyword&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism��taobao _com*/

function lang_hh($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hh', $lang);
    }else{
        return lang('plugin/xigua_hh', $lang);
    }
}?>

<script>
    var rowtypedata = [
        [
            [1, '&nbsp;'],
            [1, '&nbsp;'],
            [1,'<input type="text" class="txt" name="n[uid][]" value="0" />', ''],
            [1,'<input type="text" class="txt" name="n[fansuid][]" value="0" /> <span><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></span>', '']
        ]
    ];
</script>
