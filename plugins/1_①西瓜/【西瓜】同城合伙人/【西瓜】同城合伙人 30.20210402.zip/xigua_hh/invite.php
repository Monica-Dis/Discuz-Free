<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$urlext = $urlext .'&idu='.($_G['uid'] ? $_G['uid'] : $_GET['idu']);
$urljump = $hh_config['defaultjump'];
if(!$urljump){
    $urljump = "$SCRITPTNAME?id=xigua_hb";
}
if(!$user){
    dheader("Location: $urljump&ignore1=1".$urlext);
}
if(0 && !$_SERVER['HTTP_REFERER']){
    dheader("Location: $urljump&ignore2=1".$urlext);
}
if(!$user['display'] || $user['end']){
    dheader("Location: $urljump&ignore3=1".$urlext);
    /*dheader("Location: $hbmy".$urlext);*/
}
if($_GET['idu'] && $_GET['idu']!=$_G['uid']){
    dheader("Location: $urljump&hhr_type=1".$urlext);
}