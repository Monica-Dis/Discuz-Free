<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/9/30
 * Time: 9:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$t = '<div style="display:none">'.$_G['siteurl'].'plugin.php?id=xigua_hb&mobile=2'.'</div><br><br>'.lang('plugin/xigua_hb','jiaocheng').' http://dism.taobao.com/?@xigua_hb.plugin.79644';
cpmsg($t, '','succeed');