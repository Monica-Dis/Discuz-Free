<?php
/*/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/3/27
 * Time: 13:58
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_xigua_hc
{
    public function post_message($value)
    {

        global $_G;

        if (!$_G['cache']['plugin']) {
            loadcache('plugin');
        }
        $hb_config = $_G['cache']['plugin']['xigua_hb'];
        $hc_config = $_G['cache']['plugin']['xigua_hc'];
        if (!$hb_config) {
            return true;
        }
        if (!$hc_config['open']) {
            return false;
        }
        $param = $value['param'];
        $tid = $param[2]['tid'];
        $pid = $param[2]['pid'];
        $fid = $param[2]['fid'];

        if (
            strtolower($_SERVER['REQUEST_METHOD']) == 'post'
            && (
                $param[0] == 'post_newthread_succeed'
                ||
                ($param[0] == 'post_edit_succeed')
            )
            && $tid && $pid
        ) {

            $this->post2hb($tid, $pid, $fid, 1);

        }
        if($hc_config['allowtbhf'] &&$tid && $pid && in_array($param[0], array('post_reply_succeed', 'post_reply_mod_succeed'))){

            $hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
            if ($hbuser['pingbi']) {
                return false;
            }
            $pubinfo = DB::fetch_first("SELECT * FROM %t WHERE tid=%d", array('xigua_hb_pub', $tid));

            $imglist = array();
            foreach (C::t('forum_attachment_n')->fetch_all_by_id('pid:' . $pid, 'pid', $pid) as $attach) {
                $_G['setting']['attachurl'] = $attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
                if(!$_G['setting']['attachurl']){
                    $_G['setting']['attachurl'] = 'data/attachment';
                }
                if ($attach['isimage']) {
                    $imglist[] = (($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'forum/') . $attach['attachment'];
                }
            }

            $post = DB::fetch_first("SELECT subject,message,dateline FROM %t WHERE pid=%d", array('forum_post', $pid));
            $subject = $post['subject'];
            $message = $post['message'];

            if (strpos($message, '[/img]') !== FALSE) {
                preg_match_all("/\[img.*?\](.*?)\[\/img\]/i", $message, $matchsimg);
                if ($matchsimg[1]) {
                    $imglist = array_merge($imglist, $matchsimg[1]);
                }
            }

            $pattern = "/(\[attach(img)?\]|\[(img|url|media|audio|flash)(.*)\]).*?(\[\/attach(img)?\]|\[\/(img|url|media|audio|flash)\])/i";
            $message = preg_replace($pattern, '', $message);

//            require_once libfile('function/discuzcode');
//            $message = discuzcode($hc_config['subject'] ? $subject . $message : $message);
            $memeb =  getuserbyuid($pubinfo['uid']);

            $cid = C::t('#xigua_hb#xigua_hb_comment')->insert(array(
                'authorid' => $_G['uid'],
                'author'   => $_G['username'],
                'touid'    => $pubinfo['uid'],
                'touser'   => $memeb['username'],
                'comment'  => $message,
                'pubid'    => $pubinfo['id'],
                'pubuid'   => $pubinfo['uid'],
                'shid'     => 0,
                'star'     => 0,
                'imglist'  => serialize($imglist),
                'type'     => 0,
                'new'      => 0,
                'crts'     => TIMESTAMP,
            ), true);
        }

    }

    function deletethread($value)
    {

        global $_G;

        if (!$_G['cache']['plugin']) {
            loadcache('plugin');
        }
        $hb_config = $_G['cache']['plugin']['xigua_hb'];
        $hc_config = $_G['cache']['plugin']['xigua_hc'];
        if (!$hb_config) {
            return true;
        }

        if (!$hc_config['del']) {
            return false;
        }

        $dellist = array();
        $dellist = $value['param'][0];
        foreach ($dellist as $tid) {
            $data = DB::fetch_first("SELECT uid FROM " . DB::table('xigua_hb_pub') . " WHERE tid=" . intval($tid));
            if ($data) {
                DB::query("DELETE FROM " . DB::table('xigua_hb_pub') . " WHERE tid=" . intval($tid));
                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($data['uid'], 'pubs', -1);
            }
        }

    }

    function deletepost($value)
    {

        global $_G;

        if (!$_G['cache']['plugin']) {
            loadcache('plugin');
        }
        $hb_config = $_G['cache']['plugin']['xigua_hb'];
        $hc_config = $_G['cache']['plugin']['xigua_hc'];
        if (!$hb_config) {
            return true;
        }

        if (!$hc_config['del']) {
            return false;
        }

        $dellist = array();
        $dellist = $value['param'][0];
        foreach ($dellist as $pid) {
            $data = DB::fetch_first("SELECT uid FROM " . DB::table('xigua_hb_pub') . " WHERE pid=" . intval($pid));
            if ($data) {
                DB::query("DELETE FROM " . DB::table('xigua_hb_pub') . " WHERE pid=" . intval($pid));
                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($data['uid'], 'pubs', -1);
            }
        }
    }

    public function post2hb($tid, $pid, $fid, $hb_noti = 0)
    {
        global $_G;
        if (!$_G['cache']['plugin']) {
            loadcache('plugin');
        }
        $hb_config = $_G['cache']['plugin']['xigua_hb'];
        $hc_config = $_G['cache']['plugin']['xigua_hc'];
        global $_G;

        require_once libfile('function/attachment');
        loadforum($fid);
        $wher1 = $fid;

        $thread = DB::fetch_first("SELECT authorid,author,typeid,sortid FROM %t WHERE tid=%s", array('forum_thread', $tid));

        $uid = $thread['authorid'];
        $author = $thread['author'];
        $sortid = $thread['sortid'];
        $typeid = $thread['typeid'];

        if ($sortid) {
            $wher2 = $_G['forum']['threadsorts']['types'][$sortid];
        }
        if ($typeid) {
            $wher3 = $_G['forum']['threadtypes']['types'][$typeid];
        }
        if ($wher2 && $wher3) {
            $wher = "$wher1,$wher2,$wher3";
        } elseif ($wher2 && !$wher3) {
            $wher = "$wher1,$wher2";
        } elseif (!$wher2 && $wher3) {
            $wher = "$wher1,,$wher3";
        } else {
            $wher = $wher1;
        }
        $catinfo = DB::fetch_first("SELECT * FROM %t WHERE FIND_IN_SET(%d, fid)", array('xigua_hb_cat', $fid));
        if ($catinfo) {
            if ($hb_config['maxpub'] > 0) {
                $mycount = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_mycount_today();
                if ($mycount >= $hb_config['maxpub']) {
                    return false;
                }
            }

            $data = array();
            $data['tid'] = $tid;
            $data['pid'] = $pid;
            $data['fid'] = $fid;
            $hb_pub = DB::fetch_first("SELECT id FROM %t WHERE pid=%s", array('xigua_hb_pub', $pid));
            if($hb_pub){
                return false;
            }


            $hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($uid);
            if ($hbuser['pingbi']) {
                return false;
            }

            $imglist = array();
            foreach (C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'tid', $tid) as $attach) {
                $_G['setting']['attachurl'] = $attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
                if(!$_G['setting']['attachurl']){
                    $_G['setting']['attachurl'] = 'data/attachment';
                }
                if ($attach['isimage']) {
                    $imglist[] = (($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'forum/') . $attach['attachment'];
                }
            }

            $post = DB::fetch_first("SELECT subject,message,dateline FROM %t WHERE pid=%s", array('forum_post', $pid));
            $subject = $post['subject'];
            $message = $post['message'];
            $dateline = $post['dateline'];


            $typeoption = $_GET['typeoption'];

            if (strpos($message, '[/img]') !== FALSE) {
                preg_match_all("/\[img.*?\](.*?)\[\/img\]/i", $message, $matchsimg);
                if ($matchsimg[1]) {
                    $imglist = array_merge($imglist, $matchsimg[1]);
                }
            }
            for ($i = 0; $i < 10; $i++) {
                if ($typeoption['image' . $i]['url']) {
                    $imglist[] = $typeoption['image' . $i]['url'];
                }
            }
            $imglist = array_flip($imglist);
            $imglist = array_flip($imglist);

            $pattern = "/(\[attach(img)?\]|\[(img|url|media|audio|flash)(.*)\]).*?(\[\/attach(img)?\]|\[\/(img|url|media|audio|flash)\])/i";
            $message = preg_replace($pattern, '', $message);

            require_once libfile('function/discuzcode');

            $data['catid'] = $catinfo['id'];
            $data['imglist'] = serialize($imglist);
            $data['description'] = discuzcode($hc_config['subject'] ? $subject . $message : $message);
            $data['realname'] = $typeoption['realname'] ? $typeoption['realname'] : $author;
            $data['mobile'] = $typeoption['mobile'] ? $typeoption['mobile'] : '';
            $data['uid'] = $uid;

            if (!$catinfo['endtime']) {
                $data['endts'] = $dateline + 7776000;
            } else {
                $data['endts'] = $dateline + $catinfo['endtime'] * 86400;
            }

            unset($typeoption['mobile']);
            unset($typeoption['realname']);

            if ($typeoption) {

                $vars = C::t('#xigua_hb#xigua_hb_var')->fetch_all_by_pluginid($catinfo['id']);
                if (!$vars) {
                    $vars = C::t('#xigua_hb#xigua_hb_var')->fetch_all_by_pluginid($catinfo['pid']);
                }

                $typeoption = array();
                foreach ($_G['forum_optionlist'] as $index => $item) {
                    $typeoption[$item['title']] = $item['identifier'];
                }
                foreach ($typeoption as $index => $item) {
                    if ($sindex = array_search($item['title'], $typeoption)) {
                        $typeoption[$sindex] = is_array($item['value']) ? implode(' ', $item['value']) : $item['value'];
                    }
                }

                $formvars = array();
                foreach ($vars as $index => $vvar) {
                    $optionid = $typeoption[$vvar['title']];
                    $value = $typeoption[$optionid];
                    $html = '';
                    foreach (explode("\n", trim($vvar['extra'])) as $str => $extra_string) {
                        list($_tmp1, $_tmp2) = explode('=', trim($extra_string));
                        $_tmp2 = trim($_tmp2);
                        if ($_tmp1 == $value || trim($_tmp1) == $value) {
                            $html = $_tmp2;
                            break;
                        } elseif (in_array($_tmp1, $value) || in_array(trim($_tmp1), $value)) {
                            $html .= ' ' . $_tmp2;
                        }
                    }
                    $formvars[$index] = array(
                        'title' => $vvar['title'],
                        'value' => $value,
                        'html' => ($html ? $html : (is_array($value) ? $value[0] : $value)) . $vvar['unitnew'],
                    );
                    if ($vvar['type'] == 'area') {
                        list($tmp1, $tmp2, $tmp3) = explode(' ', $value);
                        $data['dist1'] = trim($tmp1);
                        $data['dist2'] = trim($tmp2);
                        $data['dist3'] = trim($tmp3);
                    }
                }
            }
            $data['vars'] = serialize($formvars);

            $data['cr_time'] = $data['up_time'] = dgmdate($dateline, 'Y-m-d H:i:s');

            $rpid = $hb_pub['id'];
            if (!$rpid) {
                $rpid = C::t('#xigua_hb#xigua_hb_pub')->insert($data, true);
            }

            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($uid, 'pubs', 1);
            $_u = C::t('#xigua_hb#xigua_hb_user')->fetch($uid);
            if (!$_u['mobile'] && $typeoption['mobile']) {
                C::t('#xigua_hb#xigua_hb_user')->update($uid, array('mobile' => $data['mobile']));
            }

            if ($hb_config['freedis']) {
                $data = array('order_id' => -1, 'pay_status' => 1);
                if ($hb_noti) $this->hb_noti($rpid, 'notice_shen');
            } else {
                $data = array('order_id' => -1, 'pay_status' => 1, 'display' => 1);
                if ($hb_noti) $this->hb_noti($rpid, 'notice_pub', $catinfo['name']);
            }
            C::t('#xigua_hb#xigua_hb_pub')->update($rpid, $data);
        }
        return true;
    }

    function hb_noti($pubid, $lang, $catname = '', $ourl = '')
    {
        global $_G;
        $adminids = array();
        $hb_config = $_G['cache']['plugin']['xigua_hb'];
        $SCRITPTNAME = $hb_config['scriptname'] ? $hb_config['scriptname'] : 'plugin.php';
        if ($hb_config['adminids']) {
            $__ds = dintval(explode(',', str_replace(';', ',', trim($hb_config['adminids']))), true);
            $adminids = array_filter($__ds);
        }
        if ($adminids) {
            $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$pubid";
            if ($lang == 'notice_shen') {
                $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_hb&ac=manage&stat=display&display=0";
            }
            $adminids = array_slice($adminids, 0, 10);
            foreach ($adminids as $adminid) {
                notification_add($adminid, 'system', lang('plugin/xigua_hb', $lang), array('id' => $pubid, 'url' => ($ourl ? $ourl : $url), 'cat' => $catname, 'username' => $_G['username']), 1);
            }
        }
    }
}

class plugin_xigua_hc_forum extends plugin_xigua_hc
{
}

class mobileplugin_xigua_hc extends plugin_xigua_hc_forum
{

}

class mobileplugin_xigua_hc_forum extends plugin_xigua_hc_forum
{

}