<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1      From: DisM.taobao.Com
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
dheader('Location: https://dism.taobao.com/category-1476983555.htm');