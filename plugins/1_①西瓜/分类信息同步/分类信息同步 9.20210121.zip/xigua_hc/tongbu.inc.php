<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/9/30
 * Time: 9:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;
if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}
$hb_config = $_G['cache']['plugin']['xigua_hb'];
$hc_config = $_G['cache']['plugin']['xigua_hc'];

$LANGS = array();
foreach (explode("\n", trim($hc_config['yyb'])) as $index => $item) {
    list($key, $val) = explode('=', trim($item));
    $LANGS[$key] = $val;
}
if($_GET['day']>0 && $_GET['formhash']==FORMHASH){
	$day = intval($_GET['day']);
	$page = intval($_GET['page']);
	tongbu($page,$day);
}



showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hc&pmod=tongbu");
showtableheader();

showsetting($LANGS['lang1'], 'day', 1, 'number','','',$LANGS['lang2']);


showsubmit('dosubmit');
showtablefooter();/*dism _ taobao _ com*/
showformfooter();/*dism - taobao - com*/


function tongbu($page,$day=1){
    global $pluginid, $LANGS;
	$fids = array();
	$query = DB::query("SELECT fid FROM ".DB::table('xigua_hb_cat')." ");
	while($data=DB::fetch($query)){
		if($data['fid']){
			$fid = explode(',',$data['fid'],2);
			$fids[]= $fid[0];
		}
	}
	$fids = array_unique($fids);
//	$fids = implode(",",$fids);

	$count = DB::fetch_first("SELECT count(*) as num FROM %t WHERE dateline>%d AND first=1 AND invisible=0 AND fid in (%n) ", array('forum_post', TIMESTAMP-86400*$day, $fids));
	
	$count = $count['num'];

	$pagesize= 100;
	$pagemax = ceil($count/$pagesize);
	if($page<=0) {
	    $page=1;
    }
	
	if($page>$pagemax){
        cpmsg($LANGS['lang3'], '','succeed');
		
	}else{

		$pagebegin = ($page-1)*$pagesize;
		
		$sql = "SELECT tid,pid,fid FROM %t WHERE  dateline>%d AND first=1 AND invisible=0 AND fid in (%n) ORDER BY dateline ASC LIMIT $pagebegin,$pagesize";
		
		$query = DB::query($sql, array('forum_post', TIMESTAMP-86400*$day, $fids));
		
		require_once(DISCUZ_ROOT."source/plugin/xigua_hc/lib/hook.class.php");
		$xigua_hc = new plugin_xigua_hc();
		
		while($data=DB::fetch($query)){
			
			$xigua_hc->post2hb($data['tid'],$data['pid'],$data['fid'],0);
			
			
		}
		
		$oldpage = $page;
		
		$page++;

        $nextlink = "action=plugins&operation=config&do=$pluginid&identifier=xigua_hc&pmod=tongbu&&day=$day&page=$page&formhash=".FORMHASH;
        cpmsg(sprintf($LANGS['lang4'], $oldpage, $page), $nextlink, 'loading');
		
	}

}
