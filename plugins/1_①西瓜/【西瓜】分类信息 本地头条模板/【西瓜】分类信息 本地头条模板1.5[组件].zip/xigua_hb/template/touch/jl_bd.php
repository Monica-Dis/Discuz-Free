<?php exit('From: DisM.taobao.Com ���²����http://t.cn/Aiux1Jx1'); ?>
<!--{if $_GET['is_my'] || $_GET['is_admin']}-->
<!--{template xigua_hb:mypub_item}-->
<!--{else}-->
<!--{loop $list $k $v}-->
<!--{eval
$subtit = '';
$subtit = cutstr(str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))), 80);
foreach($v[vars] as $___k => $___v):
  if($___v[autoin] && $___v[html]):
    $subtit = $___v[html];
    break;
  endif;
endforeach;
$showideo = $v['video_cover'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php');
$cntimg = count($v[img_preview]);
if(!$showideo):
if($cntimg<3 && strpos($v[description], '<img')!==false):
    preg_match_all('/img\s+src\=\"([^\"]*?)\"/is', $v[description], $tmpimg);
    $v[img_count] = count($tmpimg[1]);
    if($tmpimg[1]):
        $v[img_preview] = array_slice(array_merge($v[img_preview], $tmpimg[1]), 0, 3);
    endif;
    $cntimg = count($v[img_preview]);
endif;
else:
    if(!$cntimg):
        $cntimg = 1;
        $v[img_preview] = array( $v['video_cover']);
    endif;
endif;
$v[img_preview] = array_slice($v[img_preview], 0, 3);
}-->
<div class="bd_row <!--{if $cntimg>=3}-->bd_row_block<!--{/if}-->" >
    <div class="bd_right">
        <h3 class="view_jump <!--{if $cntimg && $cntimg<3}-->bd_h24<!--{/if}-->" data-id="$v[id]" data-stid="$v[stid]"><!--{if $v[dig_on]}--><em class="mod-lv is-star">{lang xigua_hb:zhiding}</em><!--{/if}--><!--{if $v[hb_num]}--><em class="mod-lv is-hot">{lang xigua_hb:hb}</em><!--{/if}-->{$subtit}</h3>
        <!--{if $cntimg<3}-->
        <div class="bd_box">
            <a class="bd_cat_link" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$v[catid]">{$cats[$v[catid]][name]}</a>
            <a href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]">{$users[$v[uid]][username]}</a>
            <span><em>$v[views]</em>{lang xigua_hb:ll}</span>
        </div>
        <!--{/if}-->
    </div>
    <!--{if $cntimg && $cntimg<3}-->
    <div class="bd_left view_jump" data-id="$v[id]" data-stid="$v[stid]">
        <img class="bd_abs_img" src="<!--{if $v[img_preview][0]}-->$v[img_preview][0]<!--{elseif $showideo}-->$v[video_cover]<!--{/if}-->" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
        <!--{if $showideo}-->
        <div class="bd_video_play"></div>
        <!--{/if}-->
    </div>
    <!--{elseif $cntimg>=3}-->
    <div class="bd_photos">
        <!--{eval $img_preview_cnt = $cntimg-1;}-->
        <!--{loop $v[img_preview] $k $img}-->
        <div <!--{if $config[picin]}-->class="imgloading view_jump" data-id="$v[id]" data-stid="$v[stid]"<!--{else}-->class="imgloading"<!--{/if}-->>
            <img src="$img">
            <!--{if $k==$img_preview_cnt && $v[img_count]>3}--><span class="bd_num">$v[img_count]{lang xigua_hb:zhang}</span><!--{/if}-->
        </div>
        <!--{/loop}-->
    </div>
    <div class="bd_box">
        <a class="bd_cat_link" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$v[catid]">{$cats[$v[catid]][name]}</a>
        <a href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]">{$users[$v[uid]][username]}</a>
        <span><em>$v[views]</em>{lang xigua_hb:ll}</span>
    </div>
    <!--{/if}-->
</div>
<!--{/loop}-->
<!--{/if}-->