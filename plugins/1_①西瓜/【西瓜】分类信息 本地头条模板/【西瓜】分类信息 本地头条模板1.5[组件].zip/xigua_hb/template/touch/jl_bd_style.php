<?php exit('From: DisM.taobao.Com ���²����http://t.cn/Aiux1Jx1'); ?>
<style>.bd_row:after{content:" ";position:absolute;left:.75rem;bottom:0;width:calc(100% - 1.5rem);height:1px;border-bottom:1px solid #e5e5e5;color:#e5e5e5;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleY(.5);transform:scaleY(.5)}
.bd_row:last-child:after{display:none}
.bd_row{position:relative;padding:.75rem;display:-webkit-box;-webkit-box-pack:start;-webkit-justify-content:flex-start;-ms-flex-pack:start;justify-content:flex-start;overflow:hidden;background:#fff}
.bd_row.bd_row_block,.bd_row.bd_row_block .bd_right{display:block}
.bd_left{position:relative;width:calc(33.333333% - .2rem);min-width:5rem;border-radius:.2rem}
.bd_right{padding-right:.6rem;position:relative;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-flex:1;-webkit-flex:1;-ms-flex:1;flex:1}
.bd_left:before{content:'';display:block;height:0;padding-top:75%;overflow:hidden}
.bd_video_play{position:absolute;right:1.5rem;bottom:1rem;width:2rem;height:2rem;background:url(source/plugin/xigua_hb/static/img/vp.png) no-repeat;background-size:100%}
.bd_abs_img{position:absolute;top:0;left:0;width:100%;height:100%;border-radius:.2rem;z-index:0}
.bd_box{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:end;-webkit-align-items:flex-end;-ms-flex-align:end;align-items:flex-end;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;height:1rem;line-height:1rem;overflow:hidden;font-size:.65rem;margin-top:.6rem;position:relative}
.bd_box span{position:absolute;right:0}
.bd_box a:first-child{margin-left:0}
.bd_box a,.bd_box span{margin-left:.3rem;color:#999}
.bd_box a.bd_cat_link{color:#597bae}
.bd_right h3{display:-webkit-box;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;-webkit-box-orient:vertical;-webkit-box-align:start;-webkit-line-clamp:2;font-size:.85rem;color:#333;letter-spacing:0;line-height:1.2rem;overflow:hidden;width:100%}
.bd_photos>div{width:calc(33.333333% - .2rem);float:left;overflow:hidden;height:100%;margin-right:.3rem}
.bd_photos>div:last-child{margin-right:0}
.bd_photos>div img{width:100%;height:100%;display:block}
.bd_photos{position:relative;width:100%;height:4.5rem}
.bd_row.bd_row_block .bd_right{padding-right:0}
.bd_row.bd_row_block .bd_box,.bd_row.bd_row_block .bd_photos{margin-top:.5rem}
.bd_h24{height:2.4rem!important}
.bd_num{position:absolute;right:0;bottom:0;background:rgba(0,0,0,.5);color:#fff;padding:0 .5rem;font-size:.6rem;line-height:1rem}
</style>