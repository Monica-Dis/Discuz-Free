<?php exit('From: DisM.taobao.Com ���²����http://t.cn/Aiux1Jx1'); ?>
<style>.jzp{position:relative;background-color:#fff;max-height:49.95rem;overflow:hidden;margin:.5rem;border-radius:.4rem}
.jzp .item-shenqing-style{position:absolute;right:0;height:100%;width:3.75rem;z-index:100}
.jzp .item-shenqing-style .shenqing-btn{font-size:.65rem;position:absolute;top:2.75rem;right:.75rem;color:#fff;width:2.4rem;height:1.35rem;line-height:1.35rem;text-align:center;background-color:#e9613f;border-radius:.25rem}
.jzp .item-type{font-size:.6rem;position:absolute;top:.8rem;color:#666;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:right;right:.75rem}
.jzp .item-content{display:block;padding:.75rem}
.jzp .item-content-up{width:100%}
.jzp .item-title{overflow:hidden;-webkit-text-overflow:ellipsis;-ms-text-overflow:ellipsis;text-overflow:ellipsis;white-space:nowrap;font-size:.75rem;line-height:.9rem;color:#000;font-weight:700;margin-bottom:.5rem}
.jzp .item-title strong{font-weight:400}
.jzp .item-desc{line-height:.9rem;margin-bottom:.35rem}
.jzp .item-desc .item-salary{font-size:.75rem;color:#e9613f}
.jzp .item-desc .item-unit{font-size:.6rem;color:#e9613f}
.jzp .item-welfare{overflow:hidden;-webkit-text-overflow:ellipsis;-ms-text-overflow:ellipsis;text-overflow:ellipsis;white-space:nowrap;font-size:.55rem;height:1.1rem;line-height:.75rem;margin-bottom:.3rem;padding-right:2.75rem}
.jzp .item-welfare .tag{display:inline-block;padding:0 .05rem;border:.05rem solid;-webkit-border-radius:.1rem;-moz-border-radius:.1rem;border-radius:.1rem}
.jzp .item_tags{padding-right:2.5rem}
.jzp .item-content-down{display:-webkit-box;display:-webkit-flex;display:flex;color:#666;margin-top:.4rem}
.jzp .item-content-down .content-down{font-size:.6rem;height:1.2rem;line-height:1.2rem}
.jzp .item-content-down .item-company{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:7;max-width:69%;position:relative;padding-left:1.5rem}
.jzp .item-content-down .item-company span{color:#333;font-weight:400}
.jzp .item-content-down .item-addr{overflow:hidden;-webkit-text-overflow:ellipsis;-ms-text-overflow:ellipsis;text-overflow:ellipsis;white-space:nowrap;flex:3;text-align:right}
.jzp .content-avatr{width:1.2rem;height:1.2rem;display:inline-block;background-size:100% 100%;border-radius:5rem;overflow:hidden;position:absolute;top:0;left:0}
.jzp .b-color13{color:#666}
.jzp .b-color13:after{border-color:#dcdcd6}
.jzp .item-desc .item-cate{color:#888}
.jzp .tagic{font-size:.6rem;color:#666;padding-left:.3rem;position:relative;margin-left:.2rem}
.jzp .tagic:before{content:'';position:absolute;top:.25rem;left:0;right:0;background-color:#ccc;height:.1rem;width:.1rem;border-radius:.5rem}</style>

